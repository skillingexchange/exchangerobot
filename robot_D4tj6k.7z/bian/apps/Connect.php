<?php

namespace apps;

use Workerman\Connection\AsyncTcpConnection;

class Connect extends AsyncTcpConnection
{
    public $ws_name   = '';
    public $reconnect = true;

    public function __construct($remote_address, $ws_name = '', $context_option = [])
    {
        parent::__construct($remote_address);
        $this->transport = 'ssl';
        $this->ws_name = $ws_name;
        $this->onClose = function ($connection) {
            logs($this->ws_name . 'close');
            if ($this->reconnect) {
                $this->reconnect(1);
            }
        };
        $this->onError = function ($connection, $err_code, $err_msg) {
            logs($this->ws_name . $err_code, $this->ws_name . $err_msg);
        };
    }
}