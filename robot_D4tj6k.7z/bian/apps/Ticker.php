<?php

namespace apps;


class Ticker
{
    public static function symbol()
    {
        global $db;
        $data = $db->from('jl_ticker')
            ->select('lower(replace(market,\'/\',\'\')) as symbol')
            ->where('exchange_class = \'binance\'')
            ->query();
        $data = array_column($data, 'symbol');
        foreach ($data as $k => $v) {
//            if (!preg_match('/^[a-z]+$/', $v)) {
//                unset($data[$k]);
//            }
        }
        $data = array_values($data);
        return $data;
    }

    public static function setData($ch, $tick)
    {
//         global $db, $redis;
//         $redis->get('kline_binance_' . $ch, function ($result, $redis) use ($ch, $tick, $db) {
            
//             if ($result) {
//                 $result = json_decode($result, true);
//                 if ( $result['c'] != $tick['c'] || $result['o'] != $tick['o']) {
//                     $result = null;
//                 }
//             }
//             if (!$result) {
                
//                 $redis->set('kline_binance_' . $ch, json_encode($tick));
//                 //	(本阶段收盘价-本阶段开盘价*100)/本阶段开盘价= 涨幅
//                 //(整整24小时前，向后数的第一次成交价格-最新成交价格*100)/最新成交价格= 涨幅
//                 $change = (($tick['c']-$tick['o'])*100)/$tick['o'];
//                 $change = bcadd($change,0,8);
// //                $change = bcsub($tick['close'], $tick['open'], 8);
// //                $change = bcdiv($change * 100, $tick['open'], 8);
                
//                 $data = [
//                     'price'       => $tick['c'],
//                     'change'      => $change,
//                     'update_time' => time(),
//                 ];
//                 $redis->set('price_binance_'.$ch,$tick['c']);
                
// 				//jl_ticker表的数据缓存   读取数据优先读取redis里面的数据
//                 $result = $redis->hMSet('ticker_price_binance_'.$ch,[
//                 	'price'       => $tick['c'],
//                     'change'      => $change,
//                     'update_time' => time(),
//                 	'where'=>'exchange_class = \'binance\' and lower(replace(market,\'/\',\'\')) = \'' . $ch . '\'',
//                 ]);
//                 $redis->set('redis_titcker_binance_prices',time());
// //				$redis->hMSet("redis_titcker_price",['last_time'=>time()]);
				
// //				Timer::add(12, function()
// //			    {
// //			    	
// //			    },[],false);
// //              $db->update('jl_ticker')
// //                  ->cols([
// //                      'price'       => $tick['close'],
// //                      'change'      => $change,
// //                      'update_time' => time(),
// //                  ])
// //                  ->where('exchange_class = \'huobipro\' and lower(replace(market,\'/\',\'\')) = \'' . $ch . '\'')
// //                  ->query();
//             }
//         });
    }
    
    public static function setSWAPData($ch, $tick)
    {
    	//last最新成交价/本阶段收盘价
//  	open_24h  本阶段开盘价/24小时开盘价
        global $db, $redis;
        $redis->get('kline_okex_' . $ch, function ($result, $redis) use ($ch, $tick, $db) {
//      	var_dump($result);
            if ($result) {
                $result = json_decode($result, true);
                // if ( $result['c'] != $tick['c'] || $result['o'] != $tick['o']) {
                //     $result = null;
                // }
            }
            $result=null;
            if (!$result) {
                // var_dump($ch);
                $redis->set('kline_binance_' . $ch.'swap', json_encode($tick));
                
                
                $redis->set('price_binance_'. $ch.'swap',$tick['p']);
                $result = $redis->hMSet('ticker_price_binance_'. $ch.'swap',[
                	'price'       => $tick['p'],
                    'change'      => '1',
                    'update_time' => time(),
                ]);
            }
        });
    }
    
    
    public static function setDataKLine($ch, $tick)
    {
        global $db, $redis,$sync_redis;
//      日期有几种格式 5m,30m,1h,4h,12h,1d
//		分别代表5分钟，30分钟，1小时，4小时，12小时，1天
        $k = $tick['k'];
//      直接往redis里面存入数据
//		时间
		$time = $k['t'];
//		收盘价
		$close = $k['c'];
//		名称
		$string = $ch."_kline_binance";
		$sync_redis->hset($string,$time,$close);
		
		$length = $sync_redis->hLen($string);
		$number = 365;
		if($length > $number){
			# 删除前面的
		    $data = $sync_redis->hKeys($string);
		    $vi = 0;
		    # 需要删除多少个
		    $lens = $length - $number;
		    foreach($data as $k=>$v){
		    	if($vi < $lens){
		            $sync_redis->hdel($string, $v);
		        }else{
		            break;
		        }
		        $vi ++;
		    }   
		}
    }
}
