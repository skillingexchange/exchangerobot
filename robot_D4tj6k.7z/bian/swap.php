<?php

require_once __DIR__ . '/vendor/autoload.php';

use apps\Kline;
use apps\Order;
use Workerman\Worker;

Worker::$logFile = __DIR__ . '/log/workerman.log';

$kline = new Worker();
$kline->onWorkerStart = [Kline::class, 'onWorkerStart'];
$kline->onConnect = [Kline::class, 'onConnect'];
$kline->onMessage = [Kline::class, 'onMessage'];
$kline->onClose = [Kline::class, 'onClose'];
$kline->onWorkerStop = [Kline::class, 'onWorkerStop'];


Worker::runAll();