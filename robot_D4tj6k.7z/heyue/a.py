
import redisbase
import numpy as np
import pandas as pd
import random
from decimal import Decimal, ROUND_DOWN
import logger
import ccxt
import time
import json


def get():
    symbol = 'ETH-USDT-SWAP'
    longs = 'long'
    exchange_id ='okex'
    api_key = '81a29ec8-4c7d-431b-a052-1312c08d8284'
    secret_key = 'F717D7CFB6D565DFD2819C7FB9513B72'
    passphrase = 'Xm321321$'
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        'apiKey': api_key,
        'secret': secret_key,
        'password': passphrase,
        'timeout': 30000,
        'enableRateLimit': True,
        'options': {
            'createMarketBuyOrderRequiresPrice': False,
        },
    })
    if exchange_id == 'binance':
        # info =exchange.fapiPrivate_get_positionrisk({'symbol': symbol})
        # for ite in info:
        #     if ite['marginType'] == 'cross' and ite['positionSide']==longs:
        #         info = ite
        #         info['expire'] =time.time()*1000
        # qing = redis_content.hset('account_qiang' + api_info['platform'] + '_'+str(uid),symbol+str(longs)+str(uid),json.dumps(info))
        return {}
    else:
        # {'symbol': symbol,'instType':"SWAP"}
        info =exchange.private_get_account_positions({'instId': symbol,'instType':"SWAP"})['data']
        print(info)
        for ite in info:
            if ite['mgnMode'] == 'cross' and ite['posSide']==longs:
                if not ite is None and ite['availPos'] != '':
                    infos = {
                        'deal_money': ite['notionalUsd'],
                        'executedQty': ite['availPos'],
                        'avgPx': ite['avgPx'],
                        'imr': ite['imr'],
                        'strong_pay': ite['liqPx'],
                        'margin_lilv': float(ite['mgnRatio'])*100,
                        'margin_price': ite['imr'],
                    }
                    infos['expire'] =time.time()*1000
                else:
                    infos = {}
        # qing = redis_content.hset('account_qiang' + api_info['platform'] + '_'+str(uid),symbol+str(longs)+str(uid),json.dumps(infos))
        print(infos)
        return infos
     
     
get()