
def getapilist():
    data =[
        #'http://43.155.79.118:6379',
        # 'http://127.0.0.1:6379'
    ]
    return data
