import aiohttp
import asyncio
import threading
import log
from decimal import Decimal, ROUND_DOWN
import math
import time
import json
import uuid
import ccxt.async_support as ccxt
import ccxt as ccxt_all
import common
from database import MySqLHelper
import redisbase
import logger
import random
import requests
import api
import bianheyue as heyue
import nest_asyncio
import inspect
nest_asyncio.apply()
global list_times,last_time,list_timest,last_timet,iplist
iplist={}
list_times = 0
list_timest= 0
last_timet=int(time.time()*1000)
last_time = int(time.time()*1000)



redis_content = redisbase.getrids(15)



def getlisttimes():
    global list_times,last_time,iplist
    iplist=api.getapilist()
    if iplist == False:
        return False
    now = int(time.time()*1000)
    if now-last_time<=500:
        list_times += 1
    if list_times> (len(iplist)-1):
        list_times = 0
    last_time = now
    print('使用线路'+iplist[list_times])

def set_lever(direction,symbol, api_info,type_all,lever,platfrom='binance'):
    ret = {}
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        iplist=api.getapilist()
        exchange_class = getattr(ccxt_all, exchange_id)
        if int(type_all) == 0:
            global list_timest, last_timet
            now = int(time.time() * 1000)
            if now - last_timet <= 500:
                time.sleep(float((500 - (now - last_timet)) / 1000))
            last_timet = now
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        else:
            resul = getlisttimes()
            if resul == False:
                return False
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'aiohttp_proxy': iplist[0],
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        if exchange_id == 'binance':
            result = {
                'symbol': symbol.upper(),  # 产品ID
                'leverage': lever,  # 数量
            }
            re=exchange.fapiPrivate_post_leverage(result)
            return True
        else:
            direction = 'LONG' if direction == 1 else 'SHORT'
            result = {
                'instId': symbol.upper()+'SWAP',  # 产品ID
                'mgnMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                # 'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'lever': lever,  # 数量
            }
            re=exchange.private_post_account_set_leverage(result)
            return True
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    return ret


# 主函数
def strategy(robot, market_info, api_info,type_all):
    # 交易所
    platform_source = robot['platform']
    platform = platform_source+'_contract'
    # 交易对 如：BTCUSDT     注意这里的交易对是不需要加/的
    if platform_source == 'binance':
        market = market_info['stock'] + market_info['money']
    else:
        market = market_info['stock'] + "-" + market_info['money'] + "-" + str(market_info['instType'])
    # 机器人id# 用户id
    robot_id = int(robot['id'])
    uid = int(robot['uid'])
    
    # 机器人状态
    loops = asyncio.get_event_loop()
    # 获取交易对的实时价格
    tick_price_str = common.ContractGetTick(api_info, market, platform_source)
    tick_price = None
    if tick_price_str:
        tick_price = float(tick_price_str)
    if tick_price is None:
        log.get_logger(robot['id']).error('获取交易对' + market + "实时价格失败")
        return
    if robot['cover_info'] and not robot['cover_info'] is None and robot['cover_info'] != 'None':
        cover_info = json.loads(robot['cover_info'])
    else:
        cover_info = {}
    # 清仓策略
    if robot['cover_grid'] and not robot['cover_grid'] is None and robot['cover_grid'] != 'None' and robot['cover_grid'] != '':
        cover_grid = json.loads(robot['cover_grid'])
        nu = 5
        i = 0
        ke = []
        while i < len(cover_grid):
            ke.append(nu)
            i += 1
            nu += 1
        cover_grid = dict(zip(ke, cover_grid))
    else:
        cover_grid = None
    # 网格止盈回调
    if robot['cover_grid_back'] and not robot['cover_grid_back'] is None and robot['cover_grid_back'] != 'None' and robot['cover_grid_back'] != '':
        cover_grid_back = int(float(robot['cover_grid_back']))
    else:
        cover_grid_back = None
    # 合约全仓止盈价格回调
    stop_profit_callback_rate = float(robot['stop_profit_callback_rate'])
    # 合约参数设置
    values_str = robot['values_str']
    # 策略设置判断是否为循环策略还是单次策略
    recycle_status = int(robot['recycle_status'])
    minQtys=  common.minQtys(market,platform_source)
    # 策略配置 # 交易对最大精度 # 交易对最小精度
    maxQty = 0 if 'maxQty' not in minQtys.keys() else minQtys['maxQty']
    minQty = 0 if 'minQty' not in minQtys.keys() else minQtys['minQty']
    
    minQty = float(minQty)
    common.set_listenkey(api_info,uid,platform_source)
    # 首单是否加倍
    is_double = int(float(robot['is_double']))
    # 做空还是做多   1.多 0.空 2多空
    direction = int(float(robot['is_trend']))
    # 盈利率 如0.5% 合约全仓止盈比例
    profit = float(robot['stop_profit_rate'])
    # 止损率 如50%(损失达到了这么多就是自动卖出，最好止损率要大于止盈率，不然 永远只会止损不会止盈)
    stop_loss = float(robot['cover_callback_rate'])
    # 单个投入(单笔下单金额)(USDT) # 杠杆
    first_order_money = float(robot['first_order_value'])
    lever = cover_grid_back
    cover_rate = float(robot['cover_rate'])
    # 风险控制 0.不开 1.开启# 最小买入金额# 最大买入金额
    risk_management = int(float(robot['open_risk']))
    
    min_price = float(Decimal(str(robot['low_buy'])))
    max_price = float(Decimal(str(robot['top_buy'])))
    # 最大仓数
    max_house_number = int(robot['max_order_count'])
    # 是否循环启动 1.循环 2.单次
    if int(robot['recycle_status']) == 1:
        is_loop =1
    else:
        is_loop =2
    # 是否清仓
    is_clean = int(robot['is_clean'])
    # 总共循环多少次
    loop_times = int(robot['round_num'])
    # 当前循环第几次
    now_loop = int(robot['now_round_num'])
    if robot['amount_value_short'] is None:
        robot['amount_value_short']  = 0
    if robot['is_bucang_short'] is None:
        robot['is_bucang_short']  = 0
    if robot['amount_value_long'] is None:
        robot['amount_value_long']  = 0
    if robot['is_bucang_long'] is None:
        robot['is_bucang_long']  = 0
    if robot['synchro'] is None:
        redisbase.updaterobot(redis_content, robot_id, uid, 'synchro', 0)
    if common.autoSynchro(uid,platform_source,market,direction) == True:
        robot['synchro'] = 1    
    # if robot_id != 77:
    #     return
    if values_str:
        values_str = json.loads(values_str)
        # 获取强平价格
        # 判断机器人是否需要同步一次数据，如果需要，则需要进入到当前流程中
        if 'synchro' in robot.keys() and  not robot['synchro'] is None and int(robot['synchro']) == 1:
            redisbase.updaterobot(redis_content, robot_id, uid, 'synchro', 0)
            values_data = values_str
            result_data = common.getSynchro(api_info,uid,platform_source,market,direction)
            if direction == 1:
                values_data['deal_amount'] = float(result_data['positionAmt'])
            else:
                values_data['deal_amount'] = 0-float(result_data['positionAmt'])
            values_data['base_price'] = float(result_data['entryPrice'])
            values_data['last_price'] = values_data['base_price'] 
            values_data['executedQty'] = values_data['deal_amount'] 
            values_data['strong_pay'] = result_data['liquidationPrice']
            values_data['deal_money'] = values_data['deal_amount'] *  values_data['base_price']
            redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', json.dumps(values_data))
            return
        if not 'clean_short' in robot.keys() and not robot['clean_short'] is None:
            clean_short = int(robot['clean_short'])
        else:
            clean_short =0
        if not 'clean_long' in robot.keys() and not robot['clean_long'] is None:
            clean_long = int(robot['clean_long'])
        else:
            clean_long =0
        # 做单方向
        if values_str['position']=='long' or values_str['position']=='LONG':
            direction = 1
        else:
            direction = 0
        # 补仓跌幅和倍数参数
        qiang = common.getQiang(api_info,uid,platform_source,market,direction)
        cover_rates = robot['cover_rates']
        if cover_rates:
            cover_rates_list = json.loads(cover_rates)
            if  isinstance(cover_rates_list, list):
                order_count = values_str.get('order_count', 1)
                if (len(cover_rates_list) - 1) >= order_count:
                    cover_rate = cover_rates_list[order_count]

        if type(cover_rate) == int:
            cover_rate = {}
            cover_rate['multiple'] = (order_count+1)*2
        symbol = values_str['symbol']
        
        # 总投入
        deal_money = float(values_str['deal_money'])
        # 总购买了多少币
        deal_amount = float(values_str['deal_amount'])
        # 首单的订单号
        order_id = values_str['order_id']
        # 上次购买单价
        trend_side = int(values_str['trend_side'])
        last_price = float(values_str['last_price'])
        base_price = float(values_str['base_price'])
        if values_str['margin_price'] is None or values_str['margin_price']=='':
            margin_price = 1
        else:
            margin_price = float(values_str['margin_price'])
        up_price = float(values_str['up_price'])
        # 持仓数量
        executedQty = float(values_str['executedQty'])
        # 当前仓数
        house_number = int(values_str['order_count'])
        ensure_value = common.orderMian(api_info,symbol)
        for ensure_value_item in ensure_value:
            if int(ensure_value_item['notionalFloor']) < int(float(deal_amount)*tick_price) < int(ensure_value_item['notionalCap']):
                ensure_value = ensure_value_item
        ensuer_account = common.user_account(api_info,uid,'binance')
        for ensuer_account_item in ensuer_account:
            if str(ensuer_account_item['asset']) =='USDT':
                ensuer_account = ensuer_account_item
        # 求出保证金率
        margin_lilv =common.order_take(ensuer_account,deal_amount,tick_price,ensure_value,platform_source)
        margin_price = common.margin_ratio(deal_amount,tick_price,lever,platform_source)
         # 重交易所获取收益和手续费
        if base_price !=0:
            if direction !=1:
                values_str['revenue'] =(base_price-tick_price) *  deal_amount
            else:
                values_str['revenue'] = (tick_price - base_price) *  deal_amount
            # 收益  (尚未扣除手续费)
        else:
            values_str['revenue']=0
        values_str['margin_lilv'] = margin_lilv
        values_str['margin_price'] = margin_price
        values_str['strong_pay'] = qiang['liquidationPrice']
        redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', json.dumps(values_str))
        common.set_lever(direction,market,api_info,type_all,lever,platform_source)
        # 收益计算
        # 清仓处理卖出所有的合约张数，
        if int(is_clean) == 1:
            loops.run_until_complete(clean_order_sell(base_price, direction, deal_amount, 2, api_info,market_info, market, robot_id, uid, lever,house_number,1 ,0, platform_source,type_all))
            cleanFinish(robot_id, uid)
            return
        # 止损,判断全仓是否到达止损，达到止损后就开始卖出 获取全仓止损率
        rate = float(float(float(tick_price) - float(base_price)) / float(base_price)) * 100
        if direction != 1:
            # 开空   需要将负数转为正数   正数转为负数  因为开空的情况和开多的情况是相反的
            rate = rate * -1
        # 判断仓位是否到达止盈和止损
        if direction==1:
            tick_ba=float(tick_price) > float(base_price)
            price_allback = tick_price > up_price
        else:
            tick_ba=float(base_price) > float(tick_price)
            price_allback = tick_price < up_price
        if tick_ba:
            # 机器人达到止盈后判断是否到达止盈回调 并判断是否开始止盈
            if trend_side == 0 or trend_side == 2:
                if float(rate) >= float(profit):
                    values_str['up_price'] = tick_price
                    values_str['trend_side'] =1
                    updateValues(robot_id,uid,json.dumps(values_str))
                    insertLog(platform_source, robot_id, uid, u"达到止盈率 ,当前价格 %s" %(str(Decimal(str(tick_price)))))
                    updateMsg(robot_id, uid, u"达到止盈率 ,当前价格 %s" %(str(Decimal(str(tick_price)))))
            if trend_side == 1:
                if price_allback:
                    values_str['up_price'] = tick_price
                    # 达到止盈后继续上涨
                    updateValues(robot_id, uid, json.dumps(values_str))
                    insertLog(platform_source, robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %(str(Decimal(str(tick_price)))))
                    updateMsg(robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %(str(Decimal(str(tick_price)))))
                else:
                    down_num = abs(up_price - tick_price)
                    down_rate = down_num * 100 / up_price
                    if down_rate >= stop_profit_callback_rate:
                        # 改变全仓为开始卖出状态
                        insertLog(platform_source, robot_id, uid,u"循环次数:" + str(now_loop) + ",止盈回调率:" + str(stop_profit_callback_rate) + "%,当前:" + str(round(down_rate,2)) + "%")
                        values_str['trend_side'] = 0
                        updateValues(robot_id,uid,json.dumps(values_str))
                        order_profit(base_price, direction, executedQty, 2, api_info, market,market_info,  robot_id, uid,lever ,house_number, 2, now_loop,platform_source)

        else:
            if float(abs(rate)) >= stop_loss:
                # 改变分仓为卖出中  这里避免进程不一样导致卖出中   进入了下一次循环  在卖的情况
                order_profit(base_price, direction, executedQty, 2, api_info, market,market_info, robot_id, uid,lever ,house_number, 2 , now_loop,platform_source)
                insertLog(platform_source, robot_id, uid,u"循环次数:" + str(now_loop) + ",止损率:" + str(stop_loss) + "%,当前:" + str(abs(round(rate,2))) + "%")
                updateMsg(robot_id, uid, u"第" + str(now_loop) + "次循环机器人达到设定的止损率:" + str(stop_loss) + "%,当前:" + str(abs(round(rate,2))) + "%")
                return
        
        if house_number < max_house_number:
            if values_str['order_finish'] == 1:
                return
            # 当前价格如果超过了最大买入金额 和最小买入金额  就不进行开仓  只进行平仓
            # 下一句代码解释:如果没有开启了风险控制或者
            # 开启了风险控制并当前金额在最小和最大之间就进行买入
            if risk_management == 0 or (risk_management == 1 and min_price <= tick_price <= max_price):
                # 补仓  开一个新的分仓马丁放在这个里面 判断趋势 是否执行补仓 价格需要大于补仓价格才能补仓
                result = open_provide(cover_rate['decline'], direction, tick_price, base_price)
                if result:
                    # 开新仓   使用进程开启一个新的进程  单独去处理加仓的问题
                    # 加仓数量  将usdt转换为对应的币    注意杠杆
                    if platform == 'okex_contract':
                        # 开仓时设置的张数，不需要转换
                        usdt_total = first_order_money * cover_rate['multiple']
                        amount = usdt_total
                    else:
                        usdt_total = first_order_money * cover_rate['multiple']
                        amount = common.usdtSymbolBinance(usdt_total, tick_price, lever, minQty)
                    print("第" + str(int(now_loop)+1) + "次循环机器人达到设定的补仓比例")
                    # 已经达到止盈   卖出  进行收益处理   注意这里也要用多线程去处理
                    insertLog(platform_source, robot_id, uid, u"循环次数:" + str(now_loop) + ",补仓比例:" + str(round(cover_rate['decline'],2)))
                    updateMsg(robot_id, uid, u"第" + str(now_loop) + "次循环机器人达到设定的补仓比例:" + str(round(cover_rate['decline'],2)))
                    # 仓数加1  赋值到另一个变量  避免影响下面的数据
                    house_num = house_number
                    # 注意这里是通过异步进程去处理的   那么就会出现一个时间上的问题  需要先将主仓里面的仓数先加上  在在进程里面失败扣除
                    loops.run_until_complete(order_scale(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_num, usdt_total, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
                    print('加仓')

        if 'is_bucang_short' in robot.keys() and str(robot['is_bucang_short'])=='1' and int(robot['amount_value_short'])>0:
            amount = int(robot['amount_value_short'])
            amount = common.usdtSymbolBinance(amount, tick_price, lever, minQty)
            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"is_bucang_short": 0, "amount_value_short": 0})
            if amount * tick_price <5:
                insertLog(platform_source, robot_id, uid, u'单笔下单金额不能少于5u')
                return
            # insertLog(platform_source, robot_id, uid, u"手动补仓张数%s张" %(str(amount)))
            loops.run_until_complete(order_scales(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_number, first_order_money, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
            
        if 'is_bucang_long' in robot.keys() and str(robot['is_bucang_short'])=='1' and int(robot['amount_value_long'])>0:
            amount = int(robot['amount_value_long'])
            amount = common.usdtSymbolBinance(amount, tick_price, lever, minQty)
            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"is_bucang_long": 0, "amount_value_long": 0})
            if amount * tick_price <5:
                insertLog(platform_source, robot_id, uid, u'单笔下单金额不能少于5u')
                return
            loops.run_until_complete(order_scales(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_number, first_order_money, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
            

    else:
        print('进入首单买入，计算是否开启风险控制 ，并判断是否买入')
        # 多次循环# 超过最大循环次数了  清空数据  关闭机器人  关闭运行进程  删除进程id
        if is_loop == 1 and loop_times <= now_loop:
            disableRobot(robot_id, uid)
            runDisableRobot(robot_id, uid)
            insertLog(platform_source, robot_id, uid, u"策略达到最大循环次数(" + str(loop_times) + "次)，停止策略，如需重新执行，请重新启动,")
            return
        # 第几次循环
        loop = int(now_loop) + int(1)
        if risk_management == 0 or (risk_management == 1 and min_price <= tick_price <= max_price):
            # 订单每第一次开始买入设置杠杆倍数
            ret = set_lever(direction,market,api_info,type_all,lever,platform_source)
            if ret!=True:
                ret = common.orderLog(ret,platform_source)
                disableRobot(robot_id, uid)
                insertLog(platform_source, robot_id, uid, u"循环次数" + str(loop) + ",首单开单失败" + str(ret['msg']))
                return
            # 开仓数量  将对应的usdt转为要买入的对应的交易对数量
            if platform == 'okex_contract':
                if int(is_double)==1:
                    first_order_money = float(first_order_money) * 2
                amount = first_order_money
            else:
                if int(is_double)==1:
                    first_order_money = float(first_order_money) * 2
                amount = common.usdtSymbolBinance(first_order_money, tick_price, lever, minQty)
            if amount * tick_price <5:
                insertLog(platform_source, robot_id, uid, u'单笔下单金额不能少于5u')
                return
            if amount <= 0:
                # 保存日志 并退出
                insertLog(platform_source, robot_id, uid, u'单笔下单金额转换为' + str(market_info['stock']) + ",不足" + str(minQty) + str(market_info['stock']) + ",不能开单")
                updateMsg(robot_id, uid, u'单笔下单金额转换为' + str(market_info['stock']) + ",不足" + minQty*tick_price + "USDT,不能开单")
            else:
                
                # 首单买入方法
                loops.run_until_complete(first_order_buy(direction, amount, 1, api_info, market,type_all,lever,loop,uid,robot_id,market_info,first_order_money,platform_source))
            
        else:
            # 当前价格不可开仓
            # 写入日志
            log.get_logger(robot['id']).info("当前单价超过风险控制价格,未能成功开仓")

# 多空函数
def strategy_three(robot,market_info,api_info,type_all):
    # 交易所
    robot_id= int(robot['id'])
    uid = int(int(robot['uid']))
    # 交易所
    platform_source = robot['platform']
    platform = platform_source + "_contract"
    
    # 交易对 如：BTCUSDT     注意这里的交易对是不需要加/的
    if platform_source == 'binance':
        market = market_info['stock'] + market_info['money']
    else:
        market = market_info['stock'] + "-" + market_info['money'] + "-" + str(market_info['instType'])
    # 单独的分仓信息
    if robot['cover_info'] and not robot['cover_info'] is None and robot['cover_info'] != 'None':
        cover_info = json.loads(robot['cover_info'])
    else:
        cover_info = {}
    # 清仓策略
    if robot['cover_grid'] and not robot['cover_grid'] is None and robot['cover_grid'] != 'None' and robot['cover_grid'] != '':
        cover_grid = json.loads(robot['cover_grid'])
        nu = 5
        i = 0
        ke = []
        while i < len(cover_grid):
            ke.append(nu)
            i += 1
            nu += 1
        cover_grid = dict(zip(ke, cover_grid))
    else:
        cover_grid = None
    # 网格止盈回调
    if robot['cover_grid_back'] and not robot['cover_grid_back'] is None and robot['cover_grid_back'] != 'None' and robot['cover_grid_back'] != '':
        cover_grid_back = int(float(robot['cover_grid_back']))
    else:
        cover_grid_back = None
    # 合约全仓止盈价格回调
    lever =cover_grid_back
    stop_profit_callback_rate = float(robot['stop_profit_callback_rate'])
    minQtys=  common.minQtys(market,platform_source)
    common.set_listenkey(api_info,uid,platform_source)
    # 策略配置 # 交易对最大精度 # 交易对最小精度
    maxQty = 0 if 'maxQty' not in minQtys.keys() else minQtys['maxQty']
    minQty = 0 if 'minQty' not in minQtys.keys() else minQtys['minQty']
    if robot['synchro'] is None:
        redisbase.updaterobot(redis_content, robot_id, uid, 'synchro', 0)
    # 是否循环启动 1.循环 2.单次
    if int(robot['recycle_status']) == 1:
        is_loop =1
    else:
        is_loop =2
    loop_times = int(robot['round_num'])
    values_str = robot['values_str']
    if 'values_strs' in robot.keys():
        values_strs = robot['values_strs']
    else:
        values_strs = '';
    if 'now_round_num_s' in robot.keys() and not robot['now_round_num_s'] is None:
        now_loop_two = int(robot['now_round_num_s'])
    else:
        now_loop_two =0
    if 'clean_short' in robot.keys() and not robot['clean_short'] is None:
        clean_short = int(robot['clean_short'])
    else:
        clean_short =0
    if 'clean_long' in robot.keys() and not robot['clean_long'] is None:
        clean_long = int(robot['clean_long'])
    else:
        clean_long =0
    # 当前循环第几次
    now_loop_one = int(robot['now_round_num'])
    if platform_source == 'binance':
        market = market_info['stock'] + market_info['money']
    else:
        market = market_info['stock'] + "-" + market_info['money'] + "-" + str(market_info['instType'])
    loop=0
    if clean_short==2 and clean_long ==2:
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'now_round_num', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'now_round_num_s', 0)
        disableRobot(robot_id,uid)
    
    # print('开始做单')
    # if robot_id!=87:
    #     return
    # direction = 1;
    # result_data = common.getSynchro(api_info,uid,platform_source,market,direction)
    # if direction == 1:
    #     values_data = json.loads(values_strs)
    #     values_data['deal_amount'] = float(result_data['positionAmt'])
    # else:
    #     values_data = json.loads(values_str)
    #     values_data['deal_amount'] = 0-float(result_data['positionAmt'])
    # values_data['base_price'] = float(result_data['entryPrice'])
    # values_data['last_price'] = values_data['base_price'] 
    # values_data['executedQty'] = values_data['deal_amount'] 
    # values_data['strong_pay'] = result_data['liquidationPrice']
    # values_data['deal_money'] = values_data['deal_amount'] *  values_data['base_price']
    # if direction == 1:
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'values_strs', json.dumps(values_data))
    # else:
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', json.dumps(values_data))
    # print(values_data)
    # return
    # if values_strs=='' and values_str=='':
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short', 0)
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long', 0)
    common.set_lever(0,market,api_info,type_all,lever,platform_source)
    if clean_short!=2:
        try:
            short = heyue.positon_short(robot,market_info,api_info,type_all,loop,platform_source,platform,market,robot_id,uid,cover_info,cover_grid,cover_grid_back,stop_profit_callback_rate,maxQty,minQty)
        except Exception as e:
            logger.get_logger(str(robot_id)).info(robot_id)
            logger.get_logger(str(robot_id)).info(inspect.trace()[-1])
    if clean_long!=2:
        try:
            longs = heyue.positon_long(robot,market_info,api_info,type_all,loop,platform_source,platform,market,robot_id,uid,cover_info,cover_grid,cover_grid_back,stop_profit_callback_rate,maxQty,minQty)
        except Exception as e:
            logger.get_logger(str(robot_id)).info(robot_id)
            logger.get_logger(str(robot_id)).info(inspect.trace()[-1])
    if int(robot['is_clean'])==1:
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long', 0)
        disableRobot(robot_id,uid)
    if 'synchro' in robot.keys() and int(robot['synchro']) == 1:
        redisbase.updaterobot(redis_content, robot_id, uid, 'synchro', 0)

# 判断当前单价是否可以进行开仓
def open_provide(cover_rate, direction, present, last):
    """
    判断当前单价是否可以进行开仓
    :param direction: 做空还是做多   1.多 2.空
    :param last: 上次开仓价格
    :param cover_rate: 补仓跌幅
    :param present: 现价
    :return: int
    """
    # 计算下次开仓的最低价格
    # 如果是做多就是 价格下跌  做空是价格上涨
    # 计算这轮开仓的价格
    price = float(last) * float(cover_rate) / 100
    if direction == 1:
        price = float(last) - price
    else:
        price += float(last)
    # 做多的情况
    if direction == 1:
        # 当前价小于等于开仓价
        if present <= price:
            return True
        else:
            return False
    else:
        # 当前价大于等于开仓价
        if present >= price:
            return True
        else:
            return False

# 订单卖出 进行止盈
def order_profit(price, direction, executedQty, side, api_info, market,market_info, robot_id, uid, lever,house, types ,is_loop,now_loop=1, platform='binance',type_all = 0 ):
    """
    订单卖出 进行止盈 止损
    :param now_loop: 第几次循环
    :param price: 买入均价
    :param house: 第几仓
    :param platform: 交易所
    :param uid: 用户id
    :param robot_id: 机器人id
    :param direction: 空还是多
    :param executedQty: 数量
    :param side: 买还是卖
    :param api_info: api
    :param type: 卖出类型
    :param market: 交易对
    :return:
    """
    logger.get_logger(str(robot_id)).info('订单卖出数量'+str(executedQty))
    ret = SustainableOrder(direction, executedQty, side, api_info, market,type_all,lever)
    logger.get_logger(str(robot_id)).info(ret)
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 订单号   348363948206282
        order_id = result['order_id']
        # 卖出价格
        sell_price = result['last_price']
        # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
        revenue = (float(sell_price) - float(price)) * float(result['executedQty'])
        if direction != 1:
            revenue = revenue * -1
        # 手续费
        fee = 0
        symbols=symbol.upper()+'SWAP'
        # 重交易所获取收益和手续费
        commission = common.orderServiceCharge(order_id, api_info, symbols)
        # 收益  (尚未扣除手续费)
        revenue = commission['revenue']
        # 手续费
        fee = commission['fee']
        # 收益扣除手续费
        revenue = float(revenue) - float(fee)
        # 订单入库
        money='USDT'
        symbol_side = side
        insertOrder(platform,uid, order_id, robot_id, 1,direction, market,market_info['stock'],market_info['money'],result['deal_money'], result['executedQty'], price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
        # 收益入库
        insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)

        # 修改redis数据
        # 判断循环次数，循环为零时表示清仓处理，需要重置循环
        if now_loop==0:
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        if types==1:
            insertLog(platform, robot_id, uid, u"清仓卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['executedQty']).quantize(Decimal('0.000000')))))
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
            updateMsg(robot_id, uid, u"清仓卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        else:
            insertLog(platform, robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['executedQty']).quantize(Decimal('0.000000')))))
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': int(now_loop)})
            updateMsg(robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        updateValues(robot_id, uid, '')
        updateRevenue(robot_id, uid, 0)
        updateMsg(robot_id, uid, u'卖出成功')
        if is_loop == 2:
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})

        # 记录日志
    else:
        if ret['code'] == -2019:
            # 账户余额不足
            ret['msg'] = '账户余额不足'
        if ret['code'] == 51202:
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == -2022:
            ret['msg'] = '订单被拒绝'
        if ret['code'] == 51001:
            ret['msg'] = '订单不存在'
        if ret['code'] == 51112:
            ret['msg'] = '平仓张数大于该仓位的可平张数'
        if types==1:
            updateValues(robot_id, uid, '')
            updateRevenue(robot_id, uid, 0)
            updateMsg(robot_id, uid, u'卖出成功')
            disableRobot(robot_id, uid)
        # TODO: write code...
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
        insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))
        updateMsg(robot_id, uid,u"机器人卖出失败" + str(ret['msg']))
        if is_loop == 2:
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
# 永续合约订单处理(合约)
def SustainableOrder(direction, amount, side, api_info, symbol,type_all, lever,platfrom='binance'):

    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
                                                #   exchange, symbol, side, direction, amount,api_info,first_order_money
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, amount,api_info,amount))
        loops.run_until_complete(task)
        ret = task.result()
        return ret
    else:
        loops = asyncio.get_event_loop()
        task = loops.create_task(okex5_order_buy(exchange, symbol, side, direction, amount))
        loops.run_until_complete(task)
        res = task.result()
        return res


# 订单购入  进行加仓
async def order_scale( direction,values_str ,amount, side, api_info, market, market_info ,robot_id, uid, house, first_order_money, deal_money, deal_amount,cover_info, max_house_number ,type_all,lever ,platform='binance'):
    """
    订单购入  进行加仓
    :param deal_amount: 已购入多少币
    :param first_order_money: 投入usdt
    :param deal_money: 已投入usdt
    :param house: 第几仓
    :param platform: 交易所
    :param uid: 用户id
    :param robot_id: 机器人id
    :param direction: 空还是多
    :param executedQty: 数量
    :param side: 买还是卖
    :param api_info: api
    :param market: 交易对
    :param cover_info: 分仓信息
    :return:
    """
    symbol =market
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, amount,api_info,first_order_money))
        loops.run_until_complete(task)
        ret = task.result()
    else:
        return
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 第几仓
        values_str['order_count'] = house
        # 总投入了多少usdt
        values_str['deal_money'] = float(values_str['deal_money']) + float(result['deal_money'])
        # 计算总购买了多少币
        values_str['deal_amount'] = float(values_str['deal_amount']) + float(result['deal_amount'])
        # 持仓张数
        values_str['executedQty'] = float(values_str['executedQty']) + float(result['executedQty'])
        # 方向
        values_str['strong_pay'] = result['strong_pay']
        values_str['margin_price'] = result['margin_price']
        values_str['margin_lilv'] = result['margin_lilv']
        values_str['direction'] = direction
        values_str['pid'] = str(uuid.uuid4())
        # 全仓基础价格
        values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
        values_str['base_price'] = float(Decimal(float(values_str['base_price'])).quantize(Decimal('0.000000000')))
        values_str['order_count'] = values_str['order_count']+1
        # 开单成功
        pid = str(uuid.uuid4())
        result['fee'] = abs(float(result['deal_fee']))
        # 订单入库
        money = 'USDT'

        if direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platform, uid, result['order_id'], robot_id, 2,symbol_direction, market, market_info['stock'],market_info['money'], result['deal_money'], amount, result['last_price'], 2,pid, 0, result['fee'],values_str['order_count'], result['deal_money'],2)
        # 修改redis数据   需要将这一仓的数据覆盖上一仓的数据 保证下一次加仓的数据正确性
        # 记录分仓的数据
        cover_key = values_str['order_count']
        cover_info[cover_key] = {
            'price': result['last_price'],
            'last_price': result['last_price'],
            'is_out': 0,
            'out_price': deal_amount,
            'deal_amount': deal_amount,
            'buy_oid': result['order_id'],
        }
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {"cover_info": json.dumps(cover_info)})
        # 修改补仓后全仓信息
        result['trend_side'] = 0
        if result['order_count'] >= max_house_number:
            # 只能等盈利
            result['order_finish'] = 1
            insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " % result['order_count'])
        updateValues(robot_id, uid, json.dumps(values_str))
        insertLog(platform, robot_id, uid, u"补仓成功，基准价调整为: %s " % values_str['base_price'])
        updateMsg(robot_id, uid,u"补仓成功，基准价调整为: %s " % values_str['base_price'])
    else:
        ret['msg'] = '委托失败，账户可用余额不足'
        common.orderLog(ret,platform)
        # 返回仓数
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:加仓失败')
        insertLog(platform, robot_id, uid, u"机器人加仓失败" + str(ret['msg']))


async def order_scales( direction,values_str ,amount, side, api_info, market,market_info, robot_id, uid, house, first_order_money, deal_money, deal_amount,cover_info, max_house_number ,type_all,lever ,platform='binance'):
    symbol = market
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, amount,api_info,first_order_money))
        loops.run_until_complete(task)
        ret = task.result()
    else:
        return 
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 第几仓
        values_str['order_count'] = house
        # 总投入了多少usdt
        values_str['deal_money'] = float(values_str['deal_money']) + float(result['deal_money'])
        # 计算总购买了多少币
        values_str['deal_amount'] = float(values_str['deal_amount']) + float(result['deal_amount'])
        # 持仓张数
        values_str['executedQty'] = float(values_str['executedQty']) + float(result['executedQty'])
        # 方向
        values_str['strong_pay'] = result['strong_pay']
        values_str['margin_price'] = result['margin_price']
        values_str['margin_lilv'] = result['margin_lilv']
        values_str['direction'] = direction
        values_str['pid'] = str(uuid.uuid4())
        # 全仓基础价格
        values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
        values_str['base_price'] = float(Decimal(values_str['base_price']).quantize(Decimal('0.000000000')))
        result['fee'] = abs(float(result['deal_fee']))
        # 开单成功
        pid = str(uuid.uuid4())
        # 订单入库
        money = 'USDT'
        if direction == 0:
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platform, uid, result['order_id'], robot_id, 2,symbol_direction, market, market_info['stock'],market_info['money'], result['deal_money'], amount, result['last_price'], 2,pid, 0, result['fee'],values_str['order_count'], result['deal_money'],2)
        # 修改redis数据   需要将这一仓的数据覆盖上一仓的数据 保证下一次加仓的数据正确性
        # 记录分仓的数据
        cover_key = values_str['order_count']
        cover_info[cover_key] = {
            'price': result['last_price'],
            'last_price': result['last_price'],
            'is_out': 0,
            'out_price': deal_amount,
            'deal_amount': deal_amount,
            'buy_oid': result['order_id'],
        }
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {"cover_info": json.dumps(cover_info)})
        # 修改补仓后全仓信息
        result['trend_side'] = 0
        if result['order_count'] >= max_house_number:
            # 只能等盈利
            result['order_finish'] = 1
            insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " % result['order_count'])
        updateValues(robot_id, uid, json.dumps(values_str))
        updateMsg(robot_id, uid, u'补仓成功')
    else:
        ret['msg'] = '委托失败，账户可用余额不足'
        common.orderLog(ret,platform)
        # 返回仓数
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:加仓失败')
        insertLog(platform, robot_id, uid, u"机器人加仓失败" + str(ret['msg']))
        updateMsg(robot_id, uid, u"机器人加仓失败" + str(ret['msg']))



async def first_order_buy(direction, amount, side, api_info, symbol,type_all, lever,loop,uid,robot_id,market_info,first_order_money,platfrom='binance'):
    # 注意事项:
    # 1.做多 买入的情况就是开仓  卖出就是平仓
    # 2.做空 买入的情况就是平仓  卖出就是开仓
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    result={}
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, amount,api_info,first_order_money))
        loops.run_until_complete(task)
        ret = task.result()
    else:
        return
    if ret['code'] == 1:
        # 开单成功
        values_str = ret['data']
        values_str['first_order_price'] = amount
        # 手续费
        if str(values_str['commissionAsset']) == 'USDT':
            fee = abs(float(values_str['deal_fee']))
        else:
            fee = abs(float(values_str['deal_fee'])*float(values_str['last_price']))
        revenue = 0
        values_str['pid'] = str(uuid.uuid4())
        # 订单入库
        # 用户id，订单id，机器人id，买入还是卖出，支出金额，买入数量，单价，是否首单，uuid，收益，手续费，总张数，下单总金额USDT,仓数(第几仓)
        side=1
        symbol_side = side
        if direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        
        insertOrder(platfrom,uid, values_str['order_id'], robot_id, 2,symbol_direction,symbol,market_info['stock'],market_info['money'], values_str['deal_money'], amount,values_str['last_price'], 1,  values_str['pid'], 0, fee, 0, values_str['deal_money'],2)
        # 修改redis数据
        insertLog(platfrom, robot_id, uid, u"循环次数:" + str(loop) + ",首单开单成功")
        updateValues(robot_id, uid, json.dumps(values_str))
        updateMsg(robot_id, uid, u'下单成功')
        # 更新机器人循环次数
        redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"process_id": values_str['pid'], "now_round_num": loop})
    else:
        common.orderLog(ret,platfrom)
        # 开单失败
        insertLog(platfrom, robot_id, uid, u"循环次数:" + str(loop) + ",首单开单(" + str(amount) + ")失败" + str(ret['msg']))
        updateMsg(robot_id, uid, u"循环次数:" + str(loop) + ",首单开单(" + str(amount) + ")失败" + str(ret['msg']))
        # 停止机器人
        # print('关闭机器人')
        disableRobot(robot_id, uid)
        updaterobotkeys(robot_id, uid, {'values_str': ''})

async def clean_order_sell(price, direction, executedQty, side, api_info,market_info, market, robot_id, uid, lever,house, typwe ,now_loop=1, platform='binance',type_all = 0):
    symbol =market
    # 注意事项:
    # 1.做多 买入的情况就是开仓  卖出就是平仓
    # 2.做空 买入的情况就是平仓  卖出就是开仓
    # 判断到底是改买还是卖，BUY,SELL
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    result={}
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, executedQty,api_info,executedQty))
        loops.run_until_complete(task)
        ret = task.result()
    else:
        return
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 订单号   348363948206282
        order_id = result['order_id']
        # 卖出价格
        sell_price = result['last_price']
        # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
        # 手续费
        fee = 0
        symbols=symbol.upper()
        # 重交易所获取收益和手续费
        commission = common.orderServiceCharge(order_id, api_info, symbols)
        # 收益  (尚未扣除手续费)
        revenue = commission['revenue']
        # 手续费
        fee = commission['fee']
        # 收益扣除手续费
        revenue = float(revenue) - float(fee)
        # 订单入库
        money='USDT'
        symbol_side = 1
        if symbol_direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        # insertOrder(platform,uid, order_id, robot_id, symbol_side,symbol_direction, market,market_info['stock'],market_info['money'] ,result['deal_money'], result['executedQty'], sell_price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
        # 收益入库
        insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)

        # 修改redis数据
        # 判断循环次数，循环为零时表示清仓处理，需要重置循环
        if now_loop==0:
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        if typwe==1:
            disableRobot(robot_id, uid)
            insertLog(platform, robot_id, uid, u"清仓卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000000'))),
            str(Decimal(result['executedQty']).quantize(Decimal('0.00000000')))))
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
        else:
            insertLog(platform, robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.00000000'))),
            str(Decimal(result['executedQty']).quantize(Decimal('0.00000000')))))
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        updateValues(robot_id, uid, '')
        updateRevenue(robot_id, uid, 0)
        updateMsg(robot_id, uid, u'卖出成功')

        # 记录日志
    else:
        ret = common.orderLog(ret,'binance')
        if typwe==1:
            updateValues(robot_id, uid, '')
            updateRevenue(robot_id, uid, 0)
            updateMsg(robot_id, uid, u'清仓卖出成功')
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
        # TODO: write code...
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
        insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))



# 币安合约下单
async def binance_order_buy(exchange, symbol, side, direction, amount,api_info,first_order_money):

    """
    币安合约下单
    :param exchange: ccxt数据信息
    :param symbol: 交易对
    :param side: 买还是卖
    :param direction: 方向 做空还是做多
    :param amount: 数量
    :return: dist
    """
    ret = {}
    try:
        result = {
            "symbol": symbol,
            "side": side,  # 买还是卖
            "positionSide": direction,  # 做空
            "type": "MARKET",  # 市价单
            "quantity": amount,
            "spot":'test'
        }
        result = await exchange.fapiPrivatePostOrder(result)
        logger.get_logger(str('order')).info(result)
        # exit()
        # result = {'info': {'status': 'ok', 'data': '345450498901036'}, 'id': '345450498901036',
        #           'timestamp': 1629180511922, 'datetime': '2021-08-17T06:08:31.922Z', 'lastTradeTimestamp': None,
        #           'status': None, 'symbol': 'BTT/USDT', 'type': 'market', 'side': 'buy', 'price': None,
        #           'amount': 10.0, 'filled': None, 'remaining': None, 'cost': None, 'trades': None, 'fee': None,
        #           'clientOrderId': None, 'average': None}
        # result['orderId']='8389765523317898308'
        if result['orderId']:
            # 获取订单信息
            info = await exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 10})
            # info = await exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['orderId']})
            while len(info) == 0:
                time.sleep(1)
                # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['orderId']})
                info =await exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 10})
            info_bili = await exchange.fapiPrivate_get_positionrisk({"symbol": symbol})
            while len(info_bili) == 0:
                info_bili = await exchange.fapiPrivate_get_positionrisk({"symbol": symbol})
            for ite in info_bili:
                if ite['marginType']!='cross':
                    continue
                if direction.lower() =='long' and ite['positionSide']=='LONG':
                    info_bili=ite
                elif direction.lower() == 'short' and ite['positionSide']=='SHORT':
                    info_bili=ite
            strs = {
                'order_id': result['orderId'],  # 订单号
                'symbol': symbol,  # 交易对
                'up_price': 0,  # 上涨价
                'order_count': 0,  # 补仓次数
                'down_price': 0,  # 下跌价
                'trend_side': 0,  # 趋势
                'is_clean':0, #清仓
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'time': '',  # 成交时间
                'lever':info_bili['leverage'],
                'now_round_num':0,
                'base_price':info_bili['entryPrice'],
                'strong_pay':info_bili['liquidationPrice'],# 预估强平价格
                'margin_price':info_bili['isolatedMargin'],# 保证金价格
                'margin_lilv':info_bili['isolatedMargin'],#保证金比例
                'pid': 0,  # 线程id
                'order_finish': 0,
                'deal_amount':0,
                'executedQty':0,
                'last_price':0,
                'first_order_price':0,
                'deal_money':0,
                'position':0,
                'direction':0,
                'deal_fee':0,
            }
            for i in info:
                if i['orderId'] == result['orderId']:
                    strs['deal_amount'] += float(i['qty'])
                    strs['executedQty'] =  first_order_money
                    strs['last_price'] = i['price']
                    strs['first_order_price'] = i['price']
                    strs['deal_money'] += float(i['quoteQty'])
                    strs['position'] = i['positionSide']#做空还是做多空SHORT 多long
                    strs['direction'] =  i['positionSide']
                    strs['deal_fee'] += float(i['commission'])
                    strs['time'] = i['time']
                    strs['commissionAsset'] = i['commissionAsset']
            if strs['deal_amount'] <= 0:
                time.sleep(1)
                info =await exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 20})
                for i in info:
                    if i['orderId'] == result['orderId']:
                        strs['deal_amount'] += float(i['qty'])
                        strs['executedQty'] =  first_order_money
                        strs['last_price'] = i['price']
                        strs['first_order_price'] = i['price']
                        strs['deal_money'] += float(i['quoteQty'])
                        strs['position'] = i['positionSide'].lower() #做空还是做多空SHORT 多long
                        strs['direction'] =  i['positionSide']
                        strs['deal_fee'] += float(i['commission'])
                        strs['time'] = i['time']
                        strs['commissionAsset'] = i['commissionAsset']
            strs['margin_price'] = float(strs['executedQty']) * float(strs['last_price']) / float(info_bili['leverage'])
            ret['code'] = 1
            ret['data'] = strs
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        if str(msg['code']) == str(1):
            code= msg['data'][0]['sCode']
        else:
            code = msg['code']
        ret['code'] = code
        ret['data'] = {}
        ret['msg'] = msg
    print(ret)
    await exchange.close()
    return ret


# okex5合约下单
async def okex5_order_buy(exchange, symbol, side, direction, amount):
    """
    okex5合约下单
    :param exchange: ccxt链接数据
    :param symbol: 交易对
    :param side: 开仓还是平仓  buy开  sell平
    :param direction: 方向 做空还是做多long 多 short 空
    :param amount: 数量
    :return:
    """
    ret = {}
    result = {}
    result_two = {}
    resulf = {}
    symbols = symbol
    symbol = symbol.upper() + 'SWAP'
    resulf = {
        'instId': symbol,  # 产品ID
        'instType': 'SWAP',
    }
    clordId = str(int(time.time()*10000000))+'heyue'
    ctVal =1
    try:
        result = {
            'instId': symbol,  # 产品ID
            'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
            'clOrdId': clordId,  # 订单号
            'side': side.lower(),  # 方向 buy 买 sell 卖
            'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
            'ordType': 'market',  # 市价单
            'sz': int(amount),  # 数量
        }
        # 获取合约币种公共信息
        public_result = await exchange.public_get_public_instruments(resulf)
        public_result = public_result['data'][0]
        ctVal = public_result['ctVal']
        logger.get_logger(str('order')).info(result)
        result = await exchange.private_post_trade_order(result)
        result = result['data'][0]
        if result['ordId']:
            # 获取订单信息
            info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
            info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
            if info_bili['data']==[]:
                info_bili={}
                info_bili['liqPx']=0
                info_bili['imr']=0
                info_bili['mgnRatio']=0
            else:
                info_bili = info_bili['data'][0]
            info = info['data'][0]
            while info['tradeId'] =='':
                time.sleep(1)
                info =  await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                info_bili = info_bili['data'][0]
                info = info['data'][0]
            strs = {
                'order_id': result['ordId'],  # 订单号
                'first_order_price': info['avgPx'],  # 开仓价
                'symbol': symbols,  # 交易对
                'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                'last_price': info['avgPx'],  # 平均成交价
                'base_price': info['avgPx'],  # 基础价
                'up_price': 0,  # 上涨价
                'order_count': 0,  # 补仓次数
                'down_price': 0,  # 下跌价
                'trend_side': 0,  # 趋势
                'is_clean':0, #清仓
                'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx'])  ,  # 成交金额
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'position': info['posSide'],  # 做空还是多 空SHORT 多long
                'direction': info['posSide'],
                'time': '',  # 成交时间
                'fee': info['fee'],  # 手续费
                'lever':info['lever'],
                'now_round_num':0,
                'strong_pay':info_bili['liqPx'],# 预估强平价格
                'margin_price':info_bili['imr'],# 保证金价格
                'margin_lilv':info_bili['mgnRatio'],#保证金比例
                'pid': 0,  # 线程id
                'executedQty': float(info['sz']),  # 成交量
                'order_finish': 0
            }
            ret['code'] = 1
            ret['data'] = strs
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        logger.get_logger(str('order')).error(e)
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    return ret

# 更新机器人信息字典模式
def updaterobotkeys(robot_id, uid, data):
    keys = data.keys()
    for v in keys:
        va = data[v]
        redis_content.hset('user_contract_' + str(uid) + '_' + str(robot_id), v, va)
        sql = "update jq_quant_robot set `" + str(v) + "` = '" + str(va) + "' where id=%d" % (int(robot_id))
        redis_content.hset('update_sql', 'new_robot_' + str(v) + '_' + str(robot_id), sql)
    return True

# 修改机器人数据
def order_update_redis( robot_id, uid, data):
    """
    修改机器人数据
    :param robot_id: 机器人id
    :param uid: 用户id
    :return: null
    """
    updateValues(robot_id, uid, data)

# 删除redis里面的数据信息
def order_delete_redis(self, robot_id, uid):
    """
    删除机器人redis里面的日志数据信息
    :param robot_id: 机器人id
    :param uid: 用户id
    :return: null
    """
    # 删除redis里面的数据信息    new_user_robot_position_79_11_*
    robot_str = 'new_user_robot_position_' + str(uid) + '_' + str(robot_id) + '_*'
    common.delete_robot(robot_str)
# 启动合约机器人
def runEnableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 1)
# 禁用合约机器人
def disableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'status', 0)

def updateBalanceStatus(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'sell_status', '1')


def updateNew(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'new', 0)


def updateMsg(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'show_msg', show_msg)


def updateValues(robot_id, uid, values_str):
    redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', values_str)


def updateRevenue(robot_id, uid, revenue):
    redisbase.updaterobot(redis_content, robot_id, uid, 'revenue', revenue)

def cleanFinish(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'is_clean', 0)
    redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long',0)
    redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short',0)


def runDisableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 0)

def insertLog(platform, robot_id, uid, log):
    redisbase.insertlog(redis_content, robot_id, platform, uid, log,2)

def insertRevenueLog(platform, robot_id, pid, uid, market, stock, money, revenue):
    # redisbase.insertrevene(redis_content,platform, robot_id, pid, uid, market, stock, money, revenue)
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_revenue (platform,qrobot_id,pid,uid,market,stock,money,revenue,deal_status,transaction_type) values ('%s',%d,'%s',%d,'%s','%s','%s','%s',%d,%d)" % (
    platform,
    robot_id, pid, uid, market, stock, money, revenue, 0,2)
    cur.execute(insert_sql)

def insertOrder(platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first,uuid, revenue, fee, amount, total,transaction_type):
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_order (type,platform,uid,order_id,qrobot_id,side,position,market,stock,money,deal_money,deal_amount,price,order_status,is_first,pid,revenue,fee,amount,total,transaction_type) values (%d,'%s',%d,'%s',%d,%d,%d,'%s','%s','%s','%s','%s','%s',1,%d,'%s','%s','%s',%d,'%s',%d)" % (
        2,platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first, uuid,revenue, fee, amount, total,transaction_type)
    cursor, conn, count = cur.execute(insert_sql)
    return cursor.lastrowid

import threading

POOL = {}
Active_Thread = []

def loadStrategyConfig(cur):
    # 获取数据库中所有的合约类型市场
    markets = cur.fetchall("select id,platform,market,market_name,type,stock,money,instType from jl_spot_market where status = 1 ")
    if  markets == 0:
        print('没有合约市场')
        return
    market_list = {}
    for k in markets.keys():
        market = markets[k]
        market_list[market['id']] = market
    # 获取所有用户的第三方api信息
    apis = cur.fetchall("select id,uid,platform,api_key,secret_key,passphrase from jl_third_api where status = 1")
    api_list = {}
    for k in apis.keys():
        apias = apis[k]
        api_list["%s-%s" % (apias['platform'], apias['uid'])] = apias
    # 获取机器人所有的配置选项
    lists = cur.fetchall("SELECT option_value from jl_option where option_name='system_setting'")
    lists = json.loads(lists[0]['option_value'])
    config = {}
    config['type'] = lists['type']
    robots = redisbase.getrobotbian()
    # 获取代理参数
    aolist = api.getapilist()
    if robots:
        for k in robots.keys():
            robot = robots[k]
            if robot['platform']!='binance':
                continue
            if str(robot['new']) == str(4):
                continue
            if str(robot['status']) != str(1):
                continue
            # if str(robot['id']) != str(57):
            #     continue
            market_id = int(robot['market_id'])
            platform = robot['platform']
            uid = int(robot['uid'])
            robot_id = int(robot['id'])
            if market_id in market_list.keys():
                market_info = market_list[market_id]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, '市场 %s 没有找到' % market_id)
                insertLog(platform, robot_id, uid, '市场 %s  没有找到, 停止机器人' % market_id)
                continue
            if "%s-%s" % (platform, uid) in api_list.keys():
                api_info = api_list["%s-%s" % (platform, uid)]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, '%s api not found' % platform)
                insertLog(platform, robot_id, uid,'%s api not found , stopped...' % platform)
                continue
            if aolist == False:
                try:
                    if int(robot['is_trend'])==2:
                        task = strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = strategy(robot, market_info, api_info, config['type'])
                    # print('机器人结算'+str(robot['id']))
                except Exception as e:
                    # print(e)
                    logger.get_logger(str('order')).error(inspect.trace()[-1])
                continue
            # 判断是否使用代理如果使用代理则需要传代理参数

            if str(config['type']) == '0':
                try:
                    if int(robot['is_trend'])==2:
                        task = strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = strategy(robot, market_info, api_info, config['type'])
                except Exception as e:
                    # print(e)
                    # disableRobot(robot_id,uid)
                    logger.get_logger(str('order')).error(inspect.trace()[-1])
            else:
                try:
                    if robot_id in Active_Thread:
                        continue
                    if int(robot['is_trend'])==2:
                        task = threading.Thread(target=strategy_three, args=(robot, market_info, api_info, config['type']))
                        # strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = threading.Thread(target=strategy, args=(robot, market_info, api_info, config['type']))
                    POOL[robot_id] = task
                    POOL[robot_id].setDaemon(True)
                    POOL[robot_id].start()
                except Exception as e:
                    disableRobot(robot_id,uid)
                    # print(e)
                    logger.get_logger(str('order')).error(inspect.trace()[-1])



if __name__ == '__main__':
    
    while True:
        try:
            last_time=int(time.time()*1000)
            cur = MySqLHelper()
            Active_Thread = [k for k, v in POOL.items() if v.is_alive()]
            loadStrategyConfig(cur)
            time.sleep(0.5)
        except Exception as e:
            logger.get_logger(str('order')).info('Exception:%s', e)
            time.sleep(1)
            logger.get_logger(str('order')).info(inspect.trace()[-1])