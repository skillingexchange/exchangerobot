import aiohttp
import asyncio
import threading
import log
from decimal import Decimal, ROUND_DOWN
import math
import time
import json
import uuid
import ccxt.async_support as ccxt
import ccxt as ccxt_all
import common
import order
from database import MySqLHelper
import redisbase
from logger import logger
import random
import requests
import api
import heyue
import nest_asyncio
import inspect
import test_order

from orders import iplist
from orders import list_times
from orders import list_timest
from orders import last_timet
from orders import last_time
redis_content = redisbase.getrids(15)

brokerid = 'ac9d0764ab8dBCDE'
def clean_amount_sell(values_str,revenues,price, direction, executedQty, side, api_info,market_info, market, robot_id, uid, lever,house, typwe ,now_loop=1, platform='binance',type_all = 0,type_direction = 1,first_order_money=0):
    symbol =market
    # 注意事项:
    # 1.做多 买入的情况就是开仓  卖出就是平仓
    # 2.做空 买入的情况就是平仓  卖出就是开仓
    # 判断到底是改买还是卖，BUY,SELL
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    
    if exchange_id == 'binance':
        ret = SustainableOrder(symbol_direction, executedQty, 2, api_info, market, type_all, lever,platform)
        if ret['code'] == 1:
            # data数据
            result = ret['data']
            # 交易对
            symbol = result['symbol']
            # 订单号   348363948206282
            order_id = result['order_id']
            # 卖出价格
            sell_price = result['last_price']
            
            # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
            revenue = (float(sell_price) - float(price)) * float(result['deal_amount'])
            if direction != 1:
                revenue = revenue * -1
            # 手续费
            fee = 0
            symbols=symbol.upper()+'SWAP'
            # 重交易所获取收益和手续费
            commission = common.orderServiceCharge(order_id, api_info, symbol)
            # 收益  (尚未扣除手续费)
            revenue = commission['revenue']
            if symbol_direction==1:
                result['deal_money'] = result['deal_money'] + abs(commission['revenue'])
            else:
                result['deal_money'] = result['deal_money'] - abs(commission['revenue'])
            # 手续费
            fee = commission['fee']
            # 收益扣除手续费
            revenue = float(revenue) - float(fee)
            # 订单入库
            money='USDT'
            symbol_side = 1
            if symbol_direction == 0:
                # 做空
                if side == 1:
                    symbol_side = 2
                else:
                    symbol_side = 1
            insertOrder(platform,uid, order_id, robot_id, symbol_side,symbol_direction, market,market_info['stock'],market_info['money'] ,result['deal_money'], result['deal_amount'], sell_price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
            # 收益入库
            insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
            # 修改redis数据
            # 判断循环次数，循环为零时表示清仓处理，需要重置循环
            insertLog(platform, robot_id, uid, u"手动卖出成功：成交均价 %s,成交 %s USDT" % (
            str(Decimal(price).quantize(Decimal('0.000000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            values_str['deal_amount'] = first_order_money - result['deal_amount']
            if values_str['deal_amount']<=0:
                if type_direction == 1:
                    updateValues(robot_id, uid, '')
                    redisbase.updaterobotkeys(redis_content, robot_id, uid, {'status': 0})
                    redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
                else:
                    if symbol_direction==0:
                        # 做空
                        updateValues(robot_id, uid, '')
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'clean_short': 2})
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
                    else:
                        # 做多
                        updateValuess(robot_id, uid, '')
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'clean_long': 2})
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num_s': 0})
            else:
                # 总投入了多少usdt
                values_str['deal_money'] = float(values_str['deal_money']) - float(result['deal_money'])
                # 方向
                values_str['strong_pay'] = result['strong_pay']
                values_str['margin_price'] = result['margin_price']
                values_str['margin_lilv'] = result['margin_lilv']
                values_str['direction'] = direction
                values_str['pid'] = str(uuid.uuid4())
                values_str['order_finish'] = 2
                # 全仓基础价格
                values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
                values_str['base_price'] = float(Decimal(float(values_str['base_price'])).quantize(Decimal('0.000000000')))
                if type_direction == 1:
                    updateValues(robot_id, uid, json.dumps(values_str))
                else:
                    if symbol_direction==0:
                        # 做空
                        updateValues(robot_id, uid, json.dumps(values_str))
                    else:
                        # 做多
                        updateValuess(robot_id, uid, json.dumps(values_str))
            # 记录日志
        else:
            common.orderLog(ret,exchange_id)
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
            if revenues >0:
                insertRevenueLog(platform,robot_id, str(uuid.uuid4()),uid, market, market, 'USDT', revenues)
            log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
            insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))
    else:
        ret = SustainableOrder(symbol_direction, executedQty, 2, api_info, market, type_all, lever,platform)
        if ret['code'] == 1:
            # data数据
            result = ret['data']
            # 交易对
            symbol = result['symbol']
            # 订单号   348363948206282
            order_id = result['order_id']
            # 卖出价格
            sell_price = result['last_price']
            # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
            revenue = (float(sell_price) - float(price)) * float(result['executedQty'])
            if direction != 1:
                revenue = revenue * -1
            # 手续费
            fee = 0
            symbols=symbol.upper()+'SWAP'
            # 重交易所获取收益和手续费
            commission = common.orderServiceCharge(order_id, api_info, symbols)
            # 收益  (尚未扣除手续费)
            revenue = commission['revenue']
            # 手续费
            fee = commission['fee']
            # 收益扣除手续费
            revenue = float(revenue) - float(fee)
            # 订单入库
            money='USDT'
            symbol_side = 1
            if symbol_direction == 0:
                # 做空
                if side == 1:
                    symbol_side = 2
                else:
                    symbol_side = 1
            insertOrder(platform,uid, order_id, robot_id, symbol_side,symbol_direction, market,market_info['stock'],market_info['money'] ,result['deal_money'], result['executedQty'], sell_price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
            # 收益入库
            insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
            # 修改redis数据
            # 判断循环次数，循环为零时表示清仓处理，需要重置循环
            insertLog(platform, robot_id, uid, u"手动卖出成功：成交均价 %s,成交数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            values_str['executedQty'] = int(values_str['executedQty']) - int(result['executedQty'])
            if values_str['executedQty']<=0:
                if type_direction == 1:
                    updateValues(robot_id, uid, '')
                    redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
                else:
                    if symbol_direction==0:
                        # 做空
                        updateValues(robot_id, uid, '')
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'clean_short': 2})
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
                    else:
                        # 做多
                        updateValuess(robot_id, uid, '')
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'clean_long': 2})
                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num_s': 0})
            else:
                # 总投入了多少usdt
                values_str['deal_money'] = float(values_str['deal_money']) - float(result['deal_money'])
                # 计算总购买了多少币
                values_str['deal_amount'] = float(values_str['deal_amount']) - float(result['deal_amount'])
                
                # 方向
                values_str['strong_pay'] = result['strong_pay']
                values_str['margin_price'] = result['margin_price']
                values_str['margin_lilv'] = result['margin_lilv']
                values_str['direction'] = direction
                values_str['pid'] = str(uuid.uuid4())
                values_str['order_finish'] = 2
                # 全仓基础价格
                values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
                values_str['base_price'] = float(Decimal(float(values_str['base_price'])).quantize(Decimal('0.000000000')))
                if type_direction == 1:
                    updateValues(robot_id, uid, json.dumps(values_str))
                else:
                    if symbol_direction==0:
                        # 做空
                        updateValues(robot_id, uid, json.dumps(values_str))
                    else:
                        # 做多
                        updateValuess(robot_id, uid, json.dumps(values_str))
            # 记录日志
        else:
            common.orderLog(ret,exchange_id)
            # TODO: write code...
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
            if revenues >0:
                insertRevenueLog(platform,robot_id, str(uuid.uuid4()),uid, market, market, 'USDT', revenues)
            log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
            insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))

# 永续合约订单处理(合约)
def SustainableOrder(direction, amount, side, api_info, symbol, type_all, lever, platfrom='binance'):
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    
    if exchange_id == 'binance':
        loops = asyncio.get_event_loop()
        task = loops.create_task(binance_order_buy(exchange, symbol, side, direction, amount,api_info,amount))
        loops.run_until_complete(task)
        res = task.result()
        return res
    else:
        loops = asyncio.get_event_loop()
        task = loops.create_task(okex5_order_buy(exchange, symbol, side, direction, amount))
        loops.run_until_complete(task)
        res = task.result()
        return res

        
  
# 币安合约下单
async def binance_order_buy(exchange, symbol, side, direction, amount,api_info,first_order_money):

    """
    币安合约下单
    :param exchange: ccxt数据信息
    :param symbol: 交易对
    :param side: 买还是卖
    :param direction: 方向 做空还是做多
    :param amount: 数量
    :return: dist
    """
    ret = {}
    log.get_logger(symbol).error('手动下单开始')
    try:
        result = {
            "symbol": symbol,
            "side": side,  # 买还是卖
            "positionSide": direction,  # 做空
            "type": "MARKET",  # 市价单
            "quantity": amount,
            "spot":'test'
        }
        result = await exchange.fapiPrivatePostOrder(result)
        if result['orderId']:
            # 获取订单信息
            time.sleep(1)
            info = await exchange.fapiPrivateGetUserTrades({'symbol': symbol})
            while len(info) == 0:
                info =await exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 10})
            info_bili = await exchange.fapiPrivate_get_positionrisk({"symbol": symbol})
            while len(info_bili) == 0:
                info_bili = await exchange.fapiPrivate_get_positionrisk({"symbol": symbol})
            for ite in info_bili:
                if ite['marginType']!='cross':
                    continue
                if direction.lower() =='long' and ite['positionSide']=='LONG':
                    info_bili=ite
                elif direction.lower() == 'short' and ite['positionSide']=='SHORT':
                    info_bili=ite
            strs = {
                'order_id': result['orderId'],  # 订单号
                'symbol': symbol,  # 交易对
                'up_price': 0,  # 上涨价
                'order_count': 0,  # 补仓次数
                'down_price': 0,  # 下跌价
                'trend_side': 0,  # 趋势
                'is_clean':0, #清仓
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'time': '',  # 成交时间
                'lever':info_bili['leverage'],
                'now_round_num':0,
                'base_price':info_bili['entryPrice'],
                'strong_pay':info_bili['liquidationPrice'],# 预估强平价格
                'margin_price':info_bili['notional'],# 保证金价格
                'margin_lilv':info_bili['isolatedMargin'],#保证金比例
                'pid': 0,  # 线程id
                'order_finish': 0,
                'deal_amount':0,
                'executedQty':0,
                'last_price':0,
                'first_order_price':0,
                'deal_money':0,
                'position':0,
                'direction':0,
                'deal_fee':0,
            }
            for i in info:
                if i['orderId'] == result['orderId']:
                    strs['deal_amount'] += float(i['qty'])
                    strs['executedQty'] =  first_order_money
                    strs['last_price'] = i['price']
                    strs['first_order_price'] = i['price']
                    strs['deal_money'] += float(i['quoteQty'])
                    strs['position'] = i['positionSide']#做空还是做多空SHORT 多long
                    strs['direction'] =  i['positionSide']
                    strs['deal_fee'] += float(i['commission'])
                    strs['time'] = i['time']
                    strs['commissionAsset'] = i['commissionAsset']
            ret['code'] = 1
            ret['data'] = strs
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId, exchange, symbol, ctVal, symbols, side))
        loops.run_until_complete(task)
        ret = task.result()
    await exchange.close()
    log.get_logger(symbol).error(ret)
    log.get_logger(symbol).error('手动下单结束')
    return ret
    
# okex5合约下单
async def okex5_order_buy(exchange, symbol, side, direction, amount):
    """
    okex5合约下单
    :param exchange: ccxt链接数据
    :param symbol: 交易对
    :param side: 开仓还是平仓  buy开  sell平
    :param direction: 方向 做空还是做多long 多 short 空
    :param amount: 数量
    :return:
    """
    ret = {}
    result = {}
    result_two = {}
    resulf = {}
    symbols = symbol
    symbol = symbol.upper() + 'SWAP'
    resulf = {
        'instId': symbol,  # 产品ID
        'instType': 'SWAP',
    }
    clordId = brokerid + str(int(time.time() * 10)) + 'heyue'
    ctVal = 1
    try:
        result = {
            'instId': symbol,  # 产品ID
            'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
            'clOrdId': clordId,  # 订单号
            'side': side.lower(),  # 方向 buy 买 sell 卖
            'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
            'ordType': 'market',  # 市价单
            'sz': int(amount),  # 数量
        }
        # 获取合约币种公共信息
        public_result = await exchange.public_get_public_instruments(resulf)
        public_result = public_result['data'][0]
        ctVal = public_result['ctVal']
        logger.info(result)
        result = await exchange.private_post_trade_order(result)
        result = result['data'][0]
        if result['ordId']:
            # 获取订单信息
            info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
            info_bili = await exchange.private_get_account_positions({"instId": symbol, "instType": "SWAP"})
            if info_bili['data'] == []:
                info_bili = {}
                info_bili['liqPx'] = 0
                info_bili['imr'] = 0
                info_bili['mgnRatio'] = 0
            else:
                info_bili = info_bili['data'][0]
            info = info['data'][0]
            while info['tradeId'] == '':
                time.sleep(1)
                info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                info_bili = await exchange.private_get_account_positions({"instId": symbol, "instType": "SWAP"})
                info_bili = info_bili['data'][0]
                info = info['data'][0]
            strs = {
                'order_id': result['ordId'],  # 订单号
                'first_order_price': info['avgPx'],  # 开仓价
                'symbol': symbols,  # 交易对
                'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                'last_price': info['avgPx'],  # 平均成交价
                'base_price': info['avgPx'],  # 基础价
                'up_price': 0,  # 上涨价
                'order_count': 0,  # 补仓次数
                'down_price': 0,  # 下跌价
                'trend_side': 0,  # 趋势
                'is_clean': 0,  # 清仓
                'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx']),  # 成交金额
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'position': info['posSide'],  # 做空还是多 空SHORT 多long
                'direction': info['posSide'],
                'time': '',  # 成交时间
                'fee': info['fee'],  # 手续费
                'lever': info['lever'],
                'now_round_num': 0,
                'strong_pay': info_bili['liqPx'],  # 预估强平价格
                'margin_price': info_bili['imr'],  # 保证金价格
                'margin_lilv': info_bili['mgnRatio'],  # 保证金比例
                'pid': 0,  # 线程id
                'executedQty': float(info['sz']),  # 成交量
                'order_finish': 0
            }
            ret['code'] = 1
            ret['data'] = strs
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        logger.error(e)
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId, exchange, symbol, ctVal, symbols, side))
        loops.run_until_complete(task)
        ret = task.result()
    await exchange.close()
    return ret


    
def insertLog(platform, robot_id, uid, log):
    redisbase.insertlog(redis_content, robot_id, platform, uid, log,2)
def insertRevenueLog(platform, robot_id, pid, uid, market, stock, money, revenue):
    # redisbase.insertrevene(redis_content,platform, robot_id, pid, uid, market, stock, money, revenue)
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_revenue (platform,qrobot_id,pid,uid,market,stock,money,revenue,deal_status,transaction_type) values ('%s',%d,'%s',%d,'%s','%s','%s','%s',%d,%d)" % (
    platform,
    robot_id, pid, uid, market, stock, money, revenue, 0,2)
    cur.execute(insert_sql)
    
def insertOrder(platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first,uuid, revenue, fee, amount, total,transaction_type):
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_order (type,platform,uid,order_id,qrobot_id,side,position,market,stock,money,deal_money,deal_amount,price,order_status,is_first,pid,revenue,fee,amount,total,transaction_type) values (%d,'%s',%d,'%s',%d,%d,%d,'%s','%s','%s','%s','%s','%s',1,%d,'%s','%s','%s',%d,'%s',%d)" % (
        2,platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first, uuid,revenue, fee, amount, total,transaction_type)
    cursor, conn, count = cur.execute(insert_sql)
    return cursor.lastrowid
def updateValues(robot_id, uid, values_str):
    redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', values_str)
def updateValuess(robot_id, uid, values_str):
    redisbase.updaterobot(redis_content, robot_id, uid, 'values_strs', values_str)
def updateRevenue(robot_id, uid, revenue):
    redisbase.updaterobot(redis_content, robot_id, uid, 'revenue', revenue)
    
