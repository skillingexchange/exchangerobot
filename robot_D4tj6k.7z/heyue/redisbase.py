import redis
import time
from datetime import datetime
import json

redis_auth = ''


def getrids(db=0):
    pool = redis.ConnectionPool(host='127.0.0.1', port=6379, password=redis_auth, decode_responses=True, db=db)
    redis_content = redis.Redis(connection_pool=pool, decode_responses=True, password=redis_auth, db=db)
    return redis_content


# 获取某个列 返回字典
def getlitall(content, name, keys):
    listname = content.keys(name)
    if not listname:
        return {}
    arr = {}
    ke = 0
    for v in listname:
        val = content.hmget(v, keys)
        if not val:
            continue
        data = dict(zip(keys, val))
        if data['transaction_type'] == 1:
            continue
        arr[ke] = data
        ke += 1
    return arr


# 获取某个列 返回字典
def getlitdocumentary(content, name, keys):
    listname = content.keys(name)
    if not listname:
        return {}
    arr = {}
    ke = 0
    for v in listname:
        val = content.hmget(v, keys)
        if not val:
            continue
        data = dict(zip(keys, val))
        arr[ke] = data
        ke += 1
    return arr


# 获取某个列 返回字典
def getlitbian(content, name, keys):
    listname = content.keys(name)
    if not listname:
        return {}
    arr = {}
    ke = 0
    for v in listname:

        val = content.hmget(v, keys)

        # if val=='huobi':
        #     continue
        if not val:
            continue
        data = dict(zip(keys, val))
        if data['transaction_type'] == 1:
            continue
        arr[ke] = data
        ke += 1
    return arr


# 获取机器人列表
def getrobotall():
    listname = robot_redis.keys('user_contract_*')
    if not listname:
        # redis没有数据去数据库查询一次
        from database import MySqLHelper
        list = MySqLHelper().fetchall('SELECT * from jl_quant_robot where transaction_type=2')
        # print(list)
        #     先同步到redis 再返回list信息
        for k in list.keys():
            v = list[k]
            robot_id = v['id']
            uid = v['uid']
            for key in v.keys():
                value = v[key]
                if type(value) == bytes:
                    value = str(value, encoding='utf8')
                robot_redis.hset('user_contract_' + str(uid) + '_' + str(robot_id), key, str(value))
        return list
    else:
        keys = robot_redis.hkeys(listname[0])
        keys = ['id', 'uid', 'show_msg', 'revenue', 'cover_grid', 'new', 'transaction_type', 'last_cover_buy',
                'low_buy', 'cover_info', 'sub_warehouse', 'status', 'cd_key', 'now_round_num', 'now_round_num_s',
                'round_num', 'type', 'first_order_value', 'is_clean', 'top_buy', 'run_status', 'ctime',
                'stop_profit_callback_rate', 'stop_profit_rate', 'cover_grid_back', 'is_double', 'is_trend',
                'market_id', 'id', 'platform', 'recycle_status', 'cover_callback_rate', 'cover_rates', 'open_risk',
                'cover_rate', 'order_status', 'clean_long', 'clean_short', 'max_order_count', 'values_strs',
                'sell_status', 'amount_value_short', 'amount_value_long', 'is_bucang_short', 'is_bucang_long',
                'values_str', 'process_id', 'synchro', 'clean_amount_long', 'clean_amount_short', 'dt_top_id',
                'is_follow']
        return getlitall(robot_redis, 'user_contract_*', keys)


# 获取某一个机器人配置
def getRobotInfo(robot_id, uid, type_robot=1):
    if type_robot == 2:
        str_robot = 'user_contract_' + str(uid) + '_' + str(robot_id)
        str_set = 'user_contract_'
    else:
        str_robot = 'user_robot_' + str(uid) + '_' + str(robot_id)
        str_set = 'user_robot_'
    listname = robot_redis.keys(str_robot)
    if not listname:
        # redis没有数据去数据库查询一次
        from database import MySqLHelper
        list = MySqLHelper().fetchall('SELECT * from jl_quant_robot where transaction_type=2')
        # print(list)
        #     先同步到redis 再返回list信息
        for k in list.keys():
            v = list[k]
            robot_id = v['id']
            uid = v['uid']
            for key in v.keys():
                value = v[key]
                if type(value) == bytes:
                    value = str(value, encoding='utf8')
                robot_redis.hset(str_set + str(uid) + '_' + str(robot_id), key, str(value))
        return list
    else:
        keys = robot_redis.hkeys(listname[0])
        keys = ['id', 'uid', 'show_msg', 'revenue', 'cover_grid', 'new', 'transaction_type', 'last_cover_buy',
                'low_buy', 'cover_info', 'sub_warehouse', 'status', 'cd_key', 'now_round_num', 'now_round_num_s',
                'round_num', 'type', 'first_order_value', 'is_clean', 'top_buy', 'run_status', 'ctime',
                'stop_profit_callback_rate', 'stop_profit_rate', 'cover_grid_back', 'is_double', 'is_trend',
                'market_id', 'id', 'platform', 'recycle_status', 'cover_callback_rate', 'cover_rates', 'open_risk',
                'cover_rate', 'order_status', 'clean_long', 'clean_short', 'max_order_count', 'values_strs',
                'sell_status', 'amount_value_short', 'amount_value_long', 'is_bucang_short', 'is_bucang_long',
                'values_str', 'process_id', 'synchro', 'clean_amount_long', 'clean_amount_short', 'dt_top_id',
                'is_follow']
        return getlitall(robot_redis, str_robot, keys)[0]


def getdocumentarystr(robot_str):
    keys = ['robot_id']
    return getlitdocumentary(robot_redis, robot_str, keys)


# 获取跟单机器人id
def getfollowstr(robot_id):
    data = robot_redis.hgetall('new_follow_' + str(robot_id))
    return data


# 判断当前机器人下是否有跟单策略
def checkDtTopId(robot_id, uid, methods_type, hand_movement_money=0, now_outgoing_time=0, cover_key_first=0,
                 cover_key_last=0, grid=0, now_outgoing_times=0, position=0):
    data = {
        'hand_movement_money': hand_movement_money,
        'now_outgoing_times': now_outgoing_times,
        'cover_key_first': cover_key_first,
        'cover_key_last': cover_key_last,
        'grid': grid,
        'methods_type': methods_type,
        'position': position,
        'uid': int(uid),
        'robot_id': int(robot_id),
    }
    tasks = []
    robot_data = getfollowstr(robot_id)
    for roid in robot_data.keys():
        data['robot_id'] = int(roid)
        data['uid'] = int(robot_data[roid])
        robot_redis.hset('new_documentary_robot_' + str(roid) + '_' + str(position) + '_' + str(methods_type),
                         'robot_id', json.dumps(data))
    return True


# 删除记录
def delete_documentary(robot_id, position, methods_type):
    robot_redis.delete('new_documentary_robot_' + str(robot_id) + "_" + str(position) + "_" + str(methods_type))
    return True


# 获取币安机器人列表
def getrobotbian():
    listname = robot_redis.keys('user_contract_*')
    if not listname:
        #         redis没有数据去数据库查询一次
        from database import MySqLHelper
        list = MySqLHelper().fetchall('SELECT * from jl_quant_robot where transaction_type=2')
        # print(list)
        # 先同步到redis 再返回list信息
        for k in list.keys():
            v = list[k]
            robot_id = v['id']
            uid = v['uid']
            for key in v.keys():
                value = v[key]
                if type(value) == bytes:
                    value = str(value, encoding='utf8')
                robot_redis.hset('user_contract_' + str(uid) + '_' + str(robot_id), key, str(value))
        return list
    else:
        keys = ['uid', 'show_msg', 'revenue', 'cover_grid', 'new', 'last_cover_buy', 'low_buy', 'cover_info',
                'sub_warehouse', 'status', 'cd_key', 'now_round_num', 'now_round_num_s', 'round_num', 'type',
                'first_order_value', 'is_clean', 'top_buy', 'run_status', 'ctime', 'stop_profit_callback_rate',
                'stop_profit_rate', 'cover_grid_back', 'is_double', 'is_trend', 'market_id', 'id', 'platform',
                'recycle_status', 'cover_callback_rate', 'cover_rates', 'open_risk', 'clean_long', 'clean_short',
                'cover_rate', 'order_status', 'max_order_count', 'sell_status', 'amount_value_short',
                'amount_value_long', 'is_bucang_short', 'is_bucang_long', 'values_str', 'values_strs', 'process_id',
                'synchro', 'clean_amount_long', 'clean_amount_short', 'dt_top_id', 'is_follow']
        return getlitbian(robot_redis, 'user_contract_*', keys)


# #     更新redis机器人对应msg
# def updatetobotmsg(content, robot_id, msg):
#     content.hset('user_robot_'+ str(robot_id), 'show_msg', msg)
# #     加入redis需更新队列
#     sql = "update jl_quant_robot set show_msg = '%s' where id = %d" % (msg, robot_id)
#     content.hset('update_sql','robot_msg_'+str(robot_id), sql)
#     return True
# #     更新机器人value信息
# def updaterobotvalues(content, robot_id, values_str):
#     content.hset('user_robot_' + str(robot_id), 'values_str', values_str)
#     sql = "update jl_quant_robot set values_str = '%s' where id = %d" % (values_str, robot_id)
#     content.hset('update_sql', 'robot_values_' + str(robot_id), sql)
#     return True
# # 机器人更新状态
# def updaterobotstatus(content, robot_id, status):
#     content.hset('user_robot_' + str(robot_id) , 'status', status)
#     sql = "update jl_quant_robot set status = "+status+" where id = %d" % robot_id
#     content.hset('update_sql', 'robot_status_' + str(robot_id), sql)
#     return True
# # 机器人更新盈利
# def updaterobotrevenue(content, robot_id, revenue):
#     content.hset('user_robot_' + str(robot_id) , 'revenue', revenue)
#     sql = "update jl_quant_robot set revenue = '%s' where id = %d" % (
#         revenue, robot_id)
#     content.hset('update_sql', 'robot_revenue_' + str(robot_id), sql)
#     return True
# # 更新清仓状态
# def updaterobotclean(content, robot_id, clean):
#     content.hset('user_robot_' + str(robot_id) , 'status', clean)
#     sql = "update jl_quant_robot set is_clean = " + str(clean) + " where id = %d" % robot_id
#     content.hset('update_sql', 'robot_clean_' + str(robot_id), sql)
#     return True
# 更新机器人单字段信息
def updaterobot(content, robot_id, uid, key, value):
    robot_redis.hset('user_contract_' + str(uid) + '_' + str(robot_id), key, value)
    sql = "update jl_quant_robot set `" + str(key) + "` = '" + str(value) + "' where id=%d" % (int(robot_id))
    content.hset('update_sql', 'robot_' + str(key) + '_' + str(robot_id), sql)
    return True


# 更新机器人信息字典模式
def updaterobotkeys(content, robot_id, uid, data):
    keys = data.keys()
    for v in keys:
        va = data[v]
        robot_redis.hset('user_contract_' + str(uid) + '_' + str(robot_id), v, va)
        sql = "update jl_quant_robot set `" + str(v) + "` = '" + str(va) + "' where id=%d" % (int(robot_id))
        content.hset('update_sql', 'robot_' + str(v) + '_' + str(robot_id), sql)
    return True


# 插入日志
def insertlog(content, robot_id, platform, uid, log, tid):
    log_redis = getrids(2)
    # 先获取上一次内容防止重复插入
    ss = 'user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id)
    data = log_redis.lrange(ss, 0, 6)
    for iterm in data:
        if str(iterm) == str(log):
            print('日志已经记录')
            return True
    last = log_redis.lindex('user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id), 1)
    lasttwo = log_redis.lindex('user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id), 3)
    if str(last) == str(log) or (('继续上涨' in str(last) and '继续上涨' in str(log)) or (
            '继续下跌' in str(last) and '继续下跌' in str(log))):
        return True
    if str(lasttwo) == str(log) or (('继续上涨' in str(lasttwo) and '继续上涨' in str(log)) or (
            '继续下跌' in str(lasttwo) and '继续下跌' in str(log))):
        return True
    log = log.replace("'", "\'")
    now_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_redis.lpush('user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id), log, str(now_time))
    now_len = log_redis.llen('user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id))
    if now_len > 100000:
        # 超过10W删除其他后面的
        log_redis.ltrim('user_log_' + str(platform) + '_contract_' + str(uid) + '_' + str(robot_id), 100000, -1)

    # 以列表长度作为位数 否则insert会被覆盖
    sql = "('%s',%d,%d,'%s','%s',%d)" % (platform, int(uid), int(robot_id), log, now_time, tid)
    content.hset('insert_log_sqls', 'robot_log_' + str(robot_id) + '_' + str(now_len), sql)
    return True


# 插入盈利记录
def insertrevene(content, platform, robot_id, pid, uid, market, stock, money, revenue):
    # 先获取上一次内容防止重复插入
    last = content.lindex('user_revenue_' + str(uid) + '_' + str(robot_id), 0)
    if last == revenue:
        return True
    now_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    content.rpush('user_log_' + str(platform) + '_' + str(uid) + '_' + str(robot_id), str(now_time), revenue)
    # 以列表长度作为位数 否则insert会被覆盖
    lenth = content.llen('user_revenue_' + str(uid) + '_' + str(robot_id))
    sql = "('%s',%d,'%s',%d,'%s','%s','%s','%s',%d,'%s')" % (
    platform, int(robot_id), pid, int(uid), market, stock, money, revenue, 0, now_time)
    content.hset('insert_revenue_sql', 'robot_revenue_' + str(robot_id) + '_' + str(lenth), sql)
    return True


redis_content = getrids()
redis_test = getrids(8)
robot_redis = getrids(1)