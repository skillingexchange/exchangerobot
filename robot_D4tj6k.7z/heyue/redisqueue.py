import redisbase
from database import MySqLHelper
import time
def runsqlinfo():
    # 连击redis连接池
    content = redisbase.redis_content
    robot_content = redisbase.robot_redis
    log_content = redisbase.getrids(2)
    log_contents = redisbase.getrids(15)
    # 连接sql连接池
    sql_content = MySqLHelper()
    sql = log_sql = revenue_sql = ''
    # 获取分两步，先获取需要插入的，再获取更新的，可能插入之后会有更新所以先获取插入语句
    # log
    log_keys = log_contents.hkeys('insert_log_sqls')
    print(log_keys)
    if len(log_keys)>100:
        log_keys = log_keys[0:100]
    if len(log_keys)>0:
        log_sql = "insert into jl_quant_robot_log (platform,uid,qrobot_id,content,ctime,transaction_type) values "
        for key in log_keys:
            log_sql += str(log_contents.hget('insert_log_sqls', key)) + ','
        
    elif len(log_keys)<100:
        log_keys2 = log_content.hkeys('insert_sql')
        if len(log_keys2) > 0:
            less = 100-len(log_keys)
            log_keys2 = log_keys2[0:less]
            if log_sql!='':
                for key in log_keys2:
                    log_sql += str(log_content.hget('insert_log_sqls', key)) + ','
            else:
                log_sql = "insert into jl_quant_robot_log (platform,uid,qrobot_id,content,ctime,transaction_type) values "
                for key in log_keys2:
                    log_sql += str(log_content.hget('insert_log_sqls', key)) + ','
    if log_sql != '':
        log_sql = log_sql[0:-1]
        log_sql += ';'
    print(log_sql)
    # if len(update_keys)>0:
    #     for key in update_keys:
    #         sql += str(content.hget('update_sql', key)) + ';'
    # 执行sql
    if log_sql != '':
        try:
           sql_content.execute(log_sql)
           if len(log_keys) > 0:
                for key in log_keys:
                    content.hdel('insert_log_sqls',key)
        except Exception as e:
            if len(log_keys) > 0:
                for key in log_keys:
                    content.hdel('insert_log_sqls',key)
            pass
    else:
        print('empty')
    print('over')
    return
if __name__=='__main__':
    times = 3
    while True:
        runsqlinfo()
        time.sleep(times)