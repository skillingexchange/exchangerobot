import aiohttp
import asyncio
import threading
import log
from decimal import Decimal, ROUND_DOWN
import math
import time
import json
import uuid
import ccxt.async_support as ccxt
import ccxt as ccxt_all
import common
from database import MySqLHelper
import redisbase
from logger import logger
import random
import requests
import api
import heyue
import nest_asyncio
import inspect
nest_asyncio.apply()
global list_times,last_time,list_timest,last_timet,iplist
iplist={}
list_times = 0
list_timest= 0
last_timet=int(time.time()*1000)
last_time = int(time.time()*1000)
brokerid = 'ac9d0764ab8dBCDE'



redis_content = redisbase.getrids(15)



def getlisttimes():
    global list_times,last_time,iplist
    iplist=api.getapilist()
    if iplist == False:
        return False
    now = int(time.time()*1000)
    if now-last_time<=500:
        list_times += 1
    if list_times> (len(iplist)-1):
        list_times = 0
    last_time = now
    print('使用线路'+iplist[list_times])

async def test(direction,symbol, api_info,type_all,lever,platfrom='binance'):
    ret = {}
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        iplist=api.getapilist()
        exchange_class = getattr(ccxt, exchange_id)
        if int(type_all) == 0:
            global list_timest, last_timet
            now = int(time.time() * 1000)
            if now - last_timet <= 500:
                time.sleep(float((500 - (now - last_timet)) / 1000))
            last_timet = now
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        else:
            resul = getlisttimes()
            if resul == False:
                return False
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'aiohttp_proxy': iplist[0],
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        if exchange_id == 'binance':
            return
        else:
            info_bili = await exchange.private_get_account_positions({"instId":symbol.upper()+'SWAP',"instType":"SWAP"})
            return True
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    return ret

def set_lever(direction,symbol, api_info,type_all,lever,platfrom='binance'):
    ret = {}
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        iplist=api.getapilist()
        exchange_class = getattr(ccxt_all, exchange_id)
        if int(type_all) == 0:
            global list_timest, last_timet
            now = int(time.time() * 1000)
            if now - last_timet <= 500:
                time.sleep(float((500 - (now - last_timet)) / 1000))
            last_timet = now
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        else:
            resul = getlisttimes()
            if resul == False:
                return False
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'aiohttp_proxy': iplist[0],
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        if exchange_id == 'binance':
            return
        else:
            direction = 'LONG' if direction == 1 else 'SHORT'
            result = {
                'instId': symbol.upper()+'SWAP',  # 产品ID
                'mgnMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                # 'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'lever': lever,  # 数量
            }
            re=exchange.private_post_account_set_leverage(result)
            return True
    except Exception as e:
        print(e)
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    return ret


# 主函数
def strategy(robot, market_info, api_info,type_all):
    
    return
    # 交易所
    platform_source = robot['platform']
    platform = platform_source+'_contract'
    # 交易对 如：BTCUSDT     注意这里的交易对是不需要加/的
    if platform_source == 'binance':
        market = market_info['stock'] + market_info['money']
    else:
        market = market_info['stock'] + "-" + market_info['money'] + "-" + str(market_info['instType'])
    # 机器人id# 用户id
    robot_id = int(robot['id'])
    uid = int(robot['uid'])

    print(str(robot_id)+'机器人单向开始做单')
    # 机器人状态
    loops = asyncio.get_event_loop()
    # 获取交易对的实时价格
    tick_price_str = common.ContractGetTick(api_info, market, platform_source)
    tick_price = None
    if tick_price_str:
        tick_price = float(tick_price_str)
    if tick_price is None:
        log.get_logger(robot['id']).error('获取交易对' + market + "实时价格失败")
        return
    if robot['cover_info'] and not robot['cover_info'] is None and robot['cover_info'] != 'None':
        cover_info = json.loads(robot['cover_info'])
    else:
        cover_info = {}
    # 清仓策略
    if robot['cover_grid'] and not robot['cover_grid'] is None and robot['cover_grid'] != 'None' and robot['cover_grid'] != '':
        cover_grid = json.loads(robot['cover_grid'])
        nu = 5
        i = 0
        ke = []
        while i < len(cover_grid):
            ke.append(nu)
            i += 1
            nu += 1
        cover_grid = dict(zip(ke, cover_grid))
    else:
        cover_grid = None
    # 网格止盈回调
    if robot['cover_grid_back'] and not robot['cover_grid_back'] is None and robot['cover_grid_back'] != 'None' and robot['cover_grid_back'] != '':
        cover_grid_back = int(float(robot['cover_grid_back']))
    else:
        cover_grid_back = None
    # 合约全仓止盈价格回调
    stop_profit_callback_rate = float(robot['stop_profit_callback_rate'])
    # 合约参数设置
    values_str = robot['values_str']
    # 策略设置判断是否为循环策略还是单次策略
    recycle_status = int(robot['recycle_status'])
    # 策略配置 # 交易对最大精度 # 交易对最小精度
    minQtys=  common.minQtys(market,platform_source)
    # 策略配置 # 交易对最大精度 # 交易对最小精度
    maxQty = 0 if 'maxQty' not in minQtys.keys() else minQtys['maxQty']
    minQty = 0 if 'minQty' not in minQtys.keys() else minQtys['minQty']
    minQty = float(minQty)
    common.set_listenkey(api_info,uid,platform_source)
    # 首单是否加倍
    is_double = int(float(robot['is_double']))
    # 做空还是做多   1.多 0.空 2多空
    direction = int(float(robot['is_trend']))
    # 盈利率 如0.5% 合约全仓止盈比例
    profit = float(robot['stop_profit_rate'])
    # 止损率 如50%(损失达到了这么多就是自动卖出，最好止损率要大于止盈率，不然 永远只会止损不会止盈)
    stop_loss = float(robot['cover_callback_rate'])
    # 单个投入(单笔下单金额)(USDT) # 杠杆
    first_order_money = float(robot['first_order_value'])
    lever = cover_grid_back
    cover_rate = float(robot['cover_rate'])
    # 风险控制 0.不开 1.开启# 最小买入金额# 最大买入金额
    risk_management = int(float(robot['open_risk']))
    min_price = float(Decimal(str(robot['low_buy'])))
    max_price = float(Decimal(str(robot['top_buy'])))
    # 最大仓数
    max_house_number = int(robot['max_order_count'])
    # 是否循环启动 1.循环 2.单次
    if int(robot['recycle_status']) == 1:
        is_loop =1
    else:
        is_loop =2
    # 是否清仓
    is_clean = int(robot['is_clean'])
    # 总共循环多少次
    loop_times = int(robot['round_num'])
    # 当前循环第几次
    now_loop = int(robot['now_round_num'])
    if robot['amount_value_short'] is None:
        robot['amount_value_short']  = 0
    if robot['is_bucang_short'] is None:
        robot['is_bucang_short']  = 0
    if robot['amount_value_long'] is None:
        robot['amount_value_long']  = 0
    if robot['is_bucang_long'] is None:
        robot['is_bucang_long']  = 0
    if values_str:
        
        values_str = json.loads(values_str)
        if not 'clean_short' in robot.keys() and not robot['clean_short'] is None:
            clean_short = int(robot['clean_short'])
        else:
            clean_short =0
        if not 'clean_long' in robot.keys() and not robot['clean_long'] is None:
            clean_long = int(robot['clean_long'])
        else:
            clean_long =0
        # 做单方向
        if values_str['position']=='long' or values_str['position']=='LONG':
            direction = 1
        else:
            direction = 0
        # 补仓跌幅和倍数参数

        cover_rates = robot['cover_rates']
        if cover_rates:
            cover_rates_list = json.loads(cover_rates)
            if  isinstance(cover_rates_list, list):
                order_count = values_str.get('order_count', 1)
                if (len(cover_rates_list) - 1) >= order_count:
                    cover_rate = cover_rates_list[order_count]

        if type(cover_rate) == int:
            cover_rate = {}
            cover_rate['multiple'] = (order_count+1)*2
        symbol = values_str['symbol']
        # 总投入
        deal_money = float(values_str['deal_money'])
        # 总购买了多少币
        deal_amount = float(values_str['deal_amount'])
        # 首单的订单号
        order_id = values_str['order_id']
        # 上次购买单价
        trend_side = int(values_str['trend_side'])
        last_price = float(values_str['last_price'])
        base_price = float(values_str['base_price'])
        if values_str['margin_price'] is None or values_str['margin_price']=='':
            margin_price = 1
        else:
            margin_price = float(values_str['margin_price'])
        up_price = float(values_str['up_price'])
        # 持仓数量
        executedQty = int(values_str['executedQty'])
        # 当前仓数
        house_number = int(values_str['order_count'])
        qiang = common.getQiang(api_info,uid,platform_source,market,direction)
         # 重交易所获取收益和手续费
        if base_price !=0:
            # TODO: write code...
            if direction !=1:
                values_str['revenue'] =(base_price-tick_price) * lever/ base_price * margin_price
            else:
                values_str['revenue'] = (tick_price - base_price) * lever / base_price * margin_price
            # 收益  (尚未扣除手续费)
        else:
            values_str['revenue']=0
        if qiang != False:
            values_str['strong_pay'] = qiang['strong_pay']
            values_str['margin_lilv'] = qiang['margin_lilv']
            values_str['margin_price'] = qiang['margin_price']
        # 收益计算
        redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', json.dumps(values_str))
        common.set_lever(direction,market,api_info,type_all,lever,platform_source)
        # 清仓处理卖出所有的合约张数，
        if int(is_clean) == 1:
            print('单项做单开始清仓卖出'+str(executedQty))
            loops.run_until_complete(clean_order_sell(values_str['revenue'],base_price, direction, executedQty, 2, api_info,market_info, market, robot_id, uid, lever,house_number,1 ,0, platform_source,type_all))
            cleanFinish(robot_id, uid)
            return
        # 止损,判断全仓是否到达止损，达到止损后就开始卖出 获取全仓止损率
        rate = float(float(float(tick_price) - float(base_price)) / float(base_price)) * 100
        if direction != 1:
            # 开空   需要将负数转为正数   正数转为负数  因为开空的情况和开多的情况是相反的
            rate = rate * -1
        print('比例-------------------------------------------'+str(rate))
        print(now_loop)
        print(float(tick_price) > float(base_price))
        # 判断仓位是否到达止盈和止损
        if direction==1:
            tick_ba=float(tick_price) > float(base_price)
            price_allback = tick_price > up_price
        else:
            tick_ba=float(base_price) > float(tick_price)
            price_allback = tick_price < up_price
        if tick_ba:
            # 机器人达到止盈后判断是否到达止盈回调 并判断是否开始止盈
            if trend_side == 0 or trend_side == 2:
                if float(rate) >= float(profit):
                    print('机器人达到止盈')
                    values_str['up_price'] = tick_price
                    values_str['trend_side'] =1
                    updateValues(robot_id,uid,json.dumps(values_str))
                    insertLog(platform_source, robot_id, uid, u"达到止盈率 ,当前价格 %s" %(str(Decimal(str(tick_price)))))
                    updateMsg(robot_id, uid, u"达到止盈率 ,当前价格 %s" %(str(Decimal(str(tick_price)))))
            print('机器人达到止盈后判断是否到达止盈后 并判断是否开始止盈')
            if trend_side ==1:
                if price_allback:
                    print('机器人达到止盈后继续上涨')
                    values_str['up_price'] = tick_price
                    # 达到止盈后继续上涨
                    updateValues(robot_id, uid, json.dumps(values_str))
                    insertLog(platform_source, robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %(str(Decimal(str(tick_price)))))
                    updateMsg(robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %(str(Decimal(str(tick_price)))))
                else:
                    down_num = abs(up_price - tick_price)
                    down_rate = down_num * 100 / up_price
                    print('判断是否到达止盈回调，到达止盈回调后合约开始卖出')
                    # 判断是否到达止盈回调，到达止盈回调后合约开始卖出
                    print(down_rate)
                    print(stop_profit_callback_rate)
                    print(down_rate >= stop_profit_callback_rate)
                    if down_rate >= stop_profit_callback_rate:
                        # 改变全仓为开始卖出状态
                        order_profit(base_price, direction, executedQty, 2, api_info, market,market_info,  robot_id, uid,lever ,house_number, 2, is_loop,now_loop,platform_source)
                        insertLog(platform_source, robot_id, uid,u"第" + str(now_loop) + "次循环机器人，达到设定的止盈回调率:" + str(stop_profit_callback_rate) + "%,当前:" + str(round(down_rate,2)) + "%")
                        updateMsg(robot_id, uid, u"第" + str(now_loop) + "次循环机器人，达到设定的止盈回调率:" + str(stop_profit_callback_rate) + "%,当前:" + str(round(down_rate,2)) + "%")

        else:
            if float(abs(rate)) >= stop_loss:
                print('止损')
                # 改变分仓为卖出中  这里避免进程不一样导致卖出中   进入了下一次循环  在卖的情况
                order_profit(base_price, direction, executedQty, 2, api_info, market,market_info, robot_id, uid,lever ,house_number, 2 , is_loop,now_loop,platform_source)
                insertLog(platform_source, robot_id, uid,u"第" + str(now_loop) + "次循环机器人达到设定的止损率:" + str(stop_loss) + "%,当前:" + str(abs(round(rate,2))) + "%")
                updateMsg(robot_id, uid, u"第" + str(now_loop) + "次循环机器人达到设定的止损率:" + str(stop_loss) + "%,当前:" + str(abs(round(rate,2))) + "%")
                # 主进程不会等待子线程，当主线程结束，子线程就会被强制停止运行并回收
                # task.setDaemon(True)
                # 启动一个子线程
                # task.start()
                return



        # 已经开仓的数量不超过最大开仓数量限制    就能开新仓 补仓
        print('补仓次数'+str(house_number))
        print('最大补仓次数'+str(max_house_number))
        if house_number < max_house_number:
            if values_str['order_finish'] == 1:
                return
            # 当前价格如果超过了最大买入金额 和最小买入金额  就不进行开仓  只进行平仓
            # 下一句代码解释:如果没有开启了风险控制或者
            # 开启了风险控制并当前金额在最小和最大之间就进行买入
            # print(risk_management == 0 or (risk_management == 1 and min_price <= tick_price <= max_price))
            # print(min_price <= tick_price <= max_price)
            # print(str(min_price)+'--------------' + str(max_price))
            # print(risk_management)
            # exit()
            if risk_management == 0 or (risk_management == 1 and min_price <= tick_price <= max_price):
                # 补仓  开一个新的分仓马丁放在这个里面 判断趋势 是否执行补仓 价格需要大于补仓价格才能补仓
                result = open_provide(cover_rate['decline'], direction, tick_price, base_price)

                print('是否可以进行补仓'+str(result))
                if result:
                    # 开新仓   使用进程开启一个新的进程  单独去处理加仓的问题
                    # 加仓数量  将usdt转换为对应的币    注意杠杆
                    if platform == 'okex_contract':
                        # 开仓时设置的张数，不需要转换
                        usdt_total = first_order_money * cover_rate['multiple']
                        amount = common.usdtSymbol(usdt_total, tick_price, lever, minQty)
                    else:
                        usdt_total = first_order_money * cover_rate['multiple']
                        amount = common.usdtSymbol(usdt_total, tick_price, lever, minQty)
                    print("第" + str(now_loop) + "次循环机器人达到设定的补仓比例")
                    # 已经达到止盈   卖出  进行收益处理   注意这里也要用多线程去处理
                    insertLog(platform_source, robot_id, uid, u"第" + str(now_loop) + "次循环机器人达到设定的补仓比例:" + str(round(cover_rate['decline'],2)))
                    updateMsg(robot_id, uid, u"第" + str(now_loop) + "次循环机器人达到设定的补仓比例:" + str(round(cover_rate['decline'],2)))
                    # 仓数加1  赋值到另一个变量  避免影响下面的数据
                    house_num = house_number
                    # 注意这里是通过异步进程去处理的   那么就会出现一个时间上的问题  需要先将主仓里面的仓数先加上  在在进程里面失败扣除
                    loops.run_until_complete(order_scale(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_num, first_order_money, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
                    print('加仓')

        if 'is_bucang_short' in robot.keys() and str(robot['is_bucang_short'])=='1' and int(robot['amount_value_short'])>0:
            amount = int(robot['amount_value_short'])
            amount = common.usdtSymbol(amount, tick_price, lever, minQty)
            loops.run_until_complete(order_scales(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_number, first_order_money, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"is_bucang_short": 0, "amount_value_short": 0})
        if 'is_bucang_long' in robot.keys() and str(robot['is_bucang_short'])=='1' and int(robot['amount_value_long'])>0:
            amount = int(robot['amount_value_long'])
            amount = common.usdtSymbol(amount, tick_price, lever, minQty)
            loops.run_until_complete(order_scales(direction,values_str, amount, 1, api_info, market,market_info, robot_id, uid, house_number, first_order_money, deal_money, deal_amount,cover_info,max_house_number , type_all ,lever,platform_source))
            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"is_bucang_long": 0, "amount_value_long": 0})

    else:
        print('进入首单买入，计算是否开启风险控制 ，并判断是否买入')
        # 多次循环# 超过最大循环次数了  清空数据  关闭机器人  关闭运行进程  删除进程id
        if is_loop == 1 and loop_times <= now_loop:
            disableRobot(robot_id, uid)
            runDisableRobot(robot_id, uid)
            insertLog(platform_source, robot_id, uid, u"策略达到最大循环次数(" + str(loop_times) + "次)，停止策略，如需重新执行，请重新启动")
            updateMsg(robot_id, uid, u"策略达到最大循环次数(" + str(loop_times) + "次)，停止策略，如需重新执行，请重新启动")
            return
        # 第几次循环
        loop = int(now_loop) + int(1)
        if risk_management == 0 or (risk_management == 1 and min_price <= tick_price <= max_price):
            # 订单每第一次开始买入设置杠杆倍数
            ret = common.set_lever(direction,market,api_info,type_all,lever,platform_source)
            if ret!=True:
                if ret['code'] == '50114':
                    ret['msg'] = '无效的授权,api秘钥未授权'
                if ret['code'] == '59102':
                    ret['msg'] = '杠杆倍数超过最大杠杆倍数，请重新调整杠杆倍数'
                if ret['code'] == '59108':
                    ret['msg'] = '杠杆倍数过低，账户中保证金不足，请重新调整杠杆倍数'
                if ret['code'] == '59107':
                    ret['msg'] = '当前业务存在全仓挂单，请撤销所有挂单后进行杠杆倍数修改'
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, u'首单开单失败 : ' + str(ret['msg']))
                insertLog(platform_source, robot_id, uid, u"第" + str(loop) + "次循环首单开单失败" + str(ret['msg']))
                return
            # 开仓数量  将对应的usdt转为要买入的对应的交易对数量
            if platform == 'okex_contract':
                if int(is_double)==1:
                    first_order_money = float(first_order_money) * 2
                amount = int(common.usdtSymbol(first_order_money, tick_price,lever, minQty))
            else:
                if int(is_double)==1:
                    first_order_money = float(first_order_money) * 2
                amount = int(common.usdtSymbolBinance(first_order_money, tick_price,lever, minQty))
            if amount <= 0:
                disableRobot(robot_id, uid)
                # 保存日志 并退出
                insertLog(platform_source, robot_id, uid, u'单笔下单金额转换为' + str(market_info['stock']) + ",不足" + str(minQty) + str(market_info['stock']) + ",不能开单")
                updateMsg(robot_id, uid, u'单笔下单金额转换为不足1张,不能开单')
            else:
                print(amount)
                # 首单买入方法
                loops.run_until_complete(first_order_buy(direction, amount, 1, api_info, market,type_all,lever,loop,uid,robot_id,market_info,first_order_money,platform_source))
            
        else:
            # 当前价格不可开仓
            # 写入日志
            log.get_logger(robot['id']).info("当前单价超过风险控制价格,未能成功开仓")

# 多空函数
def strategy_three(robot,market_info,api_info,type_all):
    # 交易所
    robot_id= int(robot['id'])
    uid = int(int(robot['uid']))
    print(str(robot_id)+'机器人双向开始做单'+'-------------------------------------------------')
    platform_source = robot['platform']
    platform = platform_source + "_contract"
    # 是否循环启动 1.循环 2.单次
    if int(robot['recycle_status']) == 1:
        is_loop =1
    else:
        is_loop =2
    loop_times = int(robot['round_num'])
    values_str = robot['values_str']
    if 'values_strs' in robot.keys():
        values_strs = robot['values_strs']
    else:
        values_strs = '';
    if 'now_round_num_s' in robot.keys() and not robot['now_round_num_s'] is None:
        now_loop_two = int(robot['now_round_num_s'])
    else:
        now_loop_two =0
    if 'clean_short' in robot.keys() and not robot['clean_short'] is None:
        clean_short = int(robot['clean_short'])
    else:
        clean_short =0
    if 'clean_long' in robot.keys() and not robot['clean_long'] is None:
        clean_long = int(robot['clean_long'])
    else:
        clean_long =0
    # 网格止盈回调
    if robot['cover_grid_back'] and not robot['cover_grid_back'] is None and robot['cover_grid_back'] != 'None' and robot['cover_grid_back'] != '':
        lever = int(float(robot['cover_grid_back']))
    else:
        lever = None
    # 当前循环第几次
    now_loop_one = int(robot['now_round_num'])
    if platform_source == 'binance':
        market = market_info['stock'] + market_info['money']
    else:
        market = market_info['stock'] + "-" + market_info['money'] + "-" + str(market_info['instType'])
    loop=0
    if clean_short==2 and clean_long ==2:
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'now_round_num', 0)
        redisbase.updaterobot(redis_content, robot_id, uid, 'now_round_num_s', 0)
        disableRobot(robot_id,uid)
    common.set_listenkey(api_info,uid,platform_source)
    # if values_strs=='' and values_str=='':
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short', 0)
    #     redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long', 0)
    
    common.set_lever(0,market,api_info,type_all,lever,platform_source)
    if clean_short!=2:
        # print('关闭')
        short = heyue.positon_short(robot,market_info,api_info,type_all,loop)
    if clean_long!=2:
        # print('关闭')
        longs = heyue.positon_long(robot,market_info,api_info,type_all,loop)

    if int(robot['is_clean'])==1:
        disableRobot(robot_id,uid)

# 判断当前单价是否可以进行开仓
def open_provide(cover_rate, direction, present, last):
    """
    判断当前单价是否可以进行开仓
    :param direction: 做空还是做多   1.多 2.空
    :param last: 上次开仓价格
    :param cover_rate: 补仓跌幅
    :param present: 现价
    :return: int
    """
    # 计算下次开仓的最低价格
    # 如果是做多就是 价格下跌  做空是价格上涨
    # 计算这轮开仓的价格
    price = float(last) * float(cover_rate) / 100
    if direction == 1:
        price = float(last) - price
    else:
        price += float(last)
    print('补仓价格:'+str(price))
    print('现价'+str(present))
    # 做多的情况
    if direction == 1:
        # 当前价小于等于开仓价
        if present <= price:
            return True
        else:
            return False
    else:
        # 当前价大于等于开仓价
        if present >= price:
            return True
        else:
            return False

# 订单卖出 进行止盈
def order_profit(price, direction, executedQty, side, api_info, market,market_info, robot_id, uid, lever,house, type ,is_loop,now_loop=1,platform='binance',type_all = 0 ):
    """
    订单卖出 进行止盈 止损
    :param now_loop: 第几次循环
    :param price: 买入均价
    :param house: 第几仓
    :param platform: 交易所
    :param uid: 用户id
    :param robot_id: 机器人id
    :param direction: 空还是多
    :param executedQty: 数量
    :param side: 买还是卖
    :param api_info: api
    :param type: 卖出类型
    :param market: 交易对
    :return:
    """
    print('订单卖出')
    ret = SustainableOrder(direction, executedQty, side, api_info, market,type_all,lever)
    logger.info(ret)
    print('订单卖出成功开始记录订单信息')
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 订单号   348363948206282
        order_id = result['order_id']
        # 卖出价格
        sell_price = result['last_price']
        # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
        revenue = (float(sell_price) - float(price)) * float(result['executedQty'])
        if direction != 1:
            revenue = revenue * -1
        # 手续费
        fee = 0
        symbols=symbol.upper()+'SWAP'
        # 重交易所获取收益和手续费
        commission = common.orderServiceCharge(order_id, api_info, symbols)
        # 收益  (尚未扣除手续费)
        revenue = commission['revenue']
        # 手续费
        fee = commission['fee']
        # 收益扣除手续费
        revenue = float(revenue) - float(fee)
        # 订单入库
        money='USDT'
        symbol_side = side
        print(symbol_side)
        insertOrder(platform,uid, order_id, robot_id, 1,direction, market,market_info['stock'],market_info['money'],result['deal_money'], result['executedQty'], price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
        # 收益入库
        insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)
        
            
        # 修改redis数据
        # 判断循环次数，循环为零时表示清仓处理，需要重置循环
        if now_loop==0:
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        if type==1:
            insertLog(platform, robot_id, uid, u"清仓卖出成功：成交均价 %s,成交 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
            updateMsg(robot_id, uid, u"清仓卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        else:
            insertLog(platform, robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': int(now_loop)})
            updateMsg(robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        updateValues(robot_id, uid, '')
        updateRevenue(robot_id, uid, 0)
        
        if is_loop == 2:
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})

        # 记录日志
    else:
        if ret['code'] == -2019:
            # 账户余额不足
            ret['msg'] = '账户余额不足'
        if ret['code'] == 51202:
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == -2022:
            ret['msg'] = '订单被拒绝'
        if ret['code'] == 51001:
            ret['msg'] = '订单不存在'
        if ret['code'] == 51112:
            ret['msg'] = '平仓张数大于该仓位的可平张数'
        if type==1:
            updateValues(robot_id, uid, '')
            updateRevenue(robot_id, uid, 0)
            updateMsg(robot_id, uid, u'卖出成功')
            disableRobot(robot_id, uid)
        # TODO: write code...
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
        insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))
        updateMsg(robot_id, uid,u"机器人卖出失败" + str(ret['msg']))
        if is_loop == 2:
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
# 永续合约订单处理(合约)
def SustainableOrder(direction, amount, side, api_info, symbol,type_all, lever,platfrom='binance'):

    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        return binance_order_buy(exchange, symbol, side, direction, amount)
    else:
        loops = asyncio.get_event_loop()
        task = loops.create_task(okex5_order_buy(exchange, symbol, side, direction, amount))
        loops.run_until_complete(task)
        res = task.result()
        return res


# 订单购入  进行加仓
async def order_scale( direction,values_str ,amount, side, api_info, market, market_info ,robot_id, uid, house, first_order_money, deal_money, deal_amount,cover_info, max_house_number ,type_all,lever ,platform='binance'):
    """
    订单购入  进行加仓
    :param deal_amount: 已购入多少币
    :param first_order_money: 投入usdt
    :param deal_money: 已投入usdt
    :param house: 第几仓
    :param platform: 交易所
    :param uid: 用户id
    :param robot_id: 机器人id
    :param direction: 空还是多
    :param executedQty: 数量
    :param side: 买还是卖
    :param api_info: api
    :param market: 交易对
    :param cover_info: 分仓信息
    :return:
    """
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        return ''
    else:

        """
        okex5合约下单
        :param exchange: ccxt链接数据
        :param symbol: 交易对
        :param side: 开仓还是平仓  buy开  sell平
        :param direction: 方向 做空还是做多long 多 short 空
        :param amount: 数量
        :return:
        """
        ret = {}
        symbol=market
        result = {}
        resulf = {}
        symbols = symbol
        symbol = symbol.upper() + 'SWAP'
        resulf = {
            'instId': symbol,  # 产品ID
            'instType': 'SWAP',
        }
        ctVal = 1 
        clordId = brokerid + str(int(time.time()*10))+'heyue'
        # 获取合约币种公共信息
        try:
            public_result = await exchange.public_get_public_instruments(resulf)
            public_result = public_result['data'][0]
            ctVal = public_result['ctVal']
            result = {
                'instId': symbol,  # 产品ID
                'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                'clOrdId': clordId,  # 订单号
                'side': side.lower(),  # 方向 buy 买 sell 卖
                'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'ordType': 'market',  # 市价单
                'sz': int(amount),  # 数量
            }
            # result = await exchange.private_post_trade_order(result)
            result = await exchange.private_post_trade_order(result)
            result = result['data'][0]

            # result['ordId']=432231205587795974
            if result['ordId']:
                # 获取订单信息
                info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                logger.info(info)
                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                logger.info(info_bili)
                if info_bili['data']==[]:
                    info_bili={}
                    info_bili['liqPx']=0
                    info_bili['imr']=0
                    info_bili['mgnRatio']=0
                else:
                    info_bili = info_bili['data'][0]
                info = info['data'][0]
                while info['state'] == 'live':
                    time.sleep(1)
                    # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "ordId": result['ordId']})
                    info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                    info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                    info_bili = info_bili['data'][0]
                    info = info['data'][0]
                strs = {
                    'order_id': result['ordId'],  # 订单号
                    'first_order_price': info['avgPx'],  # 开仓价
                    'symbol': symbols,  # 交易对
                    'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                    'last_price': info['avgPx'],  # 平均成交价
                    'base_price': info['avgPx'],  # 基础价
                    'up_price': 0,  # 上涨价
                    'order_count': 0,  # 补仓次数
                    'down_price': 0,  # 下跌价
                    'trend_side': 0,  # 趋势
                    'is_clean':0, #清仓
                    'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx']) ,  # 成交金额USDT
                    'type': 'MARKET',  # 订单类型 MARKET市价单
                    'side': side,  # 方向 SELL 卖出 BUY买入
                    'position': info['posSide'],  # 做空还是多 空SHORT 多long
                    'direction': info['posSide'],
                    'time': '',  # 成交时间
                    'fee': info['fee'],  # 手续费
                    'lever':info['lever'],
                    'now_round_num':0,
                    'strong_pay':info_bili['liqPx'],# 预估强平价格
                    'margin_price':info_bili['imr'],# 保证金价格
                    'margin_lilv':info_bili['mgnRatio'],#保证金比例
                    'pid': 0,  # 线程id
                    'executedQty': float(info['sz']),  # 成交量
                    'order_finish': 0
                }
                ret['code'] = 1
                ret['data'] = strs
                ret['msg'] = ''
            else:
                # 开单失败
                ret['code'] = 0
                ret['data'] = {}
                ret['msg'] = '开单失败'
        except Exception as e:
            msg = json.loads(e.args[0].split(' ', 1)[1])
            ret['code'] = msg['data'][0]['sCode']
            ret['data'] = {}
            ret['msg'] = msg['data'][0]['sMsg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 第几仓
        values_str['order_count'] = house
        # 总投入了多少usdt
        values_str['deal_money'] = float(values_str['deal_money']) + float(result['deal_money'])
        # 计算总购买了多少币
        values_str['deal_amount'] = float(values_str['deal_amount']) + float(result['deal_amount'])
        # 持仓张数
        values_str['executedQty'] = int(values_str['executedQty']) + int(result['executedQty'])
        # 方向
        values_str['strong_pay'] = result['strong_pay']
        values_str['margin_price'] = result['margin_price']
        values_str['margin_lilv'] = result['margin_lilv']
        values_str['direction'] = direction
        values_str['pid'] = str(uuid.uuid4())
        # 全仓基础价格
        values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
        values_str['base_price'] = float(Decimal(float(values_str['base_price'])).quantize(Decimal('0.000000000')))
        values_str['order_count'] = values_str['order_count']+1
        # 开单成功
        pid = str(uuid.uuid4())
        result['fee'] = abs(float(result['fee']))
        # 订单入库
        money = 'USDT'

        if direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platform, uid, result['order_id'], robot_id, 2,symbol_direction, market, market_info['stock'],market_info['money'], result['deal_money'], amount, result['last_price'], 2,pid, 0, result['fee'],values_str['order_count'], result['deal_money'],2)
        # 修改redis数据   需要将这一仓的数据覆盖上一仓的数据 保证下一次加仓的数据正确性
        # 记录分仓的数据
        cover_key = values_str['order_count']
        cover_info[cover_key] = {
            'price': result['last_price'],
            'last_price': result['last_price'],
            'is_out': 0,
            'out_price': deal_amount,
            'deal_amount': deal_amount,
            'buy_oid': result['order_id'],
        }
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {"cover_info": json.dumps(cover_info)})
        # 修改补仓后全仓信息
        result['trend_side'] = 0
        if result['order_count'] >= max_house_number:
            # 只能等盈利
            result['order_finish'] = 1
            insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " % result['order_count'])
        updateValues(robot_id, uid, json.dumps(values_str))
        insertLog(platform, robot_id, uid, u"基准价调整为: %s " % values_str['base_price'])
        updateMsg(robot_id, uid,u"基准价调整为: %s " % values_str['base_price'])
    else:
        if ret['code'] == '51121':
            ret['msg'] = '下单张数应为一手张数的倍数'
        if ret['code'] == '20221':
            ret['msg'] = '订单被拒绝'
        if ret['code'] == '51202':
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == '51008':
            ret['msg'] = '委托失败，账户可用余额不足'
        if ret['code'] == '51603':
            ret['msg'] = '委托失败'
        # 返回仓数
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:加仓失败')
        insertLog(platform, robot_id, uid, u"机器人加仓失败" + str(ret['msg']))
        updateMsg(robot_id, uid,u"机器人加仓失败" + str(ret['msg']))


async def order_scales( direction,values_str ,amount, side, api_info, market,market_info, robot_id, uid, house, first_order_money, deal_money, deal_amount,cover_info, max_house_number ,type_all,lever ,platform='binance'):
    """
    订单购入  进行加仓
    :param deal_amount: 已购入多少币
    :param first_order_money: 投入usdt
    :param deal_money: 已投入usdt
    :param house: 第几仓
    :param platform: 交易所
    :param uid: 用户id
    :param robot_id: 机器人id
    :param direction: 空还是多
    :param executedQty: 数量
    :param side: 买还是卖
    :param api_info: api
    :param market: 交易对
    :param cover_info: 分仓信息
    :return:
    """
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    if exchange_id == 'binance':
        return ''
    else:

        """
        okex5合约下单
        :param exchange: ccxt链接数据
        :param symbol: 交易对
        :param side: 开仓还是平仓  buy开  sell平
        :param direction: 方向 做空还是做多long 多 short 空
        :param amount: 数量
        :return:
        """
        ret = {}
        symbol=market
        result = {}
        resulf = {}
        symbols = symbol
        symbol = symbol.upper() + 'SWAP'
        resulf = {
            'instId': symbol,  # 产品ID
            'instType': 'SWAP',
        }
        # 获取合约币种公共信息
        clordId = brokerid + str(int(time.time()*10))+'heyue'
        ctVal=1
        try:
            public_result = await exchange.public_get_public_instruments(resulf)
            public_result = public_result['data'][0]
            ctVal = public_result['ctVal']
            result = {
                'instId': symbol,  # 产品ID
                'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                'clOrdId': clordId,  # 订单号
                'side': side.lower(),  # 方向 buy 买 sell 卖
                'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'ordType': 'market',  # 市价单
                'sz': int(amount),  # 数量
            }
            # result = await exchange.private_post_trade_order(result)
            result = await exchange.private_post_trade_order(result)
            result = result['data'][0]
            # result['ordId']=432231205587795974
            if result['ordId']:
                # 获取订单信息
                # info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})

                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                info = info['data'][0]
                while info['tradeId'] =='':
                    time.sleep(1)
                    # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "ordId": result['ordId']})
                    info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                    # info = test_commn.private_get_trade_order(result)
                    info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                    info = info['data'][0]
                if info_bili['data']==[]:
                    info_bili={}
                    info_bili['liqPx']=0
                    info_bili['imr']=0
                    info_bili['mgnRatio']=0
                else:
                    info_bili = info_bili['data'][0]

                strs = {
                    'order_id': result['ordId'],  # 订单号
                    'first_order_price': info['avgPx'],  # 开仓价
                    'symbol': symbols,  # 交易对
                    'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                    'last_price': info['avgPx'],  # 平均成交价
                    'base_price': info['avgPx'],  # 基础价
                    'up_price': 0,  # 上涨价
                    'order_count': 0,  # 补仓次数
                    'down_price': 0,  # 下跌价
                    'trend_side': 0,  # 趋势
                    'is_clean':0, #清仓
                    'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx']) ,  # 成交金额USDT
                    'type': 'MARKET',  # 订单类型 MARKET市价单
                    'side': side,  # 方向 SELL 卖出 BUY买入
                    'position': info['posSide'],  # 做空还是多 空SHORT 多long
                    'direction': info['posSide'],
                    'time': '',  # 成交时间
                    'fee': info['fee'],  # 手续费
                    'lever':info['lever'],
                    'now_round_num':0,
                    'strong_pay':info_bili['liqPx'],# 预估强平价格
                    'margin_price':info_bili['imr'],# 保证金价格
                    'margin_lilv':info_bili['mgnRatio'],#保证金比例
                    'pid': 0,  # 线程id
                    'executedQty': float(info['sz']),  # 成交量
                    'order_finish': 0
                }
                ret['code'] = 1
                ret['data'] = strs
                ret['msg'] = ''
            else:
                # 开单失败
                ret['code'] = 0
                ret['data'] = {}
                ret['msg'] = '开单失败'
        except Exception as e:
            msg = json.loads(e.args[0].split(' ', 1)[1])
            ret['code'] = msg['data'][0]['sCode']
            ret['data'] = {}
            ret['msg'] = msg['data'][0]['sMsg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 第几仓
        values_str['order_count'] = house
        # 总投入了多少usdt
        values_str['deal_money'] = float(values_str['deal_money']) + float(result['deal_money'])
        # 计算总购买了多少币
        values_str['deal_amount'] = float(values_str['deal_amount']) + float(result['deal_amount'])
        # 持仓张数
        values_str['executedQty'] = int(values_str['executedQty']) + int(result['executedQty'])
        # 方向
        values_str['strong_pay'] = result['strong_pay']
        values_str['margin_price'] = result['margin_price']
        values_str['margin_lilv'] = result['margin_lilv']
        values_str['direction'] = direction
        values_str['pid'] = str(uuid.uuid4())
        # 全仓基础价格
        values_str['base_price'] = float(values_str['deal_money']) / float(values_str['deal_amount'])
        values_str['base_price'] = float(Decimal(values_str['base_price']).quantize(Decimal('0.000000000')))
        result['fee'] = abs(float(result['fee']))
        # 开单成功
        pid = str(uuid.uuid4())
        # 订单入库
        money = 'USDT'
        # 用户id，订单id，机器人id，买入还是卖出，支出金额，买入数量，单价，是否首单，uuid，收益，手续费，总单数，下单总金额USDT,仓数(第几仓)
        # common.insertOrder(uid, result['order_id'], robot_id, 1, result['cumQuote'], result['executedQty'], result['last_price'], 1, pid, 0, 0, amount, first_order_money, house)
        if direction == 0:
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platform, uid, result['order_id'], robot_id, 2,symbol_direction, market, market_info['stock'],market_info['money'], result['deal_money'], amount, result['last_price'], 2,pid, 0, result['fee'],values_str['order_count'], result['deal_money'],2)
        # 修改redis数据   需要将这一仓的数据覆盖上一仓的数据 保证下一次加仓的数据正确性
        # 记录分仓的数据
        cover_key = values_str['order_count']
        cover_info[cover_key] = {
            'price': result['last_price'],
            'last_price': result['last_price'],
            'is_out': 0,
            'out_price': deal_amount,
            'deal_amount': deal_amount,
            'buy_oid': result['order_id'],
        }
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {"cover_info": json.dumps(cover_info)})
        # 修改补仓后全仓信息
        result['trend_side'] = 0
        if result['order_count'] >= max_house_number:
            # 只能等盈利
            result['order_finish'] = 1
            insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " % result['order_count'])
        updateValues(robot_id, uid, json.dumps(values_str))
        updateMsg(robot_id, uid, u"达到最大做单数量次数：单数 %s " % result['order_count'])
    else:
        if ret['code'] == '51121':
            ret['msg'] = '下单张数应为一手张数的倍数'
        if ret['code'] == '20221':
            ret['msg'] = '订单被拒绝'
        if ret['code'] == '51202':
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == '51008':
            ret['msg'] = '委托失败，账户可用余额不足'
        if ret['code'] == '51603':
            ret['msg'] = '委托失败'
        # 返回仓数
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:加仓失败')
        insertLog(platform, robot_id, uid, u"机器人加仓失败" + str(ret['msg']))
        updateMsg(robot_id, uid,u"机器人加仓失败" + str(ret['msg']))




async def first_order_buy(direction, amount, side, api_info, symbol,type_all, lever,loop,uid,robot_id,market_info,first_order_money,platfrom='binance'):
    # 注意事项:
    # 1.做多 买入的情况就是开仓  卖出就是平仓
    # 2.做空 买入的情况就是平仓  卖出就是开仓
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    ret = {}
    result={}
    resulf={}
    if exchange_id == 'binance':
        return binance_order_buy(exchange, symbol, side, direction, amount)
    else:
        symbols = symbol
        symbol = symbol.upper() + 'SWAP'
        resulf = {
            'instId': symbol,  # 产品ID
            'instType': 'SWAP',
        }
        ctVal=1
        clordId = brokerid + str(int(time.time()*10))+'heyue'
        # 获取合约币种公共信息
        try:
            public_result = await exchange.public_get_public_instruments(resulf)
            public_result = public_result['data'][0]
            ctVal = public_result['ctVal']
            result = {
                'instId': symbol,  # 产品ID
                'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                'clordId':clordId,
                'side': side.lower(),  # 方向 buy 买 sell 卖
                'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'ordType': 'market',  # 市价单
                'sz': int(amount),  # 下单张数
            }
            result =await exchange.private_post_trade_order(result)
            result = result['data'][0]
            logger.info(result)
            if result['ordId']:
                # 获取订单信息
                info =await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                logger.info(info)
                info = info['data'][0]
                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                if info_bili['data']==[]:
                    info_bili={}
                    info_bili['liqPx']=0
                    info_bili['imr']=0
                    info_bili['mgnRatio']=0
                else:
                    info_bili = info_bili['data'][0]
                while info['tradeId'] =='':
                    info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                    info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                    info_bili = info_bili['data'][0]
                    info = info['data'][0]
                strs = {
                    'order_id': result['ordId'],  # 订单号
                    'first_order_price': info['avgPx'],  # 开仓价
                    'symbol': symbols,  # 交易对
                    'deal_amount': float(info['sz']) * float(ctVal),  # 成交数量量
                    'last_price': info['avgPx'],  # 平均成交价
                    'base_price': info['avgPx'],  # 基础价
                    'up_price': 0,  # 上涨价
                    'order_count': 0,  # 补仓次数
                    'down_price': 0,  # 下跌价
                    'trend_side': 0,  # 做单方向
                    'is_clean':0, #清仓
                    'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx']) ,  # 成交金额
                    'type': 'MARKET',  # 订单类型 MARKET市价单
                    'side': side,  # 方向 SELL 卖出 BUY买入
                    'position': info['posSide'],  # 做空还是多 空SHORT 多long
                    'direction': info['posSide'],
                    'time': '',  # 成交时间
                    'fee': info['fee'],  # 手续费
                    'lever':info['lever'], #做单倍数
                    'now_round_num':0,
                    'strong_pay':info_bili['liqPx'],# 预估强平价格
                    'margin_price':info_bili['imr'],# 保证金价格
                    'margin_lilv':info_bili['mgnRatio'],#保证金比例
                    'pid': 0,  # 线程id
                    'executedQty': float(info['sz']),  # 成交张数
                    'order_finish': 0
                }
                ret['code'] = 1
                ret['data'] = strs
                ret['msg'] = ''
            else:
                # 开单失败
                ret['code'] = 0
                ret['data'] = {}
                ret['msg'] = '开单失败'
        except Exception as e:
            print(e)
            logger.error(e)
            msg = json.loads(e.args[0].split(' ', 1)[1])
            ret['code'] = msg['data'][0]['sCode']
            ret['data'] = {}
            ret['msg'] = msg['data'][0]['sMsg']
    
    if ret['code'] == 50004:
        loops = asyncio.get_event_loop()
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    print(ret)
    await exchange.close()
    if ret['code'] == 1:
        print("机器人第" + str(loop) + "次成功开仓")
        values_str = ret['data']
        values_str['first_order_price'] = amount
        # 手续费
        fee = abs(float(values_str['fee']))
        revenue = 0
        # 开单成功
        pid = str(uuid.uuid4())
        values_str['pid'] = pid
        # 订单入库
        # 用户id，订单id，机器人id，买入还是卖出，支出金额，买入数量，单价，是否首单，uuid，收益，手续费，总张数，下单总金额USDT,仓数(第几仓)
        side=1
        symbol_side = side
        if direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platfrom,uid, values_str['order_id'], robot_id, 2,symbol_direction,symbol,market_info['stock'],market_info['money'], values_str['deal_money'], amount,values_str['last_price'], 1, pid, 0, fee, 0, values_str['deal_money'],2)
        # 修改redis数据
        insertLog(platfrom, robot_id, uid, u"第" + str(loop) + "次循环首单开单成功")
        updateMsg(robot_id, uid,u"第" + str(loop) + "次循环首单开单成功")
        updateValues(robot_id, uid, json.dumps(values_str))
        updateMsg(robot_id, uid, u'下单成功')
        # 更新机器人循环次数
        redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"process_id": pid, "now_round_num": loop})
    else:
        if ret['code'] == '51121':
            ret['msg'] = '下单张数应为一手张数的倍数'
        if ret['code'] == '20221':
            ret['msg'] = '订单被拒绝'
        if ret['code'] == '51202':
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == '51008':
            ret['msg'] = '委托失败，账户可用余额不足'
        if ret['code'] == '51603':
            ret['msg'] = '委托失败'
        # 开单失败
        log.get_logger(robot_id).error('机器人' + str(robot_id) + ':第"+ str(loop) +"次首单开单失败' + str(ret['msg']))
        insertLog(platfrom, robot_id, uid, u"第" + str(loop) + "次循环首单开单(" + str(amount) + ")失败" + str(ret['msg']))
        # 停止机器人
        # print('关闭机器人')
        disableRobot(robot_id, uid)
        updateMsg(robot_id, uid, u"第" + str(loop) + "次循环首单开单(" + str(amount) + ")失败" + str(ret['msg']))
        updaterobotkeys(robot_id, uid, {'values_str': ''})

async def clean_order_sell(revenues,price, direction, executedQty, side, api_info,market_info, market, robot_id, uid, lever,house, typwe ,now_loop=1, platform='binance',type_all = 0):
    symbol =market
    # 注意事项:
    # 1.做多 买入的情况就是开仓  卖出就是平仓
    # 2.做空 买入的情况就是平仓  卖出就是开仓
    # 判断到底是改买还是卖，BUY,SELL
    symbol_side = side
    symbol_direction = direction
    if direction == 0:
        # 做空
        if side == 1:
            symbol_side = 2
        else:
            symbol_side = 1
    # 是开仓还是平仓
    side = 'BUY' if symbol_side == 1 else 'SELL'
    # 是空头还是多头
    direction = 'LONG' if direction == 1 else 'SHORT'
    # print(direction)
    # print(side)
    # exit();
    # 交易所
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    iplist=api.getapilist()
    exchange_class = getattr(ccxt, exchange_id)
    if int(type_all) == 0:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[0],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    ret = {}
    result={}
    resulf={}
    if exchange_id == 'binance':
        return ''
        return binance_order_buy(exchange, symbol, side, direction, amount)
    else:
        symbols =symbol

        symbol =symbol.upper()+'SWAP'

        resulf = {
            'instId': symbol , # 产品ID
            'instType':'SWAP',
        }
        clordId = brokerid + str(int(time.time()*10))+'heyue'
        ctVal =1 

        # 获取合约币种公共信息
        try:
            public_result = await exchange.public_get_public_instruments(resulf)
            public_result = public_result['data'][0]
            ctVal = public_result['ctVal']
            # print(ctVal)
            result = {
                'instId': symbol,  # 产品ID
                'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                'clOrdId': clordId,  # 订单号
                'side': side.lower(),  # 方向 buy 买 sell 卖
                'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'ordType': 'market',  # 市价单
                'sz': int(executedQty),  # 数量
            }
            result = await exchange.private_post_trade_order(result)
            result = result['data'][0]
            logger.info(result)
            # result['ordId']=432231205587795974
            if result['ordId']:
                # 获取订单信息
                info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                print(info_bili)
                if info_bili['data']==[]:
                    info_bili={}
                    info_bili['liqPx']=0
                    info_bili['imr']=0
                    info_bili['mgnRatio']=0
                else:
                    info_bili = info_bili['data'][0]
                info = info['data'][0]
                while info['tradeId'] =='':
                    time.sleep(1)
                    # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "ordId": result['ordId']})
                    info =await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                    info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                    info_bili = info_bili['data'][0]
                    info = info['data'][0]
                strs = {
                    'order_id': result['ordId'],  # 订单号
                    'first_order_price': info['avgPx'],  # 开仓价
                    'symbol': symbols,  # 交易对
                    'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                    'last_price': info['avgPx'],  # 平均成交价
                    'base_price': info['avgPx'],  # 基础价
                    'up_price': 0,  # 上涨价
                    'order_count': 0,  # 补仓次数
                    'down_price': 0,  # 下跌价
                    'trend_side': 0,  # 趋势
                    'is_clean':0, #清仓
                    'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx'])  ,  # 成交金额
                    'type': 'MARKET',  # 订单类型 MARKET市价单
                    'side': side,  # 方向 SELL 卖出 BUY买入
                    'position': info['posSide'],  # 做空还是多 空SHORT 多long
                    'direction': info['posSide'],
                    'time': '',  # 成交时间
                    'fee': info['fee'],  # 手续费
                    'lever':info['lever'],
                    'now_round_num':0,
                    'strong_pay':info_bili['liqPx'],# 预估强平价格
                    'margin_price':info_bili['imr'],# 保证金价格
                    'margin_lilv':info_bili['mgnRatio'],#保证金比例
                    'pid': 0,  # 线程id
                    'executedQty': float(info['sz']),  # 成交张数
                    'order_finish': 0
                }
                ret['code'] = 1
                ret['data'] = strs
                ret['msg'] = ''
            else:
                # 开单失败
                ret['code'] = 0
                ret['data'] = {}
                ret['msg'] = '开单失败'
            asda = symbol_direction
        except Exception as e:
            msg = json.loads(e.args[0].split(' ', 1)[1])
            if msg['data'] == '' or msg['data'] is None:
                ret['code'] = 1111
                ret['data'] = {}
                ret['msg'] = '账户余额不足'
            else:
                ret['code'] = msg['data'][0]['sCode']
                ret['data'] = {}
                ret['msg'] = msg['data'][0]['sMsg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    
    if ret['code'] == 1:
        # data数据
        result = ret['data']
        # 交易对
        symbol = result['symbol']
        # 订单号   348363948206282
        order_id = result['order_id']
        # 卖出价格
        sell_price = result['last_price']
        # 计算盈利 ：(开仓单价-平仓单价) * 数量   这里有可能为负数   负数就是负盈利
        revenue = (float(sell_price) - float(price)) * float(result['executedQty'])
        if direction != 1:
            revenue = revenue * -1
        # 手续费
        fee = 0
        symbols=symbol.upper()+'SWAP'
        # 重交易所获取收益和手续费
        commission = common.orderServiceCharge(order_id, api_info, symbols)
        # 收益  (尚未扣除手续费)
        revenue = commission['revenue']
        # 手续费
        fee = commission['fee']
        # 收益扣除手续费
        revenue = float(revenue) - float(fee)
        # 订单入库
        money='USDT'
        symbol_side = 1
        if symbol_direction == 0:
            # 做空
            if side == 1:
                symbol_side = 2
            else:
                symbol_side = 1
        insertOrder(platform,uid, order_id, robot_id, symbol_side,symbol_direction, market,market_info['stock'],market_info['money'] ,result['deal_money'], result['executedQty'], sell_price, 2, 0, revenue, fee, house,  result['deal_money'], 2)
        # 收益入库
        insertRevenueLog(platform,robot_id, order_id,uid, market, symbol, money, revenue)

        # 修改redis数据
        # 判断循环次数，循环为零时表示清仓处理，需要重置循环
        if now_loop==0:
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        if typwe==1:
            disableRobot(robot_id, uid)
            insertLog(platform, robot_id, uid, u"清仓卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.000000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
            updateMsg(robot_id, uid, u"清仓卖出成功：成交均价 %s,成交USDT %s" % (
            str(Decimal(price).quantize(Decimal('0.00000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        else:
            insertLog(platform, robot_id, uid, u"卖出成功：成交均价 %s,成交张数 %s" % (
            str(Decimal(price).quantize(Decimal('0.00000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
            updateMsg(robot_id, uid, u"卖出成功：成交均价 %s,成交USDT %s" % (
            str(Decimal(price).quantize(Decimal('0.00000000'))),
            str(Decimal(result['deal_money']).quantize(Decimal('0.00')))))
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        updateValues(robot_id, uid, '')
        updateRevenue(robot_id, uid, 0)

        # 记录日志
    else:
        if ret['code'] == -2019:
            # 账户余额不足
            ret['msg'] = '账户余额不足'
        if ret['code'] == 51202:
            ret['msg'] = '市价单下单数量超出最大值'
        if ret['code'] == -2022:
            ret['msg'] = '订单被拒绝'
        if ret['code'] == 51001:
            ret['msg'] = '交易产品ID不存在'
        if ret['code'] == 51112:
            ret['msg'] = '平仓张数大于该仓位的可平张数'
        if ret['code'] == 51603:
            ret['msg'] = '下单失败，请稍后再试'
        
        if typwe==1:
            updateValues(robot_id, uid, '')
            updateRevenue(robot_id, uid, 0)
            updateMsg(robot_id, uid, u'清仓卖出成功')
            disableRobot(robot_id, uid)
            redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': 0})
        # TODO: write code...
        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
        if revenues >0:
            insertRevenueLog(platform,robot_id, str(uuid.uuid4()),uid, market, market, 'USDT', revenues)
        log.get_logger(robot_id).error('机器人' + str(robot_id) + '第' + str(house) + '仓:卖出失败')
        insertLog(platform, robot_id, uid, u"机器人卖出失败" + str(ret['msg']))
        updateMsg(robot_id, uid, u'机器人卖出失败' + str(ret['msg']))


# 币安合约下单
def binance_order_buy(exchange, symbol, side, direction, amount):

    """
    币安合约下单
    :param exchange: ccxt数据信息
    :param symbol: 交易对
    :param side: 买还是卖
    :param direction: 方向 做空还是做多
    :param amount: 数量
    :return: dist
    """
    ret = {}
    try:
        result = {
            "symbol": symbol,
            "side": side,  # 买还是卖
            "positionSide": direction,  # 做空
            "type": "MARKET",  # 市价单
            "quantity": amount,
        }
        result = exchange.fapiPrivatePostOrder(result)
        # result = {'info': {'status': 'ok', 'data': '345450498901036'}, 'id': '345450498901036',
        #           'timestamp': 1629180511922, 'datetime': '2021-08-17T06:08:31.922Z', 'lastTradeTimestamp': None,
        #           'status': None, 'symbol': 'BTT/USDT', 'type': 'market', 'side': 'buy', 'price': None,
        #           'amount': 10.0, 'filled': None, 'remaining': None, 'cost': None, 'trades': None, 'fee': None,
        #           'clientOrderId': None, 'average': None}
        # result['orderId']='8389765519614131693'
        if result['orderId']:
            # 获取订单信息
            info = exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 10})
            # print(info)
            # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['orderId']})
            while len(info) == 0:
                time.sleep(1)
                # info = exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['orderId']})
                info = exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': 10})
            str = {
                'order_id': result['orderId'],  # 订单号
                'first_order_price' : amount, #开仓价
                'symbol': info[0]['symbol'],  # 交易对
                'deal_amount': 0,  # 成交量
                'last_price': 0,  # 平均成交价
                'base_price': 0,  # 基础价
                'up_price': 0,  # 上涨价
                'order_count' : 0, #补仓次数
                'down_price': 0,  # 下跌价
                'trend_side' : 0, # 趋势
                'deal_money': 0, # 成交金额
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'position': direction,  # 做空还是多 空SHORT 多long
                'direction': direction,  # 做空还是多 空SHORT 多long
                'time': '',  # 成交时间
                'fee': 0,  # 手续费
                'pid': 0,  # 线程id
                'executedQty': 0,  # 成交量
                'order_finish': 0,
                'deal_fee':0
                # 'last_price': info['avgPrice'],  # 平均成交价
                # 'cumQuote': info['cumQuote'],  # 成交金额
                # 'type': info['type'],  # 订单类型 MARKET市价单
                # 'side': info['side'],  # 方向 SELL 卖出 BUY买入
                # 'position': info['positionSide'],  # 做空还是多 空SHORT 多long
                # 'time': info['time'],  # 成交时间
                # 'fee': 0,  # 手续费
            }
            for i in info:
                if i['orderId'] == result['orderId']:
                    str['deal_amount'] += float(i['qty'])
                    str['executedQty'] += float(i['qty'])
                    str['last_price'] = i['price']
                    str['base_price'] = i['price']
                    str['deal_money'] += float(i['quoteQty'])
                    str['side'] = i['side']
                    str['position'] = i['positionSide']#做空还是做多空SHORT 多long
                    str['direction'] =  i['positionSide'],
                    str['deal_fee'] += float(i['commission'])
                    str['time'] = i['time']
            ret['code'] = 1
            ret['data'] = str
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    return ret


# okex5合约下单
async def okex5_order_buy(exchange, symbol, side, direction, amount):
    """
    okex5合约下单
    :param exchange: ccxt链接数据
    :param symbol: 交易对
    :param side: 开仓还是平仓  buy开  sell平
    :param direction: 方向 做空还是做多long 多 short 空
    :param amount: 数量
    :return:
    """
    ret = {}
    result = {}
    result_two = {}
    resulf = {}
    symbols = symbol
    symbol = symbol.upper() + 'SWAP'
    resulf = {
        'instId': symbol,  # 产品ID
        'instType': 'SWAP',
    }
    clordId = brokerid + str(int(time.time()*10))+'heyue'
    ctVal =1
    try:
        result = {
            'instId': symbol,  # 产品ID
            'tdMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
            'clOrdId': clordId,  # 订单号
            'side': side.lower(),  # 方向 buy 买 sell 卖
            'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
            'ordType': 'market',  # 市价单
            'sz': int(amount),  # 数量
        }
        # 获取合约币种公共信息
        public_result = await exchange.public_get_public_instruments(resulf)
        public_result = public_result['data'][0]
        ctVal = public_result['ctVal']
        logger.info(result)
        result = await exchange.private_post_trade_order(result)
        result = result['data'][0]
        if result['ordId']:
            # 获取订单信息
            info = await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
            info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
            if info_bili['data']==[]:
                info_bili={}
                info_bili['liqPx']=0
                info_bili['imr']=0
                info_bili['mgnRatio']=0
            else:
                info_bili = info_bili['data'][0]
            info = info['data'][0]
            while info['tradeId'] =='':
                time.sleep(1)
                info =  await exchange.private_get_trade_order({"instId": symbol, "ordId": result['ordId']})
                info_bili = await exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
                info_bili = info_bili['data'][0]
                info = info['data'][0]
            strs = {
                'order_id': result['ordId'],  # 订单号
                'first_order_price': info['avgPx'],  # 开仓价
                'symbol': symbols,  # 交易对
                'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
                'last_price': info['avgPx'],  # 平均成交价
                'base_price': info['avgPx'],  # 基础价
                'up_price': 0,  # 上涨价
                'order_count': 0,  # 补仓次数
                'down_price': 0,  # 下跌价
                'trend_side': 0,  # 趋势
                'is_clean':0, #清仓
                'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx'])  ,  # 成交金额
                'type': 'MARKET',  # 订单类型 MARKET市价单
                'side': side,  # 方向 SELL 卖出 BUY买入
                'position': info['posSide'],  # 做空还是多 空SHORT 多long
                'direction': info['posSide'],
                'time': '',  # 成交时间
                'fee': info['fee'],  # 手续费
                'lever':info['lever'],
                'now_round_num':0,
                'strong_pay':info_bili['liqPx'],# 预估强平价格
                'margin_price':info_bili['imr'],# 保证金价格
                'margin_lilv':info_bili['mgnRatio'],#保证金比例
                'pid': 0,  # 线程id
                'executedQty': float(info['sz']),  # 成交量
                'order_finish': 0
            }
            ret['code'] = 1
            ret['data'] = strs
            ret['msg'] = ''
        else:
            # 开单失败
            ret['code'] = 0
            ret['data'] = {}
            ret['msg'] = '开单失败'
    except Exception as e:
        logger.error(e)
        print(e)
        msg = json.loads(e.args[0].split(' ', 1)[1])
        print(msg)
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    if ret['code'] == 50004:
        task = loops.create_task(query_order(clordId,exchange,symbol,ctVal,symbols,side))
        loops.run_until_complete(task)
        ret = task.result()
    return ret

async def query_order(clordId,exchange,symbol,ctVal,symbols,side):
    ret = {}
    try:
        info = await exchange.private_get_trade_order({"instId": symbol, "clOrdId": clordId})
        info_bili = await exchange.private_get_account_positions({"instId": symbol, "instType": "SWAP"})
        if info_bili['data'] == []:
            info_bili = {}
            info_bili['liqPx'] = 0
            info_bili['imr'] = 0
            info_bili['mgnRatio'] = 0
        else:
            info_bili = info_bili['data'][0]
        info = info['data'][0]
        while info['tradeId'] == '':
            time.sleep(0.5)
            info = await exchange.private_get_trade_order({"instId": symbol, "clOrdId": clordId})
            info_bili = await exchange.private_get_account_positions({"instId": symbol, "instType": "SWAP"})
            info_bili = info_bili['data'][0]
            info = info['data'][0]
        strs = {
            'order_id': info['ordId'],  # 订单号
            'first_order_price': info['avgPx'],  # 开仓价
            'symbol': symbols,  # 交易对
            'deal_amount': float(info['sz']) * float(ctVal),  # 成交量
            'last_price': info['avgPx'],  # 平均成交价
            'base_price': info['avgPx'],  # 基础价
            'up_price': 0,  # 上涨价
            'order_count': 0,  # 补仓次数
            'down_price': 0,  # 下跌价
            'trend_side': 0,  # 趋势
            'is_clean': 0,  # 清仓
            'deal_money': float(ctVal) * float(info['sz']) * float(info['avgPx']),  # 成交金额
            'type': 'MARKET',  # 订单类型 MARKET市价单
            'side': side,  # 方向 SELL 卖出 BUY买入
            'position': info['posSide'],  # 做空还是多 空SHORT 多long
            'direction': info['posSide'],
            'time': '',  # 成交时间
            'fee': info['fee'],  # 手续费
            'lever': info['lever'],
            'now_round_num': 0,
            'strong_pay': info_bili['liqPx'],  # 预估强平价格
            'margin_price': info_bili['imr'],  # 保证金价格
            'margin_lilv': info_bili['mgnRatio'],  # 保证金比例
            'pid': 0,  # 线程id
            'executedQty': float(info['sz']),  # 成交量
            'order_finish': 0
        }
        ret['code'] = 1
        ret['data'] = strs
        ret['msg'] = ''
        await exchange.close()
        return ret
    except Exception as e:
        await exchange.close()
        msg = json.loads(e.args[0].split(' ', 1)[1])
        if msg['code'] == 50004:
            ret = query_order(clordId, exchange, symbol, ctVal, symbols, side)
        elif msg['code'] == 51603:
            ret['code'] = msg['code']
            ret['data'] = {}
            ret['msg'] = '下单失败，请稍后再试'
        else:
            ret['code'] = msg['code']
            ret['data'] = {}
            ret['msg'] = msg['msg']
    return ret

# 更新机器人信息字典模式
def updaterobotkeys(robot_id, uid, data):
    keys = data.keys()
    for v in keys:
        va = data[v]
        redis_content.hset('user_contract_' + str(uid) + '_' + str(robot_id), v, va)
        sql = "update jq_quant_robot set `" + str(v) + "` = '" + str(va) + "' where id=%d" % (int(robot_id))
        redis_content.hset('update_sql', 'new_robot_' + str(v) + '_' + str(robot_id), sql)
    return True

# 修改机器人数据
def order_update_redis( robot_id, uid, data):
    """
    修改机器人数据
    :param robot_id: 机器人id
    :param uid: 用户id
    :return: null
    """
    updateValues(robot_id, uid, data)

# 删除redis里面的数据信息
def order_delete_redis(self, robot_id, uid):
    """
    删除机器人redis里面的日志数据信息
    :param robot_id: 机器人id
    :param uid: 用户id
    :return: null
    """
    # 删除redis里面的数据信息    new_user_robot_position_79_11_*
    robot_str = 'new_user_robot_position_' + str(uid) + '_' + str(robot_id) + '_*'
    common.delete_robot(robot_str)
# 启动合约机器人
def runEnableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 1)
# 禁用合约机器人
def disableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'status', 0)

def updateBalanceStatus(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'sell_status', '1')


def updateNew(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'new', 0)


def updateMsg(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'show_msg', show_msg)


def updateValues(robot_id, uid, values_str):
    redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', values_str)


def updateRevenue(robot_id, uid, revenue):
    redisbase.updaterobot(redis_content, robot_id, uid, 'revenue', revenue)

def cleanFinish(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'is_clean', 0)
    redisbase.updaterobot(redis_content, robot_id, uid, 'clean_long',0)
    redisbase.updaterobot(redis_content, robot_id, uid, 'clean_short',0)


def runDisableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 0)

def insertLog(platform, robot_id, uid, log):
    redisbase.insertlog(redis_content, robot_id, platform, uid, log,2)

def insertRevenueLog(platform, robot_id, pid, uid, market, stock, money, revenue):
    # redisbase.insertrevene(redis_content,platform, robot_id, pid, uid, market, stock, money, revenue)
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_revenue (platform,qrobot_id,pid,uid,market,stock,money,revenue,deal_status,transaction_type) values ('%s',%d,'%s',%d,'%s','%s','%s','%s',%d,%d)" % (
    platform,
    robot_id, pid, uid, market, stock, money, revenue, 0,2)
    cur.execute(insert_sql)

def insertOrder(platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first,uuid, revenue, fee, amount, total,transaction_type):
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_order (type,platform,uid,order_id,qrobot_id,side,position,market,stock,money,deal_money,deal_amount,price,order_status,is_first,pid,revenue,fee,amount,total,transaction_type) values (%d,'%s',%d,'%s',%d,%d,%d,'%s','%s','%s','%s','%s','%s',1,%d,'%s','%s','%s',%d,'%s',%d)" % (
        2,platform, uid, order_id, robot_id, side,direction, market, stock, money, deal_money, deal_amount, price, is_first, uuid,revenue, fee, amount, total,transaction_type)
    cursor, conn, count = cur.execute(insert_sql)
    return cursor.lastrowid

import threading

POOL = {}
Active_Thread = []

def loadStrategyConfig(cur):
    # 获取数据库中所有的合约类型市场
    markets = cur.fetchall("select id,platform,market,market_name,type,stock,money,instType from jl_spot_market where status = 1 ")
    if  markets == 0:
        print('没有合约市场')
        return
    market_list = {}
    for k in markets.keys():
        market = markets[k]
        market_list[market['id']] = market
    # 获取所有用户的第三方api信息
    apis = cur.fetchall("select id,uid,platform,api_key,secret_key,passphrase from jl_third_api where status = 1")
    api_list = {}
    for k in apis.keys():
        apias = apis[k]
        api_list["%s-%s" % (apias['platform'], apias['uid'])] = apias
    # 获取机器人所有的配置选项
    lists = cur.fetchall("SELECT option_value from jl_option where option_name='system_setting'")
    lists = json.loads(lists[0]['option_value'])
    config = {}
    config['type'] = lists['type']
    robots = redisbase.getrobotall()
    # 获取代理参数
    aolist = api.getapilist()
    if robots:
        for k in robots.keys():
            robot = robots[k]
            if str(robot['platform']) != 'okex':
                continue
            if str(robot['status']) != str(1):
                continue
            if str(robot['id']) != str(22):
                continue
            print('机器人开始'+str(robot['id']))
            # exit()
            market_id = int(robot['market_id'])
            platform = robot['platform']
            uid = int(robot['uid'])
            robot_id = int(robot['id'])
            if market_id in market_list.keys():
                market_info = market_list[market_id]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, '市场 %s 没有找到' % market_id)
                insertLog(platform, robot_id, uid, '市场 %s  没有找到, 停止机器人' % market_id)
                continue
            if "%s-%s" % (platform, uid) in api_list.keys():
                api_info = api_list["%s-%s" % (platform, uid)]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, '%s api not found' % platform)
                insertLog(platform, robot_id, uid,'%s api not found , stopped...' % platform)
                continue
            print(str(robot_id)+'机器人id----------大萨达撒大所多')
            if aolist == False:
                try:
                    if int(robot['is_trend'])==2:
                        task = strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = strategy(robot, market_info, api_info, config['type'])
                    print('机器人结算'+str(robot['id']))
                except Exception as e:
                    disableRobot(robot_id, uid)
                    logger.error(inspect.trace()[-1])
                continue
            # 判断是否使用代理如果使用代理则需要传代理参数

            if str(config['type']) == '0':
                try:
                    if int(robot['is_trend'])==2:
                        task = strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = strategy(robot, market_info, api_info, config['type'])
                except Exception as e:
                    disableRobot(robot_id, uid)
                    logger.error(inspect.trace()[-1])
                continue
            else:
                try:
                    if robot_id in Active_Thread:
                        continue
                    if int(robot['is_trend'])==2:
                        task = threading.Thread(target=strategy_three, args=(robot, market_info, api_info, config['type']))
                        # strategy_three(robot, market_info, api_info, config['type'])
                    else:
                        task = threading.Thread(target=strategy, args=(robot, market_info, api_info, config['type']))
                    POOL[robot_id] = task
                    POOL[robot_id].setDaemon(True)
                    POOL[robot_id].start()
                except Exception as e:
                    disableRobot(robot_id, uid)
                    logger.error(inspect.trace()[-1])
                continue

if __name__ == '__main__':
    exchange_class = getattr(ccxt_all, 'okex')
    exchange = exchange_class({
        'apiKey': 'fdd5dfc0-9a22-4e15-9de6-fa7ce6604161',
        'secret': 'CF9B6D24E02BBCE89686581065970F53',
        'password': 'Scmmwl@888',
        'timeout': 30000,
        'enableRateLimit': True,
        'options': {
            'createMarketBuyOrderRequiresPrice': False,
        },
    })
    symbol ='AAVE-USDT-SWAP'
    result = {}
    side ='BUY'
    direction = 'SHORT'
    # result['ordId']=60602582218
    # info =exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['ordId']})
    # info = exchange.fapiPrivateGetUserTrades({"instId": symbol, "ordId": result['ordId']})
    info_bili = exchange.private_get_account_positions({"instId":symbol,"instType":"SWAP"})
    # print(info_bili)
    # exit()
    # sty={
    #     'code': '0', 'data': [{'adl': '1', 'availPos': '59', 'avgPx': '57.5342062544760088', 'baseBal': '', 'cTime': '1656622201910', 'ccy': 'USDT', 'deltaBS': '', 'deltaPA': '', 'gammaBS': '', 'gammaPA': '', 'imr': '34.5209', 'instId': 'AAVE-USDT-SWAP', 'instType': 'SWAP', 'interest': '0', 'last': '58.5', 'lever': '10', 'liab': '', 'liabCcy': '', 'liqPx': '34.89295958160528', 'margin': '', 'markPx': '58.51', 'mgnMode': 'cross', 'mgnRatio': '13.874548998730658', 'mmr': '6.90418', 'notionalUsd': '344.80510547', 'optVal': '', 'pos': '59', 'posCcy': '', 'posId': '453669835761926149', 'posSide': 'short', 'quoteBal': '', 'thetaBS': '', 'thetaPA': '', 'tradeId': '33135803', 'uTime': '1656641266117', 'upl': '-5.757183098591523', 'uplRatio': '-0.1696023651057277', 'usdPx': '', 'vegaBS': '', 'vegaPA': ''
    # }
    values_str ={
        'base_price': 57.5342062544760088,
        'deal_amount': 4.9,
        'deal_money': 281.91,
        'direction': 0,
        'executedQty': 49,
        'fee': 0.048186,
        'first_order_price': 49,
        'last_price': "57.53",
        'lever': "10",
        'lilv': -20.128954399999998,
        'margin_lilv': 712.4912836127194,
        'margin_mmr': "1.9270800000000003",
        'margin_price': "34.5209",
        'now_round_num': "4",
        'order_count': 3,
        'order_finish': 0,
        'order_id': "462842293211512887",
        'pid': "a264c365-21a8-4fc4-8a76-e3455e3c76fc",
        'position': "short",
        'revenue': -21.320999999999874,
        'side': "SELL",
        'strong_pay': "34.8929",
        'symbol': "AAVE-USDT-",
        'time': "",
        'trend_side': 0,
        'type': "MARKET",
        'up_price': 0,
    }
    # 修改redis数据
    uid = 3
    robot_id =22
    updateValues(robot_id, uid, json.dumps(values_str))
    exit()
    for ite in info_bili:
        if ite['marginType']!='cross':
            continue
        if direction.lower() =='long' and ite['positionSide']=='LONG':
            info_bili=ite
        elif direction.lower() == 'short' and ite['positionSide']=='SHORT':
            info_bili=ite
    strs = {
        'order_id': result['ordId'],  # 订单号
        'symbol': symbol,  # 交易对
        'up_price': 0,  # 上涨价
        'order_count': 0,  # 补仓次数
        'down_price': 0,  # 下跌价
        'trend_side': 0,  # 趋势
        'is_clean':0, #清仓
        'type': 'MARKET',  # 订单类型 MARKET市价单
        'side': side,  # 方向 SELL 卖出 BUY买入
        'time': '',  # 成交时间
        'lever':info_bili['leverage'],
        'now_round_num':0,
        'base_price':info_bili['entryPrice'],
        'strong_pay':info_bili['liquidationPrice'],# 预估强平价格
        'margin_price':info_bili['isolatedMargin'],# 保证金价格
        'margin_lilv':info_bili['isolatedMargin'],#保证金比例
        'pid': 0,  # 线程id
        'order_finish': 0,
        'deal_amount':0,
        'executedQty':0,
        'last_price':0,
        'first_order_price':0,
        'deal_money':0,
        'position':0,
        'direction':0,
        'deal_fee':0,
    }
    for i in info:
        if i['orderId'] == str(result['ordId']):
            strs['deal_amount'] += float(i['qty'])
            strs['executedQty'] =  100
            strs['last_price'] = i['price']
            strs['base_price'] = i['price']
            strs['first_order_price'] = i['price']
            strs['deal_money'] += float(i['quoteQty'])
            strs['position'] = i['positionSide'].lower() #做空还是做多空SHORT 多long
            strs['direction'] =  i['positionSide']
            strs['deal_fee'] += float(i['commission'])
            strs['time'] = i['time']
            strs['commissionAsset'] = i['commissionAsset']
    ret = {
        'code':1,
        'msg':'',
        'data':strs
    }
    if ret['code'] == 1:
        # print("机器人第" + str(loop) + "次成功开仓")
        values_str = ret['data']
        values_str['first_order_price'] = 100
        # 第一仓
        values_str['order_count'] = 0
        values_str['fee']=abs(float(values_str['deal_fee']))
        # 手续费
        fee = values_str['fee']
        revenue = 0
        # 开单成功
        pid = str(uuid.uuid4())
        values_str['pid'] = pid
        # 订单入库
        # 用户id，订单id，机器人id，买入还是卖出，支出金额，买入数量，单价，是否首单，uuid，收益，手续费，总张数，下单总金额USDT,仓数(第几仓)
        side=1
        symbol_side = side
        platform_source = 'binance' 
        uid = 3
        robot_id =22
        # insertOrder(platform_source,uid, values_str['order_id'], robot_id, 2,0,'BTC-USDT-','BTC','USDT', values_str['deal_money'], values_str['executedQty'],values_str['last_price'], 1, pid, 0, fee, 0, 100,2)
        
    exit()
        # insertLog(platform_source, robot_id, uid, u"循环次数" + str(loop) + ",首单做空开单成功")
        # 更新机器人循环次数
        # redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"process_id": pid, "now_round_num": loop})
    
    while True:
        try:
            last_time=int(time.time()*1000)
            cur = MySqLHelper()
            Active_Thread = [k for k, v in POOL.items() if v.is_alive()]
            loadStrategyConfig(cur)
            time.sleep(0.5)
        except Exception as e:
            logger.info('Exception:%s', e)
            time.sleep(1)
            logger.info(inspect.trace()[-1])
# if __name__ == '__main__':
#     exchange_class = getattr(ccxt_all, 'okex')
#     exchange = exchange_class({
#         'apiKey': 'mfylZp2Xe100f23A0l3ydKC9Z12MHbaAoCk0UM4Wh0eIXBFx19EmVt0GMZcrgpPa',
#         'secret': 'rRXjgFRYWFVEhJyS0yq5b19S1E72vi25usg9LfVScJKzlixG0mxobqehY5m2BKup',
#         'password': '',
#         'timeout': 30000,
#         'enableRateLimit': True,
#         'options': {
#             'createMarketBuyOrderRequiresPrice': False,
#         },
#     })
#     symbol ='BTCUSDT'
#     result = {}
#     side ='BUY'
#     direction = 'SHORT'
#     result['ordId']=60602582218
#     # info =exchange.fapiPrivateGetOrder({"symbol": symbol, "orderId": result['ordId']})
#     info = exchange.fapiPrivateGetUserTrades({"instId": symbol, "ordId": result['ordId']})
#     info_bili = exchange.fapiPrivate_get_positionrisk({"instId":symbol,"instType":"SWAP"})
    
#     for ite in info_bili:
#         if ite['marginType']!='cross':
#             continue
#         if direction.lower() =='long' and ite['positionSide']=='LONG':
#             info_bili=ite
#         elif direction.lower() == 'short' and ite['positionSide']=='SHORT':
#             info_bili=ite
#     strs = {
#         'order_id': result['ordId'],  # 订单号
#         'symbol': symbol,  # 交易对
#         'up_price': 0,  # 上涨价
#         'order_count': 0,  # 补仓次数
#         'down_price': 0,  # 下跌价
#         'trend_side': 0,  # 趋势
#         'is_clean':0, #清仓
#         'type': 'MARKET',  # 订单类型 MARKET市价单
#         'side': side,  # 方向 SELL 卖出 BUY买入
#         'time': '',  # 成交时间
#         'lever':info_bili['leverage'],
#         'now_round_num':0,
#         'base_price':info_bili['entryPrice'],
#         'strong_pay':info_bili['liquidationPrice'],# 预估强平价格
#         'margin_price':info_bili['isolatedMargin'],# 保证金价格
#         'margin_lilv':info_bili['isolatedMargin'],#保证金比例
#         'pid': 0,  # 线程id
#         'order_finish': 0,
#         'deal_amount':0,
#         'executedQty':0,
#         'last_price':0,
#         'first_order_price':0,
#         'deal_money':0,
#         'position':0,
#         'direction':0,
#         'deal_fee':0,
#     }
#     for i in info:
#         if i['orderId'] == str(result['ordId']):
#             strs['deal_amount'] += float(i['qty'])
#             strs['executedQty'] =  100
#             strs['last_price'] = i['price']
#             strs['base_price'] = i['price']
#             strs['first_order_price'] = i['price']
#             strs['deal_money'] += float(i['quoteQty'])
#             strs['position'] = i['positionSide'].lower() #做空还是做多空SHORT 多long
#             strs['direction'] =  i['positionSide']
#             strs['deal_fee'] += float(i['commission'])
#             strs['time'] = i['time']
#             strs['commissionAsset'] = i['commissionAsset']
#     ret = {
#         'code':1,
#         'msg':'',
#         'data':strs
#     }
#     if ret['code'] == 1:
#         # print("机器人第" + str(loop) + "次成功开仓")
#         values_str = ret['data']
#         values_str['first_order_price'] = 100
#         # 第一仓
#         values_str['order_count'] = 0
#         values_str['fee']=abs(float(values_str['deal_fee']))
#         # 手续费
#         fee = values_str['fee']
#         revenue = 0
#         # 开单成功
#         pid = str(uuid.uuid4())
#         values_str['pid'] = pid
#         # 订单入库
#         # 用户id，订单id，机器人id，买入还是卖出，支出金额，买入数量，单价，是否首单，uuid，收益，手续费，总张数，下单总金额USDT,仓数(第几仓)
#         side=1
#         symbol_side = side
#         platform_source = 'binance' 
#         uid = 3
#         robot_id =22
#         # insertOrder(platform_source,uid, values_str['order_id'], robot_id, 2,0,'BTC-USDT-','BTC','USDT', values_str['deal_money'], values_str['executedQty'],values_str['last_price'], 1, pid, 0, fee, 0, 100,2)
#         values_str ={
#             base_price: 57.01240000000001
#             cover_price: 61.57339200000001
#             cover_rate: 8
#             deal_amount: 22.5
#             deal_money: 1282.7790000000002
#             direction: 0
#             down_price: 0
#             executedQty: 225
#             fee: 0.048186
#             first_order_price: 225
#             last_price: "53.54"
#             lever: "10"
#             lilv: -20.128954399999998
#             margin_lilv: 712.4912836127194
#             margin_mmr: "1.9270800000000003"
#             margin_price: "464.784"
#             now_round_num: "4"
#             order_count: 3
#             order_finish: 0
#             order_id: "462842293211512887"
#             pid: "a264c365-21a8-4fc4-8a76-e3455e3c76fc"
#             position: "short"
#             revenue: -21.320999999999874
#             side: "SELL"
#             strong_pay: "275.37239412383525"
#             symbol: "AAVE-USDT-"
#             time: ""
#             trend_side: 0
#             type: "MARKET"
#             up_price: 0
#         }
#         # 修改redis数据
        
#         updateValues(robot_id, uid, json.dumps(values_str))
#     exit()
#         # insertLog(platform_source, robot_id, uid, u"循环次数" + str(loop) + ",首单做空开单成功")
#         # 更新机器人循环次数
#         # redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),{"process_id": pid, "now_round_num": loop})
    
#     while True:
#         try:
#             last_time=int(time.time()*1000)
#             cur = MySqLHelper()
#             Active_Thread = [k for k, v in POOL.items() if v.is_alive()]
#             loadStrategyConfig(cur)
#             time.sleep(0.5)
#         except Exception as e:
#             logger.info('Exception:%s', e)
#             time.sleep(1)
#             logger.info(inspect.trace()[-1])