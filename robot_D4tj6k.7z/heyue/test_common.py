
import redisbase
import numpy as np
import pandas as pd
import random
from decimal import Decimal, ROUND_DOWN
import logger
import ccxt
import time
import json

redis_content = redisbase.redis_content

def Trend(sysbol='', exchange='binance'):
    # 处理数据
    if sysbol is not None:
        sysbol = sysbol.replace('/', '')
        sysbol = sysbol.lower()
    if exchange == 'huobi':
        exchange = 'huobipro'

    symbol_redis = "app_config"
    symbol_redis_comprehensive = 'app_config_symbol_redis_comprehensive_' + exchange
    kline_cycle = redis_content.hget(symbol_redis, 'kline_cycle')
    Company = kline_cycle[-1]
    kline_cycle = int(kline_cycle[:-1])
    if Company == 'm':
        kline_cycle = kline_cycle * 60
    elif Company == 'h':
        kline_cycle = kline_cycle * 60 * 60
    else:
        kline_cycle = kline_cycle * 86400

    comprehensive_number = 25  # 趋势累加税数据
    comprehensive = 0  # 趋势判断数据
    if sysbol is not None:
        string = sysbol + "_" + exchange
        # 获取redis数据
        data = TrendDATA(sysbol, exchange)
        comprehensive = 0  # 趋势判断数据
        comprehensives = redis_content.hget(symbol_redis_comprehensive, string)
        # print(comprehensives)
        if comprehensives:
            return comprehensives
        # 判断MACD
        if not MACD(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断EMA均线
        if not EMA(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断布林带
        if not BOLL(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断RSI数据
        if not RSI(data, symbol_redis):
            comprehensive += comprehensive_number
        redis_content.hset(symbol_redis_comprehensive, string, comprehensive)
        redis_content.expire(symbol_redis_comprehensive, kline_cycle)
    else:
        # 获取收盘价数据
        keys = redis_content.keys('*_kline_'+exchange)
        for i in keys:
            symbol = i.split('_')
            exchange = symbol[2]
            sysbol = symbol[0]
            string = sysbol + "_" + exchange
            # 获取redis数据
            data = TrendDATA(sysbol, exchange)
            comprehensive = 0  # 趋势判断数据
            # 判断MACD
            if not MACD(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断EMA均线
            if not EMA(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断布林带
            if not BOLL(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断RSI数据
            if not RSI(data, symbol_redis):
                comprehensive += comprehensive_number
            redis_content.hset(symbol_redis_comprehensive, string, comprehensive)
            redis_content.expire(symbol_redis_comprehensive, kline_cycle)
    return comprehensive

# 币安合约交易对的实时价格
def ContractGetTick(api_info, market, platform='binance'):
    # platform = "binance"
    """
    获取交易对的实时价格
    :param platform: 交易所
    :param api_info: api数据
    :param market: 交易对数据
    :return:
    """
    # 价格
    ticker = None
    # 交易对
    keys = ""
    try:
        # 去掉字符串
        # 币安等交易所是/号分开交易对  但是okex5是用-号分开的
        if platform == 'okex':
            # BTC-USDT-SWAP   源market
            keys = market.replace('-', '')
        else:
            # BTC/USDT  源market
            keys = market.replace('/', '')
        # 大写转小写
        keys = keys.lower()
        # print('price_' + platform + '_' + keys)
        # 重redis里面获取到实时价格
        # ticker = redis_content.get('price_binance_contract_' + keys)
        ticker = redis_content.get('price_' + platform + '_'+  keys+'swap')
        if ticker == None:
            raise Exception("行情获取失败!")
        # 精确计算价格  避免科学计算法的问题
        ticker = Decimal(ticker).quantize(Decimal('0.00000000'), ROUND_DOWN)
        ticker = str(ticker)
    except Exception as e:
        logger.get_logger(0).error('getTick Exception:%s' % e)
    if ticker is not None:
        return ticker
    else:
        logger.get_logger(0).error(keys + '-' + platform + '-第一次行情获取失败')
    # 重redis里面获取到行情失败   就去交易所获取实时价格
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_id = platform
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        'apiKey': api_key,
        'secret': secret_key,
        'password': passphrase,
        'timeout': 30000,
        'enableRateLimit': True,
    })

    try:
        ticker_data = exchange.fetch_ticker(market)
        return ticker_data['close']
    except Exception as e:

        logger.get_logger(0).info('Exception:%s', e)
        return None



# ip代理
def ip_list():
    iplist = [
        'http://58.220.95.44:10174',
        'http://69.165.77.110:59394',
        'http://39.97.164.165:7890',
        'http://39.108.137.133:3128',
        'http://42.3.186.126:8888',
        'http://36.55.229.4:4455',
        'http://39.108.88.42:80',
        'http://39.100.117.89:80',
        'http://39.96.11.1:8003',
    ]
    rand = random.randint(0, 2)
    return iplist[rand]


# USDT转交易对数量
def usdtSymbol(amount, ticker, lever, minQty=0):
    """
    USDT转交易对数量
    :param minQty: 要求的最小精度
    :param amount: 需要转换的数量
    :param ticker:交易对最新价格
    :param lever:杠杆
    :return:
    """
    # 杠杆过后的最终买入金额
    amount = float(amount)
    # 买入金额除以单价  得到买入数量
    num = amount / ticker
    # 买入数量只能保留3位小数
    if minQty == 0:
        num = Decimal(num).quantize(Decimal('0.000'), ROUND_DOWN)
    else:
        num = Decimal(num).quantize(Decimal(str(minQty)), ROUND_DOWN)
    num = float(num)
    if num < minQty:
        return 0
    # okex 有这样一条规则 交易张数必须是最小的整倍数  就比如DOGE的最小是1000个  那么买入2025个是会错误的   就只能买入2000个   为了统一  币安我干脆也这样算了
    if minQty > 0:
        num -= num % minQty
    return float(num) if minQty < 1 else int(num)

    
# 合约订单查询
def orderServiceCharge(orderid, api_info, symbol, limit=10):
    """
    币安合约订单查询
    :param orderid: 要获取收益和手续费的订单号
    :param api_info: api数据
    :param symbol: 交易对
    :param limit: 查询条数
    :return: {}
    """
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        ip = ip_list()
        exchange_class = getattr(ccxt, exchange_id)
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            # 'aiohttp_proxy': ip,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    
        if exchange_id == 'binance':
            info = exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': limit})
        else:
            info = exchange.private_get_trade_order({"instId": symbol, "ordId": orderid})
            info = info['data']
        revenue = 0
        fee = 0
        # 注意：交易所卖的时候有可能会分为几单卖出
        for i in info:
            if exchange_id == 'binance':
                if i['orderId'] == orderid:
                    # 盈利
                    revenue += float(i['realizedPnl'])
                    # 手续费
                    fee += float(i['commission'])
            else:
                if i['ordId'] == orderid:
                    # okex5
                    revenue += float(i['pnl'])
                    # 手续费 (okex的手续费是负数 需要转换为正数)
                    fee += float(i['fee']) * -1
        return {'revenue': revenue, 'fee': fee}
    except Exception as e:
        print(e)
        return {'revenue': 0, 'fee': 0}
        
# 合约持仓和保证金率查询
def orderMian( api_info, symbol, limit=10):
    info = redis_content.get('ensure_value' + api_info['platform'] + '_'+ symbol+'_'+'SWAP')
    if info is None or info=='':
        try:
            exchange_id = api_info['platform']
            api_key = api_info['api_key']
            secret_key = api_info['secret_key']
            passphrase = api_info['passphrase']
            ip = ip_list()
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                # 'aiohttp_proxy': ip,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
            if exchange_id == 'binance':
                info = exchange.fapiPrivate_get_leveragebracket({'symbol': symbol})
                info = info[0]['brackets']
            else:
                info = exchange.public_get_public_position_tiers({"instType": 'SWAP', "tdMode": "cross","uly":symbol[:-1]})
                info = info['data']
            redis_content.set('ensure_value' + api_info['platform'] + '_'+  symbol+'_'+'SWAP',json.dumps(info))
            return info
        except Exception as e:
            return False
    else:
        return json.loads(info)
# 合约手续费查询
def orderFee(api_info, symbol, limit=10):
    info = redis_content.get('fee_value' + api_info['platform'] + '_'+ symbol+'_'+'SWAP')
    if info is None or info=='':
        try:
            exchange_id = api_info['platform']
            api_key = api_info['api_key']
            secret_key = api_info['secret_key']
            passphrase = api_info['passphrase']
            ip = ip_list()
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
            
            if exchange_id == 'binance':
                info = exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': limit})
            else:
                info = exchange.private_get_account_trade_fee({"instType": 'SWAP'})
            info = info['data']
            redis_content.set('fee_value' + api_info['platform'] + '_'+  symbol+'_'+'SWAP',json.dumps(info))
            return info
        except Exception as e:
            return False
    else:
        return json.loads(info)
# 合约面值查询
def orderFace(api_info, symbol, limit=10):
    info = redis_content.get('face_value' + api_info['platform'] + '_'+ symbol+'_'+'SWAP')
    if info is None or info=='':
        try:
            exchange_id = api_info['platform']
            ip = ip_list()
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class({
                'timeout': 30000,
                'enableRateLimit': True,
                # 'aiohttp_proxy': ip,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
            resulf = {
                'instId': symbol + 'SWAP',  # 产品ID
                'instType': 'SWAP',
            }
            if exchange_id == 'binance':
                info = exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': limit})
            else:
                info = exchange.public_get_public_instruments(resulf)
            info = info['data']
            redis_content.set('face_value' + api_info['platform'] + '_'+  symbol+'_'+'SWAP',json.dumps(info))
            return info
        except Exception as e:
            return False
    else:
        return json.loads(info)
        
# 合约面值查询
def orderFaceAwait(api_info, symbol, limit=10):
    info = redis_content.get('face_value' + api_info['platform'] + '_'+ symbol+'_'+'SWAP')
    if info is None or info=='':
        try:
            exchange_id = api_info['platform']
            ip = ip_list()
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class({
                'timeout': 30000,
                'enableRateLimit': True,
                # 'aiohttp_proxy': ip,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
            resulf = {
                'instId': symbol + 'SWAP',  # 产品ID
                'instType': 'SWAP',
            }
            if exchange_id == 'binance':
                info =exchange.fapiPrivateGetUserTrades({'symbol': symbol, 'limit': limit})
            else:
                info = exchange.public_get_public_instruments(resulf)
            info = info['data']
            redis_content.set('face_value' + api_info['platform'] + '_'+  symbol+'_'+'SWAP',json.dumps(info))
            return info
        except Exception as e:
            return False
    else:
        return json.loads(info)
        
# 保证金率计算公式
def order_take(ensuer_account,executedQty,tick_price,ensure_value,platform):
    try:
        if platform =='binance':
            # 全仓账户余额
            MarginRatio = float(ensuer_account['crossWalletBalance'])+ float(ensuer_account['crossUnPnl'])
            # 维持保证金计算
            maintMarginRatio = float(executedQty) * float(tick_price) * float(ensure_value['maintMarginRatio'])
            return maintMarginRatio / MarginRatio *100
        else:
            return 0
    except Exception as e:
        return 0
# 保证金计算
def margin_ratio(executedQty,tick_price,lever,platform):
    try:
        if platform =='binance':
            # usdt
            margin_usdt = float(tick_price) * float(executedQty)
            return margin_usdt / lever
        else:
            return 0
    except Exception as e:
        return 0
    
    
def minQtys(symbol,platform):
    info = redis_content.get('minQtys_value' + platform)
    if info is None or info=='':
        try:
            exchange_class = getattr(ccxt, platform)
            exchange = exchange_class({
                'timeout': 30000,
            })
            if platform == 'binance':
                info =exchange.fapiPublic_get_exchangeinfo()
                redis_content.set('minQtys_value' + platform,json.dumps(info))
                info = info['symbols']
                for minQty_item in info:
                    if str(minQty_item['symbol']) ==symbol:
                        info = minQty_item['filters'][1]
            else:
                resulf = {
                    'instId': symbol + 'SWAP',  # 产品ID
                    'instType': 'SWAP',
                }
                info = exchange.public_get_public_instruments(resulf)
                redis_content.set('minQtys_value' + platform,json.dumps(info))
                info = info['data']
                for minQty_item in info:
                    if str(minQty_item['instId']) ==symbol+'SWAP':
                        info ={}
                        info['maxQty'] = 10000000
                        info['minQty'] = minQty_item['ctVal']
            return info
        except Exception as e:
            return False
    else:
        info = json.loads(info)
        if platform =='binance':
            info = info['symbols']
            for minQty_item in info:
                if str(minQty_item['symbol']) ==symbol:
                    info = minQty_item['filters'][1]
        else:
            info = info['data']
            for minQty_item in info:
                if str(minQty_item['instId']) ==symbol+'SWAP':
                    info ={}
                    info['maxQty'] = 10000000
                    info['minQty'] = minQty_item['ctVal']
        return info
    
def user_account(api_info,uid,platform):
    info = redis_content.get('account_usdt' + api_info['platform'] + '_'+str(uid))
    if info is None or info=='':
        try:
            exchange_id = api_info['platform']
            api_key = api_info['api_key']
            secret_key = api_info['secret_key']
            passphrase = api_info['passphrase']
            ip = ip_list()
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                # 'aiohttp_proxy': ip,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
            if exchange_id == 'binance':
                info =exchange.fapiPrivateV2_get_balance()
            else:
                return
            redis_content.set('account_usdt' + api_info['platform'] + '_'+str(uid),json.dumps(info))
            return info
        except Exception as e:
            return False
    else:
        return json.loads(info)
    
def orderLog(ret,platform):
    if platform == 'okex':
        if ret['code'] == '50114':
            ret['msg'] = '无效的授权,api秘钥未授权'
        if ret['code'] == '59102':
            ret['msg'] = '杠杆倍数超过最大杠杆倍数，请重新调整杠杆倍数'
    elif platform == 'binance':
        if ret['code'] == -2027:
            ret['msg'] = '挂单或持仓超出当前初始杠杆下的最大值'
        if ret['code'] == -2024:
            ret['msg'] = '持仓不足'
        if ret['code'] == -2028:
            ret['msg'] = '调整初始杠杆过低，导致可用余额不足'
        if ret['code'] == -2015:
            ret['msg'] = '无效的API密钥，IP或操作权限.'
        if ret['code'] == -2014:
            ret['msg'] = 'API-key 格式无效。'
        if ret['code'] == -2013:
            ret['msg'] = '订单不存在。'
        if ret['code'] == -1121 :
            ret['msg'] = '无效的交易对。'
        if ret['code'] == -1119:
            ret['msg'] = '客户自定义的订单ID为空。'
        if ret['code'] == -1117 :
            ret['msg'] = '无效买卖方向。'
        if ret['code'] == -4300 :
            ret['msg'] = '因为在期货账户注册60天后可以使用更高的杠杆率。'
    return ret
# 设置合约杠杆倍数
def set_lever(direction,symbol, api_info,type_all,lever,uid,platfrom='binance'):
    level = redis_content.get('account_level' + api_info['platform'] + '_'+str(uid)+symbol)
    if level is None or level=='':
        return request_level(direction,symbol, api_info,type_all,lever,uid,platfrom='binance')
    else:
        if json.loads(level)['lever'] == lever:
            return True
        else:
            return request_level(direction,symbol, api_info,type_all,lever,uid,platfrom='binance')
def request_level(direction,symbol, api_info,type_all,lever,uid,platfrom='binance'):
    ret = {}
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        exchange_class = getattr(ccxt, exchange_id)
        if int(type_all) == 0:
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        else:
            exchange = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'password': passphrase,
                'timeout': 30000,
                'enableRateLimit': True,
                'aiohttp_proxy': iplist[0],
                'options': {
                    'createMarketBuyOrderRequiresPrice': False,
                },
            })
        if exchange_id == 'binance':
            result = {
                'symbol': symbol.upper(),  # 产品ID
                'leverage': lever,  # 数量
            }
            re=exchange.fapiPrivate_post_leverage(result)
        else:
            direction = 'LONG' if direction == 1 else 'SHORT'
            result = {
                'instId': symbol.upper()+'SWAP',  # 产品ID
                'mgnMode': 'cross',  # 交易模式 保证金模式：isolated：逐仓 ；cross：全仓
                # 'posSide': direction.lower(),  # 持仓方向 long 开多 short 开空
                'lever': lever,  # 数量
            }
            re=exchange.private_post_account_set_leverage(result)
        res={'lever':lever}
        redis_content.set('account_level' + api_info['platform'] + '_'+str(uid)+str(symbol),json.dumps(res))
        return True
    except Exception as e:
        msg = json.loads(e.args[0].split(' ', 1)[1])
        ret['code'] = msg['code']
        ret['data'] = {}
        ret['msg'] = msg['msg']
    return ret
    
    
def set_listenkey(api_info,uid,platform):
    if platform == 'binance':
        info = redis_content.get('listenkey' + api_info['platform'] + '_'+str(uid))
        if info is None or info=='':
            get_listenkey(api_info,uid,platform)
        else:
            info =json.loads(info)
            if 'expire' in info.keys() or info['expire'] == True:
                get_listenkey(api_info,uid,platform)
            return True
    else:
        info = redis_content.get('listenkey' + api_info['platform'] + '_'+str(uid))
        
        if info is None or info=='':
            get_listenkey(api_info,uid,platform)
        else:
            info =json.loads(info)
            if int(info['time'])+600000*59<time.time()*1000:
                get_listenkey(api_info,uid,platform)
            return True
def get_listenkey(api_info,uid,platform):
    try:
        exchange_id = api_info['platform']
        api_key = api_info['api_key']
        secret_key = api_info['secret_key']
        passphrase = api_info['passphrase']
        exchange_class = getattr(ccxt, exchange_id)
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
        if exchange_id == 'binance':
            info =exchange.fapiPrivate_post_listenkey()
            info['id'] = uid
            info['expire'] = False
            info['time'] = int(time.time()*1000)
            redis_content.set('listenkey' + '_'+str(info['listenKey']) + '_'+str(uid),json.dumps(info))
            redis_content.set('listenkey' + api_info['platform'] + '_'+str(uid),json.dumps(info))
        else:
            info = exchange.private_get_account_config()
            info = info['data'][0]
            info['id'] = uid
            info['api_info'] = api_key
            info['secret_key'] = secret_key
            info['password'] = passphrase
            info['time']=int(time.time()*1000)
            info['expire'] = False
            redis_content.set('listenkey' + api_info['platform'] + '_'+str(uid),json.dumps(info))
            redis_content.set('listenkey' + '_'+str(info['uid']) + api_info['platform'],json.dumps(info))
        return info
    except Exception as e:
        print(e)
        return False
        
        
        
        
        
        
        
        
        
        
        
        
#获取强平getQiang价格
def getQiang(api_info,uid,platform,symbol,longs):
    if longs == 0:
        longs = 'SHORT'
    else:
        longs = 'LONG'
    try:
        if platform =='binance':
            qiang = redis_content.hget('account_qiang' + api_info['platform'] + '_'+str(uid),symbol+str(longs)+str(uid))
            if qiang=='' or qiang is None:
                info =get(api_info,uid,platform,symbol,longs)
                return info
            else:
                info = json.loads(qiang)
                print(qiang)
                # print(int(info['expire'])+100000)
                # print(int(time.time()*1000))
                # print(int(info['expire'])+300000<time.time()*1000)
                if int(info['expire'])+300000<time.time()*1000:
                    info = get(api_info,uid,platform,symbol,longs)
                return info
        else:
            qiang = redis_content.hget('account_qiang' + api_info['platform'] + '_'+str(uid),symbol+str(longs)+str(uid))
            if qiang=='' or qiang is None:
                info =get(api_info,uid,platform,symbol,longs)
                return info
            else:
                info = json.loads(qiang)
                return info
    except Exception as e:
        return False

def get(api_info,uid,platform,symbol,longs):
    
    exchange_id = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        'apiKey': api_key,
        'secret': secret_key,
        'password': passphrase,
        'timeout': 30000,
        'enableRateLimit': True,
        'options': {
            'createMarketBuyOrderRequiresPrice': False,
        },
    })
    if exchange_id == 'binance':
        info =exchange.fapiPrivate_get_positionrisk({'symbol': symbol})
    else:
        return False
    for ite in info:
        if ite['marginType'] == 'cross' and ite['positionSide']==longs:
            info = ite
            info['expire'] =time.time()*1000
    qing = redis_content.hset('account_qiang' + api_info['platform'] + '_'+str(uid),symbol+str(longs)+str(uid),json.dumps(info))
    return info
     