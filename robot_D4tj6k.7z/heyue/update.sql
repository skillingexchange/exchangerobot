alter table jl_quant_robot add transaction_type int(10)  not null  default 1 COMMENT '交易类型';
alter table jl_quant_robot add is_trend int(2)  not null  default 1 COMMENT '交易';
alter table jl_quant_robot_log add transaction_type int(10)  not null  default 1 COMMENT '交易类型';
alter table jl_quant_robot_order add transaction_type int(10)  not null  default 1 COMMENT '交易类型';
alter table jl_quant_robot_revenue add transaction_type int(10)  not null  default 1 COMMENT '交易类型';
alter table jl_spot_market add instType varchar (255)  not null  default '' COMMENT '交易币种类型';