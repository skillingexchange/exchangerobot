<?php

namespace app;


class Ticker
{
    public static function symbol()
    {
        global $db;
        $data = $db->from('jl_ticker')
            ->select('lower(replace(market,\'/\',\'-\')) as symbol')
            ->where('exchange_class = \'huobipro\'')
            ->query();
        $data = array_column($data, 'symbol');
        return $data;
    }

    public static function setData($ch, $tick)
    {
    	//last最新成交价/本阶段收盘价
//  	open_24h  本阶段开盘价/24小时开盘价
        global $db, $redis;
        $redis->get('kline_okex_' . $ch, function ($result, $redis) use ($ch, $tick, $db) {
//      	var_dump($result);
            if ($result) {
                $result = json_decode($result, true);
                if ( $result['last'] != $tick['last'] || $result['open24h'] != $tick['open24h']) {
                    $result = null;
                }
            }
            if (!$result) {
                $redis->set('kline_okex_' . $ch, json_encode($tick));
                //	(本阶段收盘价-本阶段开盘价*100)/本阶段开盘价= 涨幅
                //(整整24小时前，向后数的第一次成交价格-最新成交价格*100)/最新成交价格= 涨幅
                $change = (($tick['last']-$tick['open24h'])*100)/$tick['open24h'];
                $change = bcadd($change,0,8);
//                $change = bcsub($tick['close'], $tick['open'], 8);
//                $change = bcdiv($change * 100, $tick['open'], 8);
                $data = [
                    'price'       => $tick['last'],
                    'change'      => $change,
                    'update_time' => time(),
                ];
                $redis->set('price_okex_'.$ch,$tick['last']);
				//jl_ticker表的数据缓存   读取数据优先读取redis里面的数据
                $result = $redis->hMSet('ticker_price_okex_'.$ch,[
                	'price'       => $tick['last'],
                    'change'      => $change,
                    'update_time' => time(),
                	'where'=>'exchange_class = \'okex\' and lower(replace(market,\'/\',\'\')) = \'' . $ch . '\'',
                ]);
                $redis->set('redis_titcker_okex_prices',time());
            }
        });
    }
    
    public static function setSWAPData($ch, $tick)
    {
    	//last最新成交价/本阶段收盘价
//  	open_24h  本阶段开盘价/24小时开盘价
        global $db, $redis;
        $redis->get('kline_okex_' . $ch, function ($result, $redis) use ($ch, $tick, $db) {
//      	var_dump($result);
            if ($result) {
                $result = json_decode($result, true);
                if ( $result['last'] != $tick['last'] || $result['open24h'] != $tick['open24h']) {
                    $result = null;
                }
            }
            if (!$result) {
                $redis->set('kline_okex_' . $ch, json_encode($tick));
                $redis->set('price_okex_'.$ch,$tick['last']);
                $result = $redis->hMSet('ticker_price_okex_'.$ch,[
                	'price'       => $tick['last'],
                    'change'      => $change,
                    'update_time' => time(),
                ]);
            }
        });
    }
    
    public static function setKlineData($ch, $time, $close)
    {
    	global $redis,$sync_redis;
//		名称
		$string = $ch."_kline_okex5";
		$fs = fopen('./log/'.$string.'.log', 'a+');
       	fwrite($fs, $time."___".$close."\n");
       	fclose($fs);
		$sync_redis->hset($string,$time,$close);
		
		$length = $sync_redis->hLen($string);
		$number = 365;
		if($length > $number){
			# 删除前面的
		    $data = $sync_redis->hKeys($string);
		    $vi = 0;
		    # 需要删除多少个
		    $lens = $length - $number;
		    foreach($data as $k=>$v){
		    	if($vi < $lens){
		            $sync_redis->hdel($string, $v);
		        }else{
		            break;
		        }
		        $vi ++;
		    }   
		}
    }
}
