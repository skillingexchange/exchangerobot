<?php

function dump()
{
    $vars = func_get_args();
    if (empty($vars)) {
        return;
    }
    foreach ($vars as $var) {
        var_dump($var);
    }
}

function die_dump()
{
    dump();
    die();
}

function get_config($key = null)
{
    $config = require_once __DIR__ . '/config.php';
    if (!is_null($key)) {
        $config = $config[$key] ?? null;
    }
    return $config;
}

function logs()
{
    $vars = func_get_args();
    if (empty($vars)) {
        return;
    }
    $time = date('Y-m-d H:i:s');
    $fill = str_pad('', strlen($time));
    $cont = '';
    foreach ($vars as $k => $var) {
        if ($k == 0) {
            $cont .= $time;
        } else {
            $cont .= $fill;
        }
        $cont .= ' ' . (is_string($var) ? $var : json_encode($var)) . "\n";
    }
    $date = str_replace('-', '_', substr($time, 0, 10));
    $path = __DIR__ . '/log/log_' . $date . '.log';
    if (!is_file($path)) {
        touch($path);
    }
    $file = fopen($path, 'a+');
    fwrite($file, $cont);
    fclose($file);
}
