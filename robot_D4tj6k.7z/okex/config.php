<?php
return [
    'database' => [
        'host'     => '127.0.0.1',
        'port'     => '3306',
        'user'     => 'yan_robot',
        'password' => 'fEmyhzsjDCYz6CiK',
        'db_name'  => 'yan_robot',
    ],
    'redis'    => [
        'host' => '127.0.0.1',
        'port' => '6379',
        'auth' => 'scmmwl888',
        'db'=>0
    ],
];

