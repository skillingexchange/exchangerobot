#! /bin/bash
cd /www/wwwroot/robot_yanshi/okex/
php start.php reload
