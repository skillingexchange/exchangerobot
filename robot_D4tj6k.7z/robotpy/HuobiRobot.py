import MySQLdb
import configparser
import sys
import time
import random
from Huobipro import Huobipro
import json
from decimal import Decimal, ROUND_DOWN
import hashlib
import uuid
from database import MySqLHelper
import redisbase

robot_reids = redisbase.robot_redis


# zl 2021-05-07 机器人数据库操作基础类
class huobirobot:
    def __init__(self):
        # 初始化函数，初始化数据库连接
        # conn = self.Conn()
        # self.conn = conn
        self.cur = MySqLHelper()

    # 启动机器人
    def enableRobot(self, robot, market, third_api, source=1):
        # 获取当前状态避免重复开单
        key = robot_reids.keys('user_robot_*_' + str(robot['id']))
        key = key[0]
        now = robot_reids.hget(key, 'values_str')
        if now != '':
            return self.returnAPI('', 0)
        # 添加启动中状态，若有此状态则返回空值
        coin_name = 'user_robot_enable'
        coin_key = 'robot_' + str(robot['id'])
        hascover = self.rediscoin(coin_name, coin_key)
        if not hascover is None and int(hascover) == 1:
            return self.returnAPI('')
        self.rediscoin(coin_name, coin_key, 1)
        res = self.insertLog(robot['uid'], robot['id'], market['platform'], '机器人开始启动')
        try:
            self.updateRobotData(robot['id'], robot['uid'], {'status': 1})
            #     交易小数精度
            precision = market['value_precision']
            #     自建单号
            order_no = self.getOrderNo(robot['id'], 'quant_robot_order', 'FR')
            #     下单总金额 USDT
            amount = robot['first_order_value']
            #     首单加倍
            if int(robot['is_double']) == 1:
                amount = float(robot['first_order_value']) * 2
            #     创建订单
            resp = self.createOrder(amount, market['market'], third_api, order_no)
            if resp['code'] == 0:
                msg = self.parseMsg(resp['msg'])
                if msg == '请求过于频繁' and source == 2:
                    self.updateRobotData(robot['id'], robot['uid'], {'status': 1})
                    self.redisdelcoin(coin_name, coin_key)
                    return self.returnAPI('')
                msg = '首单开单失败:' + msg
                self.insertLog(robot['uid'], robot['id'], robot['platform'], msg)
                self.redisdelcoin(coin_name, coin_key)
                return self.returnAPI(msg)
            order_id = resp['data']['id']
            money_name = market['money']
            # ROUND_HALF_UP().prec = precision
            exame = '0.'
            i = 0
            while i < precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            deal_money = Decimal(resp['data']['field-cash-amount']).quantize(exame, ROUND_DOWN)
            deal_amount = Decimal(resp['data']['field-amount']).quantize(exame, ROUND_DOWN)
            # ROUND_HALF_UP().prec = 8
            deal_fee = Decimal(resp['data']['field-fees']).quantize(Decimal('0.00000000'), ROUND_DOWN)
            # price = bcdiv(deal_money, deal_amount, precision)
            # ROUND_HALF_UP().prec = precision
            price = deal_money / deal_amount
            side = 2
            pid = self.uuid()
            # print(pid)
            # deal_amount = bcsub(deal_amount, deal_fee, precision)
            deal_amount = deal_amount - deal_fee
            # 组合机器人数据库数据
            build_param = {'platform': market['platform'], 'uid': robot['uid'], 'order_id': order_id,
                           'qrobot_id': robot['id'], 'side': side, 'market': market['market_name'],
                           'stock': market['stock'], 'money': money_name, 'deal_money': deal_money,
                           'deal_amount': deal_amount, 'price': price, 'order_status': 1, 'is_first': 1, 'pid': pid,
                           'order_no': order_no, 'revenue': 0, 'fee': deal_fee, 'amount': 0, 'total': amount}
            # 生成插入语句
            order_sql = self.build_insert('jl_quant_robot_order', build_param)
            # 执行插入
            self.cur.execute(order_sql)
            #     更新机器人信息
            #     组合返回数据
            values_dict = {'order_id': order_id, 'first_order_price': float(price), 'base_price': float(price),
                           'up_price': 0, 'down_price': 0, 'trend_side': 0, 'order_count': 0,
                           'last_price': float(price), 'deal_amount': float(deal_amount),
                           'deal_money': float(deal_money), 'order_finish': 0, 'pid': pid}
            for k in values_dict.keys():
                if type(values_dict[k]) == Decimal:
                    values_dict[k] = float(values_dict[k])
            robotdata = {'show_msg': '下单成功', 'run_status': 1, 'status': 1, 'order_status': 1,
                         'values_str': json.dumps(values_dict, ensure_ascii=False)}
            self.updateRobotData(robot['id'], robot['uid'], robotdata)
            self.insertLog(robot['uid'], robot['id'], market['platform'],
                           '首单开单：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(
                               price) + money_name + ',成交数' + str(deal_amount) + market['stock'])
        except Exception as e:
            e = str(e)
            self.updateRobotData(robot['id'], robot['uid'], {'status': 0})
            self.insertLog(robot['uid'], robot['id'], market['platform'], '启用失败' + str(e))
            self.redisdelcoin(coin_name, coin_key)
            return self.returnAPI('启用失败' + e)

        # self.conn.commit()
        # self.cur.close()
        # self.conn.close()
        self.redisdelcoin(coin_name, coin_name)
        return self.returnAPI('启用成功', 1)

    # 清仓
    def cleanRobot(self, robot, market, third_api, source=1):
        self.insertLog(robot['uid'], robot['id'], market['platform'], '机器人开始清仓')
        try:
            values_dict = json.loads(robot['values_str'])
            if values_dict is None:
                return self.returnAPI('数据不存在')
            self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓前关闭机器人')
            self.updateRobotData(robot['id'], robot['uid'], {'run_status': 0})
            order_no = self.getOrderNo(robot['id'], 'quant_robot_order', 'CL')
            #     火币交易后小数精度
            precision = market['value_precision']
            #     请求接口卖出时小数精度
            sell_precision = market['amount_precision']
            #     卖出数量
            #     amount = bcadd(values_dict['deal_amount'], 0,sell_precision)
            huobi = Huobipro(third_api['api_key'], third_api['secret_key'])
            symbol_balance = huobi.getAccountBalance(third_api['account_id'], market['stock'])
            # symbol_balance2 = bcadd(symbol_balance, 0,sell_precision)
            # ROUND_HALF_UP().prec = sell_precision
            exame = '0.'
            i = 0
            while i < sell_precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            symbol_balance2 = Decimal(symbol_balance).quantize(exame, ROUND_DOWN)
            if symbol_balance2 <= 0:
                self.updateRobotData(robot['id'], robot['uid'],
                                     {'show_msg': '清仓失败:数量不足' + str(symbol_balance), 'values_str': '', 'revenue': 0,
                                      'is_clean': 0, 'run_status': 1})
                self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓失败：数量不足' + str(symbol_balance))
                return self.returnAPI('清仓卖出失败')
            resp = self.createOrder(symbol_balance2, market['market'], third_api, order_no, 'sell-market')
            if resp['code'] == 0:
                msg = self.parseMsg(resp['msg'])
                msg = '清仓卖出失败:' + msg
                self.updateRobotData(robot['id'], robot['uid'], {'show_msg': msg, 'run_status': 1})
                self.insertLog(robot['uid'], robot['id'], market['platform'], msg)
                return self.returnAPI('清仓卖出失败')
            order_id = resp['data']['id']
            side = 1
            money_name = market['money']
            # ROUND_HALF_UP().prec = precision
            exame = '0.'
            i = 0
            while i < precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            deal_money = Decimal(resp['data']['field-cash-amount']).quantize(exame, ROUND_DOWN)
            deal_amount = Decimal(resp['data']['field-amount']).quantize(exame, ROUND_DOWN)
            # ROUND_HALF_UP().prec = 8
            deal_fee = Decimal(resp['data']['field-fees']).quantize(Decimal('0.00000000'), ROUND_DOWN)
            # ROUND_HALF_UP().prec = precision
            price = deal_money / deal_amount
            deal_money = deal_money - deal_fee
            revenue = deal_money - Decimal(values_dict['deal_money']).quantize(exame, ROUND_DOWN)
            if revenue < 0:
                revenue = 0
            # 订单数据插入
            order_data = {'platform': market['platform'], 'uid': robot['uid'], 'order_id': order_id,
                          'qrobot_id': robot['id'], 'side': side, 'market': market['market_name'],
                          'stock': market['stock'], 'money': money_name, 'order_status': 1, 'is_first': 2,
                          'order_no': order_no, 'pid': values_dict['pid'], 'deal_money': deal_money,
                          'deal_amount': deal_amount, 'revenue': revenue, 'fee': deal_fee,
                          'total': values_dict['deal_amount'], 'amount': values_dict['order_count']}
            order_data_sql = self.build_insert('jl_quant_robot_order', order_data)
            self.cur.execute(order_data_sql)
            # 盈利数据插入
            quant_robot_revenue_data = {'platform': market['platform'], 'qrobot_id': robot['id'],
                                        'pid': values_dict['pid'], 'uid': robot['uid'], 'market': market['market_name'],
                                        'stock': market['stock'], 'money': money_name, 'revenue': revenue,
                                        'deal_status': 0}
            quant_robot_revenue_data_sql = self.build_insert('jl_quant_robot_revenue', quant_robot_revenue_data)
            self.cur.execute(quant_robot_revenue_data_sql)
            #     机器人修改
            update_data['is_clean'] = 0
            update_data['status'] = 0
            update_data['run_status'] = 0
            update_data['new'] = 0
            self.updateRobotData(robot['id'], robot['uid'], update_data)
            self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓卖出：成交总价' + str(
                deal_money) + money_name + ',成交均价' + price + '' + money_name + ',成交数' + deal_amount + '' + market[
                               'stock'])
            # 日志写入
            self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓成功,机器人已经关闭')

        except Exception as e:
            e = str(e)
            self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1})
            self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓失败' + e)
            return self.returnAPI('清仓失败' + e)
        # self.conn.commit()
        # self.cur.close()
        # self.conn.close()
        return self.returnAPI('清仓成功', 1)

    def rediscoin(self, name, key, value=0):
        redis = redisbase.redis_content
        if value > 0:
            hascover = redis.hset(name, key, value)
            return hascover
        else:
            return redis.hget(name, key)

    def redisdelcoin(self, name, key):
        redis = redisbase.redis_content
        return redis.hdel(name, key)

    # 补仓
    def coverRobot(self, robot, market, third_api, total, source=1):
        # 添加补仓中状态，若有此状态则返回空值
        coin_name = 'user_robot_cover'
        coin_key = 'robot_' + str(robot['id'])
        hascover = self.rediscoin(coin_name, coin_key)
        if not hascover is None and int(hascover) == 1:
            values_dict = json.loads(robot['values_str'])
            values_dict['trend_side'] = 0
            values_dict = json.dumps(values_dict, ensure_ascii=False)
            self.updateRobotData(robot['id'], robot['uid'], {"values_str": values_dict})
            # self.insertLog(robot['uid'], robot['id'], market['platform'], '补仓进行中，等待补仓完成')
            return self.returnAPI('')
        self.rediscoin(coin_name, coin_key, 1)
        # self.insertLog(robot['uid'], robot['id'], market['platform'], '机器人开始补仓')
        try:
            # 火币交易后小数精度
            precision = market['value_precision']
            # 请求接口卖出时小数精度
            sell_precision = market['amount_precision']
            # ROUND_HALF_UP().prec = sell_precision
            exame = '0.'
            i = 0
            while i < sell_precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            amount = Decimal(total).quantize(exame, ROUND_DOWN)
            # print(amount)
            if amount <= 5:
                self.insertLog(robot['uid'], robot['id'], market['platform'], '补仓失败,金额过低')
                self.redisdelcoin(coin_name, coin_key)
                values_dict = json.loads(robot['values_str'])
                values_dict['trend_side'] = 0
                values_dict = json.dumps(values_dict, ensure_ascii=False)
                self.updateRobotData(robot['id'], robot['uid'], {"values_str": values_dict})
                return self.returnAPI('补仓失败,金额过低')
            # self.insertLog(robot['uid'], robot['id'], market['platform'], '补仓前关闭机器人')
            self.updateRobotData(robot['id'], robot['uid'], {'run_status': 0})
            order_no = self.getOrderNo(robot['id'], 'quant_robot_order', 'CL')
            resp = self.createOrder(amount, market['market'], third_api, order_no)
            # print('补仓返回')
            # print(resp)
            if resp['code'] == 0:
                msg = self.parseMsg(resp['msg'])
                if msg == '请求过于频繁':
                    if source == 2:
                        self.insertLog(robot['uid'], robot['id'], market['platform'], '请求超时重启机器人')
                        self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1})
                    self.redisdelcoin(coin_name, coin_key)
                    return self.returnAPI(msg)
                if msg == '账户余额不足' and source == 2:
                    self.updateRobotData(robot['id'], robot['uid'], {'run_status': 0})
                msg = '补仓失败：' + str(msg)
                values_dict = json.loads(robot['values_str'])
                values_dict['trend_side'] = 0
                values_dict = json.dumps(values_dict, ensure_ascii=False)
                self.insertLog(robot['uid'], robot['id'], market['platform'], msg)
                self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1, "values_str": values_dict})
                self.redisdelcoin(coin_name, coin_key)
                return self.returnAPI(msg)

            order_id = resp['data']['id']
            money_name = market['money']
            # ROUND_HALF_UP().prec = precision
            exame = '0.'
            i = 0
            while i < precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            deal_money = Decimal(resp['data']['field-cash-amount']).quantize(exame, ROUND_DOWN)
            deal_amount = Decimal(resp['data']['field-amount']).quantize(exame, ROUND_DOWN)
            # ROUND_HALF_UP().prec = 8
            deal_fee = Decimal(resp['data']['field-fees']).quantize(Decimal('0.00000000'), ROUND_DOWN)
            # ROUND_HALF_UP().prec = precision
            price = deal_money / deal_amount
            side = 2
            deal_amount = deal_amount - deal_fee
            insert_order_data = {'platform': market['platform'], 'uid': robot['uid'], 'order_id': order_id,
                                 'qrobot_id': robot['id'], 'side': side, 'market': market['market_name'],
                                 'stock': market['stock'], 'money': money_name, 'deal_money': deal_money,
                                 'deal_amount': deal_amount, 'price': price, 'order_no': order_no, 'order_status': 1,
                                 'revenue': 0, 'fee': deal_fee, 'total': amount}
            # print(robot['values_str'])
            if robot['values_str'] is None or robot['values_str'] == '':
                pid = self.uuid()
                insert_order_data['pid'] = pid
                insert_order_data['is_first'] = 1
                insert_order_data['amount'] = 0

                values_dict = {'first_order_price': price, 'base_price': price, 'up_price': 0, 'down_price': 0,
                               'trend_side': 0, 'order_count': 0, 'last_price': price, 'deal_amount': deal_amount,
                               'deal_money': deal_money, 'order_finish': 0, 'pid': pid}
                for k in values_dict.keys():
                    if type(values_dict[k]) == Decimal:
                        values_dict[k] = float(values_dict[k])
                self.updateRobotData(robot['id'], robot['uid'], {'show_msg': '(补仓)下单成功', 'run_status': 1,
                                                                 'values_str': json.dumps(values_dict,
                                                                                          ensure_ascii=False)})
                self.insertLog(robot['uid'], robot['id'], market['platform'],
                               '(补仓)首单开单：成交总价' + str(amount) + str(money_name) + ',成交均价' + str(
                                   price) + money_name + ',成交数' + str(deal_amount) + market['stock'])
            else:
                values_dict = json.loads(robot['values_str'])
                for k in values_dict.keys():
                    v = values_dict[k]
                    if type(v) == float or k in ['deal_amount', 'deal_money']:
                        values_dict[k] = Decimal(v).quantize(Decimal('0.0000000000'), ROUND_DOWN)
                insert_order_data['pid'] = values_dict['pid']
                insert_order_data['is_first'] = 2
                insert_order_data['amount'] = int(values_dict['order_count']) + 1
                values_dict['trend_side'] = 0
                values_dict['deal_amount'] = values_dict['deal_amount'] + deal_amount
                values_dict['deal_money'] = values_dict['deal_money'] + deal_money
                # ROUND_HALF_UP().prec = 10
                values_dict['base_price'] = Decimal(values_dict['deal_money'] / values_dict['deal_amount']).quantize(
                    Decimal('0.0000000000'), ROUND_DOWN)

                #         自动补仓
                if source == 2:
                    # print('自动补仓开始')
                    values_dict['order_count'] = int(values_dict['order_count']) + 1
                    if int(values_dict['order_count']) >= int(robot['max_order_count']):
                        self.insertLog(robot['uid'], robot['id'], market['platform'],
                                       '达到最大补仓数量次数：单数 ' + str(values_dict['order_count']))
                        values_dict['order_finish'] = 1

                ticker_info = self.cur.fetchone(
                    "select * from jl_ticker where exchange_class='huobipro' and market = '" + market[
                        'market_name'] + "'")
                if not ticker_info:
                    ticker_price = 0
                else:
                    ticker_price = ticker_info['price']
                values_dict['last_price'] = ticker_price
                for k in values_dict.keys():
                    if type(values_dict[k]) == Decimal:
                        values_dict[k] = float(values_dict[k])

                self.updateRobotData(robot['id'], robot['uid'], {'show_msg': '补仓成功', 'run_status': 1,
                                                                 'values_str': json.dumps(values_dict,
                                                                                          ensure_ascii=False)})

                self.insertLog(robot['uid'], robot['id'], market['platform'],
                               '补仓：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(
                                   price) + money_name + ',成交数' + str(deal_amount) + market['stock'])

                self.insertLog(robot['uid'], robot['id'], market['platform'],
                               '基准价调整为:' + str(values_dict['base_price']))
            insert_sql = self.build_insert('jl_quant_robot_order', insert_order_data)
            self.cur.execute(insert_sql)
        except Exception as e:
            e = str(e)
            # print(e)
            self.insertLog(robot['uid'], robot['id'], market['platform'], '补仓失败' + e)
            self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1})
            self.redisdelcoin(coin_name, coin_key)
            return self.returnAPI('补仓失败' + e)
        # self.conn.commit()
        # self.cur.close()
        # self.conn.close()
        self.redisdelcoin(coin_name, coin_key)
        return self.returnAPI('补仓成功', 1)

    # 更新机器人信息
    def updateRobotData(self, robot_id, uid, params):
        # update_sql = "update jl_quant_robot set "
        # update_data = []
        # strs = ""
        # for k in params.keys():
        #     strs = k + "='" + str(params[k]) + "'"
        #     update_data.append(strs)
        # update_data = ','.join(update_data)
        # update_sql = update_sql + update_data
        # update_sql += " where id = '"+str(robot_id)+"' "
        # # print(update_sql)
        # res = self.cur.execute(update_sql)
        res = redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, params)
        return res

    # 卖出
    def sellRobot(self, robot, market, third_api, source=1):
        # 添加卖出中状态，若有此状态则返回空值
        coin_name = 'user_robot_sell'
        coin_key = 'robot_' + str(robot['id'])
        hascover = self.rediscoin(coin_name, coin_key)
        if not hascover is None and int(hascover) == 1:
            self.redisdelcoin(coin_name, coin_key)
            return self.returnAPI('')
        self.rediscoin(coin_name, coin_key, 1)
        self.insertLog(robot['uid'], robot['id'], market['platform'], '机器人开始卖出')
        try:
            values_dict = json.loads(robot['values_str'])
            if values_dict is None or values_dict == {}:
                # self.redisdelcoin(coin_name, coin_key)
                return self.returnAPI('数据不存在')
            order_no = self.getOrderNo(robot['id'], 'quant_robot_order', 'CL')
            # 火币交易后小数精度
            precision = market['value_precision']
            # 请求接口卖出时小数精度
            sell_precision = market['amount_precision']
            # print('卖出前关闭，避免冲突')
            self.insertLog(robot['uid'], robot['id'], market['platform'], '卖出前关闭机器人')
            self.updateRobotData(robot['id'], robot['uid'], {"status": 0})
            # print('关闭完成')
            # ROUND_HALF_UP().prec = sell_precision
            # print(sell_precision)
            if sell_precision > 0:
                exame = '0.'
                i = 0
                while i < sell_precision:
                    exame += '0'
                    i += 1
                exame = Decimal(exame)
                amount = Decimal(values_dict['deal_amount']).quantize(exame, ROUND_DOWN)
            else:
                amount = int(float(values_dict['deal_amount']))
            # print('amount-' + str(amount))
            resp = self.createOrder(amount, market['market'], third_api, order_no, 'sell-market')
            # print('卖出订单返回： '+str(resp))
            # print(resp)
            if resp['code'] == 0:
                msg = self.parseMsg(resp['msg'])
                # print(msg)
                if msg == '请求过于频繁' and source == 2:
                    self.insertLog(robot['uid'], robot['id'], market['platform'], '接口请求失败3秒后重启机器人')
                    time.sleep(3)
                    self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1})
                    self.insertLog(robot['uid'], robot['id'], market['platform'], '后重启机器人成功')
                    self.redisdelcoin(coin_name, coin_key)
                    return self.returnAPI('接口请求失败重启机器人')
                if msg == '账户余额不足':
                    huobi = Huobipro(third_api['api_key'], third_api['secret_key'])
                    symbol_balance = symbol_balance_old = huobi.getAccountBalance(third_api['account_id'],
                                                                                  market['stock'])
                    # ROUND_HALF_UP().prec = sell_precision
                    exame = '0.'
                    i = 0
                    while i < sell_precision:
                        exame += '0'
                        i += 1
                    exame = Decimal(exame)
                    symbol_balance = Decimal(symbol_balance).quantize(exame, ROUND_DOWN)
                    if symbol_balance > 0:
                        amount = symbol_balance
                        order_no = self.getOrderNo(robot['id'], 'quant_robot_order', 'CL')
                        resp = self.createOrder(amount, market['market'], third_api, order_no, 'sell-market')
                        # print('实际卖出订单返回： ' + str(resp))
                        if resp['code'] == 0:
                            msg = self.parseMsg(resp['msg'])
                            if 'Sell amount can not be less than' in msg:
                                # 实际仓库剩余不足，查询订单详情
                                self.cur.execute(
                                    "update jl_quant_robot set values_str='' where id='" + str(robot['id']) + "'")
                                msg = '实际持仓额不足'
                            # 自动下单且限流 返回空 等候重新下单
                            if msg == '请求过于频繁' and source == 2:
                                self.updateRobotData(robot['id'], robot['uid'], {"status": 1})
                                self.returnAPI('')
                            # 余额不足
                            if msg == '实际持仓额不足' or msg == '账户余额不足':
                                self.cur.execute(
                                    "update jl_quant_robot set values_str='' where id='" + str(robot['id']) + "'")
                                self.insertLog(robot['uid'], robot['id'], market['platform'],
                                               "实际持仓仅" + str(symbol_balance) + "，清空数据自动重启")
                                self.updateRobotData(robot['id'], robot['uid'],
                                                     {'values_str': '', 'revenue': 0, 'run_status': 1, 'is_clean': 0})
                                self.redisdelcoin(coin_name, coin_key)
                                return self.returnAPI('卖出失败:' + "实际持仓仅" + str(symbol_balance) + "，清空数据自动重启")
                            msg = '卖出失败' + str(msg)
                            self.insertLog(robot['uid'], robot['id'], market['platform'], msg)
                            self.updateRobotData(robot['id'], robot['uid'], {'is_clean': 0, 'run_status': 1})
                            self.redisdelcoin(coin_name, coin_key)
                            return self.returnAPI(msg)
                        else:
                            self.updateRobotData(robot['id'], robot['uid'], {'new': 0, 'run_status': 0,'is_clean': 0})
                            print('卖出成功')
                            # self.insertLog(robot['uid'], robot['id'], market['platform'], '卖出失败：余额不足')
                            # self.updateRobotData(robot['id'], robot['uid'], {'is_clean': 0, 'run_status': 0})
                            # # self.insertLog(robot['uid'], robot['id'], market['platform'],)
                            # self.redisdelcoin(coin_name, coin_key)
                            # return self.returnAPI('卖出失败')
                    else:
                        if msg == '账户余额不足' or msg == '余额不足':
                            self.cur.execute(
                                "update jl_quant_robot set values_str='' where id='" + str(robot['id']) + "'")
                            self.insertLog(robot['uid'], robot['id'], market['platform'],
                                           "实际持仓仅" + str(symbol_balance) + "，需手动启动2")
                            self.updateRobotData(robot['id'], robot['uid'],
                                                 {'values_str': '', 'revenue': 0, 'run_status': 0, 'is_clean': 0})
                            return self.returnAPI('卖出失败:' + "实际持仓仅" + str(symbol_balance) + "，需手动启动")
                        else:
                            self.insertLog(robot['uid'], robot['id'], market['platform'], '卖出失败:余额不足')
                            self.updateRobotData(robot['id'], robot['uid'],
                                                 {'is_clean': 0, 'stauts': 0, 'values_str': '', 'revenue': 0})
                            self.insertLog(robot['uid'], robot['id'], market['platform'],
                                           '卖出失败：' + str(msg) + str(symbol_balance))
                            self.redisdelcoin(coin_name, coin_key)
                        return self.returnAPI('卖出失败:' + "实际持仓仅" + str(symbol_balance) + "，需手动启动")
                else:
                    msg = '卖出失败' + msg
                    self.insertLog(robot['uid'], robot['id'], market['platform'], msg)
                    self.updateRobotData(robot['id'], robot['uid'], {"run_status": 1})
                    self.redisdelcoin(coin_name, coin_key)
                    return self.returnAPI('卖出失败' + msg)
            order_id = resp['data']['id']
            side = 1
            money_name = market['money']
            # ROUND_HALF_UP().prec = precision
            exame = '0.'
            i = 0
            while i < precision:
                exame += '0'
                i += 1
            exame = Decimal(exame)
            deal_money = Decimal(float(resp['data']['field-cash-amount'])).quantize(exame, ROUND_DOWN)
            deal_amount = Decimal(float(resp['data']['field-amount'])).quantize(exame, ROUND_DOWN)
            # ROUND_HALF_UP().prec = 8
            deal_fee = Decimal(float(resp['data']['field-fees'])).quantize(Decimal('0.00000000'), ROUND_DOWN)
            # ROUND_HALF_UP().prec = precision
            price = deal_money / deal_amount
            deal_money = deal_money - deal_fee
            revenue = deal_money - Decimal(values_dict['deal_money']).quantize(exame, ROUND_DOWN)
            revenue = Decimal(revenue).quantize(exame, ROUND_DOWN)
            # print('成交总量:'+str(deal_money))
            # print('成交数量:'+str(deal_amount))
            # print('持仓量:'+str(values_dict['deal_money']))
            # print('差值:'+str(revenue))
            if revenue < 0:
                revenue = 0
            insert_data = {
                'platform': market['platform'],
                'uid': robot['uid'],
                'order_id': order_id,
                'qrobot_id': robot['id'],
                'side': side,
                'market': market['market_name'],
                'stock': market['stock'],
                'money': money_name,
                'order_status': 1,
                'is_first': 2,
                'order_no': order_no,
                'price': price,
                'pid': values_dict['pid'],
                'deal_money': deal_money,
                'deal_amount': deal_amount,
                'revenue': revenue,
                'fee': deal_fee,
                'total': values_dict['deal_amount'],
                'amount': values_dict['order_count']
            }
            sql = self.build_insert('jl_quant_robot_order', insert_data)
            self.cur.execute(sql)
            insert_data = {
                'platform': market['platform'],
                'qrobot_id': robot['id'],
                'pid': values_dict['pid'],
                'uid': robot['uid'],
                'market': market['market_name'],
                'stock': market['stock'],
                'money': money_name,
                'revenue': revenue,
                'deal_status': 0
            }
            sql = self.build_insert('jl_quant_robot_revenue', insert_data)
            self.cur.execute(sql)
            update_data = {
                'is_clean': 0,
                'values_str': '',
                'revenue': 0,
                'order_status': 1,
                'new':0
            }
            if int(robot['recycle_status']) == 0:
                update_data['status'] = 0
                update_data['new']=0
                self.insertLog(robot['uid'], robot['id'], market['platform'], '量化机器人已经关闭')
                self.insertLog(robot['uid'], robot['id'], market['platform'],
                               '卖出：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(price) + str(
                                   money_name) + ',成交数' + str(deal_amount) + market['stock'])
                self.updateRobotData(robot['id'], robot['uid'], update_data)
                self.redisdelcoin(coin_name, coin_key)
                return self.returnAPI('卖出成功', 1)
            else:
                update_data['values_str'] = ''
                if int(robot['is_clean']) == 1:
                    update_data['is_clean'] = 0
                    update_data['status'] = 0
                    update_data['run_status'] = 0
                    update_data['new'] = 0
                    update_data['show_msg'] = '清仓卖出：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(
                        price) + str(money_name) + ',成交数' + str(deal_amount) + market['stock']
                    self.updateRobotData(robot['id'], robot['uid'], update_data)
                    self.insertLog(robot['uid'], robot['id'], market['platform'],
                                   '清仓卖出：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(price) + str(
                                       money_name) + ',成交数' + str(deal_amount) + market['stock'])
                    self.insertLog(robot['uid'], robot['id'], market['platform'], '清仓卖出成功停止机器人')
                    self.redisdelcoin(coin_name, coin_key)
                    return self.returnAPI('清仓卖出成功', 1)
            update_data['run_status'] = 1
            self.insertLog(robot['uid'], robot['id'], market['platform'], '量化机器人已经重新开启')
            self.insertLog(robot['uid'], robot['id'], market['platform'],
                           '卖出：成交总价' + str(deal_money) + str(money_name) + ',成交均价' + str(price) + str(
                               money_name) + ',成交数' + str(deal_amount) + market['stock'])
            self.updateRobotData(robot['id'], robot['uid'], update_data)
            self.redisdelcoin(coin_name, coin_key)
            return self.returnAPI('卖出成功', 1)
        except Exception as e:
            e = str(e)
            print(e)
            self.updateRobotData(robot['id'], robot['uid'], {'run_status': 1})
            self.insertLog(robot['uid'], robot['id'], market['platform'], '卖出失败' + e)
            self.redisdelcoin(coin_name, coin_key)
            return self.returnAPI('卖出失败' + e)

    # 生成订单号
    def getOrderNo(self, rid, db='quant_robot_order', pr='', field='order_no'):
        order_id_main = time.strftime("%m%d", time.localtime()) + "" + str(
            random.randint(1000000, 9999999)) + "" + time.strftime("%H%M%S", time.localtime())
        order_id_len = len(order_id_main)
        order_id_sum = 0
        i = 0
        while i < order_id_len:
            order_id_sum += int(order_id_main[i:i + 1])
            i += 1
        order_id = pr + order_id_main + str((100 - order_id_sum % 100) % 100).zfill(2)
        order_id = order_id + str(rid)
        select_sql = "select * from jl_" + db + " where " + field + "='" + order_id + "'"
        db = self.cur.fetchone(select_sql)
        if not db is None:
            return self.getOrderNo(rid, db, pr, field)
        return order_id

    # 创建订单
    def createOrder(self, amount, symbol, third_api, order_no, side='buy-market'):
        huobi = Huobipro(third_api['api_key'], third_api['secret_key'])
        try:
            # print([amount, symbol, third_api, order_no, side])
            # print('创建订单')
            amount = str(amount)
            result = huobi.placeOrder(third_api['account_id'], amount, symbol.lower(), side, order_no)
            # print(result)
        except Exception as e:
            e = str(e)
            return self.returnAPI(e)
        if 'status' in result.keys() and result['status'] == 'error':
            return self.returnAPI(result['err-msg'], 0, result)
        order_id = result['data']
        info = self.getOrderInfo(huobi, order_id)
        return self.returnAPI('', 1, info)

    # 获取订单详情
    def getOrderInfo(self, huobi, order_id):
        info = huobi.getOrderInfo(order_id)
        if not info['data']['id'] or info['data']['state'] != 'filled':
            time.sleep(0.5)
            return self.getOrderInfo(huobi, order_id)
        return info['data']

    # 机器人日志写入
    def insertLog(self, uid, rid, market_name, cnt):
        res = redisbase.insertlog(redisbase.redis_content, rid, market_name, uid, cnt)
        return res
        # last_log = self.cur.fetchone("select * from jl_quant_robot_log where qrobot_id = "+str(rid)+" order by id desc")
        # if not (last_log is None) and last_log['content'] == cnt:
        #     return
        # insert_sql = self.build_insert('jl_quant_robot_log', {'platform': market_name, 'uid': uid, 'qrobot_id': rid, 'content': cnt})
        # return self.cur.execute(insert_sql)

    # 建立插入sql
    def build_insert(self, table, param):
        key = ""
        val = ""
        for k in param.keys():
            v = param[k]
            key += "`" + str(k) + "`,"
            val += "'" + str(v) + "',"
        key = key[0:len(key) - 1]
        val = val[0:len(val) - 1]
        sql = "insert into " + table + " (" + key + ") values (" + val + ")"
        return sql

    # 生成uuid
    def uuid(self):
        chars = self.md5(str(uuid.uuid4()) + str(time.localtime()))
        uuids = chars[0: 8] + '-' + chars[8: 12] + '-' + chars[12: 16] + '-' + chars[16: 20] + '-' + chars[20: 32]
        return uuids

    # 消息解析
    def parseMsg(self, msg):
        cnt = msg
        if msg == '':
            return cnt
        if 'trade account balance is not enough' in msg:
            cnt = '账户余额不足'
        if 'Too Many Requests' in msg:
            cnt = '请求过于频繁'

        return cnt

    def optionLog(self, robot, type, cnt):
        if isinstance(robot, dict):
            robot = json.dumps(robot, ensure_ascii=False)
        if isinstance(robot, cnt):
            cnt = json.dumps(cnt, ensure_ascii=False)
        sql = self.build_insert('jl_option_log',
                                {'ctime': time.localtime(), 'robot_info': robot, 'type': type, 'cnt': cnt})
        self.cur.execute(sql)

    # 生成md5值
    def md5(self, str):
        md = hashlib.md5()  # 创建md5对象
        md.update(str.encode(encoding='utf8'))
        return md.hexdigest()

    # 返回信息
    def returnAPI(self, msg, code=0, data={}):
        return {'code': code, 'msg': msg, 'data': data}