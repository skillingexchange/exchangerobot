import requests
import os
import time
from urllib.parse import urlencode
import hashlib
import hmac
import base64
import json
from datetime import datetime
from logger import logger
class Huobipro:
    def __init__(self, access_key, secret_key):
        self.url = 'https://api.huobi.pro'
        self.api = 'api.huobi.pro'
        self.access_key = access_key
        self.secret_key = secret_key
        self.api_method = ''
        self.req_method = ''
        os.environ['TZ'] = 'Etc/GMT+0'

    # 查询当前用户的所有账户(即account-id)
    def getAccountId(self):
        self.api_method = "/v1/account/accounts"
        self.req_method = 'GET'
        url = self.create_sign_url([])
        data = self.curl(url)
        for item in data:
            if item['type'] == 'spot' and item['state'] == 'working':
                return item['id']
        return self.error('数据不存在')

    # 查询指定账户的余额
    def getAccountBalance(self, account_id, symbol = ''):
        self.api_method = "/v1/account/accounts/"+account_id+"/balance"
        self.req_method = 'GET'
        url = self.create_sign_url([])
        data = self.curl(url)
        if data['status'] != 'ok':
            return data
        data = data['data']
        # 如果有传币种名称，获取币种名称后返回
        if not symbol is None:
            symbol = symbol.lower()
            list = data['list']
            for v in list:
                if v['currency'] == symbol:
                    return v['balance']
            return 0
        return data

    # 查询系统支持的所有交易对及精度
    def getCommonSymbols(self):
        self.api_method = '/v1/common/symbols'
        self.req_method = 'GET'
        url = self.create_sign_url([])
        data = self.curl(url)
        return data

    # 下单
    def placeOrder(self, account_id, amount, symbol, type, client_order_id, price=0):
        source = 'api'
        self.api_method = "/v1/order/orders/place"
        self.req_method = 'POST'
        if '/' in symbol:
            symbol = symbol.replace('/', '')
        # 数据参数
        postdata = { 'account-id': account_id, 'amount': amount, 'source': source, 'symbol': symbol, 'type': type,'client-order-id':client_order_id}
        # print(postdata)
        if price > 0:
            postdata['price'] = price
        url = self.create_sign_url()
        # print(url)
        # print(postdata)
        data = self.curl(url, postdata)
        return data

    # 查询订单详情
    def getOrderInfo(self, order_id):
        self.api_method = '/v1/order/orders/'+order_id
        self.req_method = 'GET'
        url = self.create_sign_url()
        res = self.curl(url)
        return res

    # 批量获取最近的交易记录
    def getHistoryTrade(self, symbol='', size=''):
        self.api_method = "/market/history/trade"
        self.req_method = 'GET'
        param = {'symbol': symbol}
        if not size is None:
            param['size'] = size
        url = self.create_sign_url(param)
        return self.curl(url)

    # 获取 Market Detail 24小时成交量数据
    def getMarketDetail(self, symbol=''):
        self.api_method = "/market/detail"
        self.req_method = 'GET'
        param = {'symbol': symbol}
        url = self.create_sign_url(param)
        return self.curl(url)

    #     查询当前成交、历史成交
    def getOrdersMatchresults(self, symbol = '', types = '',start_date = '',end_date = '', froms = '',direct='',size = ''):
        self.api_method = '/v1/order/matchresults'
        self.req_method = 'GET'
        postdata = {'symbol': symbol}
        if not types is None:
            postdata['types'] = types
        if not start_date is None:
            postdata['start-date'] = start_date
        if not end_date is None:
            postdata['end-date'] = end_date
        if not froms is None:
            postdata['from'] = froms
        if not direct is None:
            postdata['direct'] = direct
        if not size is None:
            postdata['size'] = size
        url = self.create_sign_url()
        return self.curl(url, postdata)

    # 生成签名url
    def create_sign_url(self, append_param={}):
        # 验签参数 date('Y-m-d\TH:i:s',time())
        # now_date = time.strftime("%Y%m%d\T%H:%M:%S", time.localtime())
        now_date = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
        # print(now_date)
        param = { 'AccessKeyId': self.access_key, 'SignatureMethod': 'HmacSHA256', 'SignatureVersion': 2, 'Timestamp': now_date}
        # print(append_param)
        if append_param:
            # print('in')
            for k in append_param.keys():
                val = append_param[k]
                param[k] = val
        return self.url+self.api_method+'?'+self.bind_param(param)
    # 组合参数
    def bind_param(self, param):
        u = []
        sort_rank = {}
        keys = 0
        for k in param.keys():
            v = param[k]
            u.append(urlencode({k: v}))
            sort_rank[keys] = ord(k[0:1])
            keys += 1
        # 蛋疼 没有直接字典排序函数 需要遍历一次生成一个中转变量然后排序赋值
        # temp = []
        # for k in sorted(u):
        #     temp.append(u[k])
        # u = temp
        u.sort()
        u.append(urlencode({'Signature': self.create_sig(u)}))
        return '&'.join(u)

    # 生成签名
    def create_sig(self, param):
        sign_param_1 = self.req_method+"\n"+self.api+"\n"+self.api_method+"\n"+str('&'.join(param))
        # signature = hash_hmac('sha256', sign_param_1, self.secret_key, true)
        secret_key = self.secret_key
        signature = base64.b64encode(hmac.new(secret_key.encode('utf8'), sign_param_1.encode('utf8'), digestmod=hashlib.sha256).digest())
        signature = str(signature, 'utf8')
        return signature
    def curl(self, url, params={}, header={}, result='json'):
        if self.req_method == 'POST':
            headers = {"Content-Type": "application/json; charset=UTF-8"}
            param = json.dumps(params, ensure_ascii=True)
            # print(params)
            res = requests.post(url, param, headers=headers, timeout=300)
        else:
            res = requests.get(url, params, headers=header, timeout=300)
    #     根据头部状态码进行处理
        if res.status_code != 200:
            # 返回状态非200 休眠1秒后重试
            time.sleep(1)
            return self.curl(url, params, header, result)
        else:
            return json.loads(res.text)
    #     错误返回信息
    def error(self,msg):
        return {'msg': msg}
if __name__ == '__main__':
    Huobipro()