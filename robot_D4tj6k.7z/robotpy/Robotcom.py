from database import MySqLHelper
from HuobiRobot import huobirobot
import redisbase
redis = redisbase.redis_content
robot_redis = redisbase.robot_redis
class Robotcom:
    def __init__(self):
        self.db = MySqLHelper()
    def enable(self, robot_id,type=1,total=0):
        robot = self.checkRobot(robot_id)
        platform = robot['platform']
        third_api = self.checkThirdApi(platform, robot['uid'])
        market = self.checkSpotMarket(robot['market_id'], platform)
        if robot == False:
            return {"code": 0,"msg": "你无权访问该机器人"}
        if third_api == False:
            return {"code": 0, "msg": "当前无可用的API，请先绑定"}
        if market == False:
            return {"code": 0, "msg": "指定的市场不可用"}
        if type==1:
            # 启动
            print(str(robot_id)+'启动机器人')
            data = huobirobot().enableRobot(robot, market, third_api, 2)
        if type==2:
            # 卖出
            print(str(robot_id)+'卖出开始')
            data = huobirobot().sellRobot(robot, market, third_api, 2)
        if type==3:
            # 补仓
            print(str(robot_id)+'补仓开始')
            data = huobirobot().coverRobot(robot, market, third_api, total, 2)

        if data['code'] == 0:
            return {"code":0,'msg':data['msg'],'data':data}
        else:
            return {"code": 1, 'msg': data['msg'], 'data': data}
    #     获取机器人信息
    def checkRobot(self, id):
        # robot = self.db.fetchone("select * from jl_quant_robot where id='"+str(id)+"'")
        name = robot_redis.keys("user_robot_*_"+str(id))
        if not name:
            return False
        name = name[0]
        keys = robot_redis.hkeys(name)
        arr = robot_redis.hmget(name,keys)
        robot = dict(zip(keys,arr))
        if robot is None:
            return False
        return robot
    # 获取第三方api
    def checkThirdApi(self,platform, uid):
        findapi = self.db.fetchone("select * from jl_third_api where platform = '"+platform+"' and uid='"+str(uid)+"' and status='1'")
        if findapi is None:
            return False
        return findapi
    # 获取市场名称
    def checkSpotMarket(self,market_id, platform):
        market = self.db.fetchone("select * from jl_spot_market where platform='"+platform+"' and id='"+str(market_id)+"' and status=1")
        if market is None:
            return False
        return market
# if __name__ == '__main__':
#     a = Robotcom().enable(18, 2)
#     print(a)