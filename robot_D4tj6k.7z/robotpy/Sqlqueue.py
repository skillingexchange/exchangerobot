from database import MySqLHelper
import redisbase
import time
# redis连接池
redis_content = redisbase.redis_content
# mysql连接池
sql_content = MySqLHelper()
def updatesql():
    sql_list = redis_content.get('update_*_sql')
    if not sql_list or sql_list is None:
        print('无待执行sql')
        return True

    # print(sql_list)
if __name__ == '__main__':
    while True:
        updatesql()
        time.sleep(5)