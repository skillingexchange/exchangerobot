import random
import json
import requests
from database import MySqLHelper
import redisbase
headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_3 like Mac OS X) AppleWebKit/603.3.8 (KHTML, like Gecko) Mobile/14G60 MicroMessenger/6.5.19 NetType/4G Language/zh_TW",
}
config={}

# resp = requests.get(url=ipUrl, headers=headers, timeout=50)
# print(resp.text)
def getConfig():
    lists = MySqLHelper().fetchall("SELECT option_value from jl_option where option_name='system_setting'")
    lists=json.loads(lists[0]['option_value'])
    global config
    config['type']=lists['type']
def getapilist():
    global config
    if config=={}:
        getConfig()
    if str(config['type'])=='1':
        #静态独享方式获取
        mainUrl = 'http://tiqu.ipidea.io:81/abroad'
        param={}
        param['num']=255
        param['lb']=1
        param['sb']=0
        param['flow']=1
        param['type']=2
        param['regions']='hk'
        param['port']=1
        info = requests.get(mainUrl,param,headers=headers,timeout=300)
        iplists = json.loads(info.text)
        if iplists['success']=='False':
            return False;
        iplists = iplists['data']
        print(iplists)
        data=[];
        try:
            for iplist in iplists:
                # TODO: write code...
                data.append('http://'+str(iplist['ip'])+':'+str(iplist['port']))
            return data
        except Exception as e:
            logger.info(e)
            print("访问失败", e)
    else:
        #流量方式获取
        mainUrl = 'http://tiqu.ipidea.io:81/static'
        param={}
        param['num']=255
        param['lb']=1
        param['sb']=0
        param['flow']=1
        param['type']=2
        param['regions']='hk'
        param['port']=1
        info = requests.get(mainUrl,param,headers=headers,timeout=300)
        iplists = json.loads(info.text)
        if iplists['success']=='False':
            return False;
        iplists = iplists['data']
        data=[];
        try:
            for iplist in iplists:
                # TODO: write code...
                data.append('http://'+str(iplist['ip'])+':'+str(iplist['port']))
            return data
        except Exception as e:
            logger.info(e)
            print("访问失败", e)
