order_info['symbol'] = result['fee']['currency']
order_info['side'] = deal_result[0]['side']
if order_info['symbol'] == 'BNB' and order_info['side']=='sell':
    order_info['deal_money']=order_info['deal_fee']+order_info['deal_money']
else:
    order_info['deal_stock']=order_info['deal_stock']+order_info['deal_fee']
order_info['deal_fee'] = result['fee']['cost']