from database import MySqLHelper
import redisbase
import requests
import time
import json
import uuid
import ccxt
import common
from logger import logger

def reptile_article():
    # redis3库
    redis_content_3 = redisbase.getrids(3)
    # 获取配置
    config_operate = redis_content_3.hgetall('config_operate')
    # 请求地址
    url = 'https://api.jinse.cn/noah/v2/lives?limit=20&reading=false&source=web&flag=down&id=0&category=0'
    if url is None:
        return
    last_id = int(config_operate.get('last_id', 0))
    print(config_operate)
    response = requests.get(url)
    data = response.json()
    li_data = data['list'][0]
    # 上一次入库最新id
    last = last_id
    # 入库  入到那个分类
    type_id = int(config_operate.get('reptile_article_class', 9))
    # 备注
    reptile_source = config_operate.get('reptile_source', '')
    db = MySqLHelper()
    # 判断是否有数据需要入库
    insert_sql = "insert into jl_article (title,content,is_use,createtime,sort,type_id,time_limit) values "
    for i in li_data['lives']:
        if i['id'] <= last_id:
            continue
        if last < i['id']:
            last = i['id']
        insert = 2
        # 标题
        title = i['content_prefix']
        # 内容
        content = i['content']
        # 图片
        images = i['images']
        # 时间
        created_at = i['created_at']
        insert_sql = "insert into jl_article (title,content,is_use,createtime,sort,type_id,time_limit) values "
        # images_str = ""
        # if images is not None:
        #     for img in images:
        #         images_str += '< img src="' + img['url'] + '" />'
        # content += images_str
        # 加备注
        if len(reptile_source) > 0:
            content += "（来源:" + reptile_source + "）"
        # 组合sql
    
        insert_sql += '("%s","%s",%d,%d,%d,%d,%d),' % (title, content, 1, created_at, 0, type_id, 1)
    # 将最新的id修改到redis
        
        if insert == 2:
            # 去除最后一个字符
            insert_sql = insert_sql[:-1]
            # 入库
            print(insert_sql)
            cursor, conn, count = db.execute(insert_sql, autoclose=True)
    redis_content_3.hset('config_operate', 'last_id', last)
    return True
    
    
def clear():
    
    sql = 'select * from jl_article'
    db = MySqLHelper()
    data = db.fetchall(sql)
    if data:
        for k in data.keys():
            article = data[k]
            print(article)
            if (article['createtime']+3600*10)*1000<time.time():
                delete_sql = 'delete from jl_article where id='+str(article['id'])
                db.execute(delete_sql)
            
            
            
if __name__ == '__main__':
    
    
    # return
    while True:
        try:
            reptile_article()
            clear()
            
            time.sleep(300)
        except Exception as e:
            print(e)
            time.sleep(1)