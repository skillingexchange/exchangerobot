import redisbase
import numpy as np
import pandas as pd

redis_content = redisbase.redis_content


def Trend(sysbol='', exchange=''):
    # 处理数据
    sysbol = sysbol.replace('/', '')
    sysbol = sysbol.lower()
    if exchange == 'huobi':
        exchange = 'huobipro'

    symbol_redis = "app_config"
    symbol_redis_comprehensive = 'app_config_symbol_redis_comprehensive'
    kline_cycle = redis_content.hget(symbol_redis, 'kline_cycle')
    Company = kline_cycle[-1]
    kline_cycle = int(kline_cycle[:-1])
    if Company == 'm':
        kline_cycle = kline_cycle * 60
    elif Company == 'h':
        kline_cycle = kline_cycle * 60 * 60
    else:
        kline_cycle = kline_cycle * 86400

    comprehensive_number = 25  # 趋势累加税数据
    comprehensive = 0  # 趋势判断数据
    if sysbol is not None:
        # print(sysbol)
        # print(exchange)
        string = sysbol + "_" + exchange
        # 获取redis数据
        data = TrendDATA(sysbol, exchange)
        comprehensive = 0  # 趋势判断数据
        comprehensives = redis_content.hget(symbol_redis_comprehensive, string)
        # print(comprehensives)
        if comprehensives:
            return comprehensives
        # 判断MACD
        if not MACD(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断EMA均线
        if not EMA(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断布林带
        if not BOLL(data, symbol_redis):
            comprehensive += comprehensive_number
        # 判断RSI数据
        if not RSI(data, symbol_redis):
            comprehensive += comprehensive_number
        redis_content.hset(symbol_redis_comprehensive, string, comprehensive)
        redis_content.expire(symbol_redis_comprehensive, kline_cycle)
    else:
        # 获取收盘价数据
        keys = redis_content.keys('*_kline_*')
        for i in keys:
            symbol = i.split('_')
            exchange = symbol[2]
            sysbol = symbol[0]
            string = sysbol + "_" + exchange
            # 获取redis数据
            data = TrendDATA(sysbol, exchange)
            comprehensive = 0  # 趋势判断数据
            # 判断MACD
            if not MACD(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断EMA均线
            if not EMA(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断布林带
            if not BOLL(data, symbol_redis):
                comprehensive += comprehensive_number
            # 判断RSI数据
            if not RSI(data, symbol_redis):
                comprehensive += comprehensive_number
            redis_content.hset(symbol_redis_comprehensive, string, comprehensive)
            redis_content.expire(symbol_redis_comprehensive, kline_cycle)
    return comprehensive


def MACD(data, symbol_redis):
    # 数据格式转换
    data = MACD_DATA_REDIS_CONTENT(data)
    # 快线
    shortPeriod = int(redis_content.hget(symbol_redis, 'trend_macd_fast_length'))
    # 慢线
    longPeriod = int(redis_content.hget(symbol_redis, 'trend_macd_slow_length'))
    # 信号长度
    signalPeriod = int(redis_content.hget(symbol_redis, 'trend_macd_signal_length'))
    # 计算macd数据
    data = calculateMACD(data, shortPeriod, longPeriod, signalPeriod)
    # print(data)
    # 快线
    DIF = data[1]
    DEA = data[0]
    if DEA > DIF:
        return True
    return False
    # print(DIF)
    # print(DEA)


def calculateEMA(period, closeArray, emaArray=[]):
    """
    计算MACD中的EMA
    :param period: 时间
    :param closeArray: 收盘价数据
    :param emaArray:返回数据
    :return:
    """
    length = len(closeArray)
    nanCounter = np.count_nonzero(np.isnan(closeArray))
    if not emaArray:
        emaArray.extend(np.tile([np.nan], (nanCounter + period - 1)))
        firstema = np.mean(closeArray[nanCounter:nanCounter + period - 1])
        emaArray.append(firstema)
        for i in range(nanCounter + period, length):
            ema = (2 * closeArray[i] + (period - 1) * emaArray[-1]) / (period + 1)
            emaArray.append(ema)
    return np.array(emaArray)


def calculateMACD(closeArray, shortPeriod=12, longPeriod=26, signalPeriod=9):
    """
    计算MACD
    :param closeArray:价格数据
    :param shortPeriod:慢线时间
    :param longPeriod:快线时间
    :param signalPeriod:信号周期
    :return:
    """
    ema12 = calculateEMA(shortPeriod, closeArray, [])
    ema26 = calculateEMA(longPeriod, closeArray, [])
    diff = ema12 - ema26

    dea = calculateEMA(signalPeriod, diff, [])
    macd = (diff - dea)

    fast_values = diff[-2]
    slow_values = dea[-2]
    diff_values = macd[-2]
    return fast_values, slow_values, diff_values


def EMA(data, symbol_redis):
    data = MACD_DATA_REDIS_CONTENT(data)
    # 快线
    period = int(redis_content.hget(symbol_redis, 'trend_ema_fast_length'))
    fast = EMADATA(data, period)
    fast = float(fast.values[-1])
    # 慢线
    period = int(redis_content.hget(symbol_redis, 'trend_ema_slow_index'))
    slow = EMADATA(data, period)
    # 取最后一个
    slow = float(slow.values[-1])
    # 块钱大于慢线就代表 是上涨趋势
    if fast > slow:
        # 金叉
        return True
    else:
        return False


def EMADATA(arr, period=21):
    """
    计算EMA数据
    :param arr: 收盘价数据
    :param period: 周期
    :return:
    """
    df = pd.DataFrame(arr)
    return df.ewm(span=period, min_periods=period).mean()


def BOLL(data, symbol_redis):
    data = MACD_DATA_REDIS_CONTENT(data)
    K = int(redis_content.hget(symbol_redis, 'trend_boll_day_length'))
    N = int(redis_content.hget(symbol_redis, 'trend_boll_multiplier'))
    # 计算boll
    data = BOLLDATA(data, K, N)
    # 获取上一次的  判断状态
    boll_middle_val = data['boll_middle_val'].values[-1]
    boll_down_val = data['boll_down_val'].values[-1]
    # k线上穿下轨买入 (前两天的收盘价低于下轨，前一天的收盘价是大于下轨的  就完成了上穿下轨)
    if float(boll_middle_val) >= float(boll_down_val):
        return True
    return False


def BOLLDATA(datetime_close, K=20, N=2):
    """
    计算布林带数据
    :param datetime_close: 收盘价数据
    :param K: 周期
    :param N: 信号
    :return:
    """
    df = pd.DataFrame(datetime_close, columns=['close'])
    # 获取收盘价
    close = df['close']
    # 计算均价
    middle_vals = close.rolling(K).mean()
    # 计算标准差
    std_vals = close.rolling(K).std(0)
    # 计算压力位 (均价 + 倍数 * 标准差)
    up = middle_vals + N * std_vals
    # 计算支撑位 (均价 - 倍数 * 标准差)
    down = middle_vals - N * std_vals
    # 赋值
    df['boll_middle_val'] = middle_vals
    df['boll_up_val'] = up
    df['boll_down_val'] = down
    return df


def RSI(data, symbol_redis):
    N = int(redis_content.hget(symbol_redis, 'trend_rsi_day_length'))
    strong_index = float(redis_content.hget(symbol_redis, 'trend_rsi_strong_index'))
    weak_index = float(redis_content.hget(symbol_redis, 'trend_rsi_weak_index'))
    # 数据组合
    data = MACD_DATA_REDIS_CONTENT(data)
    # 计算rsi
    data = RSIDATA(data, N)
    # 指数
    rsi = data['rsi'].values[-1]
    # 指数大于弱指数  小于强指数  就代表上涨  买入
    if weak_index < rsi < strong_index:
        return True
    return False


def RSIDATA(datetime_close, n=14):
    df = pd.DataFrame(datetime_close, columns=['close'])
    prices = df['close']
    # 初始化
    rsi = np.zeros_like(prices)
    # 计算后一天个前一天的价差
    deltas = np.diff(prices)
    # 获取第一个周期的价差
    seed = deltas[:n]
    average_gain = seed[seed >= 0].sum() / n
    average_loss = -seed[seed < 0].sum() / n
    first_rs = average_gain / average_loss
    rsi[n] = 100 - 100 / (1 + first_rs)
    for i in range(n, len(prices) - 1):
        previous_average_gain = average_gain
        previous_average_loss = average_loss
        delta = deltas[i]
        if delta >= 0:
            current_gain = delta
            current_loss = 0
        else:
            current_gain = 0
            current_loss = -delta
        average_gain = (previous_average_gain * (n - 1) + current_gain) / n
        average_loss = (previous_average_loss * (n - 1) + current_loss) / n
        smoothed_rsi = average_gain / average_loss
        rsi[i + 1] = 100 - 100 / (1 + smoothed_rsi)
        df['rsi'] = rsi
    return df


def TrendDATA(sysbol='btcusdt', exchange='binance'):
    exchage_str = sysbol + "_kline_" + exchange
    data = redis_content.hgetall(exchage_str)
    # 删除最后一个数据  因为最后一个数据是当时的  是没有结束的
    data.popitem()
    # 组合数据
    return data


def MACD_DATA_REDIS_CONTENT(data):
    """
    macd数据组合
    :param data: 数据
    :return: list
    """
    list = []
    for i in data:
        list.append(float(data[i]))
    return list

