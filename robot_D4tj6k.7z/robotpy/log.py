#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'kevin'

import os
import logging
import logging.config
import datetime

_logger_handler = "logging.handlers.TimedRotatingFileHandler"
_backupCount = 5


def logfile(filename, robot_id):
    current_dir = os.path.abspath(os.path.dirname(__file__))
    log_dir = os.path.join(current_dir, 'order_logs', )
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    return os.path.join(log_dir, filename)


def logging_config(name, robot_id):
    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "simple": {
                'format': '%(asctime)s [%(filename)s:%(lineno)d] %(levelname)s %(message)s'
            },
            'standard': {
                'format': '%(asctime)s [%(threadName)s:%(thread)d] [%(name)s:%(lineno)d] [%(levelname)s]- %(message)s'
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": "DEBUG",
                "formatter": "simple",
                "stream": "ext://sys.stdout"
            },
            "file": {
                "class": _logger_handler,
                "level": "DEBUG",
                "formatter": "simple",
                "filename": logfile(name + '.log', robot_id),
                "when": "midnight",
                "interval": 1,
                "backupCount": _backupCount,
                "encoding": 'utf-8'
            },
        },
        "loggers": {
            # "quant": {
            #     'handlers': ['file'],
            #     'level': "DEBUG",
            #     'propagate': False
            # }
        }
    }

    if name not in logging_config['loggers'].keys():
        logging_config['loggers'] = {
            name: {
                'handlers': ['file'],
                'level': "DEBUG",
                'propagate': False
            }
        }
    return logging_config


def get_logger(robot_id):
    # 文件名后面加上时间
    now_time = datetime.datetime.now().strftime('%Y-%m-%d-%H')
    name = "logorderinfo_" + now_time
    LOGGING_CONFIG = logging_config(name, robot_id)
    logging.config.dictConfig(LOGGING_CONFIG)
    res_logger = logging.getLogger(name)
    return res_logger