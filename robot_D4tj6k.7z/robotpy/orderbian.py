import math
import time
import json
import uuid
import ccxt
import common
from database import MySqLHelper
import redisbase
from logger import logger
from Robotcom import Robotcom
from decimal import Decimal, ROUND_DOWN
import random
import requests
import api

thread_alive = {}
redis_content = redisbase.redis_content

global list_timest, last_timet, iplist
global list_times, last_time
iplist = {}
list_times = 0
list_timest = 0
last_timet = int(time.time() * 1000)
last_time = int(time.time() * 1000)
list_gettime = 0
list_gettimes = 0


def getlisttimes():
    global list_times, last_time, iplist
    iplist = api.getapilist()
    if iplist == []:
        return False
    now = int(time.time() * 1000)
    if now - last_time <= 500:
        list_times += 1
    if list_times > (len(iplist) - 1):
        list_times = 0
    last_time = now
    print('使用线路' + iplist[list_times])


def getTick(platform, api_info, market):
    if platform == 'huobi':
        platform = 'huobipro'
    ticker = None
    try:
        keys = market.replace('/', '')
        keys = keys.lower()
        # print('price_' + platform + '_' + keys)
        ticker = redis_content.get('price_' + platform + '_' + keys)
        ticker = Decimal(ticker).quantize(Decimal('0.00000000'), ROUND_DOWN)
        ticker = str(ticker)
        # ticker = float(ticker)
    except Exception as e:
        logger.error('getTick Exception:%s' % e)
    if ticker != None:
        return ticker
    else:
        logger.error(keys + '-' + platform + '-第一次行情获取失败')
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_id = platform
    if exchange_id == 'huobi':
        exchange_id = 'huobipro'
    # if exchange_id == 'okex':
    #     exchange_id = 'okex5'
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        'apiKey': api_key,
        'secret': secret_key,
        'password': passphrase,
        'timeout': 30000,
        'enableRateLimit': True,
        'options': {
            'createMarketBuyOrderRequiresPrice': False,
        },
    })

    # if platform == 'okex':
    #     exchange.hostname = 'okexcn.com'
    #     exchange.urls['api']['rest'] = 'https://www.okexcn.com'
    # if platform == 'binance':
    #     exchange.urls['api']['v1'] = 'https://api.binancezh.cc/api/v1'
    #     exchange.urls['api']['v3'] = 'https://api.binancezh.cc/api/v3'
    #     exchange.urls['api']['private'] = 'https://api.binancezh.cc/api/v3'
    #     exchange.urls['api']['public'] = 'https://api.binancezh.cc/api/v3'
    try:
        ticker_data = exchange.fetch_ticker(market)
        if 'last' in ticker_data:
            return ticker_data['last']
        else:
            return None
    except Exception as e:
        logger.info('Exception:%s', e)
        return None


# 市价
def order(side, api_info, market, amount, type_all):
    platform = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_id = platform
    exchange_class = getattr(ccxt, exchange_id)
    if str(type_all) == '1':
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': False,
            'aiohttp_proxy': iplist[list_times],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    elif str(type_all) == '2':
        resul = getlisttimes()
        if resul == False:
            return False
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'aiohttp_proxy': iplist[list_times],
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })
    else:
        global list_timest, last_timet
        now = int(time.time() * 1000)
        if now - last_timet <= 500:
            time.sleep(float((500 - (now - last_timet)) / 1000))
        last_timet = now
        exchange = exchange_class({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'timeout': 30000,
            'enableRateLimit': True,
            'options': {
                'createMarketBuyOrderRequiresPrice': False,
            },
        })

    # if exchange_id == 'okex':
    #     exchange_id = 'okex5'
    ret = {}
    try:
        # 卖
        if side == 1:
            result = exchange.create_market_sell_order(market, amount)
        else:
            # 买入
            result = exchange.create_market_buy_order(market, amount, {'quoteOrderQty': amount})
        order_info = {}
        order_info['order_id'] = result['id']
        deal_result = exchange.fetch_order(result['id'], market)
        while len(deal_result) == 0:
            time.sleep(0.5)
            deal_result = exchange.fetch_order(result['id'])
        logger.info('查询订单时间结束' + str(int(time.time())))
        order_info['deal_money'] = deal_result['cost']
        order_info['deal_stock'] = deal_result['filled']
        # 结果
        if side == 1:
            # 卖出
            if deal_result['fee']:
                order_info['deal_fee'] = deal_result['fee']['cost']
                if deal_result['fee']['currency'] != 'USDT' and deal_result['fee']['currency'] != 'usdt':
                    order_info['deal_fee'] = deal_result['fee']['cost']
                    order_info['deal_fees'] = deal_result['fee']['cost']
            else:
                order_info['deal_fee'] = result['fee']['cost']
                if result['fee']['currency'] != 'USDT' and result['fee']['currency'] != 'usdt':
                    order_info['deal_fee'] = result['fee']['cost']
                    order_info['deal_fees'] = result['fee']['cost']
        else:
            # 买入
            if deal_result['fee']:
                order_info['deal_fee'] = deal_result['fee']['cost']
                if deal_result['fee']['currency'] != 'USDT' and deal_result['fee']['currency'] != 'usdt':
                    order_info['deal_fee'] = deal_result['price'] * deal_result['fee']['cost']
                    order_info['deal_fees'] = deal_result['fee']['cost']
            else:
                order_info['deal_fee'] = result['fee']['cost']
                if result['fee']['currency'] != 'USDT' and result['fee']['currency'] != 'usdt':
                    order_info['deal_fee'] = result['price'] * result['fee']['cost']
                    order_info['deal_fees'] = result['fee']['cost']

        if type(order_info['deal_money']) != int and type(order_info['deal_money']) != float:
            order_info['deal_money'] = float(str(order_info['deal_money']))
        if type(order_info['deal_stock']) != int and type(order_info['deal_stock']) != float:
            order_info['deal_stock'] = float(str(order_info['deal_stock']))
        if type(order_info['deal_fee']) != int and type(order_info['deal_fee']) != float:
            order_info['deal_fee'] = float(str(order_info['deal_fee']))
        if order_info['deal_fee'] < 0:
            order_info['deal_fee'] = -order_info['deal_fee']
        ret['code'] = 1
        ret['data'] = order_info
        ret['msg'] = 'success'
        return ret
    except Exception as e:
        # logger.error(e)
        ret['code'] = 0
        ret['data'] = {}
        ret['msg'] = str(e)
        return ret


def balances(api_info, market, stock_name):
    platform = api_info['platform']
    api_key = api_info['api_key']
    secret_key = api_info['secret_key']
    passphrase = api_info['passphrase']
    exchange_id = platform
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        'apiKey': api_key,
        'secret': secret_key,
        'password': passphrase,
        'timeout': 100000,
        'enableRateLimit': True,
    })

    # if exchange_id == 'okex':
    #     exchange_id = 'okex5'

    ret = {}
    try:
        result = exchange.fetch_balance()
        ret['code'] = 1
        ret['data'] = result[stock_name]['free']
        ret['msg'] = 'success'
        return ret
    except Exception as e:
        logger.error(e)
        ret['code'] = 0
        ret['data'] = {}
        ret['msg'] = str(e)
        return ret


# jinlan市价交易

def updateBalanceStatus(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'sell_status', '1')


def updateMsg(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'show_msg', show_msg)


def updateNew(robot_id, uid, show_msg):
    redisbase.updaterobot(redis_content, robot_id, uid, 'new', 0)


def updateValues(robot_id, uid, values_str):
    redisbase.updaterobot(redis_content, robot_id, uid, 'values_str', values_str)


def updateRevenue(robot_id, uid, revenue):
    redisbase.updaterobot(redis_content, robot_id, uid, 'revenue', revenue)
    # cur = MySqLHelper()
    # update_sql = "update jl_quant_robot set revenue = '%s' where id = %d" % (
    #     revenue, robot_id)
    # cur.execute(update_sql)


def disableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'status', 0)
    # cur = MySqLHelper()
    # update_sql = "update jl_quant_robot set status = 0 where id = %d" % robot_id
    # cur.execute(update_sql)


def cleanFinish(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'is_clean', 0)


def runDisableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 0)


def runEnableRobot(robot_id, uid):
    redisbase.updaterobot(redis_content, robot_id, uid, 'run_status', 1)


def insertLog(platform, robot_id, uid, log):
    redisbase.insertlog(redis_content, robot_id, platform, uid, log)


def insertRevenueLog(platform, robot_id, pid, uid, market, stock, money, revenue):
    # redisbase.insertrevene(redis_content,platform, robot_id, pid, uid, market, stock, money, revenue)
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_revenue (platform,qrobot_id,pid,uid,market,stock,money,revenue,deal_status) values ('%s',%d,'%s',%d,'%s','%s','%s','%s',%d)" % (
        platform,
        robot_id, pid, uid, market, stock, money, revenue, 0)
    cur.execute(insert_sql)


def insertOrder(platform, uid, order_id, robot_id, side, market, stock, money, deal_money, deal_amount, price, is_first,
                uuid, revenue, fee, amount, total):
    cur = MySqLHelper()
    insert_sql = "insert into jl_quant_robot_order (platform,uid,order_id,qrobot_id,side,market,stock,money,deal_money,deal_amount,price,order_status,is_first,pid,revenue,fee,amount,total) values ('%s',%d,'%s',%d,%d,'%s','%s','%s','%s','%s','%s',1,%d,'%s','%s','%s',%d,'%s')" % (
        platform, uid, order_id, robot_id, side, market, stock, money, deal_money, deal_amount, price, is_first, uuid,
        revenue, fee, amount, total)
    cursor, conn, count = cur.execute(insert_sql)
    return cursor.lastrowid


def insertgrid(data):
    key = []
    val = []
    for k in data.keys():
        v = data[k]
        key.append('`' + str(k) + '`')
        val.append("'" + str(v) + "'")
    key = ','.join(key)
    val = ','.join(val)
    sql = "insert into jl_robot_grid (" + key + ") values (" + val + ")"
    # print(sql)
    cur = MySqLHelper()
    cur.execute(sql)


# 策略主函数
def onTick(robot_config, market_info, api_info, type_all):
    market = market_info['market_name']
    stock_name = market_info['stock']
    money_name = market_info['money']
    market_type = market_info['type']
    if 'is_trand' in robot_config.keys():
        is_trend = robot_config['is_trend']
    else:
        is_trend = 0
    robot_id = int(robot_config['id'])
    platform = robot_config['platform']
    uid = int(robot_config['uid'])
    # if robot_id !=701:
    #     return
    is_clean = int(robot_config['is_clean'])
    if robot_config['now_round_num'] is None:
        robot_config['now_round_num'] = 0
    if robot_config['open_risk'] is None:
        robot_config['open_risk'] = 1
    if robot_config['last_cover_buy'] is None:
        robot_config['last_cover_buy'] = 0
    if robot_config['last_cover_buy'] is '':
        robot_config['last_cover_buy'] = 0
    # zl 增加
    if 'new' in robot_config and not robot_config['new'] is None and int(robot_config['new']) == 1:
        # 是否开启保险
        open_risk = int(robot_config['open_risk'])
        if open_risk == 2:
            top_buy = Decimal(str(robot_config['top_buy']))
            low_buy = Decimal(str(robot_config['low_buy']))
        else:
            top_buy = Decimal(str('0'))
            low_buy = Decimal(str('0'))
        # 循环次数
        round_num = int(str(robot_config['round_num']))
        # 当前循环次数
        now_round_num = int(str(robot_config['now_round_num']))
        # 补仓详情
        if robot_config['cover_info'] and not robot_config['cover_info'] is None and robot_config[
            'cover_info'] != 'None':
            cover_info = json.loads(robot_config['cover_info'])
        else:
            cover_info = {}
        # 网格清仓策略
        if robot_config['cover_grid'] and not robot_config['cover_grid'] is None and robot_config[
            'cover_grid'] != 'None' and robot_config['cover_grid'] != '':
            cover_grid = json.loads(robot_config['cover_grid'])
            nu = 5
            i = 0
            ke = []
            while i < len(cover_grid):
                ke.append(nu)
                i += 1
                nu += 1
            cover_grid = dict(zip(ke, cover_grid))
        else:
            cover_grid = None
        # 网格止盈回调
        if robot_config['cover_grid_back'] and not robot_config['cover_grid_back'] is None and robot_config[
            'cover_grid_back'] != 'None' and robot_config['cover_grid_back'] != '':
            cover_grid_back = float(robot_config['cover_grid_back'])
        else:
            cover_grid_back = None

        tick_price = None
        tick_price_str = getTick(platform, api_info, market)
        if tick_price_str:
            tick_price = float(tick_price_str)

        if tick_price is None:
            return

        first_order_value = float(robot_config['first_order_value'])
        max_order_count = int(robot_config['max_order_count'])
        stop_profit_rate = float(robot_config['stop_profit_rate'])
        stop_profit_callback_rate = float(
            robot_config['stop_profit_callback_rate'])
        cover_rate = float(robot_config['cover_rate'])
        cover_callback_rate = float(robot_config['cover_callback_rate'])
        values_str = robot_config['values_str']
        recycle_status = int(robot_config['recycle_status'])

        if values_str:
            values_dict = json.loads(values_str)

            cover_rates = robot_config['cover_rates']
            if cover_rates:
                cover_rates_list = json.loads(cover_rates)
                if isinstance(cover_rates_list, list):
                    order_count = values_dict.get('order_count', 1)
                    if (len(cover_rates_list) - 1) >= order_count:
                        cover_rate = cover_rates_list[order_count]
            revenue = float(values_dict['deal_amount']) * tick_price - float(values_dict['deal_money'])
            updateRevenue(robot_id, uid, revenue)
            base_price = float(values_dict['base_price'])
            up_price = float(values_dict['up_price'])
            down_price = float(values_dict['down_price'])
            trend_side = int(values_dict['trend_side'])
            last_price = float(values_dict['last_price'])
            # 清仓卖出
            if is_clean == 1:
                # print('清仓卖出')
                insertLog(platform, robot_id, uid,
                          u"收到清仓卖出指令 ,当前价格 %s" % str((tick_price * 100000) / 100000))
                rst = order(1, api_info, market, values_dict['deal_amount'], type_all)
                logger.info(rst)
                if rst['code'] == 1:
                    cleanFinish(robot_id, uid)
                    order_id = rst['data']['order_id']
                    deal_money = rst['data']['deal_money']
                    deal_amount = rst['data']['deal_stock']
                    deal_fee = rst['data']['deal_fee']
                    price = float(deal_money) / float(deal_amount)
                    side = 1
                    deal_money = float(deal_money) - float(deal_fee)
                    revenue = float(deal_money) - float(values_dict['deal_money'])
                    deal_money = int(deal_money * 1000000000) / 1000000000
                    price = int(price * 1000000000) / 1000000000
                    deal_amount = int(deal_amount * 1000000000) / 1000000000
                    insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue, deal_fee,
                                values_dict['order_count'], values_dict['deal_money'])

                    insertRevenueLog(platform, robot_id, values_dict['pid'], uid, market, stock_name, money_name,
                                     revenue)
                    updateValues(robot_id, uid, '')
                    updateRevenue(robot_id, uid, 0)
                    updateMsg(robot_id, uid, u'清仓卖出成功')
                    insertLog(platform, robot_id, uid, u"清仓卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                    deal_money, money_name, price, money_name, deal_amount, stock_name))
                    disableRobot(robot_id, uid)
                    insertLog(platform, robot_id,
                              uid, u"清仓成功量化机器人已经关闭")
                    redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
                    redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"cover_info": ''})
                    # if recycle_status == 0:
                    #     # 关闭机器人
                    #     disableRobot(robot_id, uid)
                    #     insertLog(platform, robot_id,
                    #               uid, u"量化机器人已经关闭")
                    # else:
                    #     # res = Robotcom().enable(robot_id, 1)
                    #     # if int(res['code']) == 1:
                    #     runEnableRobot(robot_id, uid)
                    #     insertLog(platform, robot_id,
                    #                   uid, u"量化机器人已经重新开启")
                    return
                else:
                    amountss = balances(api_info, market, stock_name)
                    values_dict['deal_amounts'] = amountss['data']
                    if values_dict['deal_amounts'] != {}:
                        if float(values_dict['deal_amount']) > float(values_dict['deal_amounts']):
                            values_dict['deal_amount'] = values_dict['deal_amounts']

                    rst = order(1, api_info, market, values_dict['deal_amount'], type_all)
                    logger.info(rst)
                    if rst['code'] == 1:
                        cleanFinish(robot_id, uid)
                        order_id = rst['data']['order_id']
                        deal_money = rst['data']['deal_money']
                        deal_amount = rst['data']['deal_stock']
                        deal_fee = rst['data']['deal_fee']
                        price = float(deal_money) / float(deal_amount)
                        side = 1
                        deal_money = float(deal_money) - float(deal_fee)
                        revenue = float(deal_money) - float(values_dict['deal_money'])
                        deal_money = int(deal_money * 1000000000) / 1000000000
                        price = int(price * 1000000000) / 1000000000
                        deal_amount = int(deal_amount * 1000000000) / 1000000000
                        insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                    money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue,
                                    deal_fee,
                                    values_dict['order_count'], values_dict['deal_money'])

                        insertRevenueLog(platform, robot_id, values_dict['pid'], uid, market, stock_name, money_name,
                                         revenue)
                        updateValues(robot_id, uid, '')
                        updateRevenue(robot_id, uid, 0)
                        updateMsg(robot_id, uid, u'清仓卖出成功')
                        insertLog(platform, robot_id, uid, u"清仓卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                        deal_money, money_name, price, money_name, deal_amount, stock_name))
                        disableRobot(robot_id, uid)
                        insertLog(platform, robot_id,
                                  uid, u"清仓成功量化机器人已经关闭")
                        redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
                        redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"cover_info": ''})
                        return
                    else:
                        # cleanFinish(robot_id, uid)
                        # updateValues(robot_id, uid, '')
                        # updateRevenue(robot_id, uid, 0)
                        # disableRobot(robot_id, uid)
                        # redisbase.updaterobotkeys(redisbase.redis_content,robot_id,uid,{"now_round_num":0})
                        # redisbase.updaterobotkeys(redisbase.redis_content,robot_id,uid,{"cover_info":''})
                        # insertLog(platform, robot_id,uid, u"清仓成功量化机器人已经关闭")
                        cleanFinish(robot_id, uid)
                        content = rst['msg']
                        flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                        flagmin = 'Filter failure: MIN_NOTIONAL'
                        flagmins = 'Invalid quantity'
                        flagt = 'binance GET https://api.binance.com/api/v3/exchangeInfo'
                        if rst['msg'].find(flagmins):
                            content = '无效的下单数量'
                            insertLog(platform, robot_id,
                                      uid, u"清仓成功量化机器人已经关闭")
                            updateValues(robot_id, uid, '')
                            updateRevenue(robot_id, uid, 0)
                            updateMsg(robot_id, uid, u'清仓卖出成功')
                            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
                            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"cover_info": ''})
                            disableRobot(robot_id, uid)
                            return
                        if rst['msg'].find(flagmin):
                            content = '成交额低于最小值'
                            insertLog(platform, robot_id,
                                      uid, u"清仓成功量化机器人已经关闭")
                            updateValues(robot_id, uid, '')
                            updateRevenue(robot_id, uid, 0)
                            updateMsg(robot_id, uid, u'清仓卖出成功')
                            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"now_round_num": 0})
                            redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid, {"cover_info": ''})
                            disableRobot(robot_id, uid)
                            return
                        if rst['msg'].find(flagt):
                            content = '请求超时'
                        if rst['msg'].find(flag):
                            content = '账户余额不足'
                        insertLog(platform, robot_id, uid,
                                  u'清仓卖出失败:' + content)
                        updateMsg(robot_id, uid, u'清仓卖出失败' + content)
                        disableRobot(robot_id, uid)
                        return

            #   是否有分仓，且补单次数大于4
            # print(values_dict['order_count'])
            if not cover_grid is None and int(values_dict['order_count']) > 4:
                # print('分仓判断')
                i = 5
                while i < int(values_dict['order_count']):
                    if not str(i) in cover_info.keys():
                        i += 1
                        continue
                    if not i in cover_grid.keys():
                        i += 1
                        continue
                    # 当前补仓分仓止盈比例
                    cover_parset = float(cover_grid[i])
                    if cover_info[str(i)]['is_out'] == 2:
                        i += 1
                        continue
                    # 止盈价格 (1+(止盈比例/100)) * 买入价格
                    cover_saller_price = (1 + (float(cover_parset) / 100)) * float(cover_info[str(i)]['price'])
                    # print(i)
                    if int(cover_info[str(i)]['is_out']) == 1:
                        # print('分仓止盈回调')

                        stop_price = float(cover_info[str(i)]['stop_price'])
                        down_num = stop_price - tick_price
                        down_rate = down_num * 100 / stop_price
                        if tick_price > stop_price:
                            cover_info[str(i)]['stop_price'] = tick_price
                            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),
                                                      {"cover_info": json.dumps(cover_info)})
                            continue
                        # print('分仓止盈回调当前比例-'+str(down_rate)+"卖出比例-"+str(cover_parset))
                        # print(type(down_rate))
                        # print(type(cover_parset))
                        # print(down_rate >= cover_parset)

                        if down_rate >= cover_grid_back:
                            # print('分仓止盈回调卖出开始')
                            # 达到止盈回调进行分仓卖出

                            rst = order(1, api_info, market, cover_info[str(i)]['out_price'], type_all)
                            if rst['code'] == 1:
                                # print('分仓止盈回调卖出')
                                order_id = rst['data']['order_id']
                                deal_money = rst['data']['deal_money']
                                deal_amount = rst['data']['deal_stock']
                                deal_fee = rst['data']['deal_fee']
                                price = float(deal_money) / float(deal_amount)
                                side = 1
                                deal_money = float(deal_money) - float(deal_fee)
                                revenue = float(deal_money) - float(
                                    float(cover_info[str(i)]['price']) * float(cover_info[str(i)]['out_price']))
                                deal_money = int(deal_money * 1000000000) / 1000000000
                                price = int(price * 1000000000) / 1000000000
                                deal_amount = int(deal_amount * 1000000000) / 1000000000
                                grid_data = {
                                    "rid": robot_id,
                                    "sale_oid": order_id,
                                    "buy_oid": cover_info[str(i)]['buy_oid'],
                                    "num": i,
                                    'process_id': robot_config['process_id'],
                                    'revenue': revenue,
                                    'is_over': 0,
                                }
                                insertgrid(grid_data)

                                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                            money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue,
                                            deal_fee, values_dict['order_count'], values_dict['deal_money'])
                                updateMsg(robot_id, uid, u'分仓' + str(i) + '卖出成功')
                                insertLog(platform, robot_id, uid,
                                          u"分仓" + str(i) + "卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                          deal_money, money_name, price, money_name, deal_amount, stock_name))
                                cover_info[str(i)]['is_out'] = 2
                                cover_info[str(i)]['saller_price'] = deal_money
                                redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),
                                                          {"cover_info": json.dumps(cover_info)})
                                buy_order_id = cover_info[str(i)]['buy_oid']
                                all_order_one = cur.fetchall(
                                    'select deal_money,deal_amount from jl_quant_robot_order where order_id in (%s)' % (
                                        buy_order_id))
                                deal_moneys = float(values_dict['deal_money']) - float(all_order_one[0]['deal_money'])
                                deal_amounts = float(values_dict['deal_amount']) - float(all_order_one[0]['deal_amount'])
                                values_dict['base_price'] = float(deal_moneys) / float(deal_amounts)
                                insertLog(platform, robot_id, uid, u"基准价调整为: %s " % values_dict['base_price'])
                                redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),
                                                          {"values_str": json.dumps(values_dict)})
                    elif int(cover_info[str(i)]['is_out']) == 0:
                        #     达到止盈价格
                        # print('分仓止盈当前价格-'+str(tick_price)+'止盈价格-'+str(cover_saller_price))
                        # print(tick_price >= cover_saller_price)
                        if tick_price >= cover_saller_price:
                            # print('分仓止盈')

                            cover_info[str(i)]['is_out'] = 1
                            cover_info[str(i)]['stop_price'] = tick_price
                            redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),
                                                      {"cover_info": json.dumps(cover_info)})
                            insertLog(platform, robot_config['id'], robot_config['uid'], '分仓' + str(i) + '达到止盈')
                    i += 1

            print(tick_price > base_price)
            # 判断趋势
            # print('判断趋势ticke-'+str(tick_price)+'  base-'+str(base_price))
            #

            if tick_price > base_price:

                if trend_side == 0 or trend_side == 2:
                    up_num = tick_price - base_price
                    up_rate = up_num * 100 / base_price
                    if up_rate >= stop_profit_rate:
                        # print('上涨止盈')
                        # 上涨到止盈率
                        values_dict['trend_side'] = 1
                        values_dict['up_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"止盈率 %s ,止盈趋势: %s ,当前上涨价格 %s" %
                        #           (stop_profit_rate, up_rate, str(Decimal(str(tick_price)))))
                if trend_side == 1:
                    # print('止盈回调')
                    # 判断是否达到止盈回调

                    if tick_price > up_price:
                        # print('继续上涨')
                        # 继续涨了
                        values_dict['up_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        insertLog(platform, robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %
                                  (str(Decimal(str(tick_price)))))
                    else:
                        # print('上涨后下跌')
                        #                     if robot_config['sell_status'] == 1:
                        #                         return
                        down_num = up_price - tick_price
                        down_rate = down_num * 100 / up_price
                        if down_rate >= stop_profit_callback_rate:
                            # print('止盈回调')
                            # 达到止盈回调了，卖出所有deal_amount
                            # updateValues(robot_id,'')

                            # if robot_config['platform'] == 'huobi':
                            #     insertLog(platform, robot_id, uid, u"达到止盈回调率 %s ,当前回调价格 %s" %
                            #               (down_rate, str(Decimal(str(tick_price)))))
                            #     # res = getLocalOrder(robot_config['id'],first_order_value,'/api/quant/python/sellRobot')
                            #     # 卖出
                            #     res = Robotcom().enable(robot_config['id'], 2)
                            #     return
                            # print('加分仓总共持有-' + str(values_dict['deal_amount']))
                            # 2021-06-09 卖出达到止盈回调，判断是否有分仓卖出的，有分仓卖出的需要将对应已卖出的金额减去
                            has_grid = cur.fetchall("select * from jl_robot_grid where process_id='" + str(
                                robot_config['process_id']) + "' and rid='" + str(robot_id) + "' and is_over = 0")
                            grid_revenue = 0
                            if not has_grid is None and has_grid:
                                #  有分仓卖出，获取对应卖出订单
                                oids = []
                                sh_oids = []
                                for itemkey in has_grid.keys():
                                    item = has_grid[itemkey]
                                    oids.append("'" + str(item['sale_oid']) + "'")
                                    sh_oids.append("'" + str(item['buy_oid']) + "'")
                                    grid_revenue += float(item['revenue'])
                                oids = ','.join(oids)
                                sh_oids = ','.join(sh_oids)
                                cover_order = cur.fetchall(
                                    'select deal_amount from jl_quant_robot_order where order_id in (%s)' % (oids))
                                all_order = cur.fetchall(
                                    'select deal_amount from jl_quant_robot_order where order_id in (%s)' % (sh_oids))
                                for ckey in cover_order.keys():
                                    c_deal_amount = cover_order[ckey]['deal_amount']
                                    values_dict['deal_amount'] = float(values_dict['deal_amount']) - float(
                                        c_deal_amount)
                                for ckeys in all_order.keys():
                                    c_deal_money = all_order[ckeys]['deal_money']
                                    values_dict['deal_money'] = float(values_dict['deal_money']) - float(c_deal_money)
                            # print('实际卖出-'+str(values_dict['deal_amount']))

                            rst = order(1, api_info, market, values_dict['deal_amount'], type_all)
                            if rst['code'] == 1:

                                insertLog(platform, robot_id, uid, u"达到止盈回调率 %s ,当前回调价格 %s" %
                                          (str(round(float(down_rate), 2)), str((tick_price * 100000) / 100000)))
                                order_id = rst['data']['order_id']
                                deal_money = rst['data']['deal_money']
                                deal_amount = rst['data']['deal_stock']
                                deal_fee = rst['data']['deal_fee']
                                price = float(deal_money) / float(deal_amount)
                                side = 1
                                deal_money = float(deal_money) - float(deal_fee)

                                revenue = float(deal_money) - float(values_dict['deal_money'])
                                # zl 2021-06-19 实际收益需要加上分仓网格收益
                                revenue += grid_revenue
                                deal_money = int(deal_money * 1000000000) / 1000000000
                                price = int(price * 1000000000) / 1000000000
                                deal_amount = int(deal_amount * 1000000000) / 1000000000
                                # 修改网格状态为已结算
                                cur.update("update jl_robot_grid set is_over=1 where process_id='" + str(
                                    robot_config['process_id']) + "' and rid='" + str(robot_id) + "' and is_over = 0")

                                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                            money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue,
                                            deal_fee, values_dict['order_count'], values_dict['deal_money'])
                                insertRevenueLog(
                                    platform, robot_id, values_dict['pid'], uid, market, stock_name, money_name,
                                    revenue)
                                updateValues(robot_id, uid, '')
                                redisbase.updaterobotkeys(redis_content, robot_id, uid, {'cover_info': ''})
                                updateRevenue(robot_id, uid, 0)
                                updateMsg(robot_id, uid, u'卖出成功')
                                insertLog(platform, robot_id, uid,
                                          u"卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                              deal_money, money_name, price, money_name, deal_amount, stock_name))

                                if recycle_status == 0:
                                    # 关闭机器人
                                    disableRobot(robot_id, uid)
                                    insertLog(platform, robot_id,
                                              uid, u"量化机器人已经关闭")
                                else:
                                    # 验证是否达到循环次数上限
                                    if now_round_num >= round_num:
                                        # 达到次数上限关闭机器人
                                        disableRobot(robot_id, uid)
                                        insertLog(platform, robot_id, uid, u"达到循环次数上限量化机器人已经关闭")
                                        redisbase.updaterobotkeys(redis_content, robot_id, uid, {'now_round_num': ''})
                                        return
                                    # else:
                                    #     insertLog(platform, robot_id,
                                    #           uid, u"量化机器人已经重新开启")

                            else:
                                amountss = balances(api_info, market, stock_name)
                                values_dict['deal_amounts'] = amountss['data']
                                if values_dict['deal_amounts'] != {}:
                                    if float(values_dict['deal_amount']) > float(values_dict['deal_amounts']):
                                        values_dict['deal_amount'] = values_dict['deal_amounts']
                                rst = order(1, api_info, market, values_dict['deal_amount'], type_all)
                                if rst['code'] == 1:
                                    cleanFinish(robot_id, uid)
                                    order_id = rst['data']['order_id']
                                    deal_money = rst['data']['deal_money']
                                    deal_amount = rst['data']['deal_stock']
                                    deal_fee = rst['data']['deal_fee']
                                    price = float(deal_money) / float(deal_amount)
                                    side = 1
                                    deal_money = float(deal_money) - float(deal_fee)
                                    revenue = float(deal_money) - float(values_dict['deal_money'])
                                    deal_money = int(deal_money * 1000000000) / 1000000000
                                    price = int(price * 1000000000) / 1000000000
                                    deal_amount = int(deal_amount * 1000000000) / 1000000000
                                    insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                                money_name, deal_money, deal_amount, price, 2, values_dict['pid'],
                                                revenue, deal_fee,
                                                values_dict['order_count'], values_dict['deal_money'])

                                    insertRevenueLog(platform, robot_id, values_dict['pid'], uid, market, stock_name,
                                                     money_name, revenue)
                                    updateValues(robot_id, uid, '')
                                    updateRevenue(robot_id, uid, 0)
                                    updateMsg(robot_id, uid, u'卖出成功')
                                    insertLog(platform, robot_id, uid,
                                              u"卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                              deal_money, money_name, price, money_name, deal_amount, stock_name))
                                    if recycle_status == 0:
                                        # 关闭机器人
                                        disableRobot(robot_id, uid)
                                        insertLog(platform, robot_id,
                                                  uid, u"量化机器人已经关闭")
                                    else:
                                        # 验证是否达到循环次数上限
                                        if now_round_num >= round_num:
                                            # 达到次数上限关闭机器人
                                            disableRobot(robot_id, uid)
                                            insertLog(platform, robot_id, uid, u"达到循环次数上限量化机器人已经关闭")
                                            redisbase.updaterobotkeys(redis_content, robot_id, uid,
                                                                      {'now_round_num': ''})
                                            return
                                        # else:
                                        #     insertLog(platform, robot_id,
                                        #           uid, u"量化机器人已经重新开启")
                                    return
                                else:
                                    # cleanFinish(robot_id, uid)
                                    # updateValues(robot_id, uid, '')
                                    # updateRevenue(robot_id, uid, 0)
                                    # disableRobot(robot_id, uid)
                                    # redisbase.updaterobotkeys(redisbase.redis_content,robot_id,uid,{"now_round_num":0})
                                    # redisbase.updaterobotkeys(redisbase.redis_content,robot_id,uid,{"cover_info":''})
                                    # insertLog(platform, robot_id,uid, u"清仓成功量化机器人已经关闭")
                                    flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                                    flagmin = 'Filter failure: MIN_NOTIONAL'
                                    flagt = 'binance GET https://api.binance.com/api/v3/exchangeInfo'
                                    if rst['msg'].find(flag):
                                        insertLog(platform, robot_id, uid, "卖出失败账户余额不足" + rst['msg'])
                                        updateBalanceStatus(robot_id, uid)
                                        return
                                    if rst['msg'].find(flagmin):
                                        insertLog(platform, robot_id, uid, u"卖出失败关闭机器人")
                                        updateValues(robot_id, uid, '')
                                        updateRevenue(robot_id, uid, 0)
                                        updateMsg(robot_id, uid, u'卖出失败关闭机器人')
                                        redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid,
                                                                  {"now_round_num": 0})
                                        redisbase.updaterobotkeys(redisbase.redis_content, robot_id, uid,
                                                                  {"cover_info": ''})
                                        disableRobot(robot_id, uid)
                                    if rst['msg'].find(flagt):
                                        content = '请求超时'
                                    updateMsg(robot_id, uid, u'卖出失败 : ' + content)
                                    insertLog(platform, robot_id, uid,
                                              u'卖出失败 : ' + content)
                                    content = rst['msg']
                                    return
                        return

            if tick_price < base_price:
                # print('下跌')
                if values_dict['order_finish'] == 1:
                    # print('达到最大补仓次数')
                    # 达到最大做单次数后，不能再补仓了
                    return
                if open_risk == 2 and (top_buy < tick_price or tick_price < low_buy):
                    # print('下跌价格高于最高买入金额或低于最低买入金额')
                    insertLog(platform, robot_id, uid, u"下跌价格高于最高买入金额或低于最低买入金额")
                    return
                if trend_side == 0 or trend_side == 1:
                    # 下跌了多少金额
                    down_num = base_price - tick_price
                    #                 down_num = last_price - tick_price
                    down_num = math.fabs(down_num)
                    # 下跌了多少百分比
                    down_rate = down_num * 100 / base_price
                    #                 down_rate = down_num * 100/last_price
                    # print(float(cover_rate['decline']))
                    if down_rate >= float(cover_rate['decline']):
                        # 下跌到补仓线
                        values_dict['trend_side'] = 2
                        values_dict['down_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"补仓比例: %s ,补仓趋势 %s ,当前下跌价格 %s" %
                        #           (cover_rate, down_rate, str(Decimal(str(tick_price)))))
                if is_trend == 1 and common.Trend(platform, market) < 50:
                    # 如果开启了趋势控制  并且当前趋势小于2个  就不补仓
                    return
                if trend_side == 2:
                    # print('下跌补仓')
                    # 判断是否达到补仓回调
                    if tick_price < down_price:
                        # print('继续下跌')
                        # 继续跌了
                        values_dict['down_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        insertLog(platform, robot_id, uid, u"达到补仓线后继续下跌 ,当前下跌价格 %s" %
                                  (str(Decimal(str(tick_price)))))
                    else:
                        # print('下跌回调')
                        up_num = tick_price - down_price
                        up_rate = up_num * 100 / down_price
                        if up_rate >= cover_callback_rate:
                            # print('下跌回调补仓')
                            if robot_config['run_status'] == 0:
                                values_dict['trend_side'] = 0
                                updateValues(robot_id, uid, json.dumps(values_dict))
                                # print('机器人状态不可补仓,请及时查看账户余额是否足够')
                                updateMsg(robot_id, uid, u'机器人状态不可补仓,请及时查看账户余额是否足够')
                                # insertLog(platform, robot_id, uid, u"机器人状态不可补仓,请及时查看账户余额是否足够")
                                return
                            # 达到补仓回调了，补仓

                            # 下单金额
                            if type(cover_rate) == int:
                                cover_rate = {}
                                cover_rate['multiple'] = (order_count + 1) * 2
                            usdt_total = first_order_value * float(cover_rate['multiple'])

                            # if robot_config['platform'] == 'huobi':
                            #     res = Robotcom().enable(robot_config['id'], 3, usdt_total)
                            #     if res['code'] == 1:
                            #         insertLog(platform, robot_id, uid,
                            #                   u"达到补仓回调率 %s ,.当前回调价格 %s" % (up_rate, str(Decimal(str(tick_price)))))
                            #     return
                            rst = order(2, api_info, market, usdt_total, type_all)
                            if rst['code'] == 1:
                                # print(u"达到补仓回调率 %s ,当前回调价格 %s" %
                                #   (up_rate, str(Decimal(str(tick_price)))))
                                insertLog(platform, robot_id, uid, u"达到补仓回调率 %s ,当前回调价格 %s" %
                                          (up_rate, str(Decimal(str(tick_price)))))
                                order_id = rst['data']['order_id']
                                deal_money = rst['data']['deal_money']
                                deal_amount = rst['data']['deal_stock']
                                deal_fee = rst['data']['deal_fee']
                                price = float(deal_money) / float(deal_amount)
                                side = 2
                                if api_info['platform'] == 'okex':
                                    deal_amount = float(deal_amount) - (float(deal_fee) / float(price))
                                elif api_info['platform'] == 'huobi':
                                    deal_amount = float(deal_amount) - (float(deal_fee) / float(price))
                                else:
                                    deal_amount = float(deal_amount)
                                    deal_fee = rst['data']['deal_fees']
                                deal_money = int(deal_money * 1000000000) / 1000000000
                                price = int(price * 1000000000) / 1000000000
                                deal_amount = int(deal_amount * 1000000000) / 1000000000
                                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                            money_name, deal_money, deal_amount, price, 0, values_dict['pid'], 0,
                                            deal_fee,
                                            values_dict['order_count'] + 1, usdt_total)
                                # 补仓单判断大于等于4开始记录分仓
                                if (values_dict['order_count'] + 1) > 4:
                                    #     开始进行记录
                                    cover_key = values_dict['order_count'] + 1
                                    # print('分仓补仓-'+str(cover_key))
                                    # print(cover_key)
                                    # print(cover_info)
                                    cover_info[cover_key] = {
                                        'price': price,
                                        'is_out': 0,
                                        'out_price': deal_amount,
                                        'buy_oid': order_id,
                                    }
                                    # 修改信息
                                    redisbase.updaterobotkeys(redis_content, robot_id, uid,
                                                              {"cover_info": json.dumps(cover_info)})
                                values_dict['order_count'] = values_dict['order_count'] + 1
                                values_dict['trend_side'] = 0
                                values_dict['last_price'] = tick_price
                                values_dict['deal_amount'] = float(
                                    values_dict['deal_amount']) + float(deal_amount)
                                values_dict['deal_money'] = float(
                                    values_dict['deal_money']) + float(deal_money)
                                values_dict['base_price'] = float(
                                    values_dict['deal_money'] / values_dict['deal_amount'])
                                # 达到最大做单数量后，标记finish，只能等盈利
                                if values_dict['order_count'] >= max_order_count:
                                    # 只能等盈利
                                    values_dict['order_finish'] = 1
                                    insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " %
                                              values_dict['order_count'])
                                updateValues(robot_id, uid, json.dumps(values_dict))
                                updateMsg(robot_id, uid, u'补仓成功')
                                insertLog(platform, robot_id, uid,
                                          u"补仓成功：单数 %s , 成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                          values_dict['order_count'], deal_money, money_name, price, money_name,
                                          deal_amount, stock_name))
                                insertLog(platform, robot_id, uid, u"基准价调整为: %s " % values_dict['base_price'])
                            else:

                                # flag = 'https://api.huobi.pro/v1/common/symbols 429 Too Many Requests <!DOCTYPE html>'
                                # if rst['msg'].find(flag):
                                # return
                                # logger.info(rst['msg'])
                                values_dict['trend_side'] = 0
                                updateValues(robot_id, uid, json.dumps(values_dict))
                                content = rst['msg']
                                flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                                if rst['msg'].find(flag):
                                    content = '账户余额不足'
                                updateMsg(robot_id, uid, u'补仓失败 : ' + content)
                                insertLog(platform, robot_id, uid,
                                          u'补仓失败 : ' + content)
                                # runDisableRobot(robot_id, uid)
                                # time.sleep(1)

        else:
            all_num = int(robot_config['round_num'])
            now_num = int(robot_config['now_round_num'])
            # 新启动的
            # 2021-06-19 zl 新开单增加参数判断是否达到循环次数上限
            if int(robot_config['recycle_status']) == 1:

                # print('循环启动 %d' % now_num)
                if now_num >= all_num:
                    # print('循环次数上限')
                    # print('all_num-'+str(all_num))
                    # print('now_num-'+str(now_num))
                    # 达到循环次数上限 记录日志并停止机器人
                    insertLog(platform, robot_id, uid, '达到最大循环次数' + str(all_num) + "机器人停止")
                    disableRobot(robot_id, uid)
                    runDisableRobot(robot_id, uid)
                    return

            # 开始下单
            # print('初始金额-'+str(first_order_value))
            # print('是否翻倍-'+str(robot_config['is_double']))
            if int(robot_config['is_double']) == 1:
                first_order_value = first_order_value * 2
            # print('下单金额-'+str(first_order_value))
            #         logger.info(robot_config)
            # if robot_config['platform'] == 'huobi':
            #     # res = getLocalOrder(robot_config['id'],first_order_value,'/api/quant/python/enable')
            #     res = Robotcom().enable(robot_config['id'], 1)
            #     return
            # #         logger.info(2)

            # balances(api_info, market,stock_name)
            # disableRobot(robot_id, uid)
            # return
            rst = order(2, api_info, market, first_order_value, type_all)
            if rst['code'] == 1:
                cleanFinish(robot_id, uid)
                # print('开单成功')
                order_id = rst['data']['order_id']
                deal_money = rst['data']['deal_money']
                deal_amount = rst['data']['deal_stock']
                deal_fee = rst['data']['deal_fee']
                price = float(deal_money) / float(deal_amount)
                side = 2
                pid = str(uuid.uuid4())
                if api_info['platform'] == 'okex':
                    deal_amount = float(deal_amount) - (float(deal_fee) / float(price))
                elif api_info['platform'] == 'huobi':
                    deal_amount = float(deal_amount) - (float(deal_fee) / float(price))
                else:
                    deal_amount = float(deal_amount)
                    deal_fee = rst['data']['deal_fees']
                deal_money = int(deal_money * 1000000000) / 1000000000
                price = int(price * 1000000000) / 1000000000
                deal_amount = int(deal_amount * 1000000000) / 1000000000
                values_dict = {'order_id': order_id, 'first_order_price': price, 'last_price': price,
                               'base_price': price,
                               'up_price': 0, 'down_price': 0, 'trend_side': 0,
                               'order_count': 0, 'deal_amount': deal_amount, 'deal_money': deal_money,
                               'order_finish': 0,
                               'pid': pid}
                updateValues(robot_id, uid, json.dumps(values_dict))
                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name, money_name, deal_money,
                            deal_amount, price, 1, pid, 0, deal_fee, 1, first_order_value)
                # 更新机器人pid
                # 2021-06-19 zl 增加记录循环次数
                now_num += 1
                runEnableRobot(robot_id, uid)
                updateMsg(robot_id, uid, u'下单成功')
                insertLog(platform, robot_id, uid,
                          u"第" + str(now_num) + "次循环首单开单：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                          deal_money, money_name, price, money_name, deal_amount, stock_name))
                redisbase.updaterobotkeys(redisbase.robot_redis, str(robot_id), str(uid),
                                          {"process_id": pid, "now_round_num": now_num})


            else:
                # print('开单失败')
                # flag = 'https://api.huobi.pro/v1/common/symbols 429 Too Many Requests <!DOCTYPE html>'
                # if rst['msg'].find(flag):
                #   return

                #             logger.info('localorder result"%s' % rst)
                logger.info(rst)
                content = rst['msg']
                flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                if rst['msg'].find(flag):
                    content = '账户余额不足'
                insertLog(platform, robot_id, uid, u'首单开单失败 : ' + content)
                updateMsg(robot_id, uid, u'首单开单失败 : ' + content)
                disableRobot(robot_id, uid)
    else:
        if values_str:
            values_dict = json.loads(values_str)

            cover_rates = robot_config['cover_rates']
            if cover_rates:
                cover_rates_list = json.loads(cover_rates)
                if isinstance(cover_rates_list, list):
                    order_count = values_dict.get('order_count', 1)
                    if (len(cover_rates_list) - 1) >= order_count:
                        cover_rate = cover_rates_list[order_count]

            revenue = float(values_dict['deal_amount']) * tick_price - float(values_dict['deal_money'])
            updateRevenue(robot_id, uid, revenue)
            base_price = float(values_dict['base_price'])
            up_price = float(Decimal(values_dict['up_price']).quantize(Decimal('0.00000000')))
            down_price = float(values_dict['down_price'])
            trend_side = int(values_dict['trend_side'])
            last_price = float(values_dict['last_price'])
            # 清仓卖出
            if is_clean == 1:
                if robot_config['platform'] == 'huobi':
                    # 启动机器人
                    res = Robotcom().enable(robot_config['id'], 2)
                    return
                insertLog(platform, robot_id, uid,
                          u"收到清仓卖出指令 ,当前价格 %s" % str(Decimal(str(tick_price))))

                rst = order(1, api_info, market, values_dict['deal_amount'])
                if rst['code'] == 1:
                    cleanFinish(robot_id, uid)
                    order_id = rst['data']['order_id']
                    deal_money = rst['data']['deal_money']
                    deal_amount = rst['data']['deal_stock']
                    deal_fee = rst['data']['deal_fee']
                    price = float(deal_money) / float(deal_amount)
                    side = 1
                    deal_money = float(deal_money) - float(deal_fee)
                    revenue = float(deal_money) - float(values_dict['deal_money'])

                    insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue, deal_fee,
                                values_dict['order_count'], values_dict['deal_money'])

                    insertRevenueLog(
                        platform, robot_id, values_dict['pid'], uid, market, stock_name, money_name, revenue)
                    updateValues(robot_id, uid, '')
                    updateRevenue(robot_id, uid, 0)
                    updateNew(robot_id, uid, 0)
                    updateMsg(robot_id, uid, u'清仓卖出成功')
                    insertLog(platform, robot_id, uid, u"清仓卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                        deal_money, money_name, price, money_name, deal_amount, stock_name))
                    disableRobot(robot_id, uid)
                    insertLog(platform, robot_id, uid, u"量化机器人已经关闭")
                    return
                else:
                    updateMsg(robot_id, uid, u'清仓卖出失败' + rst['msg'])
                    content = rst['msg']
                    flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                    if rst['msg'].find(flag):
                        content = '账户余额不足'
                    insertLog(platform, robot_id, uid,
                              u'清仓卖出失败:' + content)
                    disableRobot(robot_id, uid)
                    return
            # 判断趋势
            if tick_price > base_price:
                if trend_side == 0 or trend_side == 2:
                    up_num = tick_price - base_price
                    up_rate = up_num * 100 / base_price
                    if up_rate >= stop_profit_rate:
                        # 上涨到止盈率
                        values_dict['trend_side'] = 1
                        values_dict['up_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"止盈率 %s ,止盈趋势: %s ,当前上涨价格 %s" %
                        #           (stop_profit_rate, up_rate, str(Decimal(str(tick_price)))))
                if trend_side == 1:
                    # 判断是否达到止盈回调
                    if tick_price > up_price:
                        # 继续涨了
                        values_dict['up_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"达到止盈率后继续上涨 ,当前上涨价格 %s" %
                        #           (str(Decimal(str(tick_price)))))
                    else:
                        #                     if robot_config['sell_status'] == 1:
                        #                         return
                        down_num = up_price - tick_price
                        down_rate = down_num * 100 / up_price
                        if down_rate >= stop_profit_callback_rate:
                            # 达到止盈回调了，卖出所有deal_amount
                            # updateValues(robot_id,'')

                            if robot_config['platform'] == 'huobi':
                                insertLog(platform, robot_id, uid, u"达到止盈回调率 %s ,当前回调价格 %s" %
                                          (down_rate, str(Decimal(str(tick_price)))))
                                # res = getLocalOrder(robot_config['id'],first_order_value,'/api/quant/python/sellRobot')
                                # 卖出
                                res = Robotcom().enable(robot_config['id'], 2)
                                return

                            rst = order(1, api_info, market, Decimal(values_dict['deal_amount']))
                            if rst['code'] == 1:

                                insertLog(platform, robot_id, uid, u"达到止盈回调率 %s ,当前回调价格 %s" %
                                          (down_rate, str(Decimal(str(tick_price)))))
                                order_id = rst['data']['order_id']
                                deal_money = rst['data']['deal_money']
                                deal_amount = rst['data']['deal_stock']
                                deal_fee = rst['data']['deal_fee']
                                price = float(deal_money) / float(deal_amount)
                                side = 1
                                deal_money = float(deal_money) - float(deal_fee)
                                revenue = float(deal_money) - float(values_dict['deal_money'])

                                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                            money_name, deal_money, deal_amount, price, 2, values_dict['pid'], revenue,
                                            deal_fee, values_dict['order_count'], values_dict['deal_money'])
                                insertRevenueLog(
                                    platform, robot_id, values_dict['pid'], uid, market, stock_name, money_name,
                                    revenue)
                                updateValues(robot_id, uid, '')
                                updateRevenue(robot_id, uid, 0)
                                updateNew(robot_id, uid, 0)
                                updateMsg(robot_id, uid, u'卖出成功')
                                insertLog(platform, robot_id, uid,
                                          u"卖出：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                              deal_money, money_name, price, money_name, deal_amount, stock_name))
                                disableRobot(robot_id, uid)
                                insertLog(platform, robot_id, uid, u"量化机器人已经关闭")
                            else:
                                flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                                if rst['msg'].find(flag):
                                    insertLog(platform, robot_id, uid, "卖出失败账户余额不足" + rst['msg'])
                                    updateBalanceStatus(robot_id, uid)
                                    # disableRobot(robot_id, uid)
                                    return

                                content = rst['msg']

                                # content = '账户余额不足'

                                #                             logger.info(u'卖出失败:%s' % rst['msg'])
                                updateMsg(robot_id, uid, u'卖出失败' + rst['msg'])
                                insertLog(platform, robot_id, uid,
                                          u'卖出失败' + content)
                                # time.sleep(2)
                                # disableRobot(robot_id, uid)

            if tick_price < base_price:
                if values_dict['order_finish'] == 1:
                    # 达到最大做单次数后，不能再补仓了
                    return
                if trend_side == 0 or trend_side == 1:
                    # 下跌了多少金额
                    down_num = base_price - tick_price
                    #                 down_num = last_price - tick_price
                    down_num = math.fabs(down_num)
                    # 下跌了多少百分比
                    down_rate = down_num * 100 / base_price
                    #                 down_rate = down_num * 100/last_price
                    if down_rate >= cover_rate:
                        # 下跌到补仓线
                        values_dict['trend_side'] = 2
                        values_dict['down_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"补仓比例: %s ,补仓趋势 %s ,当前下跌价格 %s" %
                        #           (cover_rate, down_rate, str(Decimal(str(tick_price)))))
                if trend_side == 2:
                    # 判断是否达到补仓回调
                    if tick_price < down_price:
                        # 继续跌了
                        values_dict['down_price'] = tick_price
                        updateValues(robot_id, uid, json.dumps(values_dict))
                        # insertLog(platform, robot_id, uid, u"达到补仓线后继续下跌 ,当前下跌价格 %s" %
                        #           (str(Decimal(str(tick_price)))))
                    else:
                        up_num = tick_price - down_price
                        up_rate = up_num * 100 / down_price
                        if up_rate >= cover_callback_rate:

                            if robot_config['run_status'] == 0:
                                values_dict['trend_side'] = 0
                                updateValues(robot_id, uid, json.dumps(values_dict))
                                updateMsg(robot_id, uid, u'机器人状态不可补仓,请及时查看账户余额是否足够')
                                # insertLog(platform, robot_id, uid, u"机器人状态不可补仓,请及时查看账户余额是否足够")
                                return
                            # 达到补仓回调了，补仓

                            # 下单金额
                            usdt_total = first_order_value * math.pow(2, (values_dict['order_count'] + 1))

                            if robot_config['platform'] == 'huobi':
                                res = Robotcom().enable(robot_config['id'], 3, usdt_total)
                                if res['code'] == 1:
                                    insertLog(platform, robot_id, uid,
                                              u"达到补仓回调率 %s ,.当前回调价格 %s" % (
                                              up_rate, str(Decimal(str(tick_price)))))
                                # res = getLocalOrder(robot_config['id'],usdt_total,'/api/quant/python/coverRobot')
                                # print(res)
                                return
                            rst = order(2, api_info, market, usdt_total)
                            if rst['code'] == 1:
                                insertLog(platform, robot_id, uid, u"达到补仓回调率 %s ,当前回调价格 %s" %
                                          (up_rate, str(Decimal(str(tick_price)))))
                                order_id = rst['data']['order_id']
                                deal_money = rst['data']['deal_money']
                                deal_amount = rst['data']['deal_stock']
                                deal_fee = rst['data']['deal_fee']
                                price = float(deal_money) / float(deal_amount)
                                side = 2
                                deal_amount = float(deal_amount) - float(deal_fee)
                                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                                            money_name, deal_money, deal_amount, price, 0, values_dict['pid'], 0,
                                            deal_fee,
                                            values_dict['order_count'] + 1, usdt_total)
                                values_dict['order_count'] = values_dict['order_count'] + 1
                                values_dict['trend_side'] = 0
                                values_dict['last_price'] = tick_price
                                values_dict['deal_amount'] = float(
                                    values_dict['deal_amount']) + float(deal_amount)
                                values_dict['deal_money'] = float(
                                    values_dict['deal_money']) + float(deal_money)
                                values_dict['base_price'] = float(
                                    values_dict['deal_money'] / values_dict['deal_amount'])
                                # 达到最大做单数量后，标记finish，只能等盈利
                                if values_dict['order_count'] >= max_order_count:
                                    # 只能等盈利
                                    values_dict['order_finish'] = 1
                                    insertLog(platform, robot_id, uid, u"达到最大做单数量次数：单数 %s " %
                                              values_dict['order_count'])
                                updateValues(robot_id, uid, json.dumps(values_dict))
                                updateMsg(robot_id, uid, u'补仓成功')
                                insertLog(platform, robot_id, uid,
                                          u"补仓成功：单数 %s , 成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                                              values_dict['order_count'], deal_money, money_name, price, money_name,
                                              deal_amount,
                                              stock_name))
                                insertLog(platform, robot_id, uid, u"基准价调整为: %s " %
                                          values_dict['base_price'])
                            else:

                                # flag = 'https://api.huobi.pro/v1/common/symbols 429 Too Many Requests <!DOCTYPE html>'
                                # if rst['msg'].find(flag):
                                # return
                                # logger.info(rst['msg'])
                                content = rst['msg']
                                flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                                if rst['msg'].find(flag):
                                    content = '账户余额不足'
                                updateMsg(robot_id, uid, u'补仓失败 : ' + content)
                                insertLog(platform, robot_id, uid,
                                          u'补仓失败 : ' + content)
                                # runDisableRobot(robot_id, uid)
                                # time.sleep(1)

        else:
            # 新启动的
            # 开始下单
            if int(robot_config['is_double']) == 1:
                first_order_value = first_order_value * 2
            #         logger.info(robot_config)
            if robot_config['platform'] == 'huobi':
                # res = getLocalOrder(robot_config['id'],first_order_value,'/api/quant/python/enable')
                res = Robotcom().enable(robot_config['id'], 1)
                return
            #         logger.info(2)

            rst = order(2, api_info, market, first_order_value)
            if rst['code'] == 1:
                order_id = rst['data']['order_id']
                deal_money = rst['data']['deal_money']
                deal_amount = rst['data']['deal_stock']
                deal_fee = rst['data']['deal_fee']
                price = float(deal_money) / float(deal_amount)
                side = 2
                pid = str(uuid.uuid4())
                deal_amount = float(deal_amount) - float(deal_fee)
                insertOrder(platform, uid, order_id, robot_id, side, market, stock_name,
                            money_name, deal_money, deal_amount, price, 1, pid, 0, deal_fee, 1, first_order_value)
                values_dict = {'order_id': order_id, 'first_order_price': price, 'last_price': price,
                               'base_price': price,
                               'up_price': 0, 'down_price': 0, 'trend_side': 0,
                               'order_count': 0, 'deal_amount': deal_amount, 'deal_money': deal_money,
                               'order_finish': 0,
                               'pid': pid}
                updateValues(robot_id, uid, json.dumps(values_dict))
                runEnableRobot(robot_id, uid)
                updateMsg(robot_id, uid, u'下单成功')
                insertLog(platform, robot_id, uid, u"首单开单：成交总价 %s %s ,成交均价 %s %s,成交数量 %s %s" % (
                    deal_money, money_name, price, money_name, deal_amount, stock_name))
            else:
                # flag = 'https://api.huobi.pro/v1/common/symbols 429 Too Many Requests <!DOCTYPE html>'
                # if rst['msg'].find(flag):
                #   return
                updateMsg(robot_id, uid, u'首单开单失败 : ' + rst['msg'])
                #             logger.info('localorder result"%s' % rst)
                content = rst['msg']
                flag = 'account-frozen-balance-insufficient-error","err-msg":"trade account balance is not enough'
                if rst['msg'].find(flag):
                    content = '账户余额不足'
                insertLog(platform, robot_id, uid, u'首单开单失败 : ' + content)
                # disableRobot(robot_id, uid)


def onTick_catch(robot_config, market_info, api_info, type_all):
    # try:
    onTick(robot_config, market_info, api_info, type_all)
    # except Exception as e:
    # logger.error('ontick Exception:%s' % e)
    # print('ontick Exception:%s' % e)


import threading

POOL = {}
Active_Thread = []


# 读取所有的策略配置
def loadStrategyConfig(cur):
    # read db
    markets = cur.fetchall(
        "select id,platform,market,market_name,type,stock,money from jl_spot_market where status = 1")
    # print(len(markets))
    market_list = {}
    for k in markets.keys():
        market = markets[k]
        market_list[market['id']] = market
    # print(market_list)
    # exit()
    # read api key
    # logger.debug('db have %d api' % api_count)
    apis = cur.fetchall("select id,uid,platform,api_key,secret_key,passphrase from jl_third_api where status = 1")
    api_list = {}
    for k in apis.keys():
        apias = apis[k]
        api_list["%s-%s" % (apias['platform'], apias['uid'])] = apias
    # robots = cur.fetchall('SELECT * from jl_quant_robot where status = 1')
    lists = MySqLHelper().fetchall("SELECT option_value from jl_option where option_name='system_setting'")
    lists = json.loads(lists[0]['option_value'])
    config = {}
    config['type'] = lists['type']

    robots = redisbase.getrobotbian()
    if robots:
        for k in robots.keys():
            robot = robots[k]

            if robot['platform'] != 'binance':
                continue
            # print(str(robot['id']) + '开始')
            if str(robot['status']) != str(1):
                continue
            if str(robot['run_status']) != str(1) and str(robot['status']) == str(1):
                # 启用状态为1 运行状态为0时需要判断是否需要启动运行状态
                coin_key = 'robot_' + str(robot['id'])
                redis = redisbase.redis_content
                user_robot_cover = redis.hget('user_robot_cover', coin_key)
                user_robot_sell = redis.hget('user_robot_sell', coin_key)
                user_robot_enable = redis.hget('user_robot_enable', coin_key)
                if user_robot_cover and int(user_robot_cover) == 1:
                    continue
                if user_robot_sell and int(user_robot_sell) == 1:
                    continue
                if user_robot_enable and int(user_robot_enable) == 1:
                    continue
                runEnableRobot(str(robot['id']), str(robot['uid']))
            # logger.info('机器人'+str(robot['id'])+'开始')

            market_id = int(robot['market_id'])
            platform = robot['platform']

            uid = int(robot['uid'])
            robot_id = int(robot['id'])
            if market_id in market_list.keys():
                market_info = market_list[market_id]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, 'market %s not found' % market_id)
                insertLog(platform, robot_id, uid, 'market %s  not found , stopped...' % market_id)
                continue
            if "%s-%s" % (platform, uid) in api_list.keys():
                api_info = api_list["%s-%s" % (platform, uid)]
            else:
                disableRobot(robot_id, uid)
                updateMsg(robot_id, uid, '%s api not found' % platform)
                insertLog(platform, robot_id, uid,
                          '%s api not found , stopped...' % platform)
                continue
            aolist = api.getapilist()
            if aolist == []:
                onTick(robot, market_info, api_info, config['type'])
                continue
            if str(config['type']) == '1':
                if robot_id in Active_Thread:
                    continue
                task = threading.Thread(target=onTick_catch, args=(robot, market_info, api_info, config['type']))
                POOL[robot_id] = task
                POOL[robot_id].setDaemon(True)
                POOL[robot_id].start()
            elif str(config['type']) == '2':
                if robot_id in Active_Thread:
                    continue
                task = threading.Thread(target=onTick_catch, args=(robot, market_info, api_info, config['type']))
                POOL[robot_id] = task
                POOL[robot_id].setDaemon(True)
                POOL[robot_id].start()
            else:
                onTick(robot, market_info, api_info, config['type'])
            # _thread.start_new_thread(
            #    onTick, (robot, market_info, api_info))
            # if robot_id in Active_Thread:
            #     continue
            # task = threading.Thread(target=onTick_catch, args=(robot, market_info, api_info))
            # POOL[robot_id] = task
            # POOL[robot_id].setDaemon(True)
            # POOL[robot_id].start()
            # if robot_id in thread_alive:
            #     if thread_alive[robot_id] == 1:
            #         continue
            #     else:
            #         thread_alive[robot_id] == 1
            # time.sleep(0.1)


if __name__ == '__main__':
    while True:
        try:
            # logger.info('new')
            # getlistinfos()
            getlisttimes()
            last_time = int(time.time() * 1000)
            cur = MySqLHelper()
            loadStrategyConfig(cur)
            time.sleep(0.5)
        except Exception as e:
            logger.info('Exception:%s', e)
            time.sleep(0.5)

