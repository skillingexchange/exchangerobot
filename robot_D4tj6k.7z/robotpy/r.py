from database import MySqLHelper
import redisbase
import time
# redis连接池
redis_content = redisbase.redis_content
robot_content = redisbase.robot_redis
# mysql连接池
sql_content = MySqLHelper()
list = sql_content.fetchall('select * from jl_spot_market where 1')
for k in list.keys():
    v = list[k]
    for kk in v.keys():
        vv = str(v[kk])
        redis_content.hset('spot_market_'+str(v['id']),str(kk),vv)
# time.sleep(10)
# robots = sql_content.fetchall('select * from jl_quant_robot where 1')
# if 
# for k in robots.keys():
#     v = robots[k]
#     has = robot_content.keys('user_robot_'+str(v['uid'])+'_'+str(v['id']))
#     if has:
#         continue
#     for kk in v.keys():
#         vv = str(v[kk])
#         robot_content.hset('user_robot_'+str(v['uid'])+'_'+str(v['id']),str(kk),vv)