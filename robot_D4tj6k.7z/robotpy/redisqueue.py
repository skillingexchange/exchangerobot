import redisbase
from database import MySqLHelper
import time
def runsqlinfo():
    # 连击redis连接池
    content = redisbase.redis_content
    robot_content = redisbase.robot_redis
    log_content = redisbase.getrids(2)
    # 连接sql连接池
    sql_content = MySqLHelper()
    sql = log_sql = revenue_sql = ''
    # 获取分两步，先获取需要插入的，再获取更新的，可能插入之后会有更新所以先获取插入语句
    # log
    log_keys = content.hkeys('insert_log_sql')
    if len(log_keys)>100:
        log_keys = log_keys[0:100]
    if len(log_keys)>0:
        log_sql = "insert into jl_quant_robot_log (platform,uid,qrobot_id,content,ctime) values "
        for key in log_keys:
            log_sql += str(content.hget('insert_log_sql', key)) + ','
    elif len(log_keys)<100:
        log_keys2 = log_content.hkeys('insert_sql')
        if len(log_keys2) > 0:
            less = 100-len(log_keys)
            log_keys2 = log_keys2[0:less]
            if log_sql!='':
                for key in log_keys2:
                    log_sql += str(log_content.hget('insert_log_sql', key)) + ','
            else:
                log_sql = "insert into jl_quant_robot_log (platform,uid,qrobot_id,content,ctime) values "
                for key in log_keys2:
                    log_sql += str(log_content.hget('insert_log_sql', key)) + ','
    if log_sql != '':
        log_sql = log_sql[0:-1]
        log_sql += ';'
    # revenue
    revenue_keys = content.hkeys('insert_revenue_sql')
    if len(revenue_keys)>100:
        revenue_keys = revenue_keys[0:100]
    if len(revenue_keys)>0:
        revenue_sql += "insert into jl_quant_robot_revenue (platform,qrobot_id,pid,uid,market,stock,money,revenue,deal_status,ctime) values "
        for key in revenue_keys:
            revenue_sql += str(content.hget('insert_revenue_sql', key)) + ','
    # 获取更新语句
    if revenue_sql != '':
        revenue_sql = revenue_sql[0:-1]
        revenue_sql += ';'
    update_keys = content.hkeys('update_sql')
    if len(update_keys)>10:
        update_keys = update_keys[0:10]
    update_keys2 = robot_content.hkeys('update_sql')
    if len(update_keys2) > 10:
        update_keys2 = update_keys2[0:10]
    # if len(update_keys)>0:
    #     for key in update_keys:
    #         sql += str(content.hget('update_sql', key)) + ';'
    # 执行sql
    print(update_keys2)
    if len(update_keys) > 0 or log_sql != '' or revenue_sql != '':
        try:
            if log_sql != '':
                sql_content.execute(log_sql)
            if revenue_sql != '':
                sql_content.execute(revenue_sql)
            if len(update_keys)>0:
                for key in update_keys:
                    now = content.hget('update_sql', key)
                    if 'update jl_quant_robot set `robot_id`=' in now or 'update jl_quant_robot set `language`=' in now:
                        continue
                    sql = str(now) + ';'
                    sql_content.execute(sql)
            if len(update_keys2)>0:
                for key in update_keys2:
                    now = robot_content.hget('update_sql', key)
                    if 'update jl_quant_robot set `robot_id`=' in now or 'update jl_quant_robot set `language`=' in now:
                        continue
                    sql = str(now) + ';'
                    sql_content.execute(sql)
            if len(log_keys) > 0:
                for key in log_keys:
                 content.hdel('insert_log_sql',key)
            if len(log_keys2) > 0:
                for key in log_keys2:
                 log_content.hdel('insert_log_sql',key)
            if len(revenue_keys) > 0:
                for key in revenue_keys:
                 content.hdel('insert_revenue_sql',key)
            if len(update_keys) > 0:
                for key in update_keys:
                 content.hdel('update_sql',key)
            if len(update_keys2) > 0:
                for key in update_keys2:
                 robot_content.hdel('update_sql',key)
        except Exception as e:
            pass
    else:
        print('empty')
    print('over')
    return
if __name__=='__main__':
    times = 3
    while True:
        runsqlinfo()
        time.sleep(times)