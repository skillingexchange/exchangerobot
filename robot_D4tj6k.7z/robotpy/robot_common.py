# 公共文件
import common
from flask import Flask, request
import json

server = Flask(__name__)


@server.route('/robot/comprehensive', methods=['get'])  # 进程监听
def comprehensive():
    exchange = request.args.get('exchange')  # 交易所
    sybmol = request.args.get('sybmol')  # 交易对
    result = common.Trend(sybmol, exchange)
    res = {'msg': '获取成功', 'code': 0, 'data': result}
    return json.dumps(res, ensure_ascii=False)


server.run(port=9505, debug=False, host='0.0.0.0')
