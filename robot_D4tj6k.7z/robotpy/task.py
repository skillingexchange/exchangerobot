import time
import urllib.request
from threading import Thread


class Task(Thread):
    def __init__(self, url, timeout=1):
        super(Task,self).__init__()
        self.url = url
        self.timeout = timeout

    def do(self):
        try:
            response = urllib.request.urlopen(self.url)
        except Exception as e:
            print(e)

    def run(self):
        while 1:
            self.do()
            time.sleep(self.timeout)

# 总后台域名
url = 'https://robot.btccvip.com'

# 钱包后台域名
wallet_url = 'https://wallet.btccvip.com'

conf = [
#         定时任务
        {'url' : url + '/api/home/Cron/index' , 'timeout' : 1},
#         行情
#         {'url' : url + '/api/home/Cron/test2' , 'timeout' : 1},
#         机器人分润
        {'url' : url + '/api/quant/task/quantReward' , 'timeout' : 10},
#         交易订单操作
        {'url' : url + '/api/wallet/rpc_transfer/index' , 'timeout' : 10},
#         卖出失败,后续操作
#         {'url' : url + '/api/quant/robot/sellStatus' , 'timeout' : 5},
#         余额不足，轮训余额
        {'url' : url + '/api/quant/robot/runRobotUpdate' , 'timeout' : 30},

#         修改交易对 小数点精度
        {'url' : url + '/api/task/index/getSymbol' , 'timeout' : 60*60*24},

#         redis同步更新
        {'url' : url + '/api/wxapp/ticker/send' , 'timeout' : 5},
        
#         交易订单操作
        {'url' : wallet_url + '/api/wallet/rpc_transfer' , 'timeout' : 120},
#         汇集
        {'url' : wallet_url + '/portal/tron/CheckAddressOrgTrc20' , 'timeout' : 60},
#         定时任务
        {'url' : wallet_url + '/api/wallet/Cron/index' , 'timeout' : 1},
#          获取链上交易信息
        #         发送提现
        {'url' : wallet_url + '/api/wallet/Cron/send' , 'timeout' : 1},
        # {'url' : wallet_url + '/api/wallet/rpc_fetch/index/coin_symbol/TRX' , 'timeout' : 1}
        
        ]

def domain():
    pool = []
    for i in conf:
        task = Task(i['url'],i['timeout'])
        pool.append(task)
    for i in pool:
        i.start()

if __name__ == '__main__':
    domain()
