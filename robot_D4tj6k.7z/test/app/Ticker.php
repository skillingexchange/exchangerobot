<?php

namespace app;


class Ticker
{
    public static function symbol()
    {
        global $db;
        $data = $db->from('jl_ticker')
            ->select('lower(replace(market,\'/\',\'\')) as symbol')
            ->where('exchange_class = \'binance\'')
            ->query();
        $data = array_column($data, 'symbol');
        foreach ($data as $k => $v) {
//            if (!preg_match('/^[a-z]+$/', $v)) {
//                unset($data[$k]);
//            }
        }
        $data = array_values($data);
        return $data;
    }

    public static function setTreamData($uid, $data)
    {
        global $db, $redis,$sync_redis;
        $Time_redis = new \Redis();
        $Time_redis->connect('127.0.0.1', 6379);
        $Time_redis->auth('scmmwl888');
        $Time_redis->select(1);
        $str = $sync_redis->keys('listenkey_'.$uid.'*');
        $user_account = json_decode($sync_redis->get($str),true);
        $robot_data = $Time_redis->keys('user_contract_'.$user_account['id'].'*');
        if(empty($robot_data)){
            return;
        }
        foreach ($data['data'] as $item){
            $plat_data = $item;
            if($plat_data['instType']!='SWAP'){
                return ;
            }
            $instId = $item['instId'];
            $ccy = $item['ccy'];
            //获取机器人数据。循环该用户机器人数据
            foreach ($robot_data as $ro){
                $result= $Time_redis->hgetall($ro);
                $market_id = $result['market_id'];
                $stock =  $sync_redis->hget('spot_market_'.$market_id,'stock');
                $money =  $sync_redis->hget('spot_market_'.$market_id,'money');
                $market_name = $stock.'-'.$money.'-'.'SWAP';
                if ($result['platform']!='okex'){
                    return ;
                }
                if($market_name!=$instId){
                    return ;
                }
                if($plat_data['mgnMode']!='cross'){
                    return ;
                }
                //判断机器人做单方向
                // 如果做单方向为多空
                if($result['is_trend']==2){
                    if($plat_data['posSide']=='long'){
                        if(isset($result['values_str']) && !empty($result['values_str'])){
                            $value_str = json_decode($result['values_str'],true);
                            $value_str['strong_pay'] = $plat_data['liqPx'];
                            $value_str['margin_lilv'] = floatval($plat_data['mgnRatio'])*100;
                            $value_str['margin_price'] = $plat_data['imr'];
                            $two_redis->hSet($ro,'values_str',json_encode($value_str));
                        }
                        
                    }
                    if($plat_data['posSide']=='short'){
                        if(isset($result['values_strs']) && !empty($result['values_strs'])){
                            $value_str = json_decode($result['values_strs'],true);
                            $value_str['strong_pay'] = $plat_data['liqPx'];
                            $value_str['margin_lilv'] = floatval($plat_data['mgnRatio'])*100;
                            $value_str['margin_price'] = $plat_data['imr'];
                            $two_redis->hSet($ro,'values_strs',json_encode($value_str));
                        }
                        
                    }
                }else {
                    if(isset($result['values_str']) && !empty($result['values_str'])){
                        $value_str = json_decode($result['values_str'],true);
                        $value_str['strong_pay'] = $plat_data['liqPx'];
                        $value_str['margin_lilv'] = floatval($plat_data['mgnRatio'])*100;
                        $value_str['margin_price'] = $plat_data['imr'];
                        $two_redis->hSet($ro,'values_str',json_encode($value_str));
                    }
                    
                }
                
                
            }
            
            
        }
    }
    
    public static function setSWAPData($ch, $tick)
    {
    	//last最新成交价/本阶段收盘价
//  	open_24h  本阶段开盘价/24小时开盘价
        global $db, $redis;
        $redis->get('kline_okex_' . $ch, function ($result, $redis) use ($ch, $tick, $db) {
//      	var_dump($result);
            if ($result) {
                $result = json_decode($result, true);
                // if ( $result['c'] != $tick['c'] || $result['o'] != $tick['o']) {
                //     $result = null;
                // }
            }
            $result=null;
            if (!$result) {
                $redis->set('kline_binance_' . $ch.'swap', json_encode($tick));
                var_dump($tick['p']);
                $redis->set('price_binance_'. $ch.'swap',$tick['p']);
                $result = $redis->hMSet('ticker_price_binance_'. $ch.'swap',[
                	'price'       => $tick['p'],
                    'change'      => '1',
                    'update_time' => time(),
                ]);
            }
        });
    }
    
    
    public static function setDataKLine($ch, $tick)
    {
        global $db, $redis,$sync_redis;
//      日期有几种格式 5m,30m,1h,4h,12h,1d
//		分别代表5分钟，30分钟，1小时，4小时，12小时，1天
        $k = $tick['k'];
//      直接往redis里面存入数据
//		时间
		$time = $k['t'];
//		收盘价
		$close = $k['c'];
//		名称
		$string = $ch."_kline_binance";
		$sync_redis->hset($string,$time,$close);
		
		$length = $sync_redis->hLen($string);
		$number = 365;
		if($length > $number){
			# 删除前面的
		    $data = $sync_redis->hKeys($string);
		    $vi = 0;
		    # 需要删除多少个
		    $lens = $length - $number;
		    foreach($data as $k=>$v){
		    	if($vi < $lens){
		            $sync_redis->hdel($string, $v);
		        }else{
		            break;
		        }
		        $vi ++;
		    }   
		}
    }
}
