#! /bin/bash
cd /www/wwwroot/robot_yanshi/bian/
php start.php reload
