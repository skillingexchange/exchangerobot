import redis
import time
from datetime import datetime
redis_auth = 'scmmwl888'
def getrids(db=0):
    pool = redis.ConnectionPool(host='127.0.0.1', port=6379, password=redis_auth, decode_responses=True,db=db)
    redis_content = redis.Redis(connection_pool=pool, decode_responses=True, password=redis_auth, db=db)
    return redis_content
redis_content = getrids()
trx_port_redis = getrids(3)