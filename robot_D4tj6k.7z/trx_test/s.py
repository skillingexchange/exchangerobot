from wallet import database
import time
import requests
import json
from trxrpc import trxrpc
import binascii
import redisbase
import base58
from decimal import Decimal, ROUND_DOWN
import re
less_time = 2
trx = trxrpc()
sql_content = database.MySqLHelper()
trx_port_redis = redisbase.trx_port_redis
base_url = 'http://3.225.171.164:8090/'
url_no = 0
url_arr = [
    'http://3.225.171.164:8090/',
    'http://52.53.189.99:8090/',
    'http://18.196.99.16:8090/',
    'http://34.253.187.192:8090/',
    'http://18.133.82.227:8090/',
    'http://35.180.51.163:8090/',
    'http://54.252.224.209:8090/',
    'http://18.228.15.36:8090/',
    'http://52.15.93.92:8090/',
    'http://34.220.77.106:8090/',
    'http://13.127.47.162:8090/',
    'http://13.124.62.58:8090/',
    'http://35.182.229.162:8090/',
    'http://18.209.42.127:8090/',
    'http://3.218.137.187:8090/',
    'http://34.237.210.82:8090/'
]
headers = {"Content-Type": "application/json; charset=UTF-8"}
coin_symbol = 'TRX'
# 添加线上交易
def confirm_transfer(coin_symbol, froms, to, memo, amount, fee, blockhash, txid):
    if type(froms) == bytes:
        froms = str(froms,encoding='utf8')
    if type(to) == bytes:
        to = str(to, encoding='utf8')
    # sql_content.execute("select id,wallet_id,to_wallet_id,coin_symbol,type from jl_transfer_log where tx_id='"+txid+"' and transfer_status=2")
    logs = sql_content.fetchall("select id,wallet_id,to_wallet_id,coin_symbol,type from jl_transfer_log where tx_id='"+txid+"' and transfer_status=2")
    for key in logs.keys():
        value = logs[key]
        log_id = value['id']
        # update_data = {}
        # update_data['transfer_status'] = 1
        # update_data['fee'] = fee
        cursor, conn, count = sql_content.execute("update jl_transfet_log set transfer_status=1,fee='"+fee+"' where id='"+log_id+"'")
        conn.commit()
        p = {}
        task_data = {}
        p['wallet_id'] =  value['wallet_id']
        task_data['params'] = json.dumps(p, ensure_ascii=False)
        task_data['task_name'] = "update_wallet_balance"
        task_data['wallet_id'] = value['wallet_id']
        task_data['schedule_time'] = int(time.time())
        sql = build_insert('jl_cron',task_data)
        cursor, conn, count = sql_content.execute(sql)
        conn.commit()
        if int(value['type'])!=4 and int(value['type'])!=5:
            p = {}
            task_data = {}
            p['transaction_id'] =  value['id']
            p['notify_type'] = "confirm"
            task_data['params'] = json.dumps(p, ensure_ascii=False)
            task_data['task_name'] = "notify_url"
            task_data['wallet_id'] = value['wallet_id']
            task_data['schedule_time'] = int(time.time())
            sql = build_insert('jl_cron', task_data)
            cursor, conn, count = sql_content.execute(sql)
            conn.commit()
    if not froms is None and froms!='':
        # 更新余额
        cursor, conn, count = sql_content.execute("select id,address from jl_wallet where address='"+froms+"'")
        conn.commit()
        # wallet = sql_content.fetchone()
        insert_data = {}
        insert_data['tx_id'] = txid
        insert_data['coin_symbol'] = coin_symbol
        insert_data['from_address'] = froms
        insert_data['to_address'] = to
        insert_data['memo'] = memo
        insert_data['amount'] = amount
        insert_data['fee'] = fee
        insert_data['block_hash'] = blockhash
        insert_data['log_time'] = int(time.time())
        sql = build_insert('jl_chain_log', insert_data)
        cursor, conn, count = sql_content.execute(sql)
        conn.commit()

# 添加线上交易
def add_transfer_log( coin_symbol, froms, to, memo, amount, fee, blockhash, txid):
    if type(froms) == bytes:
        froms = str(froms,encoding='utf8')
    if type(to) == bytes:
        to = str(to, encoding='utf8')
    # 先查找交易是否存在
    # sql_content.execute("select id from jl_transfer_log where type='3' and tx_id='"+txid+"' ")
    find = sql_content.fetchone("select id from jl_transfer_log where type='3' and tx_id='"+txid+"' ")
    if not find is None:
        return
    # sql_content.execute("select id,chain_balance from jl_wallet where address='"+to+"' and memo = '"+memo+"' ")
    walletData = sql_content.fetchone("select id,chain_balance from jl_wallet where address='"+to+"' and memo = '"+memo+"' ")
    if walletData is None:
        return
    cursor, conn, count = sql_content.execute("update jl_wallet set chain_balance='"+str(amount)+"' where id='"+str(walletData['id'])+"'")
    conn.commit()
    balance = walletData['chain_balance']
    #获取最新余额
    #sql_content.execute("select chain_balance from jl_wallet where id='"+walletData[0]+"'")
    balance_data = sql_content.fetchone("select chain_balance from jl_wallet where id='"+str(walletData['id'])+"'")
    # 写入交易日志
    insert_data = {}
    balance_after =  balance_data['chain_balance']
    insert_data['type'] = 3
    insert_data['wallet_id'] = walletData['id']
    insert_data['coin_symbol'] = coin_symbol
    insert_data['from_address'] = froms
    insert_data['to_address'] = to
    insert_data['amount'] = amount
    insert_data['amount_before'] = balance
    insert_data['amount_after'] = balance_after
    insert_data['fee'] = fee
    insert_data['log_time'] = int(time.time())
    insert_data['memo'] = ''
    insert_data['blockhash'] = blockhash
    insert_data['tx_id'] = txid
    insert_data['transfer_status'] = 0
    insert_data['audit_status'] = 1
    insert_data['notify_status'] = 0
    sql = build_insert('jl_transfer_log',insert_data)
    cursor, conn, count = sql_content.execute(sql)
    thisid = cursor.lastrowid
    conn.commit()
    p = {}
    task_data = {}
    p['transaction_id'] = thisid
    p['notify_type'] = "payment"
    task_data['params'] = json.dumps(p, ensure_ascii=False)
    task_data['task_name'] = "notify_url"
    task_data['wallet_id'] = walletData['id']
    task_data['schedule_time'] = int(time.time())
    sql = build_insert('jl_cron', task_data)
    cursor, conn, count = sql_content.execute(sql)
    conn.commit()
# 建立插入sql
def build_insert(table, param):
    key = ""
    val = ""
    for k in param.keys():
        v = param[k]
        key += "`" + k + "`,"
        val += "'" + str(v) + "',"
    key = key[0:len(key)-1]
    val = val[0:len(val)-1]
    sql = "insert into " + table + " (" + key + ") values (" + val + ")"
    return sql
# 哈希转换
def hexString2Base58check(hexString):
    address = hex2bin(hexString)
    base58add = base58.b58encode_check(address)
    return base58add
def hex2bin(h):
    return binascii.a2b_hex(h)
time_key = []
time_value = []
# 初始验证响应最快
# for url_info in url_arr:
#     try:
#         t1 = int(round(time.time()*1000))
#         trx.get_BlockNumber(url_info)
#         t2 = int(round(time.time()*1000))
#         less = t2-t1
#         time_key.append(str(less))
#         time_value.append(url_info)
#     except Exception as e:
#         continue
# time_arr = dict(zip(time_key,time_value))
# url_key_arr = sorted(time_arr)
# url_key = url_key_arr[0]
# base_url = time_arr[url_key]
# def getnew_port():
#     time_key = []
#     time_value = []
#     # 初始验证响应最快
#     for url_info in url_arr:
#         try:
#             t1 = int(round(time.time() * 1000))
#             trx.get_BlockNumber(url_info)
#             t2 = int(round(time.time() * 1000))
#             less = t2 - t1
#             time_key.append(str(less))
#             time_value.append(url_info)
#         except Exception as e:
#             continue
#     time_arr = dict(zip(time_key, time_value))
#     url_key_arr = sorted(time_arr)
#     url_key = url_key_arr[0]
#     base_url = time_arr[url_key]
#     return base_url
 
# while True:
#     add = []
#     confirm = []
#     all_list = []
#     last = []
#     first_time = int(time.time())
#     # print('first_time')
#     # print(first_time)
#     res = trx.get_BlockNumber(base_url)
#     if int(res['code']) == 0:
#         now_time = int(time.time())
#         if now_time-first_time > 0:
#             less = now_time-first_time
#             if less < less_time:
#                 less = less_time
#                 time.sleep(less)
#             continue
#         else:
#             # print(res)
#             continue
#     max_block = res['data']['block_num']
#     max_block = int(max_block)
#     # 获取当前高度
#     now_block = sql_content.fetchone("select rpc_last_pos from jl_coin where coin_symbol='"+str(coin_symbol)+"'")
#     if now_block and now_block['rpc_last_pos']:
#         now_block = now_block['rpc_last_pos']
#         now_block = int(now_block)
#     if now_block >= max_block:
#         continue
#     max_block = int(max_block) - 1
#     block = min(int(max_block), int(now_block)+5)
#     # print(block)
#     i = int(now_block)+1
#     if i >= (max_block+1):
#         continue
#     transactions = []
#     while i <= block:
#         result = trx.request('wallet/getblockbynum', {"num":i},base_url)
#         if result == False:
#         #     重新选择节点
#             base_url = getnew_port()
#             result = trx.request('wallet/getblockbynum', {"num": i}, base_url)
#         if result == False:
#             continue
#         result = json.loads(result)
#         # result = result
#         # result = json.loads(result)
#         # logger.error('%s' % result)
#         if 'blockID' in result.keys() and 'transactions' in result.keys() and result['blockID'] and result['transactions']:
#             for v in result['transactions']:
#                 transactions.append(v)
#         # if i == 31142314:
#         #     last = result
#         i += 1
#     # print(last['raw_data']['contract'][0]['parameter']['value'])
#     res['transactions'] = transactions
#     res['lastblock'] = block
#     # print(transactions)
#     # print(block)
#     # exit()
#     user_address = sql_content.fetchall("select address from jl_wallet where status=1")
#     if user_address is None:
#         print(block)
#         cursor, conn, count = sql_content.execute("update jl_coin set rpc_last_pos='"+str(block)+"' where coin_symbol='"+str(coin_symbol)+"'")
#         conn.commit()
#     tmp = []
#     for k in user_address.keys():
#         v = user_address[k]
#         tmp.append(v['address'])
#     user_address = tmp
#     contract_list = []
#     contract_info = {}
#     contract_data = sql_content.fetchall("select coin_symbol,contract,decimals from jl_coin where parent_coin='"+str(coin_symbol)+"'")
#     for k in contract_data.keys():
#         v = contract_data[k]
#         contract_list.append(v['contract'])
#         contract_info[str(v['contract'])] = {}
#         contract_info[str(v['contract'])]['coin_symbol'] = str(v['coin_symbol'])
#         contract_info[str(v['contract'])]['decimals'] = str(v['decimals'])

#     for value in transactions:
#         if not value['ret'][0]['contractRet']:
#             continue
#         if value['ret'][0]['contractRet'] != 'SUCCESS':
#             continue
#         blockhash = value['txID']
#         txid = value['txID']
#         list = value['raw_data']['contract']
#         for vv in list:
#             if str(vv['type'])!='TriggerSmartContract':
#                 continue
#             froms = hexString2Base58check(vv['parameter']['value']['owner_address'])
#             contract_address = hexString2Base58check(vv['parameter']['value']['contract_address'])
#             forms = str(froms,encoding='utf8')
#             contract_address = str(contract_address,encoding='utf8')
#             # all_list.append(forms)
#             # all_list.append(contract_address)
#             # print(forms)
#             if 'data' in vv['parameter']['value'].keys() and not vv['parameter']['value']['data'] is None and vv['parameter']['value']['data'] != '':
#                 contract_data = vv['parameter']['value']['data']
#             else:
#                 contract_data = ''
#             fee = 0
#             memo = ""


#             if contract_data.startswith('a9059cbb'):
#                 token_to = hexString2Base58check("41" + contract_data[32:72])
#                 token_amount = contract_data[72:len(contract_data)]
#                 hex_number = re.sub('^0+', '', token_amount)
#                 token_to = str(token_to,encoding='utf8')
#                 if hex_number is None or hex_number == '':
#                     continue
#                 token_amount = int(hex_number,16)
#                 # token_amount = hex(hex_number)
#             else:
#                 continue
#             if contract_address in contract_list:
#                 token_decimal = contract_info[contract_address]['decimals']
#                 token_amount = round(token_amount / pow(10, int(token_decimal)),8)
#                 token_symbol = contract_info[contract_address]['coin_symbol']
#             else:
#                 token_symbol=''
#             if token_symbol=='':
#                 continue
#             # if str(txid) == 'b0bb919fb8c3840ee58742651fb4a14dbdb7693919743c67ff11064dcd1984c3':
#             #     print(token_to)
#             #     print(froms)
#             #     exit()
#             if froms in user_address:
#                 confirm.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
#             if contract_address in user_address:
#                 add.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
#             if token_to in user_address:
#                 add.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
#     #开始插入
#     for val in confirm:
#         confirm_transfer(val[0],val[1],val[2],val[3],val[4],val[5],val[6],val[7])
#     for va in add:
#         add_transfer_log(va[0], va[1], va[2], va[3], va[4], va[5], va[6], va[7])
#     # 更新高度
#     cursor, conn, count = sql_content.execute("update jl_coin set rpc_last_pos='"+str(block)+"' where coin_symbol='"+str(coin_symbol)+"'")
#     conn.commit()
#     now_time = int(time.time())
#     less = now_time - first_time
#     if now_time - first_time > 0:
#         if less < less_time:
#             less = less_time
#             # print('sleep')
#             # print(less)
#             time.sleep(less)
#     # print('end')
#     # print(less)
def get_transactions_data(now_block,block,base_url):
    add = []
    confirm = []
    all_list = []
    last = []
    transactions = []
    res ={}
    i = int(now_block)+1
    while i <= block:
        result = trx.request('wallet/getblockbynum', {"num":i},base_url)
        if result == False:
        #     重新选择节点
            base_url = getnew_port()
            result = trx.request('wallet/getblockbynum', {"num": i}, base_url)
        if result == False:
            continue
        result = json.loads(result)
        if 'blockID' in result.keys() and 'transactions' in result.keys() and result['blockID'] and result['transactions']:
            for v in result['transactions']:
                transactions.append(v)
        i += 1
    res['transactions'] = transactions
    res['lastblock'] = block
    user_address = sql_content.fetchall("select address from jl_wallet where status=1")
    if user_address is None:
        cursor, conn, count = sql_content.execute("update jl_coin set rpc_last_pos='"+str(block)+"' where coin_symbol='"+str(coin_symbol)+"'")
        conn.commit()
    tmp = []
    for k in user_address.keys():
        v = user_address[k]
        tmp.append(v['address'])
    user_address = tmp
    contract_list = []
    contract_info = {}
    contract_data = sql_content.fetchall("select coin_symbol,contract,decimals from jl_coin where parent_coin='"+str(coin_symbol)+"'")
    for k in contract_data.keys():
        v = contract_data[k]
        contract_list.append(v['contract'])
        contract_info[str(v['contract'])] = {}
        contract_info[str(v['contract'])]['coin_symbol'] = str(v['coin_symbol'])
        contract_info[str(v['contract'])]['decimals'] = str(v['decimals'])

    for value in transactions:
        if not value['ret'][0]['contractRet']:
            continue
        if value['ret'][0]['contractRet'] != 'SUCCESS':
            continue
        blockhash = value['txID']
        txid = value['txID']
        list = value['raw_data']['contract']
        for vv in list:
            if str(vv['type'])!='TriggerSmartContract':
                continue
            froms = hexString2Base58check(vv['parameter']['value']['owner_address'])
            contract_address = hexString2Base58check(vv['parameter']['value']['contract_address'])
            forms = str(froms,encoding='utf8')
            contract_address = str(contract_address,encoding='utf8')
            # all_list.append(forms)
            # all_list.append(contract_address)
            # print(forms)
            if 'data' in vv['parameter']['value'].keys() and not vv['parameter']['value']['data'] is None and vv['parameter']['value']['data'] != '':
                contract_data = vv['parameter']['value']['data']
            else:
                contract_data = ''
            fee = 0
            memo = ""


            if contract_data.startswith('a9059cbb'):
                token_to = hexString2Base58check("41" + contract_data[32:72])
                token_amount = contract_data[72:len(contract_data)]
                hex_number = re.sub('^0+', '', token_amount)
                token_to = str(token_to,encoding='utf8')
                if hex_number is None or hex_number == '':
                    continue
                token_amount = int(hex_number,16)
                # token_amount = hex(hex_number)
            else:
                continue
            if contract_address in contract_list:
                token_decimal = contract_info[contract_address]['decimals']
                token_amount = round(token_amount / pow(10, int(token_decimal)),8)
                token_symbol = contract_info[contract_address]['coin_symbol']
            else:
                token_symbol=''
            if token_symbol=='':
                continue
            # if str(txid) == 'b0bb919fb8c3840ee58742651fb4a14dbdb7693919743c67ff11064dcd1984c3':
            #     print(token_to)
            #     print(froms)
            #     exit()
            if froms in user_address:
                confirm.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
            if contract_address in user_address:
                add.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
            if token_to in user_address:
                add.append([token_symbol,froms,token_to,memo,token_amount,fee,blockhash,txid])
    #开始插入
    print(add)
    for val in confirm:
        confirm_transfer(val[0],val[1],val[2],val[3],val[4],val[5],val[6],val[7])
    for va in add:
        add_transfer_log(va[0], va[1], va[2], va[3], va[4], va[5], va[6], va[7])
    # 更新高度
    trx_port = trx_port_redis.get('trx_port_redis')
    if trx_port is None or trx_port=='' or int(trx_port) < int(block):
        trx_port_redis.set('trx_port_redis',block)
    else:
        return
    # cursor, conn, count = sql_content.execute("update jl_coin set rpc_last_pos='"+str(block)+"' where coin_symbol='"+str(coin_symbol)+"'")
    # conn.commit()
    
    


base_url = 'http://52.15.93.92:8090/'
import threading

POOL = []
Active_Thread = []


def loadStrategyConfig():
    res = trx.get_BlockNumber(base_url)
    if int(res['code']) == 0:
        now_time = int(time.time())
        if now_time-first_time > 0:
            less = now_time-first_time
            if less < less_time:
                less = less_time
                time.sleep(less)
            return
        else:
            # print(res)
            return
    max_block = res['data']['block_num']
    max_block = int(max_block)
    # 获取当前高度
    now_block = sql_content.fetchone("select rpc_last_pos from jl_coin where coin_symbol='"+str(coin_symbol)+"'")
    
    if now_block and now_block['rpc_last_pos']:
        now_block = now_block['rpc_last_pos']
        now_block = int(now_block)
    # now_block = 41029900
    if now_block >= max_block:
        return
    max_block = int(max_block) - 1
    if now_block >= max_block:
        return
    count =5
    i=0
    for i in range(count):
        block = min(int(max_block), int(now_block)+5)
        task = threading.Thread(target=get_transactions_data, args=(now_block,block,base_url))
        POOL.append(task)
        task.start()
        now_block += 5 
        i+=5
    for thr in POOL:
        thr.join()
    print('判断线程是否结束')
    trx_port = trx_port_redis.get('trx_port_redis')
    print(trx_port)
    cursor, conn, count = sql_content.execute("update jl_coin set rpc_last_pos='"+str(trx_port)+"' where coin_symbol='"+str(coin_symbol)+"'")
if __name__ == '__main__':
    while True:
        try:
            # Active_Thread = [k for k, v in POOL.items() if v.is_alive()]
            loadStrategyConfig()
            time.sleep(1)
        except Exception as e:
            print(e)
            time.sleep(1)