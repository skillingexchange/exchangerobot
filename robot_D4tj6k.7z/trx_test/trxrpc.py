import requests
import json
import time
class trxrpc:
    def __init__(self):
        self.address = "http://3.225.171.164"
        self.address_wallet = "http://3.225.171.164"
        self.port = "8090"
        self.port_wallet = 8090
    #     获取区块详情
    def get_Transactions(self,id):
        # 先获取当前区块高度
        ret = self.get_BlockNumber()
        if ret['code'] == 0:
            return {'code': 0, 'data': 'get_BlockNumber fail'}
        max_block = int(ret['data']['block_num'])
        ret = {}
        if id is None or id == None or id=='':
            print('id is none')
            id = max_block - 2
        else:
            print('id is not none')
            print(id)
            id = int(id)
        if id >= max_block:
            ret['transactions'] = {}
            ret['lastblock'] = id
            return {'code': 1, 'data':ret}
        else:
            max_block = min(max_block, id + 5)
            path = "wallet/getblockbynum"
            transactions = []
            i = id + 1
            while i <= max_block:
                post_data = {'num':i}
                result = json.loads(self.request(path, post_data))
                if 'blockID' in list(result.keys()) and not result['blockID'] is None:
                    # if not result['transactions'] is None:
                    if transactions in list(result.keys()) and not result['transactions'] is None:
                        transaction_list = result['transactions']
                        for value in transaction_list:
                            transactions.append(value)
                else:
                    return {'code': 0,'data':  json.dumps(result, ensure_ascii=False)}
                i += 1
            ret['transactions'] = transactions
            ret['lastblock'] = max_block
            return {'code': 1, 'data': ret}
    # 获取当前区块高度
    def get_BlockNumber(self,url=''):
        path = "wallet/getnowblock"
        post_data = {}
        if url:
            result = json.loads(self.request(path, post_data,url))
        else:
            result = json.loads(self.request(path,post_data))
        ret = {}
        if 'blockID' in result.keys() and 'raw_data' in result['block_header'].keys() and not result['blockID'] is None and not result['block_header']['raw_data']['number'] is None:
            ret['block_num'] = result['block_header']['raw_data']['number']
            return {'code': 1, 'data': ret}
        else:
            return {'code': 0, 'data': json.dumps(result, ensure_ascii=False)}
#     curl请求
    def request(self,path, post_data, url=''):
        if url:
            url = url+path
        else:
            url = self.address+":" + self.port + "/" + path
        params = json.dumps(post_data, ensure_ascii=False)
        res = requests.post(url, params,timeout=30)
        if res.status_code!=200:
            return False
        return res.text