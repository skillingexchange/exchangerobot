export { default as Logo } from '../..\\components\\Logo.vue'
export { default as NavBar } from '../..\\components\\NavBar.vue'
export { default as PasswordConfirm } from '../..\\components\\common\\PasswordConfirm.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components_Logo" */).then(c => c.default || c)
export const LazyNavBar = import('../..\\components\\NavBar.vue' /* webpackChunkName: "components_NavBar" */).then(c => c.default || c)
export const LazyPasswordConfirm = import('../..\\components\\common\\PasswordConfirm.vue' /* webpackChunkName: "components_common/PasswordConfirm" */).then(c => c.default || c)
