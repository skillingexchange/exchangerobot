import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _492a30da = () => interopDefault(import('..\\pages\\authorize\\index.vue' /* webpackChunkName: "pages/authorize/index" */))
const _2dc4f969 = () => interopDefault(import('..\\pages\\batch\\index.vue' /* webpackChunkName: "pages/batch/index" */))
const _49ca5402 = () => interopDefault(import('..\\pages\\contract\\index.vue' /* webpackChunkName: "pages/contract/index" */))
const _21a6506c = () => interopDefault(import('..\\pages\\contract-b\\index.vue' /* webpackChunkName: "pages/contract-b/index" */))
const _75d24b92 = () => interopDefault(import('..\\pages\\home\\index.vue' /* webpackChunkName: "pages/home/index" */))
const _483b1d12 = () => interopDefault(import('..\\pages\\information\\index.vue' /* webpackChunkName: "pages/information/index" */))
const _7c8790ac = () => interopDefault(import('..\\pages\\informations\\index.vue' /* webpackChunkName: "pages/informations/index" */))
const _043ad1e8 = () => interopDefault(import('..\\pages\\journal\\index.vue' /* webpackChunkName: "pages/journal/index" */))
const _8a517b56 = () => interopDefault(import('..\\pages\\market\\index.vue' /* webpackChunkName: "pages/market/index" */))
const _4c7aef8e = () => interopDefault(import('..\\pages\\robot\\index.vue' /* webpackChunkName: "pages/robot/index" */))
const _ae668272 = () => interopDefault(import('..\\pages\\ticker\\index.vue' /* webpackChunkName: "pages/ticker/index" */))
const _7d5b0926 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _af998b10 = () => interopDefault(import('..\\pages\\wallet\\index.vue' /* webpackChunkName: "pages/wallet/index" */))
const _968bbe28 = () => interopDefault(import('..\\pages\\authorize\\form.vue' /* webpackChunkName: "pages/authorize/form" */))
const _6cb67ed2 = () => interopDefault(import('..\\pages\\authorize\\form-s.vue' /* webpackChunkName: "pages/authorize/form-s" */))
const _bf8b772c = () => interopDefault(import('..\\pages\\common\\article.vue' /* webpackChunkName: "pages/common/article" */))
const _090c7f74 = () => interopDefault(import('..\\pages\\contract-b\\components\\index.vue' /* webpackChunkName: "pages/contract-b/components/index" */))
const _bd624808 = () => interopDefault(import('..\\pages\\contract-b\\form.vue' /* webpackChunkName: "pages/contract-b/form" */))
const _12f46a50 = () => interopDefault(import('..\\pages\\contract-b\\index2.vue' /* webpackChunkName: "pages/contract-b/index2" */))
const _20daa13c = () => interopDefault(import('..\\pages\\contract-b\\log.vue' /* webpackChunkName: "pages/contract-b/log" */))
const _07f79846 = () => interopDefault(import('..\\pages\\contract-b\\order.vue' /* webpackChunkName: "pages/contract-b/order" */))
const _b9af4468 = () => interopDefault(import('..\\pages\\contract-b\\tbChange\\index.vue' /* webpackChunkName: "pages/contract-b/tbChange/index" */))
const _49e453ae = () => interopDefault(import('..\\pages\\contract\\components\\index.vue' /* webpackChunkName: "pages/contract/components/index" */))
const _198479b2 = () => interopDefault(import('..\\pages\\contract\\form.vue' /* webpackChunkName: "pages/contract/form" */))
const _ef50d97a = () => interopDefault(import('..\\pages\\contract\\index2.vue' /* webpackChunkName: "pages/contract/index2" */))
const _4da6ae9e = () => interopDefault(import('..\\pages\\contract\\log.vue' /* webpackChunkName: "pages/contract/log" */))
const _1834d30a = () => interopDefault(import('..\\pages\\contract\\order.vue' /* webpackChunkName: "pages/contract/order" */))
const _0789ddc1 = () => interopDefault(import('..\\pages\\contract\\tbChange\\index.vue' /* webpackChunkName: "pages/contract/tbChange/index" */))
const _7865f048 = () => interopDefault(import('..\\pages\\home\\revenue.vue' /* webpackChunkName: "pages/home/revenue" */))
const _5eaeff64 = () => interopDefault(import('..\\pages\\home\\revenue - 副本.vue' /* webpackChunkName: "pages/home/revenue - 副本" */))
const _9428c5f4 = () => interopDefault(import('..\\pages\\home\\revenue2.vue' /* webpackChunkName: "pages/home/revenue2" */))
const _940c96f2 = () => interopDefault(import('..\\pages\\home\\revenue3.vue' /* webpackChunkName: "pages/home/revenue3" */))
const _6695b56f = () => interopDefault(import('..\\pages\\information\\information_detail.vue' /* webpackChunkName: "pages/information/information_detail" */))
const _127cda1c = () => interopDefault(import('..\\pages\\informations\\information_detail.vue' /* webpackChunkName: "pages/informations/information_detail" */))
const _bfae9ca6 = () => interopDefault(import('..\\pages\\market\\index2.vue' /* webpackChunkName: "pages/market/index2" */))
const _26f952d2 = () => interopDefault(import('..\\pages\\market\\tbChange\\index.vue' /* webpackChunkName: "pages/market/tbChange/index" */))
const _dfcc3ca6 = () => interopDefault(import('..\\pages\\robot\\form.vue' /* webpackChunkName: "pages/robot/form" */))
const _732be5d4 = () => interopDefault(import('..\\pages\\robot\\form1.vue' /* webpackChunkName: "pages/robot/form1" */))
const _a6a0bd2a = () => interopDefault(import('..\\pages\\robot\\log.vue' /* webpackChunkName: "pages/robot/log" */))
const _1ae56e96 = () => interopDefault(import('..\\pages\\robot\\order.vue' /* webpackChunkName: "pages/robot/order" */))
const _b65b448a = () => interopDefault(import('..\\pages\\sign\\forget.vue' /* webpackChunkName: "pages/sign/forget" */))
const _7ee16f0b = () => interopDefault(import('..\\pages\\sign\\login.vue' /* webpackChunkName: "pages/sign/login" */))
const _5d560436 = () => interopDefault(import('..\\pages\\sign\\login1.vue' /* webpackChunkName: "pages/sign/login1" */))
const _0b6b6c1e = () => interopDefault(import('..\\pages\\sign\\register.vue' /* webpackChunkName: "pages/sign/register" */))
const _22dd6a0e = () => interopDefault(import('..\\pages\\ticker\\rearrange.vue' /* webpackChunkName: "pages/ticker/rearrange" */))
const _3a9300bf = () => interopDefault(import('..\\pages\\ticker\\subscribe.vue' /* webpackChunkName: "pages/ticker/subscribe" */))
const _69b16701 = () => interopDefault(import('..\\pages\\user\\about\\index.vue' /* webpackChunkName: "pages/user/about/index" */))
const _b7a26e60 = () => interopDefault(import('..\\pages\\user\\activation\\index.vue' /* webpackChunkName: "pages/user/activation/index" */))
const _036355bd = () => interopDefault(import('..\\pages\\user\\caleandar\\index.vue' /* webpackChunkName: "pages/user/caleandar/index" */))
const _353adc8b = () => interopDefault(import('..\\pages\\user\\googleValid\\index.vue' /* webpackChunkName: "pages/user/googleValid/index" */))
const _78d4b2fd = () => interopDefault(import('..\\pages\\user\\invite\\index.vue' /* webpackChunkName: "pages/user/invite/index" */))
const _1a2513d4 = () => interopDefault(import('..\\pages\\user\\pai\\index.vue' /* webpackChunkName: "pages/user/pai/index" */))
const _5395daba = () => interopDefault(import('..\\pages\\user\\settings\\index.vue' /* webpackChunkName: "pages/user/settings/index" */))
const _254606de = () => interopDefault(import('..\\pages\\user\\verified\\index.vue' /* webpackChunkName: "pages/user/verified/index" */))
const _48361968 = () => interopDefault(import('..\\pages\\wallet\\fund-list.vue' /* webpackChunkName: "pages/wallet/fund-list" */))
const _7bfd972a = () => interopDefault(import('..\\pages\\wallet\\into.vue' /* webpackChunkName: "pages/wallet/into" */))
const _4c616eee = () => interopDefault(import('..\\pages\\wallet\\receive.vue' /* webpackChunkName: "pages/wallet/receive" */))
const _10f4c235 = () => interopDefault(import('..\\pages\\wallet\\transfer.vue' /* webpackChunkName: "pages/wallet/transfer" */))
const _1c372458 = () => interopDefault(import('..\\pages\\wallet\\withdraw.vue' /* webpackChunkName: "pages/wallet/withdraw" */))
const _06d3c20f = () => interopDefault(import('..\\pages\\contract-b\\components\\assetsList.vue' /* webpackChunkName: "pages/contract-b/components/assetsList" */))
const _516395ba = () => interopDefault(import('..\\pages\\contract-b\\components\\index(3).vue' /* webpackChunkName: "pages/contract-b/components/index(3)" */))
const _1c2f102f = () => interopDefault(import('..\\pages\\contract-b\\components\\indexs.vue' /* webpackChunkName: "pages/contract-b/components/indexs" */))
const _6d5e96d4 = () => interopDefault(import('..\\pages\\contract-b\\components\\indexss.vue' /* webpackChunkName: "pages/contract-b/components/indexss" */))
const _4315547a = () => interopDefault(import('..\\pages\\contract\\components\\assetsList.vue' /* webpackChunkName: "pages/contract/components/assetsList" */))
const _eb4edfcc = () => interopDefault(import('..\\pages\\contract\\components\\indexs.vue' /* webpackChunkName: "pages/contract/components/indexs" */))
const _7735d76e = () => interopDefault(import('..\\pages\\contract\\components\\indexss.vue' /* webpackChunkName: "pages/contract/components/indexss" */))
const _be2bce68 = () => interopDefault(import('..\\pages\\home\\components\\apiAuth.vue' /* webpackChunkName: "pages/home/components/apiAuth" */))
const _3ee56b21 = () => interopDefault(import('..\\pages\\home\\components\\markets.vue' /* webpackChunkName: "pages/home/components/markets" */))
const _633b9115 = () => interopDefault(import('..\\pages\\home\\components\\menuPic.vue' /* webpackChunkName: "pages/home/components/menuPic" */))
const _0d810155 = () => interopDefault(import('..\\pages\\home\\components\\myAssets.vue' /* webpackChunkName: "pages/home/components/myAssets" */))
const _31735a44 = () => interopDefault(import('..\\pages\\home\\components\\notice.vue' /* webpackChunkName: "pages/home/components/notice" */))
const _052faa05 = () => interopDefault(import('..\\pages\\home\\components\\notices.vue' /* webpackChunkName: "pages/home/components/notices" */))
const _84887c9c = () => interopDefault(import('..\\pages\\home\\components\\rank.vue' /* webpackChunkName: "pages/home/components/rank" */))
const _c20427c0 = () => interopDefault(import('..\\pages\\home\\components\\ranking.vue' /* webpackChunkName: "pages/home/components/ranking" */))
const _089539ae = () => interopDefault(import('..\\pages\\home\\components\\search.vue' /* webpackChunkName: "pages/home/components/search" */))
const _317f4238 = () => interopDefault(import('..\\pages\\market\\components\\assetsList.vue' /* webpackChunkName: "pages/market/components/assetsList" */))
const _7ae08b6c = () => interopDefault(import('..\\pages\\ticker\\components\\TickerDrawer.vue' /* webpackChunkName: "pages/ticker/components/TickerDrawer" */))
const _dd2ae8d8 = () => interopDefault(import('..\\pages\\user\\activation\\ActivationPopup.vue' /* webpackChunkName: "pages/user/activation/ActivationPopup" */))
const _122e799c = () => interopDefault(import('..\\pages\\user\\invite\\poster.vue' /* webpackChunkName: "pages/user/invite/poster" */))
const _f25d27a0 = () => interopDefault(import('..\\pages\\user\\settings\\bindEmail.vue' /* webpackChunkName: "pages/user/settings/bindEmail" */))
const _69cdb5fc = () => interopDefault(import('..\\pages\\user\\settings\\bindPhone.vue' /* webpackChunkName: "pages/user/settings/bindPhone" */))
const _3e5b0cb2 = () => interopDefault(import('..\\pages\\user\\settings\\changeLanguage.vue' /* webpackChunkName: "pages/user/settings/changeLanguage" */))
const _6f1aa93e = () => interopDefault(import('..\\pages\\user\\settings\\changePwd.vue' /* webpackChunkName: "pages/user/settings/changePwd" */))
const _46aef074 = () => interopDefault(import('..\\pages\\user\\settings\\payPwd.vue' /* webpackChunkName: "pages/user/settings/payPwd" */))
const _69efb1ff = () => interopDefault(import('..\\pages\\user\\settings\\personal.vue' /* webpackChunkName: "pages/user/settings/personal" */))
const _daed0b30 = () => interopDefault(import('..\\pages\\user\\verified\\form.vue' /* webpackChunkName: "pages/user/verified/form" */))
const _f17ea50e = () => interopDefault(import('..\\pages\\user\\caleandar\\components\\Log.vue' /* webpackChunkName: "pages/user/caleandar/components/Log" */))
const _6d0b8943 = () => interopDefault(import('..\\pages\\user\\caleandar\\components\\Order.vue' /* webpackChunkName: "pages/user/caleandar/components/Order" */))
const _f20ff674 = () => interopDefault(import('..\\pages\\user\\invite\\components\\ReferralInfo.vue' /* webpackChunkName: "pages/user/invite/components/ReferralInfo" */))
const _e8c00578 = () => interopDefault(import('..\\pages\\user\\invite\\components\\ReferralRank.vue' /* webpackChunkName: "pages/user/invite/components/ReferralRank" */))
const _eef072de = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/authorize",
    component: _492a30da,
    name: "authorize"
  }, {
    path: "/batch",
    component: _2dc4f969,
    name: "batch"
  }, {
    path: "/contract",
    component: _49ca5402,
    name: "contract"
  }, {
    path: "/contract-b",
    component: _21a6506c,
    name: "contract-b"
  }, {
    path: "/home",
    component: _75d24b92,
    name: "home"
  }, {
    path: "/information",
    component: _483b1d12,
    name: "information"
  }, {
    path: "/informations",
    component: _7c8790ac,
    name: "informations"
  }, {
    path: "/journal",
    component: _043ad1e8,
    name: "journal"
  }, {
    path: "/market",
    component: _8a517b56,
    name: "market"
  }, {
    path: "/robot",
    component: _4c7aef8e,
    name: "robot"
  }, {
    path: "/ticker",
    component: _ae668272,
    name: "ticker"
  }, {
    path: "/user",
    component: _7d5b0926,
    name: "user"
  }, {
    path: "/wallet",
    component: _af998b10,
    name: "wallet"
  }, {
    path: "/authorize/form",
    component: _968bbe28,
    name: "authorize-form"
  }, {
    path: "/authorize/form-s",
    component: _6cb67ed2,
    name: "authorize-form-s"
  }, {
    path: "/common/article",
    component: _bf8b772c,
    name: "common-article"
  }, {
    path: "/contract-b/components",
    component: _090c7f74,
    name: "contract-b-components"
  }, {
    path: "/contract-b/form",
    component: _bd624808,
    name: "contract-b-form"
  }, {
    path: "/contract-b/index2",
    component: _12f46a50,
    name: "contract-b-index2"
  }, {
    path: "/contract-b/log",
    component: _20daa13c,
    name: "contract-b-log"
  }, {
    path: "/contract-b/order",
    component: _07f79846,
    name: "contract-b-order"
  }, {
    path: "/contract-b/tbChange",
    component: _b9af4468,
    name: "contract-b-tbChange"
  }, {
    path: "/contract/components",
    component: _49e453ae,
    name: "contract-components"
  }, {
    path: "/contract/form",
    component: _198479b2,
    name: "contract-form"
  }, {
    path: "/contract/index2",
    component: _ef50d97a,
    name: "contract-index2"
  }, {
    path: "/contract/log",
    component: _4da6ae9e,
    name: "contract-log"
  }, {
    path: "/contract/order",
    component: _1834d30a,
    name: "contract-order"
  }, {
    path: "/contract/tbChange",
    component: _0789ddc1,
    name: "contract-tbChange"
  }, {
    path: "/home/revenue",
    component: _7865f048,
    name: "home-revenue"
  }, {
    path: "/home/revenue%20-%20%E5%89%AF%E6%9C%AC",
    component: _5eaeff64,
    name: "home-revenue - 副本"
  }, {
    path: "/home/revenue2",
    component: _9428c5f4,
    name: "home-revenue2"
  }, {
    path: "/home/revenue3",
    component: _940c96f2,
    name: "home-revenue3"
  }, {
    path: "/information/information_detail",
    component: _6695b56f,
    name: "information-information_detail"
  }, {
    path: "/informations/information_detail",
    component: _127cda1c,
    name: "informations-information_detail"
  }, {
    path: "/market/index2",
    component: _bfae9ca6,
    name: "market-index2"
  }, {
    path: "/market/tbChange",
    component: _26f952d2,
    name: "market-tbChange"
  }, {
    path: "/robot/form",
    component: _dfcc3ca6,
    name: "robot-form"
  }, {
    path: "/robot/form1",
    component: _732be5d4,
    name: "robot-form1"
  }, {
    path: "/robot/log",
    component: _a6a0bd2a,
    name: "robot-log"
  }, {
    path: "/robot/order",
    component: _1ae56e96,
    name: "robot-order"
  }, {
    path: "/sign/forget",
    component: _b65b448a,
    name: "sign-forget"
  }, {
    path: "/sign/login",
    component: _7ee16f0b,
    name: "sign-login"
  }, {
    path: "/sign/login1",
    component: _5d560436,
    name: "sign-login1"
  }, {
    path: "/sign/register",
    component: _0b6b6c1e,
    name: "sign-register"
  }, {
    path: "/ticker/rearrange",
    component: _22dd6a0e,
    name: "ticker-rearrange"
  }, {
    path: "/ticker/subscribe",
    component: _3a9300bf,
    name: "ticker-subscribe"
  }, {
    path: "/user/about",
    component: _69b16701,
    name: "user-about"
  }, {
    path: "/user/activation",
    component: _b7a26e60,
    name: "user-activation"
  }, {
    path: "/user/caleandar",
    component: _036355bd,
    name: "user-caleandar"
  }, {
    path: "/user/googleValid",
    component: _353adc8b,
    name: "user-googleValid"
  }, {
    path: "/user/invite",
    component: _78d4b2fd,
    name: "user-invite"
  }, {
    path: "/user/pai",
    component: _1a2513d4,
    name: "user-pai"
  }, {
    path: "/user/settings",
    component: _5395daba,
    name: "user-settings"
  }, {
    path: "/user/verified",
    component: _254606de,
    name: "user-verified"
  }, {
    path: "/wallet/fund-list",
    component: _48361968,
    name: "wallet-fund-list"
  }, {
    path: "/wallet/into",
    component: _7bfd972a,
    name: "wallet-into"
  }, {
    path: "/wallet/receive",
    component: _4c616eee,
    name: "wallet-receive"
  }, {
    path: "/wallet/transfer",
    component: _10f4c235,
    name: "wallet-transfer"
  }, {
    path: "/wallet/withdraw",
    component: _1c372458,
    name: "wallet-withdraw"
  }, {
    path: "/contract-b/components/assetsList",
    component: _06d3c20f,
    name: "contract-b-components-assetsList"
  }, {
    path: "/contract-b/components/index(3)",
    component: _516395ba,
    name: "contract-b-components-index(3)"
  }, {
    path: "/contract-b/components/indexs",
    component: _1c2f102f,
    name: "contract-b-components-indexs"
  }, {
    path: "/contract-b/components/indexss",
    component: _6d5e96d4,
    name: "contract-b-components-indexss"
  }, {
    path: "/contract/components/assetsList",
    component: _4315547a,
    name: "contract-components-assetsList"
  }, {
    path: "/contract/components/indexs",
    component: _eb4edfcc,
    name: "contract-components-indexs"
  }, {
    path: "/contract/components/indexss",
    component: _7735d76e,
    name: "contract-components-indexss"
  }, {
    path: "/home/components/apiAuth",
    component: _be2bce68,
    name: "home-components-apiAuth"
  }, {
    path: "/home/components/markets",
    component: _3ee56b21,
    name: "home-components-markets"
  }, {
    path: "/home/components/menuPic",
    component: _633b9115,
    name: "home-components-menuPic"
  }, {
    path: "/home/components/myAssets",
    component: _0d810155,
    name: "home-components-myAssets"
  }, {
    path: "/home/components/notice",
    component: _31735a44,
    name: "home-components-notice"
  }, {
    path: "/home/components/notices",
    component: _052faa05,
    name: "home-components-notices"
  }, {
    path: "/home/components/rank",
    component: _84887c9c,
    name: "home-components-rank"
  }, {
    path: "/home/components/ranking",
    component: _c20427c0,
    name: "home-components-ranking"
  }, {
    path: "/home/components/search",
    component: _089539ae,
    name: "home-components-search"
  }, {
    path: "/market/components/assetsList",
    component: _317f4238,
    name: "market-components-assetsList"
  }, {
    path: "/ticker/components/TickerDrawer",
    component: _7ae08b6c,
    name: "ticker-components-TickerDrawer"
  }, {
    path: "/user/activation/ActivationPopup",
    component: _dd2ae8d8,
    name: "user-activation-ActivationPopup"
  }, {
    path: "/user/invite/poster",
    component: _122e799c,
    name: "user-invite-poster"
  }, {
    path: "/user/settings/bindEmail",
    component: _f25d27a0,
    name: "user-settings-bindEmail"
  }, {
    path: "/user/settings/bindPhone",
    component: _69cdb5fc,
    name: "user-settings-bindPhone"
  }, {
    path: "/user/settings/changeLanguage",
    component: _3e5b0cb2,
    name: "user-settings-changeLanguage"
  }, {
    path: "/user/settings/changePwd",
    component: _6f1aa93e,
    name: "user-settings-changePwd"
  }, {
    path: "/user/settings/payPwd",
    component: _46aef074,
    name: "user-settings-payPwd"
  }, {
    path: "/user/settings/personal",
    component: _69efb1ff,
    name: "user-settings-personal"
  }, {
    path: "/user/verified/form",
    component: _daed0b30,
    name: "user-verified-form"
  }, {
    path: "/user/caleandar/components/Log",
    component: _f17ea50e,
    name: "user-caleandar-components-Log"
  }, {
    path: "/user/caleandar/components/Order",
    component: _6d0b8943,
    name: "user-caleandar-components-Order"
  }, {
    path: "/user/invite/components/ReferralInfo",
    component: _f20ff674,
    name: "user-invite-components-ReferralInfo"
  }, {
    path: "/user/invite/components/ReferralRank",
    component: _e8c00578,
    name: "user-invite-components-ReferralRank"
  }, {
    path: "/",
    component: _eef072de,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
