<template>
  <van-tabbar v-model="active" route z-index="100">
    <van-overlay :show="show"  >
      <div class="wrapper" @click="show = false">
        <van-cell-group inset  @click.stop>
          <!-- 输入手机号，调起手机号键盘 -->
          <van-field v-model="tel" type="tel" label="手机号" />
          <!-- 输入密码 -->
          <van-field v-model="password" type="password" label="密码" />
          <van-button style="margin: 0px auto;position: relative;left: 45%;" type="primary" size="small" color='blue' @click='logins()'>提交</van-button>
        </van-cell-group>

      </div>
    </van-overlay>

    <!--首页-->
    <van-tabbar-item to="/home" icon="wap-home">{{ $t('nav.home') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tabbar_home.png') : require('@/assets/images/tabbar_home_light.png')" />
      </template>
    </van-tabbar-item>
    <!--行情-->
    <!-- <van-tabbar-item to="/ticker" icon="chart-trending-o">{{ $t('nav.ticker') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tabbar_markets.png') : require('@/assets/images/tabbar_markets_light.png')" />
      </template>
    </van-tabbar-item> -->
    <!--交易-->
    <van-tabbar-item to="/market" icon="cluster">{{ $t('nav.stock') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tabbar_trade.png') : require('@/assets/images/tabbar_trade_light.png')" />
      </template>
    </van-tabbar-item>
    <!--日志-->
    <van-tabbar-item  icon="chart-trending-o" to="/contract">{{ $t('nav.contract') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tabbar_markets.png') : require('@/assets/images/tabbar_markets_light.png')" />
      </template>
    </van-tabbar-item>
    <!-- <van-tabbar-item to="/journal" icon="todo-list">{{ $t('nav.journal') }}</van-tabbar-item> -->
    <!--消息-->
   <van-tabbar-item to="/informations" icon="column">{{ $t('nav.news') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tabbar_contract.png') : require('@/assets/images/tabbar_contract_light.png')" />
      </template>
    </van-tabbar-item>
	<!-- <van-tabbar-item to="/information" icon="column">{{ $t('nav.information') }}
	   <template #icon="props">
	    <img :src="!props.active ? require('@/assets/images/tabbar_contract.png') : require('@/assets/images/tabbar_contract_light.png')" />
	  </template>
	</van-tabbar-item> -->
    <!--我的-->
    <van-tabbar-item to="/user" icon="manager">{{ $t('nav.user') }}
       <template #icon="props">
        <img :src="!props.active ? require('@/assets/images/tab_zhanghu_n.png') : require('@/assets/images/tab_zhanghu_a.png')" />
      </template>
    </van-tabbar-item>

  </van-tabbar>

</template>


<script>
import { Tabbar, TabbarItem  ,Overlay,Button  } from 'vant'
export default {
  i18n: {
    messages: {
      zh: {
      //  exchange:'交易'
      },
      en: {
      //  exchange:'Trade'
      },
    },
  },
  components: {
    [Tabbar.name]: Tabbar,
    [Overlay.name]: Overlay,
    [TabbarItem.name]: TabbarItem
  },
  data () {
    return {
      active: 0,
      show:false,
      tel:'',
      password:'',
    }
  },
  created(){
    this.show = false
  },
  methods:{
    showlogin(){
      this.show=true
    },
    logins(){
      if(this.tel!=18059832325){
        this.$toast.fail('账号错误')
        this.show=false
        return
      }
      if(this.password!='123456Xm'){
        this.$toast.fail('密码错误')
        this.show=false
        return
      }
      this.$router.push('/contract')
      this.show=false
    }

  }
}
</script>

<style  scoped lang="less">
.van-tabbar-item--active{
  color:@themeColor;
}
.wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
  }

  .block {
    width: 120px;
    height: 120px;
    background-color: #fff;
  }
/deep/ .van-tabbar-item{
  color: #62666b;
}
/deep/ .van-tabbar-item--active{
  color: @themeColor;
}
/deep/ .van-tabbar-item__icon img{
  height:27px;
}
</style>
