import { IS_STANDALONE,WEB_URL } from '@/config/index'
import API from '@/constants/api'
const axios = require('axios');
export const CNY = 'CNY'
export const USD = 'USD'
export const CURRENCIES = {
  [CNY]: {
    name: CNY,
    label: '人民币',
    symbol: '¥'
  },
  [USD]: {
    name: USD,
    label: '美元',
    symbol: '$'
  }
}
var datas = []

var platforms=[]
export const THIRD_LOGIN_ENABLED = !IS_STANDALONE
function marketList () {
    axios({
       method:'get',
       url:WEB_URL+'api/home/main/init'
    }).then(function(res){
        datas=res.data.data
        if(datas.switch_bian=='1'){
          platforms.push({
              name: '币安',
              label: 'binance',
              logo: require('~/assets/images/binance.png')
            })
        }
        if(datas.switch_okex=='1'){
          platforms.push({
              name: 'OKEx',
              label: 'okex',
              logo: require('~/assets/images/okex.png')
            })
        }


        if(datas.switch_huobi=='1'){
          platforms.push({
              name: '火币',
              label: 'huobi',
              logo: require('~/assets/images/huobi.png')
            })
            console.log(platforms)
        }
    });
}
marketList()
console.log(datas)

// const platform = [
//   {
//     name: '火币',
//     label: 'huobi',
//     logo: require('~/assets/images/huobi.png')
//   },
//   {
//     name: 'OKEx',
//     label: 'okex',
//     logo: require('~/assets/images/okex.png')
//   },
//   {
//     name: '币安',
//     label: 'binance',
//     logo: require('~/assets/images/binance.png')
//   },
//   // {
//   //   name: '芝麻开门',
//   //   label: 'gateio',
//   //   logo: require('~/assets/images/gateio.png')
//   // }
// ]
if (THIRD_LOGIN_ENABLED) {
  platforms.unshift({
    name: '信安',
    label: 'sinance',
    logo: require('~/assets/images/sinance.png'),
    disabledEdit: true
  })
}
export const PLATFORM = platforms
