export const SET_TRANSITION_NAME = 'SET_TRANSITION_NAME'

export const SET_LANG = 'SET_LANG'

// 资产
export const SET_FUND_DATA = 'SET_FUND_DATA'
