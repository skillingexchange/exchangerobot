<template>
  <div :class="appTheme">
    <transition :name="transitionName">
      <Nuxt />
    </transition>
  </div>
</template>
 
<script>
import { mapState, mapActions } from 'vuex'
export default {
  head(){
    return{
      title:this.appName[this.$i18n.locale]
    }
  },
  name: 'Default',
  transition: 'page',
  computed: {
    ...mapState({
      transitionName: ({ transitionName }) => transitionName,
      appName: (index) => index.appName,
       appTheme: (index) => index.appTheme
    })
  },
  mounted(){
    this.getAppName()
  },
  methods:{
    ...mapActions({
      getAppName: 'getAppName',
    }),
  }
}
</script>
