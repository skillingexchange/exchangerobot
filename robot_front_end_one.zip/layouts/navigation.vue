<template>
  <div :class="appTheme">
      <div class="page" >
        <transition :name="transitionName">
          <Nuxt />
        </transition>
        <nav-bar />
      </div>
  </div>
  
</template>

<script>
import { mapState } from 'vuex'
import NavBar from '@/components/NavBar'
export default {
  head(){
    return{
      title:this.appName[this.$i18n.locale]
    }
  },
  name: 'Navigation',
  transition: 'page',
  components: { NavBar },
  computed: {
    ...mapState({
      transitionName: ({ transitionName }) => transitionName,
       appName: (index) => index.appName,
       appTheme: (index) => index.appTheme
    })
  }
}
</script>

<style lang="less" scoped>
.page {
  padding-bottom: 60px;
  box-sizing: border-box;
}


</style>
