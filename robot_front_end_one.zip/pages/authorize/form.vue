<template>
  <div class="page page_auth_form">
    <van-nav-bar
      :title="$t(platforms[active].label)"
      left-arrow
      right-text="绑定教程"
      @click-left="$router.back()"
      @click-right="$router.push({ path: '/information/information_detail?id='+ active +'&nid=1' })"
    />
    <van-form @submit="onSubmit">
      <van-field
        v-model="api_key"
        label="Api Key"
        placeholder="Api Key"
        allowEdit='false'
        :rules="[{ required: true }]"
      />
      <van-field
        v-model="secret_key"
        label="Secret Key"
        placeholder="Secret Key"
        allowEdit='false'
        :rules="[{ required: true }]"
      />
      <van-field
        v-if="platform === 'okex'"
        v-model="passphrase"
        label="密码"
        placeholder="请填写API Key密码"
        allowEdit='false'
        :rules="[{ required: true }]"
      />
      <div style="margin: 16px">
        <van-button
          round
          block
          type="info"
          native-type="submit"
        >
          {{ $t('actions.import') }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data () {
    return {
      api_key: '',
      secret_key: '',
      passphrase: ''
    }
  },
  computed: {
    ...mapState({
      platforms: ({ authorize }) => authorize.platform
    }),
    active () {
      return this.$route.query.active
    },
    platform () {
      const p = this.platforms[this.active]
      this.api_key = p.api_key
      this.secret_key = p.secret_key
      this.passphrase = p.passphrase
      return p.label
    }
  },
  methods: {
    ...mapActions({
      editApiAccount: 'authorize/editApiAccount'
    }),
    onSubmit () {
      const payload = {
        platform: this.platform,
        api_key: this.api_key.replace(/ /g,''),
        secret_key: this.secret_key.replace(/ /g,''),
        passphrase: this.platform === 'okex' ? this.passphrase : '-'
      }
      this.$toast.loading()
      this.editApiAccount(payload).then((res) => {
        this.$toast(res.msg)
        this.$router.back()
      }).catch(({ msg }) => {
        this.$toast(msg)
      })
    },
    onClickRight(){
      console.log(2233);
    }
  }
}
</script>

<style scoped lang="less">
.van-cell {
  display: block;
}
</style>
