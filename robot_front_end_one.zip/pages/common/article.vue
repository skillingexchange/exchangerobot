<template>
  <div>
    <van-nav-bar
      :title="$t('title')"
      left-arrow
      @click-left="$router.back()"
    />
    <van-cell-group>
       <div class="center" v-html="about.data">

       </div>
    </van-cell-group>
  
  </div>
</template>

<script>
import { Dialog } from 'vant'
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '用户协议',

      },
      
    }
  },
  data() {
    return {
      about:"",
     
    };
  },
  computed: {
  
  },
  methods: {
    // 用户协议
    getLists() {
      var that = this;
      this.$axios 
        .post("api/user/articles/getUserAgreement")
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data);
            that.about = ret.data.data;
          } else {
            that.$toast.fail(ret.data.msg);
          }
        });
    }
  },  
   mounted() {
    this.getLists();
  },
}
</script>

<style scoped lang="less">
.center {
  font-size: 14px;
  color: #333;
  line-height: 24px;
  width: 94%;
  margin: 0 auto;
  padding: 15px 0;
}
</style>
