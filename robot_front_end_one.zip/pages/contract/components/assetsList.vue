<template>
  <div style="position: relative">
    <van-pull-refresh v-model="isLoading" @refresh="onLoad" class="bei">
      <van-list :finished="finished">
        <!-- <div class="add_api flex" v-if="showBindTip" @click="toBindApi(curName)">
          <p  >{{coinType}} API {{$t('bind')}}</p>
          <p class="add_api_text">去绑定<van-icon style="vertical-align: middle" name="arrow" /></p>
        </div> -->
        <van-empty v-if="market.length === 0 && finished" :description="$t('empty.default')" />
        <template v-else>
          <van-cell v-for="item in market" :key="item.id" >
            <div class="asset-item">
              <div v-if="findRobot(item.id)" @click="goDetail(item)">
                <img
                  :src="item.img_url"
                  alt=""
                  style="width: 3rem; height: 3rem; margin-right: 1rem"
                />
              </div>
              <div v-else @click="addRobot(item)">
                <img
                  :src="item.img_url"
                  alt=""
                  style="width: 3rem; height: 3rem; margin-right: 1rem"
                />
              </div>
              <!-- <van-checkbox @click.stop v-if="findRobot(item.id)" v-model="checked" > </van-checkbox> -->
              <div class="center" v-if="findRobot(item.id)" @click="goDetail(item)" >
                <div class="name">
                  {{ item.market_name }}
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).recycle_status == 1"
                    round
                    type="primary"
                  >
                    循环策略
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).recycle_status == 0"
                    round
                    type="primary"
                  >
                    单次策略
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 0"
                    type="danger"
                  >
                   开空
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 1"

                    type="success"
                  >
                    开多
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 2"

                    type="primary"
                  >
                    多空
                  </van-tag>
                </div>
                <div v-if="findRobot(item.id)" class="info">
                  <p class="lef">
                    <!--   max_order_count-->
                    持仓数量：{{
                      Number(findRobot(item.id).deal_amount ? findRobot(item.id).deal_amount : '')
                        | numberFormat(2)
                    }}
                  </p>
                  <p>
                    {{ $t('expected_return') }}收益：{{
                      Number(findRobot(item.id).revenue) | numberFormat(2)
                    }}
                  </p>

                  <!--  -->
                  <!-- <p
                  v-if="findRobot(item.id).show_msg"
                  class="van-ellipsis"
                >
                  {{ $t('latest_news') }}：{{ findRobot(item.id).show_msg }}
                </p> -->
                </div>
                <div v-if="findRobot(item.id)" class="info">
                  <p class="lef">
                    <!--   max_order_count-->
                    {{ $t('jinri') }}：{{
                      Number(findRobot(item.id).today_revenue) | numberFormat(2)
                    }}
                  </p>
                  <p>
                    {{ $t('zong') }}：{{
                      Number(findRobot(item.id).all_revenue) | numberFormat(2)
                    }}
                  </p>

                  <!--  -->
                  <!-- <p
                  v-if="findRobot(item.id).show_msg"
                  class="van-ellipsis"
                >
                  {{ $t('latest_news') }}：{{ findRobot(item.id).show_msg }}
                </p> -->
                </div>
              </div>
              <div class="center" v-else @click="addRobot(item)" >
                <div class="name">
                  {{ item.market_name }}
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).recycle_status == 1"
                    round
                    type="primary"
                  >
                    循环策略
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).recycle_status == 0"
                    round
                    type="primary"
                  >
                    单次策略
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 0"
                    type="danger"
                  >
                   开空
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 1"

                    type="success"
                  >
                    开多
                  </van-tag>
                  <van-tag
                    v-if="findRobot(item.id) && findRobot(item.id).direction == 2"

                    type="primary"
                  >
                    多空
                  </van-tag>
                </div>
                <div v-if="findRobot(item.id)" class="info">
                  <p class="lef">
                    <!--   max_order_count-->
                    持仓数量：{{
                      Number(findRobot(item.id).deal_amount ? findRobot(item.id).deal_amount : '')
                        | numberFormat(2)
                    }}
                  </p>
                  <p>
                    {{ $t('expected_return') }}收益：{{
                      Number(findRobot(item.id).revenue) | numberFormat(2)
                    }}
                  </p>

                  <!--  -->
                  <!-- <p
                  v-if="findRobot(item.id).show_msg"
                  class="van-ellipsis"
                >
                  {{ $t('latest_news') }}：{{ findRobot(item.id).show_msg }}
                </p> -->
                </div>
                <div v-if="findRobot(item.id)" class="info">
                  <p class="lef">
                    <!--   max_order_count-->
                    {{ $t('jinri') }}：{{
                      Number(findRobot(item.id).today_revenue) | numberFormat(2)
                    }}
                  </p>
                  <p>
                    {{ $t('zong') }}：{{
                      Number(findRobot(item.id).all_revenue) | numberFormat(2)
                    }}
                  </p>

                  <!--  -->
                  <!-- <p
                  v-if="findRobot(item.id).show_msg"
                  class="van-ellipsis"
                >
                  {{ $t('latest_news') }}：{{ findRobot(item.id).show_msg }}
                </p> -->
                </div>
              </div>
              <div class="right">
                <template v-if="findRobot(item.id)" >
                  <span @click="goDetail(item)" v-if="findRobot(item.id) && findRobot(item.id).status === 0">{{
                    $t('status.disabled')
                  }}</span>
                  <!-- <van-icon name="arrow" /> -->
                  <span @click="goDetail(item)" :class="parseFloat(findRobot(item.id).lilv) >= 0 ? 'zheng' : 'fushu'">
                  {{parseFloat(findRobot(item.id).lilv) > 0?'+':''}}
                  {{
                    findRobot(item.id).lilv
                  }}%
                  </span>
                  <div @click="goDetail(item)" class="set_number">{{$t('cover')}}：<span class="color_blue">{{getordercount(item)}}{{$t('coverNum')}}</span></div>
                </template>
                <!-- <van-button v-else size="small" style="border: none" @click="addRobot(item)">
                  <span style="display: inline-block; vertical-align: middle">{{
                    $t('add_robot')
                  }}</span>
                  <van-icon style="vertical-align: middle" name="plus" />
                </van-button> -->
                <template v-else >
                  <span style="margin-left: auto" @click="addRobot(item)">{{ $t('status.disabled') }}</span>
                  <!-- <van-icon name="arrow" /> -->
                  <span class="zheng" @click="addRobot(item)"> 0.00% </span>
                </template>
              </div>
            </div>
          </van-cell>
        </template>
      </van-list>
    </van-pull-refresh>
    <div class="yue flex " style="margin-top: 20px;">
      <p class="flex_1">
        <span>{{ $t('sheng') }} :{{  Number(yu || 0)  | numberFormat(2)}} </span>
        <span v-if="showBindTip"> {{coinType}} API {{$t('bind')}}</span>
      </p>
      <p class="flex " v-if="showBindTip"  @click="toBindApi(curName)">
        <span >{{$t('tobind')}}<van-icon style="vertical-align: middle" name="arrow" /></span>
      </p>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        sheng: '账户余额USDT',
        jinri:'今日收益',
        zong:'总收益',
         bind:'未绑定',
         tobind:'去绑定',
         cover:'加仓',
         coverNum:'次'
      },
      en: {
        sheng: 'Balance(USDT)',
        jinri:`Today's revenue`,
        zong:'Total revenue',
        bind:'not bind ',
        tobind:'Bind API',
        cover:'Overweight',
        coverNum:''
      },
    },
  },
  props: {
    platform: {
      type: String,
      required: true,
    },
    platforms: {
      type: Array,
      required: [],
    },
    keyword: {
      type: String,
      required: true,
    },
    actives: {
      type: [String,Number],
      required: true,
    },
  },
  data() {
    return {
      finished: false,
      isLoading: false,
      yue: '',
      show: false,
      yu: '',
      is_load:false,
      clearTimeSet:null,
      showBindTip:false
    }
  },

  mounted(){
    this.onLoad();
    this.setTime();
    this.getLists()
    // console.log(this.is_load);
    /* if(this.is_load===false){
      // console.log('is load');
      this.onLoad();
      this.is_load = true;
    }
    this.$nextTick(()=>{
      setInterval(this.onLoad,5000);
    }); */
  },
  filters:{

  },
  watch:{
    //监听选项卡选择，取消非选中选项的定时请求
    actives(val,oval){
      if(this.platforms[val].label == this.platform){
        this.onLoad()
        this.setTime();
        this.getLists()
      }else{
        this.clearTime()
      }
    }
  },
  computed: {
    ...mapState({
      robotData: ({ robot }) => robot.robotLists,
      timer: ({ robot }) => robot.timer,
    }),
    ...mapGetters({
      markets: 'robot/marketss',
    }),
     coinType() {
      let type = ''
      switch (this.platform) {
        case 'huobi':
          type = this.$t('huo')
          break
        case 'okex':
          type = this.$t('okex')
          break
        case 'binance':
          type = this.$t('binance')
          break
        case 'gateio':
          type = this.$t('gateio')
          break
        default:
          type = ''
      }
      return type
    },
    // market() {
    //   var market = this.markets(this.platform) || []
    //   console.log(market)
    //   market.forEach((val, index) => {

    //     if (this.findRobot(val.id) && this.findRobot(val.id).status === 0) {
    //       market.splice(index,1);
    //       market.splice(0, 0, val);


    //     }
    //   })
    //   console.log(market)
    //   return market;
    // },
     market() {

      return this.markets(this.platform) || []
    },
  },
  methods: {
    getordercount(item){
      if(item.values_str){
        let data = this.robotData.find((items)=>item.id == items.market_id)
        return JSON.parse(data.values_str).order_count
      }else{
        return 0
      }
    },
    // 客服
    showPopup() {
      this.show = true
    },
    ...mapActions({
      marketLists: 'robot/marketLists',
      robotLists: 'robot/robotLists',
      setTimer: 'robot/setTimer',
    }),
    setTime() //设置定时器
    {
      // console.log('in setttime');
      var that = this;
      this.clearTimeSet=setInterval(() => {
        var url = window.location.href;
        /* console.log(url);
        console.log(url.indexOf('/market')); */
        if(url.indexOf('/market')>0){
          this.onLoad();
        }else{
          that.clearTime();
        }
      }, 8000);
      this.setTimer(this.clearTimeSet)
    },
    clearTime() //清除定时器
    {
      /* console.log('in clear');
      console.log(this.clearTimeSet); */
      window.clearInterval(this.clearTimeSet)
      this.clearTimeSet = ''
    },
    // 线上余额
    getLists() {
      // console.log(' in it');
      var that = this
      this.$axios
        .post('api/third/account/contractBalance', {
          platform: this.platform,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            // console.log(ret.data)
            // ;(that.yue = ret.data.data.USDT), console.log(ret.data.data)
            var num = ret.data.data.USDT.total
            that.yu = num
            that.showBindTip = false
          } else {
            // that.$toast.fail(ret.data.msg)
            that.showBindTip = true
          }
        })
    },
    toNonExponential(num) {
      var m = num.toExponential().match(/\d(?:\.(\d*))?e([+-]\d+)/)
      // return num.toFixed(Math.max(0, (m[1] || '').length - m[2]))
      var ret = num.toFixed(3);
      // console.log(ret);
      ret = ret.slice(0,ret.length-1);
      return ret
    },
    loadData() {
      this.finished = false

      this.marketLists({
        platform: this.platform,
        search: this.keyword,
        type: 'spot',
      })
      this.finished = true
      this.isLoading = false
    },
    onLoad() {


      this.loadData()
      this.robotLists()

    },
    findRobot(id) {
      return this.robotData.filter((item) => item.market_id === id)[0]
    },
    goDetail(item) {
      if (this.findRobot(item.id)) {
        this.$nextTick(() => {
          this.$router.push({
            name: 'contract-components',
            query: { market_id: item.id },
          })
        })
      }
    },
    addRobot(item) {
      this.$router.push({
        name: 'contract-form',
        query: {
          active:this.actives,
          type: 'create',
          platform: this.platform,
          data: JSON.stringify(item),

        },
      })
    },
    //绑定api
    toBindApi(p){
      this.$router.push(`/authorize`)
    }
  },
}
</script>

<style scoped lang="less">
.flex{
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.flex_1{
  flex:1;
}
.yue {
  position: relative;
  width: 100%;
  padding: 0 2%;
  line-height: 36px;
  top: -18px;
  color: @themeColor;
  background: #e3f1ff;
}
.fushu {
  display: block;
  background: #d14b64;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}
.zheng {
  display: block;
  background: #03ad90;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}
/deep/.van-checkbox__label {
  width: 100%;
}
/deep/.van-tag--primary {
  color: @themeColor;
  background: #e3f1ff;
  border-radius: 4px;
  padding: 4px 5px;
}
.lef {
  float: left;
  padding-right: 10px;
}
.asset-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .left,
  .right {
    flex-shrink: 0;
  }
  .right {
    text-align: right;
    font-size: 12px;
    color: #888888;
  }
  .set_number{
    text-align: center;
  }
  .center {
    flex-grow: 1;
    min-width: 0;
  }
  .name {
    color: #333333;
    font-size: 16px;
    font-weight: 500;
  }
  .info {
    font-size: 12px;
    color: #888888;
  }
  .btn {
    height: auto;
    padding: 5px;
  }
}
.bei {
  height: calc(95vh - 167px);
  padding-bottom: 60px;
  overflow-y: scroll;
}
.color_blue{
  color:@themeColor;
}
.add_api{
  position: sticky;
  top: 0;
  z-index: 1;
  background: #fff;
  width:100%;
  padding:10px 16px;
  background: #e3f1ff;
   color:@themeColor;
  .add_api_text{
    color:@themeColor;
  }
}
</style>
