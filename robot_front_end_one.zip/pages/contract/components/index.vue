<template>
  <div class="page page_robot">
    <van-overlay :show="show" z-index="22" style="background: #fff">
      <van-loading type="spinner" class="load" />
    </van-overlay>
    <div v-if="!show">
      <div class="hezi">
        <div class="top_bg">
          <van-nav-bar :border="false" :title="robot.market_name + '永续'" :right-text="$t('pageRobot.order')" left-arrow
            @click-left="$router.back()" @click-right="$router.push('/contract/order?id=' + robot.id)" />

          <div v-if="robot.is_trend == 2" class="top news">
            <h3 class="title"></h3>
            <h3 class="title">
              <div v-if="robot.is_trend == 0" class="nab" style="background-color: #ff0000">空</div>
              <div v-if="robot.is_trend === 1" class="nab">多</div>
              <div v-if="robot.valuee">
                <div v-if="robot.valuee.position == 'long'" class="nab">多</div>
                <div v-if="robot.valuee.position != 'long'" class="nab" style="background-color: #ff0000">
                  空
                </div>
              </div>
              <div class="">
                {{ robot.market_name }}
              </div>
              <div class="bei">全仓 {{ robot.lever }}x</div>
              <div class="label neews" v-if=" robot.is_trend == 2 && robot.recycle_status_long">
                <div @click="newapi(1,2)" v-if="robot.is_trend == 2 &&  robot.recycle_status_long == '1'">
                  单次策略
                </div>
                <div @click="newapi(1,1)" v-if="robot.is_trend == 2 && robot.recycle_status_long == '2'">
                  多次策略</div>
              </div>
              <div class="label neews" v-else-if="robot.is_trend == 2">
                <div @click="newapi(1,2)" v-if="robot.is_trend == 2 && robot.recycle_status == '0' ">
                  单次策略
                </div>
                <div @click="newapi(1,1)" v-if="robot.is_trend == 2 && robot.recycle_status == '1' ">
                  多次策略</div>
              </div>
              <!-- <div class="label neews" v-if="robot.is_trend == 2 && robot.valuee.clean=='1' && robot.status==1"
                @click="enable(1)">重新启动</div> -->
            </h3>
            <div class="">
              <van-row v-if="robot.valuee" type="flex">
                <van-col :span="12">
                  <div class="tits" style="margin-bottom: 1.125rem">
                    未实现盈亏(USDT<span class="green"></span>)
                  </div>
                  <div class="value red" :class="Number(robot.valuee.revenue) > 0 ? 'gren' : ''">
                    {{ Number(robot.valuee.revenue) | numberFormat(2) }}
                  </div>
                </van-col>
                <van-col :span="12" class="textr">
                  <div class="tits" style="margin-bottom: 1.125rem">收益率</div>
                  <div class="value red" :class="Number(robot.valuee.revenue) > 0 ? 'gren' : ''">
                    {{ Number(robot.valuee.lilv || 0) | numberFormat(2) }}%
                  </div>
                </van-col>
                <van-col :span="9">
                  <div class="tits">持仓量(USDT<span class="green"></span>)</div>
                  <div class="value" v-if="robot.is_trend == 0">
                    {{ Number(robot.valuee.deal_money || 0) | numberFormat(2) }}
                  </div>
                  <div class="value" v-if="robot.is_trend == 1">
                    {{ Number(robot.valuee.deal_money || 0) | numberFormat(2) }}
                  </div>
                  <div class="value" v-if="robot.is_trend == 2">
                    {{ Number(robot.valuee.deal_money || 0) | numberFormat(2) }}
                  </div>
                </van-col>
                <van-col :span="8">
                  <div class="tits">初始保证金</div>
                  <div class="value">
                    {{ Number(robot.valuee.margin_price || 0) | numberFormat(3) }}
                  </div>
                </van-col>
                <van-col :span="7" class="textr">
                  <div class="tits">保证金率</div>
                  <div class="value">
                    {{ Number(robot.valuee.margin_lilv || 0) | numberFormat(3) }}%
                  </div>
                </van-col>

                <!-- 持仓数量 -->
                <van-col :span="9">
                  <div class="tits">持仓均价</div>
                  <div class="value">
                    {{ (robot.valuee.deal_money / robot.valuee.deal_amount || 0) | numberFormat(5) }}
                  </div>
                </van-col>

                <van-col :span="8">
                  <div class="tits">标记价格</div>
                  <div class="value">{{ Number(robot.bi_price) | numberFormat(5) }}</div>
                </van-col>
                <!-- 单价 -->
                <van-col :span="7" class="textr">
                  <div class="tits">预估强平价</div>
                  <div class="value">
                    {{ Number(robot.valuee.strong_pay || 0) | numberFormat(5) }}
                  </div>
                </van-col>
                <van-col :span="9">
                  <div class="tits">首单额度(USDT)</div>
                  <div class="value">{{ robot.first_order_value }}</div>
                </van-col>

                <van-col :span="8">
                  <div class="tits">{{ $t('take_profit_ratio') }}</div>
                  <div class="value">{{ robot.stop_profit_rate }}%</div>
                </van-col>
                <van-col :span="7" class="textr">
                  <div class="tits">循环次数</div>
                  <div class="value">
                    {{ robot.valuee.now_round_num || 0 }} / {{ robot.round_num || 0 }}
                  </div>
                </van-col>
                <van-col :span="9">
                  <div class="tits">{{ $t('number_of_orders') }}</div>
                  <div class="value">{{ robot.valuee.order_count || 0 }}</div>
                </van-col>
                <van-col :span="8">
                  <div class="tits">补仓百分比</div>
                  <div class="value">{{ Number(robot.valuee.cover_rate || 0) | numberFormat(2) }}%</div>
                </van-col>

                <van-col :span="7" class="textr">
                  <div class="tits">出仓方式</div>
                  <div class="value">
                    {{ cov_type[robot.valuee.cover_type]}}</div>
                </van-col>
               <van-col :span="9">
                  <div class="tits">补仓价格</div>
                  <div class="value">
                     {{ Number(robot.valuee.cover_price || 0) | numberFormat(5) }}</div>
                </van-col>
                <van-col :span="8" >
                  <div class="tits">出仓价格</div>
                  <div class="value">
                     {{ Number(robot.valuee.sell_price || 0) | numberFormat(5) }}</div>
                </van-col>
               <van-col :span="7" class="textr">
                  <div class="tits">出仓金额(USDT)</div>
                  <div class="value">
                     {{ Number(robot.valuee.sell_money || 0) | numberFormat(5) }}</div>
                </van-col>
              </van-row>
            </div>
            <div class="ldk">
              <div class="label" v-if="robot.valuee  && robot.is_trend == 2" @click="newplayshows(1,true,0)">出仓方式</div>
              <div v-if="robot.is_trend == 0 && robot.status==1" class="label" @click=";(playshow = true), (indexd = 0)">
                做空补仓
              </div>
              <div v-if="robot.is_trend == 1 && robot.status==1" class="label" @click=";(playshow = true), (indexd = 1)">
                做多补仓
              </div>
              <div v-if="robot.is_trend == 2 && robot.clean_long!=2  && robot.valuee && robot.status==1" class="label">
                <div style="width: 100%"
                  @click=";(playshow = true), (indexd = 1)">
                  做多补仓
                </div>
              </div>
              <div class="label" v-if="robot.is_trend == 0"  @click=";(playshows = true), (indexb = 1)">卖出平空</div>
              <div class="label" v-if="robot.is_trend == 1"  @click=";(playshows = true), (indexb = 1)">卖出平多</div>
              <div v-if="robot.is_trend == 2 && robot.valuee" class="label">
                <div style="width: 100%"
                  @click=";(playshows = true), (indexd = 1)">
                  卖出平多
                </div>
              </div>
              <div class="label" v-if="robot.is_trend == 2 && robot.valuee.clean=='1' && robot.status==1"
                @click="enable(1)">重新启动</div>
            </div>
          </div>
          <div class="top" style="border-radius: 0;">
            <h3 class="title">
              <div v-if="robot.is_trend == 0" class="nab" style="background-color: #ff0000">空</div>
              <div v-if="robot.is_trend === 1" class="nab">多</div>
              <div v-if="robot.is_trend == 2 && robot.valuee">
                <div v-if="robot.valuee.position == 'long'" class="nab" style="background-color: #ff0000">
                  空
                </div>
                <div v-if="robot.valuee.position != 'long'" class="nab">多</div>
              </div>
              <div class="">
                {{ robot.market_name }}
              </div>
              <div class="bei">全仓 {{ robot.lever }}x</div>
               <div class="label neews" v-if="robot.recycle_status_short && robot.is_trend == 2">
                <div @click="newapi(0,2)" v-if="robot.is_trend == 2 &&  robot.recycle_status_short == '1'">
                  单次策略
                </div>
                <div @click="newapi(0,1)" v-if="robot.is_trend == 2 && robot.recycle_status_short == '2'">
                  多次策略</div>
              </div>
              <div class="label neews" v-else-if="robot.is_trend == 2">
                <div @click="newapi(0,2)" v-if="robot.is_trend == 2 &&  robot.recycle_status == '1'">
                  单次策略
                </div>
                <div @click="newapi(0,1)" v-if="robot.is_trend == 2 && robot.recycle_status == '0'">
                  多次策略</div>
              </div>
              <!-- <div class="label neews" v-if="robot.is_trend == 2 && robot.values.clean=='1' && robot.status==1"
                @click="enable(0)">重新启动</div> -->
            </h3>
            <div class="">
              <van-row v-if="robot.values" type="flex">
                <van-col :span="12">
                  <div class="tits" style="margin-bottom: 1.125rem">
                    未实现盈亏(USDT<span class="green"></span>)
                  </div>
                  <div class="value red" :class="Number(robot.values.revenue) > 0 ? 'gren' : ''">
                    {{ Number(robot.values.revenue) | numberFormat(2) }}
                  </div>
                </van-col>
                <van-col :span="12" class="textr">
                  <div class="tits" style="margin-bottom: 1.125rem">收益率</div>
                  <div class="value red" :class="Number(robot.values.revenue) > 0 ? 'gren' : ''">
                    {{ Number(robot.values.lilv || 0) | numberFormat(2) }}%
                  </div>
                </van-col>
                <van-col :span="9">
                  <div class="tits">持仓量(USDT<span class="green"></span>)</div>
                  <div class="value">
                    {{ Number(robot.values.deal_money  || 0) | numberFormat(2) }}
                  </div>
                </van-col>
                <van-col :span="8">
                  <div class="tits">初始保证金</div>
                  <div class="value">
                    {{ Number(robot.values.margin_price || 0) | numberFormat(3) }}
                  </div>
                </van-col>
                <van-col :span="7" class="textr">
                  <div class="tits">保证金率</div>
                  <div class="value">
                    {{ Number(robot.values.margin_lilv || 0) | numberFormat(3) }}%
                  </div>
                </van-col>

                <!-- 持仓数量 -->
                <van-col :span="9">
                  <div class="tits">持仓均价</div>
                  <div class="value">
                    {{
                      (robot.values.deal_money / robot.values.deal_amount || 0) | numberFormat(5)
                    }}
                  </div>
                </van-col>

                <van-col :span="8">
                  <div class="tits">标记价格</div>
                  <div class="value">{{ Number(robot.bi_price) | numberFormat(5) }}</div>
                </van-col>
                <!-- 单价 -->
                <van-col :span="7" class="textr">
                  <div class="tits">预估强平价</div>
                  <div class="value">
                    {{ Number(robot.values.strong_pay || 0) | numberFormat(5) }}
                  </div>
                </van-col>

                <van-col :span="9">
                  <div class="tits">首单额度(USDT)</div>
                  <div class="value">{{ robot.first_order_value }}</div>
                </van-col>

                <van-col :span="8">
                  <div class="tits">{{ $t('take_profit_ratio') }}</div>
                  <div class="value">{{ robot.stop_profit_rate }}%</div>
                </van-col>
                <van-col :span="7" class="textr">
                  <div class="tits">循环次数</div>
                  <div class="value">
                    {{ robot.values.now_round_num || 0 }} / {{ robot.round_num || 0 }}
                  </div>
                </van-col>

                <van-col :span="9">
                  <div class="tits">{{ $t('number_of_orders') }}</div>
                  <div class="value">{{ robot.values.order_count || 0 }}</div>
                </van-col>
                <van-col :span="8">
                  <div class="tits">补仓百分比</div>
                  <div class="value">{{ Number(robot.values.cover_rate || 0) | numberFormat(2) }}%</div>
                </van-col>
                 <van-col :span="7" class="textr">
                  <div class="tits">出仓方式</div>
                  <div class="value">
                     {{ cov_type[robot.values.cover_type]}}</div>
                </van-col>
                <van-col :span="9" >
                  <div class="tits">补仓价格</div>
                  <div class="value">
                     {{ Number(robot.values.cover_price || 0) | numberFormat(5) }}</div>
                </van-col>
                 <van-col :span="8">
                  <div class="tits">出仓价格</div>
                  <div class="value">
                     {{ Number(robot.values.sell_price || 0) | numberFormat(5) }}</div>
                </van-col>
                <van-col :span="7" class="textr">
                  <div class="tits">出仓金额(USDT)</div>
                  <div class="value">
                     {{ Number(robot.values.sell_money || 0) | numberFormat(5) }}</div>
                </van-col>
              </van-row>
            </div>
            <div class="ldk">
              <div class="label" v-if="robot.values && robot.is_trend == 2" @click="newplayshows(0,true,0)">出仓方式</div>
              <div v-if="robot.is_trend == 0 && robot.status==1" class="label" @click=";(playshow = true), (indexd = 0)">
                做空补仓
              </div>
              <div v-if="robot.is_trend == 1 && robot.status==1" class="label" @click=";(playshow = true), (indexd = 1)">
                做多补仓
              </div>
              <div v-if="robot.is_trend == 2 && robot.clean_short!=2 && robot.values && robot.status==1" class="label">
                <div style="width: 100%"
                  @click=";(playshow = true), (indexd = 0)">
                  做空补仓
                </div>
              </div>
              <div v-else-if="robot.is_trend == 0 "  class="label" @click=";(playshows = true), (indexb = 1)">卖出平空</div>
              <div v-else-if="robot.is_trend == 1 "  class="label" @click=";(playshows = true), (indexb = 1)">卖出平多</div>
              <div class="label" v-if="robot.is_trend == 2"  @click="showTable(true,0)">卖出平空</div>
              <div class="label" v-if="robot.is_trend == 2 && robot.values.clean=='1' && robot.status==1"
                @click="enable(0)">重新启动</div>
            </div>
          </div>
        </div>
      </div>
      <div class="title-block">{{ $t('latest_log') }}</div>
      <nuxt-link class="link" :to="'/contract/log?id=' + robot.id">
        {{ $t('all_log') }}
        <van-icon name="arrow" size="15" />
      </nuxt-link>
      <div class="new-msg">
        <p v-if="robot.show_msg" class="van-ellipsis">{{ robot.show_msg }}</p>
        <span v-else style="color: #888">{{ $t('empty.log') }}</span>
      </div>
      <div class="title-block">{{ $t('pageRobot.strategic_operations') }}</div>
      <van-grid column-num="4" :border="false" style="position: relative;">
        <van-grid-item v-if="robot.status === 0" @click="onEnable">
          <!-- <van-image width="50" />{{ $t('pageRobot.start') }} -->
          <div class="nlabel">{{ $t('pageRobot.start') }}</div>
        </van-grid-item>
        <van-grid-item v-else @click="onDisable">
          <!-- <van-image width="50" :src="icons.icon3" />{{ $t('pageRobot.pause') }} -->
          <div class="nlabel">{{ $t('pageRobot.pause') }}</div>
        </van-grid-item>
        <van-grid-item @click="goEdit">
          <!-- <van-image width="50" :src="icons.icon2" />{{ $t('pageRobot.trade_setup') }} -->
          <div class="nlabel">{{ $t('pageRobot.trade_setup') }}</div>
        </van-grid-item>
        <van-grid-item @click="onClean">
          <!-- <van-image width="50" :src="icons.icon4" />一键平仓 -->
          <div class="nlabel">一键平仓</div>
        </van-grid-item>
        <van-grid-item @click="all">
          <!-- <van-image width="50" :src="icons.icon4" />一键平仓 -->
          <div class="nlabel">同步持仓</div>
        </van-grid-item>
        <!-- <van-grid-item @click="playshow = true">
        <van-image width="50" :src="icons.icon5" />{{ $t('pageRobot.clearance_yi') }}
      </van-grid-item> -->
      </van-grid>
      <!-- 补仓 -->
      <div class="tan" v-if="playshow">
        <div class="bg_bai">
          <van-icon name="close" @click="playshow = false" />
          <van-cell-group :border="false">
            <!-- <van-field
            v-model="values"
            @blur="numberInputs"
            label="补仓价格"
            placeholder="请输入补仓价格不少于10U"
          /> -->
            <van-field v-model="value" @blur="numberInput" label="补仓金额" placeholder="请输入补仓金额" />
          </van-cell-group>
          <div class="ti" @click="palySub">{{ $t('ti') }}</div>
        </div>
      </div>
      <!-- 出仓 -->
      <div class="tan" v-if="newplayshow">
        <div class="bg_bai">
          <van-icon name="close" @click="newplayshow = false" />
          <van-cell-group :border="false">
            <van-field name="radio" :label="$t('pageRobot.strategy_type')" v-if="$route.query.robot_id != 0"
              class="s_radio">
              <div class="my_label flex" slot="label">
                <div class="label">分仓方式</div>
              </div>
              <template #input style="margin-top: 4px">
                <van-radio-group v-model="cover_type" direction="horizontal" style="margin-left: -15px">
                  <van-radio style="margin-right: 4px" :name="1">整体出仓</van-radio>
                  <van-radio style="margin-right: 4px" :name="2">尾单出仓</van-radio>
                  <van-radio style="margin-right: 4px" :name="3">首尾出仓</van-radio>
                </van-radio-group>
              </template>
            </van-field>
          </van-cell-group>
          <div class="ti" @click="editCover()">{{ $t('ti') }}</div>
        </div>
      </div>
      <!-- 卖出 -->
      <div class="tan" v-if="playshows">
        <div class="bg_bai">
          <div style="display: flex;align-items: center;justify-content: space-between;font-size: 16px;">
            <div class=""></div>
            <div class="">平仓</div>
            <van-icon name="cross" @click="playshowsclick()" />
          </div>
          <van-cell-group :border="false">
            <div class="" style="border-bottom: 1px solid #f1f1f2;margin-bottom: 16px;">
              <div class="fle1">
                <div class="tst">合约</div>
                <div class="resd"> {{ robot.market_name }}永续 / {{indexb==0 ? '空':'多'}} {{ robot.lever }}x</div>
              </div>
              <div class="fle1">
                <div class="tst">开仓价格(USDT)</div>
                <div class="">{{base_price}}</div>
              </div>
              <div class="fle1">
                <div class="tst">标记价格(USDT)</div>
                <div class="">{{ticke_price}}</div>
              </div>
            </div>
            <div class="tst">数量</div>
            <van-field class="but" v-model="valuesinp" center clearable placeholder="请输入卖出数量(%)" @blur="blur"
              @focus="focus">
              <template #button>
                <div class="tst">
                  USDT
                </div>
              </template>
            </van-field>
            <van-slider style="margin: 8px 0 4px;" v-model="values" @input="modval" active-color="#0166ec"
              bar-height="4" min="1">
            </van-slider>
            <div class="numbe">
              <div>1%</div>
              <div>25%</div>
              <div>50%</div>
              <div>75%</div>
              <div>100%</div>
            </div>
            <!-- <van-field v-model="value" @blur="numberInput" label="卖出数量" placeholder="请输入卖出数量"  v-if="indexb==1"/> -->
            <div class="fle1">
              <div class="tst">仓位数量</div>
              <div class="">{{deal_money}}</div>
            </div>
            <div class="fle1">
              <div class="tst" style="display: flex;align-items: center;">预计盈亏
                <van-icon name="warning" />
              </div>
              <div class="resd">≈ {{renven}}</div>
            </div>
          </van-cell-group>
          <div class="" style="display: flex;align-items: center;">
            <div class="ti" @click="playshowk(indexb,0)">{{ $t('ti') }}</div>
            <!-- <div class="ti" @click="playshowk(indexb,1)">一键全平</div> -->
          </div>
        </div>
      </div>
      <!-- 循环 -->
      <div class="tan" v-if="playshown">
        <div class="bg_bai">
          <van-icon name="close" @click="playshown = false" />
          <van-cell-group :border="false">
            <van-field v-model="numb" label="循环次数" placeholder="请输入循环次数" />
          </van-cell-group>
          <div class="ti" @click="newapi(indp,1)">{{ $t('ti') }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {
    Grid,
    GridItem,
    Popover,
    Overlay,
    Slider,
    Loading
  } from 'vant'
  import {
    mapGetters,
    mapActions,
    mapState
  } from 'vuex'
  export default {
    components: {
      [Grid.name]: Grid,
      [GridItem.name]: GridItem,
      [Popover.name]: Popover,
      [Overlay.name]: Overlay,
      [Loading.name]: Loading,
      [Slider.name]: Slider
    },
    i18n: {
      messages: {
        zh: {
          ti: '提交',
        },
      },
    },
    data() {
      return {
        value: '',
        valuee: '',
        values: 1,
        valuesinp: '1%',
        market_id: '',
        robot: {},
        icons: {
          icon1: require('@/assets/images/jiaoyi6.png'),
          icon2: require('@/assets/images/jiaoyi3.png'),
          icon3: require('@/assets/images/jiaoyi5.png'),
          icon4: require('@/assets/images/jiaoyi4.png'),
          icon5: require('@/assets/images/jiaoyi.png'),
        },
        cov_type:{
          1:'整体出仓',
          2:'尾单出仓',
          3:'首尾出仓',
        },
        valuek: {
          base_price: '0',
          cover_price: 0,
          deal_amount: 0,
          deal_money: 0,
          direction: 'long',
          down_price: 0,
          executedQty: 0,
          fee: 0,
          first_order_price: 1,
          last_price: 0,
          lever: 0,
          lilv: 0,
          margin_lilv: 0,
          margin_price: 0,
          now_round_num: 0,
          order_count: 0,
          order_finish: 0,
          order_id: 0,
          pid: 'a7cc03af-6b45-4f50-b874-96599c08a9f6',
          position: 'long',
          revenue: 0,
          side: 'BUY',
          strong_pay: 0,
          symbol: 'LTC-USDT-',
          time: '',
          trend_side: 0,
          type: 'MARKET',
          up_price: 0,
          clean: 1,
        },
        showPopover: false,
        ticke_price: 0,
        base_price: 0,
        renven: 0,
        deal_amount: 0,
        deal_money: 0,
        deal_amount_sum: 0,
        ctval: 1,
        account: {},
        playshow: false,
        platform: '',
        total: '',
        totals: '',
        num: 3,
        nums: 3,
        indexd: 0,
        show: true,
        indexb: '',
        playshows: false,
        playshown: false,
        indp: 0,
        numb: '',
        newplayshow: false,
        cover_type: 1
      }
    },
    computed: {
      ...mapGetters({
        robotFind: 'robot/robot_contract',
      }),
      ...mapState({
        timer1: ({
          robot
        }) => robot.timer1,
      }),
    },

    created() {
      this.show = true
      if (this.timer1) {
        window.clearInterval(this.timer1)
      }
      this.getAll()
      let timer1 = setInterval(() => {
        // this.getAll(1)
        this.getCurPrice()
      }, 2000)
      this.setTimer1(timer1)
    },
    destroyed() {
      if (this.timer1) {
        window.clearInterval(this.timer1)
      }
    },
    methods: {
      ...mapActions({
        robotList: 'robot/robotLists',
        robotEnable: 'robot/robotEnables',
        robotEnablesPostions: 'robot/robotEnablesPostions',
        robotDisable: 'robot/robotDisables',
        robotClean: 'robot/robotCleans',
        robotCleanT: 'robot/robotCleanT',
        apiAccountBalance: 'authorize/apiContractBalance',
        setTimer1: 'robot/setTimer1',
        getRealPrice: 'robot/getRealPrices',
      }),

      showTable(show,ins){
        this.playshows = true
        this.indexb = ins
      },
      all(){
        var that = this
        this.$dialog
            .confirm({
              message: '是否同步持仓',
            })
            .then((res) => {
              that.$axios.post('/api/quant/contract/synchro',{
                robot_id: this.robot.id,
              })
                .then(function(ret) {
                  that.$toast(ret.data.msg)
                })
            })
      },
      //获取实时价格
      async getCurPrice() {
        let res = await this.getRealPrice({
          // currency:'huobipro',
          market_name: this.robot.market_name,
          robot_id: this.robot.id,
        })
        if (res.code == 1) {
          let data = res.data

          this.robot.bi_price = data.price
          this.robot.values = data.values_str ? data.values_str : this.valuek
          this.robot.valuee = data.values_strs ? data.values_strs : this.valuek
          this.ticke_price = parseInt(data.price * 1000000000) / 1000000000
          this.platform = data.platform
          this.ctval = data.ctVal
          if (this.robot.is_trend != 2) {
            this.base_price = parseInt(data.values_str.base_price * 1000) / 1000
            this.deal_money = parseInt(data.values_str.deal_money * 1000) / 1000
            this.executedQty = data.values_str.executedQty

            this.deal_amount_sum = data.values_strs.deal_amount
          } else {
            console.log(data.values_str)
            if (this.indexb == 0) {
              this.base_price = parseInt(data.values_str.base_price * 1000) / 1000
              this.deal_money = parseInt(data.values_str.deal_money * 1000) / 1000
              this.executedQty = data.values_str.executedQty
              this.deal_amount_sum = data.values_str.deal_amount
            } else {
              this.base_price = parseInt(data.values_strs.base_price * 1000) / 1000
              this.deal_money = parseInt(data.values_strs.deal_money * 1000) / 1000
              this.executedQty = data.values_strs.executedQty
              this.deal_amount_sum = data.values_strs.deal_amount
            }
          }

          if (this.platform == 'binance') {
            this.deal_amount = parseInt(this.deal_amount_sum * this.values) / 100
            this.renven = parseInt((this.ticke_price - this.base_price) * this.deal_amount * 100) / 100
            if (this.indexb == 0) {
              this.renven = -this.renven
            }
          } else {
            this.deal_amount = parseInt(this.deal_amount_sum * this.values) / 100
            this.renven = parseInt(this.executedQty * this.ctval / (this.ticke_price - this.base_price) * 100) / 100
            if (this.indexb == 0) {
              this.renven = -this.renven
            }
          }

          this.show = false
        }
      },
      async getCurPrices() {
        let res = await this.getRealPrice({
          // currency:'huobipro',
          market_name: this.robot.market_name,
          robot_id: this.robot.id,
        })
        if (res.code == 1) {
          let data = res.data
          this.robot.bi_price = data.price
          this.robot.values = data.values_str ? data.values_str : this.valuek
          this.robot.valuee = data.values_strs ? data.values_strs : this.valuek
          this.show = false
        }
      },
      newplayshows(position,newplayshow,indexd){
        this.newplayshow=true
        if(position==0){
          this.indexd=0
        }else{
          this.indexd=1
        }
      },
      getAll(statue) {
        this.market_id = this.$route.query.market_id ? JSON.parse(this.$route.query.market_id) : ''
        this.robotList().then(() => {
          this.robot = Object.assign({}, this.robotFind(this.market_id))
          this.robot.money = this.robot.money || 'USDT'
          if (statue != 1) {
            // this.apiAccountBalance({
            //   platform: this.robot.platform,
            // })
            //   .then((res) => {
            //     this.account = res.data.free
            //   })
            //   .catch((res) => {
            //     this.$toast(res.msg)
            //   })
          }

          this.getCurPrices()
        })
        var that = this
        // setTimeout(function () {
        //   that.getAll(1)
        // }, 2000)
      },
      playshowsclick() {
        this.playshows = false
        this.deal_amount = 0
        this.deal_amount_sum = 0
        this.base_price = 0
        this.deal_money = 0
      },
      // 获取金额
      numberInput(value) {
        // console.log(value)
        this.total = this.value
        // this.palySub();
      },

      numberInputs(value) {
        // console.log(value)
        this.totals = this.values
        // this.palySub();
      },
      blur() {
        this.values = this.valuesinp
        this.valuesinp = this.valuesinp + '%(≈' + parseInt(this.deal_money * this.valuesinp) / 100 + ')'
        if (this.platform == 'binance') {
          this.deal_amount = parseInt(this.deal_amount_sum * this.values) / 100
          this.renven = parseInt((this.ticke_price - this.base_price) * this.deal_amount * 100) / 100
          if (this.indexb == 0) {
            this.renven = -this.renven
          }
        } else {
          this.deal_amount = parseInt(this.deal_amount_sum * this.values) / 100
          this.renven = parseInt(this.executedQty * this.ctval / (this.ticke_price - this.base_price) * 100) / 100
          if (this.indexb == 0) {
            this.renven = -this.renven
          }
        }
      },
      focus() {
        this.valuesinp = this.values
      },
      modval() {
        this.valuesinp = this.values + '%(≈' + parseInt(this.deal_money * this.values) / 100 + ')'
        if (this.platform == 'binance') {
          this.deal_amount = parseInt(this.deal_amount_sum * this.values) / 100
          console.log(this.deal_amount)
          this.renven = parseInt((this.ticke_price - this.base_price) * this.deal_amount * 100) / 100
          if (this.indexb == 0) {
            this.renven = -this.renven
          }
        } else {
          this.deal_amount == parseInt(this.deal_amount_sum * this.values) / 100
          this.renven = parseInt(this.executedQty * this.ctval / (this.ticke_price - this.base_price) * 100) / 100
          if (this.indexb = 0) {
            this.renven = -this.renven
          }
        }
      },
      // 切换
      nku(e) {
        this.num = e
      },
      nkus(e) {
        this.nums = e
      },
      newapi(e, index) {
        var that = this
        console.log('店家')
        var met = {
          type: e
        }
        var mesage =''
        if (e == 0) {
          if (index == 1) {
            met = {
              type: e,
              robot_id: this.robot.id,
              recycle_status_short: index,
              recycle_short_amount: this.numb
            }
            mesage ='做空是否切换单次循环?'
          } else {
            met = {
              type: e,
              robot_id: this.robot.id,
              recycle_status_short: index,
              recycle_short_amount: 0
            }
            mesage ='做空是否切换多次循环?'
          }
        } else {
          if (index == 1) {
            met = {
              robot_id: this.robot.id,
              type: e,
              recycle_status_long: index,
              recycle_long_amount: this.numb
            }
            mesage ='做多是否切换单次循环?'
          } else {
            met = {
              robot_id: this.robot.id,
              type: e,
              recycle_status_long: index,
              recycle_long_amount: 0
            }
            mesage ='做多是否切换多次循环?'
          }

        }
        this.$dialog
            .confirm({
              message: mesage,
            })
            .then((res) => {
              that.$axios.post('/api/quant/contract/edit_recycle', met)
                .then(function(ret) {
                  that.$toast(ret.data.msg)
                  that.pageup()
                })
            })
      },

      editCover(){
        var that = this
        var covertype = 0
        if(this.indexd==0){
          covertype = 0
        }else{
          covertype = 1
        }
        this.$axios
          .post('/api/quant/contract/cover_type', {
            robot_id: this.robot.id,
            cover_type: this.cover_type,
            direction_type: covertype,
          })
          .then(function(ret) {
            if (ret.data.code == 1) {
              that.$toast.success(ret.data.msg)
              that.playshow = false
            } else {
              that.$toast.fail(ret.data.msg)
            }
            this.pageup()
          })
      },
      //一键补仓
      palySub() {
        console.log(this.play_checked)
        var that = this
        this.$axios
          .post('/api/quant/contract/bucang_type', {
            robot_id: this.robot.id,
            total: this.total,
            type: this.indexd,
          })
          .then(function(ret) {
            if (ret.data.code == 1) {
              that.$toast.success(ret.data.msg)
              that.playshow = false
              // console.log(ret.data);
              // that.robotList = ret.data.data
              // that.creatQrCode();
            } else {
              that.$toast.fail(ret.data.msg)
            }
            this.pageup()
          })
        // /api/quant/robot/setRecycle
      },
      enable(e) {
        this.$dialog
          .confirm({
            message: '是否启动' + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotEnablesPostions({
                robot_id: this.robot.id,
                type: e,
              })
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 0
                  }
                })
                this.pageup()
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      goEdit() {
        this.$router.push({
          name: 'contract-form',
          query: {
            type: 'edit',
            robot_id: this.robot.id,
            platform: this.robot.platform,
          },
        })
      },
      onEnable() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_enable') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotEnable({
                robot_id: this.robot.id,
              })
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 1
                  }
                })
                this.pageup()
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      onDisable() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_pause') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotDisable({
                robot_id: this.robot.id,
              })
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 0
                  }
                })
                this.pageup()
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      pageup() {
        this.show = true
        if (this.timer1) {
          window.clearInterval(this.timer1)
        }
        this.getAll()
        let timer1 = setInterval(() => {
          // this.getAll(1)
          this.getCurPrice()
        }, 2000)
        this.setTimer1(timer1)
      },
      playshowk(e, index) {
        this.$dialog
          .confirm({
            message: '是否平仓' + '？',
          })
          .then((res) => {
            this.$toast.loading()
            var met = {
              robot_id: this.robot.id,
              type: e,
            }
            if (index == 0) {
              if (e == 0) {
                met = {
                  robot_id: this.robot.id,
                  type: e,
                  clean_amount_short: this.values
                }
              } else {
                met = {
                  robot_id: this.robot.id,
                  type: e,
                  clean_amount_long: this.values
                }
              }
            }
            this.robotCleanT(met)
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 0
                  }
                })
                this.pageup()
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      onClean() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_sell') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotClean({
              robot_id: this.robot.id,
            }).then((res) => {
              this.$toast(res.msg)
              this.$router.back()
              this.pageup()
            })
          })
      },
      onBu() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_bu') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotClean({
              robot_id: this.robot.id,
            }).then((res) => {
              this.$toast(res.msg)
              this.$router.back()
              this.pageup()
            })
          })
      },
    },
  }
</script>

<style scoped lang="less">
  // *{
  //   font-size: 10px;
  // }
  .numbe {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 0.9375rem;
    color: #858585;
  }

  .nab {
    color: #fff;
    background-color: #3bc376;
    height: 24px;
    line-height: 24px;
    width: 1.5rem;
    font-size: 1rem;
    margin-right: 1.0625rem;
  }

  /deep/.van-field {
    line-height: 50px !important;
    padding: 0 !important;
  }

  /deep/.van-cell::after {
    border: 0;
  }

  /deep/.van-cell-group {
    background: none;
    border: none;
    height: auto;
    line-height: 34px;
    margin-top: 20px;
  }

  .tan {
    width: 100%;
    position: fixed;
    top: 0;
    height: 100%;
    overflow: hidden;
    background: rgba(0, 0, 0, 0.5);
  }

  .tan .bg_bai {
    width: 90%;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    padding: 10px 7%;
    border-radius: 10px;
  }

  /deep/.van-radio-group--horizontal {
    margin-top: 20px;
    margin-bottom: 20px;
  }

  /deep/.van-icon {
    font-size: 16px;
    float: right;
  }

  .bg_bai .ti {
    width: 100%;
    margin: 0 auto;
    margin-top: 20px;
    line-height: 50px;
    border-radius: 10px;
    margin-bottom: 10px;
    color: #fff;
    background: @themeColor;
    text-align: center;
  }

  .ul {
    width: 100%;
    overflow: hidden;
    padding-bottom: 42px;
  }

  .ul .li {
    width: 94%;
    padding: 10px 0;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: flex-start;
    align-items: center;
    margin: 0 auto;
    overflow: hidden;
    border-bottom: 1px solid #f8f8f8;
  }

  .ul .li .center {
    width: 70%;
    margin-left: 10px;
  }

  .ul .li .ying {
    background: #03ad90;
    color: #fff;
    width: 70px;
    text-align: center;
    border-radius: 8px;
    line-height: 36px;
  }

  .ul .li .fu {
    background: #d14b64;
    color: #fff;
    width: 70px;
    text-align: center;
    border-radius: 8px;
    line-height: 36px;
  }

  .li .ce {
    font-size: 12px;
    color: @themeColor;
    background: #e3f1ff;
    border-radius: 4px;
    padding: 4px 5px;
  }

  /deep/ .van-popover__action {
    width: 134px;
  }

  /deep/.van-nav-bar {
    background-color: transparent;
  }

  /deep/.van-nav-bar .van-icon {
    color: #fff;
  }

  /deep/.van-nav-bar__title {
    color: #fff;
  }

  /deep/.van-nav-bar__right .van-nav-bar__text {
    color: #fff;
  }

  .hezi {
    width: 100%;
    // height: 250px;
    overflow: hidden;
  }

  .top_bg {
    width: 100%;
    margin: 0 auto;
    position: relative;
    // height: 250px;
    // background: url(~@/assets/images/me_bg@2x.png) no-repeat top center;
    // background: linear-gradient(to right, RGBA(1,102,236,.7), RGBA(1,102,236,1));
    background: linear-gradient(to bottom, @themeColor, RGBA(255, 255, 255, 0.1));
  }

  .top {
    padding: 15px 20px;
    // width: 94%;
    margin: 0 auto;
    color: #333;
    // height: 200px;
    // position: absolute;
    // top: 50px;
    // left: 3%;
    // background: linear-gradient(to bottom right, rgb(21, 69, 212), rgb(25, 137, 250));
    background: #fff;
    border-radius: 6px 6px 0 0;

    .next {
      display: flex;

      .folt {
        width: 60%;
      }

      .right {
        margin-left: auto;
        color: #3bc376;
        font-size: 1.2rem;
        font-weight: bold;
        display: flex;
        align-items: center;

        .text {
          position: relative;
          top: -0.5rem;
        }
      }
    }

    .foot {
      margin-top: 0.625rem;
      font-size: 1rem;
    }

    .title {
      color: #333;
      font-size: 1.5em;
      margin-bottom: 0.3125rem;
      padding-bottom: 0.3125rem;
      text-align: center;
      display: flex;
      align-items: center;

      // border-bottom: 1px solid #979ba5;
      .bei {
        font-size: 1.0625rem;
        color: #878d98;
        margin-left: 1.375rem;
      }

      .van-tag {
        font-weight: normal;
        display: table;
        min-width: 74px;
        line-height: 24px;
        border: 1px solid #1989fa;
        color: #1989fa;
        border-radius: 0;
        background: #fff;
        margin-left: 10px;
      }
    }

    .van-col {
      padding: 10px 0 0;
      color: #333;
    }

    .label {
      float: left;
      opacity: 0.8;
      min-width: 3rem;
      background-color: #f0f0f0;
      padding: 0.2025rem 0.625rem;
      height: 2rem;
      margin: 0 0.5rem 0.5rem 0;
      line-height: 1.5rem;
      text-align: center;
      border-radius: 0.3125rem;
      font-size: 0.875rem;
    }

    .tits {
      color: #9597a7;
      font-size: 12px;
      margin-bottom: 0.2rem;
    }

    .textr {
      text-align: right;
    }

    .green {
      color: #3bc376;
    }

    .value {
      font-size: 16px;
      margin-top: 6px;
    }
  }

  .title-block {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    font-weight: bold;
    font-size: 1.3em;

    &::before {
      content: '';
      width: 0.25em;
      height: 1em;
      margin-right: 10px;
      background-color: @themeColor;
    }
  }

  .block1 {
    background-color: #fff;
    padding: 10px 15px;
    color: #888888;

    .van-col-sp {
      width: 100%;
    }

    .van-col {
      margin: 5px 0;
    }

    span {
      color: @themeColor;
      font-size: 16px;
    }
  }

  .news {
    padding-top: 0;
  }

  .new-msg {
    background: #fff;
    padding: 10px 15px;
  }

  .link {
    float: right;
    margin-top: -39px;
    line-height: 39px;
    padding: 0 15px;
    font-size: 12px;
    display: flex;
    align-items: center;
    color: @themeColor;
  }

  .red {
    color: #cb0000;
    font-size: 1.3125rem !important;
    font-weight: bold;
  }

  .gren {
    color: #3bc376 !important;
  }

  .ldk {
    margin-top: 1.25rem;
    display: flex;
    align-items: center;
    justify-content: space-around;

    .label {
      width: 33%;
      font-size: 1.1rem;
      line-height: 2rem;
      height: 2.5rem;
      font-family: pingfang SC;
    }
  }

  .load {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .nlabel {
    text-align: center;
    border-radius: 0.3125rem;
    background-color: #f0f0f0;
    padding: 0.3125rem 0.625rem;
    width: 100%;
    font-size: 0.8rem;
    line-height: 1.8rem;
    height: 2.5rem;
    font-family: pingfang SC;
  }

  .fle1 {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .tst {
    color: #afacb4;
  }

  .resd {
    color: #d63b59;
  }

  .but {
    background-color: #f6f6f6;
    margin-bottom: 1.875rem;
  }

  /deep/.van-field__body {
    padding: 0 0.625rem;
  }

  .neews {
font-size: 10px;
    color: #3CC67A;
    margin: 0 0 0 0.8rem !important;
    line-height: 1.72rem !important;
    div{

        font-size: 8px;
    }
  }
  /deep/.van-radio--horizontal{
    margin-bottom: 4px;
  }
</style>
