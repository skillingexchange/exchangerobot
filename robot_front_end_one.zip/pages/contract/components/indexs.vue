<template>
  <div class="page page_robot">
    <div class="hezi">
      <div class="top_bg">
        <van-nav-bar :border="false" :title="robot.market_name + '永续'" :right-text="$t('pageRobot.order')" left-arrow
          @click-left="$router.back()" @click-right="$router.push('/contract/order?id=' + robot.id)" />
        <div class="top">
          <h3 class="title">
            <div class="">
              {{ robot.market_name }}
            </div>
            <div class="nab">
              双向
            </div>
          </h3>
          <div class="next">
            <div class="folt">
              <div class="label" :class="num == 1?'green':''" @click="nku(1)">全仓</div>
              <div class="label" :class="num == 2?'green':''" @click="nku(2)">{{ robot.lever }}</div>
              <div class="label" :class="num == 5?'green':''" @click="nku(5)">补仓</div>
              <div class="label" @click="playshow = true">平仓</div>
            </div>
            <div class="right">
              <div class="text">
                收益 {{ Number(robot.revenue) | numberFormat(2) }}U
              </div>
            </div>
          </div>
          <div class="">
            <van-row v-if="robot.values" type="flex">
              <van-col :span="9">
                <div class="tits">持仓量(SOLUSDT<span class="green">多</span>)</div>
                <div class="value">{{ Number(robot.values.deal_money || 0) | numberFormat(5) }}</div>
              </van-col>
              <van-col :span="8">
                <div class="tits">预估强平价</div>
                <div class="value">
                  {{ Number(robot.values.deal_money || 0) | numberFormat(5) }}
                </div>
              </van-col>
              <van-col :span="7" class="textr">
                <div class="tits">保证金</div>
                <div class="value">{{ Number(robot.values.deal_money || 0) | numberFormat(5) }}</div>
              </van-col>
              <!-- 持仓数量 -->
              <van-col :span="9">
                <div class="tits">持仓均价</div>
                <div class="value">{{ (robot.values.deal_money / robot.values.deal_amount || 0) | numberFormat(10) }}</div>
              </van-col>

              <van-col :span="8">
                <div class="tits">{{ $t('first_order_amount') }}(USDT)</div>
                <div class="value">{{ robot.first_order_value }}</div>
              </van-col>
              <!-- 单价 -->
              <van-col :span="7" class="textr">
                <div class="tits">做单次数</div>
                <div class="value">{{ robot.values.order_count || 0 }}</div>
              </van-col>

              <van-col :span="9">
                <div class="tits">{{ $t('number_of_orders') }}</div>
                <div class="value">{{ robot.max_order_count }}</div>
              </van-col>
              <van-col :span="8">
                <div class="tits">{{ $t('take_profit_ratio') }}</div>
                <div class="value">
                  {{ robot.stop_profit_rate }}%
                </div>
              </van-col>
              <van-col :span="7" class="textr">
                <div class="tits">补仓百分比</div>
                <div class="value">0%</div>
              </van-col>

              <van-col :span="9">
                <div class="tits">总计持仓</div>
                <div class="value">0</div>
              </van-col>
              <van-col :span="7" class="textr">
                <div class="tits">标记价格</div>
                <div class="value">0</div>
              </van-col>
            </van-row>
          </div>
          <div class="foot">补仓价格 < 107.5522 </div>
              <div class="foot">
                回报率 0.90%
              </div>
          </div>
        </div>
      </div>
      <div class="top news">
        <h3 class="title">
        </h3>
        <div class="next">
          <div class="folt">
            <div class="label" :class="nums == 1?'green':''" @click="nkus(1)">全仓</div>
            <div class="label" :class="nums == 2?'green':''" @click="nkus(2)">1X</div>
            <div class="label" :class="nums == 3?'green':''" @click="nkus(3)">策略循环</div>
            <div class="label" :class="nums == 4?'green':''" @click="nkus(4)">马丁</div>
            <div class="label" :class="nums == 5?'green':''" @click="nkus(5)">补仓</div>
            <div class="label" @click="playshow = true">平仓</div>
          </div>
          <div class="right">
            <div class="text red">
              收益 -1.97
            </div>
          </div>
        </div>
        <div class="">
          <van-row v-if="robot.values" type="flex">
            <van-col :span="9">
              <div class="tits">持仓量(SOLUSDT<span class="red">多</span>)</div>
              <div class="value">0</div>
            </van-col>
            <van-col :span="8">
              <div class="tits">预估强平价</div>
              <div class="value">
                0
              </div>
            </van-col>
            <van-col :span="7" class="textr">
              <div class="tits">保证金</div>
              <div class="value">0</div>
            </van-col>
            <!-- 持仓数量 -->
            <van-col :span="9">
              <div class="tits">持仓均价</div>
              <div class="value">0</div>
            </van-col>

            <van-col :span="8">
              <div class="tits">{{ $t('first_order_amount') }}(USDT)</div>
              <div class="value">{{ robot.first_order_value }}</div>
            </van-col>
            <!-- 单价 -->
            <van-col :span="7" class="textr">
              <div class="tits">做单次数</div>
              <div class="value">0</div>
            </van-col>

            <van-col :span="9">
              <div class="tits">{{ $t('number_of_orders') }}</div>
              <div class="value">{{ robot.max_order_count }}</div>
            </van-col>
            <van-col :span="8">
              <div class="tits">{{ $t('take_profit_ratio') }}</div>
              <div class="value">
                {{ robot.stop_profit_rate }}%
              </div>
            </van-col>
            <van-col :span="7" class="textr">
              <div class="tits">补仓百分比</div>
              <div class="value">0%</div>
            </van-col>

            <van-col :span="9">
              <div class="tits">总计持仓</div>
              <div class="value">0</div>
            </van-col>
            <van-col :span="8">
              <div class="tits">递减持仓</div>
              <div class="value">
                0
              </div>
            </van-col>
            <van-col :span="7" class="textr">
              <div class="tits">标记价格</div>
              <div class="value">0</div>
            </van-col>
          </van-row>
        </div>
        <div class="foot">补仓价格 < 107.5522 </div>
            <div class="foot">
              回报率 0.90%
            </div>
        </div>
        <div class="title-block">{{ $t('pageRobot.strategic_operations') }}</div>
        <van-grid column-num="4" :border="false">
          <van-grid-item v-if="robot.status === 0" @click="onEnable">
            <van-image width="50" :src="icons.icon1" />{{ $t('pageRobot.start') }}
          </van-grid-item>
          <van-grid-item v-else @click="onDisable">
            <van-image width="50" :src="icons.icon3" />{{ $t('pageRobot.pause') }}
          </van-grid-item>
          <van-grid-item @click="goEdit">
            <van-image width="50" :src="icons.icon2" />{{ $t('pageRobot.trade_setup') }}
          </van-grid-item>
          <van-grid-item @click="onClean">
            <van-image width="50" :src="icons.icon4" />{{ $t('pageRobot.clearance_sell') }}
          </van-grid-item>
          <!-- <van-grid-item @click="playshow = true">
        <van-image width="50" :src="icons.icon5" />{{ $t('pageRobot.clearance_yi') }}
      </van-grid-item> -->
        </van-grid>
        <!-- 平仓 -->
        <div class="tan" v-if="playshow">
          <div class="bg_bai">
            <van-icon name="close" @click="playshow = false" />
            <van-cell-group :border="false">
              <van-field v-model="values" @blur="numberInputs" label="补仓价格" placeholder="请输入补仓价格不少于10U" />
              <van-field v-model="value" @blur="numberInput" label="补仓金额" placeholder="请输入补仓金额不少于10U" />
            </van-cell-group>
            <div class="ti" @click="palySub">{{ $t('ti') }}</div>
          </div>
        </div>
      </div>
</template>

<script>
  import {
    Grid,
    GridItem,
    Popover
  } from 'vant'
  import {
    mapGetters,
    mapActions,
    mapState
  } from 'vuex'
  export default {
    components: {
      [Grid.name]: Grid,
      [GridItem.name]: GridItem,
      [Popover.name]: Popover,
    },
    i18n: {
      messages: {
        zh: {
          ti: '提交',
        },

      },
    },
    data() {
      return {
        value: '',
        values: '',
        market_id: '',
        robot: {},
        icons: {
          icon1: require('@/assets/images/jiaoyi6.png'),
          icon2: require('@/assets/images/jiaoyi3.png'),
          icon3: require('@/assets/images/jiaoyi5.png'),
          icon4: require('@/assets/images/jiaoyi4.png'),
          icon5: require('@/assets/images/jiaoyi.png'),
        },
        showPopover: false,
        account: {},
        playshow: false,
        total: '',
        totals: '',
        num: 3,
        nums: 3,
      }
    },
    computed: {
      ...mapGetters({
        robotFind: 'robot/robot_contract',
      }),
      ...mapState({
        timer1: ({
          robot
        }) => robot.timer1,
      }),
    },

    created() {
      if (this.timer1) {
        window.clearInterval(this.timer1)
      }
      this.getAll()
      let timer1 = setInterval(() => {
        // this.getAll(1)
        this.getCurPrice()
      }, 2000)
      this.setTimer1(timer1)
    },
    destroyed() {
      if (this.timer1) {
        window.clearInterval(this.timer1)
      }
    },
    methods: {
      ...mapActions({
        robotList: 'robot/robotLists',
        robotEnable: 'robot/robotEnables',
        robotDisable: 'robot/robotDisables',
        robotClean: 'robot/robotCleans',
        apiAccountBalance: 'authorize/apiContractBalance',
        setTimer1: 'robot/setTimer1',
        getRealPrice: 'robot/getRealPrices',
      }),
      //获取实时价格
      async getCurPrice() {
        let res = await this.getRealPrice({
          // currency:'huobipro',
          market_name: this.robot.market_name,
          robot_id: this.robot.id
        })
        if (res.code == 1) {
          let data = res.data
          this.robot.bi_price = data.price
          this.robot.values = data.values_str ? data.values_str : this.robot.values
          this.robot.revenue = data.revenue
        }
      },
      getAll(statue) {
        this.market_id = this.$route.query.market_id ? JSON.parse(this.$route.query.market_id) : ''
        this.robotList().then(() => {
          this.robot = Object.assign({}, this.robotFind(this.market_id))
          this.robot.money = this.robot.money || 'USDT'
          if (statue != 1) {
            this.apiAccountBalance({
                platform: this.robot.platform
              })
              .then((res) => {
                this.account = res.data.free
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          }
        })
        var that = this
        // setTimeout(function () {
        //   that.getAll(1)
        // }, 2000)
      },
      // 获取金额
      numberInput(value) {
        // console.log(value)
        this.total = this.value;
        // this.palySub();
      },
      numberInputs(value) {
        // console.log(value)
        this.totals = this.values;
        // this.palySub();
      },
      // 切换
      nku(e) {
        this.num = e
      },
      nkus(e) {
        this.nums = e
      },
      //一键补仓
      palySub() {
        console.log(this.play_checked)
        var that = this
        this.$axios
          .post('/api/quant/robot/bucang', {
            robot_id: this.robot.id,
            total: this.total,
          })
          .then(function(ret) {
            if (ret.data.code == 1) {
              that.$toast.success(ret.data.msg)
              that.playshow = false
              // console.log(ret.data);
              // that.robotList = ret.data.data
              // that.creatQrCode();
            } else {
              that.$toast.fail(ret.data.msg)
            }
          })
        // /api/quant/robot/setRecycle
      },
      goEdit() {
        this.$router.push({
          name: 'contract-form',
          query: {
            type: 'edit',
            robot_id: this.robot.id,
            platform: this.robot.platform
          },
        })
      },
      onEnable() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_enable') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotEnable({
                robot_id: this.robot.id
              })
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 1
                  }
                })
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      onDisable() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_pause') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotDisable({
                robot_id: this.robot.id
              })
              .then((res) => {
                this.$toast(res.msg)
                this.robotList()
                this.$nextTick(() => {
                  this.robot = this.robotFind(this.market_id)
                  if (res.code == 1) {
                    this.robot.status = 0
                  }
                })
              })
              .catch((res) => {
                this.$toast(res.msg)
              })
          })
      },
      onClean() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_sell') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotClean({
              robot_id: this.robot.id
            }).then((res) => {
              this.$toast(res.msg)
              this.$router.back()
            })
          })
      },
      onBu() {
        this.$dialog
          .confirm({
            message: this.$t('pageRobot.dialog_bu') + '？',
          })
          .then((res) => {
            this.$toast.loading()
            this.robotClean({
              robot_id: this.robot.id
            }).then((res) => {
              this.$toast(res.msg)
              this.$router.back()
            })
          })
      },
    },
  }
</script>

<style scoped lang="less">
  .nab {
    margin-left: auto;
    color: #3bc376;
    font-size: 1.3rem;
  }

  /deep/.van-field {
    line-height: 50px !important;
    padding: 0 !important;
  }

  /deep/.van-cell::after {
    border: 0
  }

  /deep/.van-cell-group {
    background: none;
    border: none;
    height: auto;
    line-height: 50px;
    margin-top: 50px;
  }

  .tan {
    width: 100%;
    position: fixed;
    top: 0;
    height: 100%;
    overflow: hidden;
    background: rgba(0, 0, 0, 0.5);
  }

  .tan .bg_bai {
    width: 90%;
    position: absolute;
    left: 5%;
    top: 30%;
    background: #fff;
    padding: 10px 7%;
    border-radius: 10px;
  }

  /deep/.van-radio-group--horizontal {
    margin-top: 20px;
    margin-bottom: 20px;
  }

  /deep/.van-icon {
    font-size: 16px;
    float: right;
  }

  .bg_bai .ti {
    width: 100px;
    margin: 0 auto;
    margin-top: 20px;
    line-height: 40px;
    border-radius: 10px;
    color: #fff;
    background: @themeColor;
    text-align: center;
  }

  .ul {
    width: 100%;
    overflow: hidden;
    padding-bottom: 42px;
  }

  .ul .li {
    width: 94%;
    padding: 10px 0;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: flex-start;
    align-items: center;
    margin: 0 auto;
    overflow: hidden;
    border-bottom: 1px solid #f8f8f8;
  }

  .ul .li .center {
    width: 70%;
    margin-left: 10px;
  }

  .ul .li .ying {
    background: #03ad90;
    color: #fff;
    width: 70px;
    text-align: center;
    border-radius: 8px;
    line-height: 36px;
  }

  .ul .li .fu {
    background: #d14b64;
    color: #fff;
    width: 70px;
    text-align: center;
    border-radius: 8px;
    line-height: 36px;
  }

  .li .ce {
    font-size: 12px;
    color: @themeColor;
    background: #e3f1ff;
    border-radius: 4px;
    padding: 4px 5px;
  }

  /deep/ .van-popover__action {
    width: 134px;
  }

  /deep/.van-nav-bar {
    background-color: transparent;
  }

  /deep/.van-nav-bar .van-icon {
    color: #fff;
  }

  /deep/.van-nav-bar__title {
    color: #fff;
  }

  /deep/.van-nav-bar__right .van-nav-bar__text {
    color: #fff;
  }

  .hezi {
    width: 100%;
    // height: 250px;
    overflow: hidden;
  }

  .top_bg {
    width: 100%;
    margin: 0 auto;
    position: relative;
    // height: 250px;
    // background: url(~@/assets/images/me_bg@2x.png) no-repeat top center;
    // background: linear-gradient(to right, RGBA(1,102,236,.7), RGBA(1,102,236,1));
    background: linear-gradient(to bottom, @themeColor, RGBA(255, 255, 255, 0.1));
  }

  .top {
    padding: 15px 20px;
    // width: 94%;
    margin: 0 auto;
    color: #333;
    // height: 200px;
    // position: absolute;
    // top: 50px;
    // left: 3%;
    // background: linear-gradient(to bottom right, rgb(21, 69, 212), rgb(25, 137, 250));
    background: #fff;
    border-radius: 6px 6px 0 0;

    .next {
      display: flex;

      .folt {
        width: 60%;
      }

      .right {
        margin-left: auto;
        color: #3bc376;
        font-size: 1.2rem;
        font-weight: bold;
        display: flex;
        align-items: center;

        .text {
          position: relative;
          top: -0.5rem;
        }
      }
    }

    .foot {
      margin-top: 0.625rem;
      font-size: 1rem;
    }

    .title {
      color: #333;
      font-size: 1.5em;
      margin-bottom: 10px;
      padding-bottom: 5px;
      text-align: center;
      display: flex;
      align-items: center;
      border-bottom: 1px solid #979ba5;

      .van-tag {
        font-weight: normal;
        display: table;
        min-width: 74px;
        line-height: 24px;
        border: 1px solid #1989fa;
        color: #1989fa;
        border-radius: 0;
        background: #fff;
        margin-left: 10px;
      }
    }

    .van-col {
      padding: 10px 0px 5px 0;
      color: #333;
    }

    .label {
      float: left;
      opacity: 0.8;
      min-width: 4rem;
      background-color: #f0f0f0;
      padding: 0.3125rem 0.625rem;
      height: 2rem;
      margin: 0 0.6rem 0.5rem 0;
      line-height: 1.5rem;
      text-align: center;
      border-radius: 0.3125rem;
      font-size: 0.875rem;
    }

    .tits {
      color: #9597a7;
      font-size: 0.875rem;
      margin-bottom: 0.8rem;
    }

    .textr {
      text-align: right;
    }

    .green {

      color: #3bc376;
    }

    .value {
      font-size: 16px;
    }
  }

  .title-block {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    font-weight: 500;
    font-size: 1em;

    &::before {
      content: '';
      width: 0.25em;
      height: 1em;
      margin-right: 10px;
      background-color: @themeColor;
    }
  }

  .block1 {
    background-color: #fff;
    padding: 10px 15px;
    color: #888888;

    .van-col-sp {
      width: 100%;
    }

    .van-col {
      margin: 10px 0;
    }

    span {
      color: @themeColor;
      font-size: 16px;
    }
  }

  .news {
    padding-top: 0;
  }

  .new-msg {
    background: #fff;
    padding: 10px 15px;
  }

  .link {
    float: right;
    margin-top: -39px;
    line-height: 39px;
    padding: 0 15px;
    font-size: 12px;
    display: flex;
    align-items: center;
    color: @themeColor;
  }

  .red {
    color: #cb0000;
  }
</style>
