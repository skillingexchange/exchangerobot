<template>
  <div class="page_market">
    <!-- <div safe-area-inset-top>
      <van-row type="flex" justify="space-between" align="center" class="page-header">
        <van-col class="page-header-left">
          <h2 class="page-title">{{ $t('nav.exchange') }}</h2>
        </van-col>
      </van-row>
    </div> -->
    <div class="sou">
      <van-search v-model="keyword" shape="round" :background="themeColor" :placeholder="$t('qing')"
        @input="searchSub" />
    </div>
    <van-tabs v-model="active" swipeable animated sticky line-width="20px">
      <van-tab v-for="item in platform" :key="item.name" v-if="item.name != 'HuobiPro'">
        <template #title>{{ $t(item.label) }}合约</template>
        <assets-list ref="child" :platform="item.label" :keyword="keyword" :platforms="platform" :actives="active">
        </assets-list>
      </van-tab>
    </van-tabs>
    <van-overlay :show="show">
      <div class="wrapper">
        <div v-html="texthtml" class="text" ref="xqBox" @click="move" @touchmove="move" @touchend="end"
          @mousedown="down" @mousemove="move" @mouseup="end"></div>
        <!-- <p v-html="texthtml" class="texts" ref="xqBox" @click="move"></p> -->
        <div>
          <van-checkbox v-model="checked">我已阅读并同意协议</van-checkbox>
        </div>
        <button class="butn" v-if="checked" @click="dislon">确认</button>
        <button class="butn disa" disabled v-if="!checked">确认</button>
      </div>
    </van-overlay>
  </div>
</template>

<script>
  import {
    mapGetters,
    mapActions,
    mapState
  } from 'vuex'
  import assetsList from './components/assetsList'
  import Vue from 'vue'
  import {
    Search,
    Overlay,
    Checkbox,
    CheckboxGroup
  } from 'vant'

  Vue.use(Search)
  Vue.use(Overlay)
  Vue.use(Checkbox)
  Vue.use(CheckboxGroup)
  export default {
    layout: 'navigation',
    i18n: {
      messages: {
        zh: {
          qing: '请输入搜索关键词',
        },
        en: {
          qing: 'Please enter search keywords',
        },
      },
    },

    components: {
      assetsList,
    },
    data() {
      return {
        active: 0,
        show: false,
        checked: false,
        keyword: '',
        texthtml: '',
        fou: true
      }
    },
    watch: {
      active(val) {
        this.$store.dispatch('robot/marketIndex', val)
      },
    },
    computed: {
      ...mapState({
        platform: ({
          robot
        }) => robot.platform,
        marketIndex: ({
          robot
        }) => robot.marketIndex,
        themeColor: (index) => index.themeColor,
      }),
    },
    methods: {
      ...mapActions({
        robotFinds: 'robot/dialog',
      }),
      searchSub(val) {
        // this.$refs.assets.onLoad(val);
        // console.log(this.$refs.child[0].onLoad(val))
        this.$nextTick(() => {
          this.$refs.child[this.active].onLoad(val)
        })
        // this.keyword = val ;
      },
      ffe() {
        console.log(99999)
      },
      add() {
        this.robotFinds()
          .then((res) => {
            console.log(res)
            if (res.data.data) {
              this.show = true
              this.texthtml = this.showHtml(res.data.data)
            }
          })
          .catch((res) => {
            this.$toast(res.msg)
          })
      },
      showHtml(str) {
        return str
          .replace(str ? /&(?!#?\w+;)/g : /&/g, '&amp;')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'")
      },
      dislon() {
        this.show = false
        this.robotFinds({
            confirm: 1
          })
          .then((res) => {
            console.log(res)
          })
          .catch((res) => {
            this.$toast(res.msg)
          })
      },
      down(event) {
        var touch
        if (event.touches) {
          touch = event.touches[0]
        } else {
          touch = event
        }
        this.dy = touch.clientY / 2
        this.fou = false
      },
      move(event) {
        console.log(this.fou);
        event.preventDefault()
        var touch
        if (event.touches) {
          touch = event.touches[0]
        } else {
          touch = event
        }
        if (this.fou) {
          this.top = this.$refs.xqBox.scrollTop
          this.dy = touch.clientY
          this.fou = false
        }
        // if (
        //   this.top - (touch.clientY - this.dy) >= 0 &&
        //   this.top - (touch.clientY - this.dy) <= this.scrollBottom
        // ) {}
        this.ny = touch.clientY
        var long = this.ny - this.dy
        this.$refs.xqBox.scrollTop = this.top - long
      },
      end(e) {
        this.fou = true
      },
    },
    mounted() {
      if (this.$route.query.active) {
        this.active = this.$route.query.active
      } else {
        this.active = this.marketIndex
      }
      this.add()
      // this.getLists()
    },
  }
</script>

<style lang="less">
  .page {
    padding-bottom: 0 !important;
  }

  .van-cell {
    background-color: transparent;
  }

  .van-tab {
    color: #333;
    font-weight: 700;
  }

  .yue {
    position: fixed;
    width: 100%;
    padding: 0 2%;
    line-height: 36px;
    bottom: 50px;
    color: @themeColor;
    background: #e3f1ff;
  }

  .sou {
    padding-top: 15px;
    background-color: @themeColor;
  }

  /deep/.page {
    padding-top: 0 !important;
  }

  .page-header {
    background-color: @themeColor;
    height: 66px;
    color: #fff;
    padding-top: 15px;

    &-right .van-icon {
      display: inline-block;
      vertical-align: middle;
    }

    &-title {
      display: flex;
      align-items: center;
      font-size: 22px;
      line-height: 1;
      color: #333333;
    }
  }

  .text::-webkit-scrollbar {
    display: none;
  }

  .wrapper {
    background-color: #fff;
    border-radius: 1.25rem;
    height: 80%;
    width: 80%;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 1.25rem;

    .text {
      width: 100%;
      height: 85%;
      overflow: scroll;
      margin-bottom: 0.625rem;

      .texts {}

      p,
      ul,
      div,
      span {
        width: 100% !important;
      }
    }

    .butn {
      width: 100%;
      height: 3rem;
      margin-top: 0.625rem;
      background-color: #1989fa;
      color: #fff;
      border: none;
      border-radius: 60px;
    }

    .disa {
      color: #fff;
      background-color: #9b9b9b;
    }
  }
</style>
