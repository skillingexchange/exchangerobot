<template>
  <div class="box page page_market"> 
    <div class="sou">
      <div  class="van-search" style="background: rgb(1, 102, 236)">
        <div  class="van-search__content van-search__content--round">
          <div  class="van-search__label" @click="selectCoin">
              {{coinType}}
              <i class="van-icon van-icon-arrow-down"></i>
            </div>
          <div  class="van-cell van-cell--borderless van-field">
            <div class="van-field__left-icon">
              <i class="van-icon van-icon-search"></i>
            </div>
            <div class="van-cell__value van-cell__value--alone van-field__value">
              <div class="van-field__body">
                <input type="search" placeholder="搜索币种名称" class="van-field__control" @input="searchSub" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="my" v-if="false">
      <div class="top">
        <div class="tou" v-if="$route.query.name == 'huobi'" @click="showPopup">
          <img src="@/assets/images/huobi.png" alt="" />{{ $t('huobi') }}
        </div>
        <div class="tou" v-if="$route.query.name == 'okex'" @click="showPopup">
          <img src="@/assets/images/okex.png" alt="" />{{ $t('okex') }}
        </div>
        <div class="tou" v-if="$route.query.name == 'binance'" @click="showPopup">
          <img src="@/assets/images/binance.png" alt="" />{{ $t('binance') }}
        </div>
        <div class="tou" v-if="$route.query.name == 'gateio'" @click="showPopup">
          <img src="@/assets/images/gateio.png" alt="" />{{ $t('gateio') }}
        </div>
        <div class="anniu" @click="showPopup"><van-icon name="sort" /></div>
        <div class="weiBang" v-if="spotok == 0" @click="$router.push({ path: 'authorize' })">
          {{ $t('wei') }}
        </div>
        <div class="yiBang" v-if="spotok == 1" @click="$router.push({ path: 'authorize' })">
          {{ $t('yi') }}
        </div>
      </div>
      <div class="yuTitle">{{ $t('dang') }}(USDT)</div>
      <div class="yushu">{{ Number(yu) | numberFormat(2) }}</div>
    </div>
    <van-popup v-model="showSetting" closeable position="bottom" :style="{ height: '20%' }">
        <div class="my" >
            <div class="ti">
                <div class="pi_sp" >
                    <van-checkbox v-model="checked" @click="checkAll" icon-size="16">{{ $t('xuan') }}</van-checkbox>
                </div>
                <p>{{ $t('jin') }}</p>
            </div>
            <div class="tu_nav">
                <!-- <div class="dl" @click="sellKai">
                <div class="dt"><img src="@/assets/images/kaiqi.png" alt="" /></div>
                <div class="dd">{{ $t('kai') }}</div>
                </div> --> 
                <div class="dl" @click="sellZan">
                    <div class="dt"><img src="~@/assets/images/zan.png" alt="" /></div>
                    <div class="dd">{{ $t('zan') }}</div>
                </div>
                <div class="dl" @click="playshow = true">
                    <div class="dt"><img src="~@/assets/images/huan.png" alt="" /></div>
                    <div class="dd">{{ $t('ce') }}</div>
                </div>
                <div class="dl" @click="sellSet">
                    <div class="dt"><img src="~@/assets/images/she.png" alt="" /></div>
                    <div class="dd">{{ $t('jiao') }}</div>
                </div>
                <div class="dl" @click="sellALl">
                    <div class="dt"><img src="~@/assets/images/mai.png" alt="" /></div>
                    <div class="dd">{{ $t('qing') }}</div>
                </div>
            </div>
        </div>
    </van-popup>
    <div class="tabs">
         <van-tabs v-model="active" swipeable animated sticky @click="gal">
            <van-tab name=" ">
                <template #title>{{ $t('quan') }}</template>
                <!-- <assets-list ref="child" :platform="item.label" :keyword="keyword"></assets-list> -->
            </van-tab>
            <van-tab name="1">
                <template #title>{{ $t('luo') }}</template>
            </van-tab>
            <van-tab name="0">
                <template #title>{{ $t('dan') }}</template>
            </van-tab>
            <van-tab name="2">
                <template #title>{{ $t('ting') }}</template>
            </van-tab>
        </van-tabs>
    </div>
   

    <div class="ul">
      <van-checkbox-group v-model="result" ref="checkboxGroup">
        <div class="li" v-for="(val, key) in robotList" :key="key">
          <van-checkbox :name="val.id"></van-checkbox>
          <div
            class="center"
            @click="$router.push({ path: '/robot', query: { market_id: val.market_id } })"
          >
            <div class="title">
              <span>{{ val.market_name }}</span
              ><span class="ce" v-if="val.recycle_status == 1">{{ $t('xucl') }}</span
              ><span class="ce" v-if="val.recycle_status == 0">{{ $t('dcxh') }}</span>
            </div>
            <div class="shu">
              <span>{{ $t('shu') }}：{{ val.deal_amount }}</span
              ><span>{{ $t('fu') }}：{{ val.revenue }}USDT</span>
            </div>
          </div>
          <div :class="Number(val.lilv) < 0 ? 'fu' : 'ying'">
            {{ Number(val.lilv) <= 0 ? val.lilv : '+' + val.lilv }}%
          </div>
        </div>
      </van-checkbox-group>
    </div>

    <div class="pi" v-if="false">
      <van-checkbox v-model="checked" @click="checkAll">{{ $t('xuan') }}</van-checkbox>
      <!-- <div class="piQ">{{ $t('information') }}</div> -->
    </div>

    <div class="yue">
        <p>{{ $t('sheng') }} :{{ yu || 0 }}</p>
        <p @click="showSetting=true">批量设置</p>
    </div>
    
    <!-- 策略循环 -->
    <div class="tan" v-if="playshow">
      <div class="bg_bai">
        <van-icon name="close" @click="playshow = false" />
        <van-radio-group v-model="play_checked" direction="horizontal">
          <van-radio :name="1">{{ $t('xucl') }}</van-radio>
          <van-radio :name="0">{{ $t('dcxh') }}</van-radio>
        </van-radio-group>
        <div class="ti" @click="palySub">{{ $t('ti') }}</div>
      </div>
    </div>
    <van-popup v-model="show" closeable position="bottom" :style="{ height: '22%' }">
      <div class="tu_nav1">
        <div class="dl" @click="changebtb('huobi')">
          <div class="dt"><img src="@/assets/images/huobi.png" alt="" /></div>
          <div class="dd">{{ $t('huo') }}</div>
        </div>
        <div class="dl" @click="changebtb('okex')">
          <div class="dt"><img src="@/assets/images/okex.png" alt="" /></div>
          <div class="dd">OKEx</div>
        </div>
        <div class="dl" @click="changebtb('binance')">
          <div class="dt"><img src="@/assets/images/binance.png" alt="" /></div>
          <div class="dd">{{ $t('binance') }}</div>
        </div>
        <div class="dl" @click="changebtb('gateio')">
          <div class="dt"><img src="@/assets/images/gateio.png" alt="" /></div>
          <div class="dd">{{ $t('gateio') }}</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import tokenStorage from '@/utils/storage'
import Vue from 'vue'
import {mapState} from 'vuex'
import { Search } from 'vant'

Vue.use(Search)
export default {
  layout: 'navigation',
  i18n: {
    messages: {
      zh: {
        information: '批量操作',
        huo: '火币',
        okex: 'OKEX',
        binance: '币安',
        gateio: '比特币',
        wei: '未绑定',
        yi: '已绑定',
        dang: '当前账户可用',
        jin: '仅对已经勾选的所有币种进行操作',
        ce: '循环策略',
        jiao: '交易设置',
        qing: '清仓卖出',
        quan: '全部',
        luo: '循环策略',
        dan: '单次策略',
        ting: '停止补单',
        shu: '数量',
        fu: '浮亏',
        xuan: '全选',
        xucl: '循环策略',
        dcxh: '单次策略',
        ti: '提交',
        kai: '开启',
        zan: '暂停',
        sheng: '当前账号可用USDT',
      },
      en: {
        information: 'Batch Processing',
        huo: 'huobi',
        okex: 'OKEX',
        binance: 'binance',
        gateio: 'gateio',
        wei: 'unbound',
        yi: 'bound',
        dang: 'Balance',
        jin: 'Operate only on all currencies that have been checked',
        ce: 'Circular Strategy',
        jiao: 'Trade Setup',
        qing: 'Clearance Sell',
        quan: 'All',
        luo: 'Circular Strategy',
        dan: 'Single Strategy',
        ting: 'Stop replenish',
        shu: 'Number',
        fu: 'P/L',
        xuan: 'Check all',
        xucl: 'Circular Strategy',
        dcxh: 'Single Strategy',
        ti: 'Submit',
        kai: 'Start',
        zan: 'Pause',
        sheng: 'Balance(USDT)',
      },
    },
  },
  data() {
    return {
      active: ' ',
      keyword: '',
      checked: '',
      robotList: '',
      platform: 'huobi',
      recycle_status: '',
      status: '',
      result: [],
      playshow: false,
      play_checked: 1,
      yu: '',
      spotok: '',
      show: false,
      market_id: '',
      yu: '',
      showSetting:false,
      curName:'huobi'
    }
  },
  computed: {
    ...mapState({
      platform1:(index)=>index.selectPlatform
    }),
    coinType() {
      let type = ''
      switch (this.curName) {
        case 'huobi':
          type = this.$t('huo')
          break
        case 'okex':
          type = this.$t('okex')
          break
        case 'binance':
          type = this.$t('binance')
          break
        case 'gateio':
          type = this.$t('gateio')
          break
        default:
          type = ''
      }
      return type
    },
  },
 
  mounted() {
    console.log(99,this.platform1)
    this.$route.query.name = this.platform1
    this.curName = this.$route.query.name
    this.getAll()
    
  },
  methods: {
    getAll() {
      this.getRobotList()
      this.getLists()
      this.spotMarket()
    },
    changebtb(name) {
      console.log(name)
      this.$route.query.name = name
      this.curName = name
      this.getAll()
      this.show = false
    },
    // 切换币种
    showPopup() {
      this.show = true
    },
    //循环
    palySub() {
      console.log(this.play_checked)
      var that = this
      this.$axios
        .post('/api/quant/robot/setRecycle', {
          robot_id: this.result.join(','),
          recycle_status: this.play_checked,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            //1成功 还是0成功
            that.$toast.success(ret.data.msg)
            that.playshow = false
            // console.log(ret.data);
            // that.robotList = ret.data.data

            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
      // /api/quant/robot/setRecycle
    },
    //交易设置
    sellSet() {
      tokenStorage.set('robot_ids', this.result)
      this.$router.push({ path: 'robot/form', query: { type: 'edit', robot_id: 0,platform: this.$route.query.name } })
    },
    //清倉賣出
    sellALl() {
      console.log(this.result)
      //
      var that = this
      this.$axios
        .post('/api/quant/robot/allClean', {
          robot_id: this.result.join(','),
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            that.$toast.success(ret.data.msg)

            setTimeout(function () {
              that.$router.go(0)
            }, 100)
            // console.log(ret.data);
            // that.robotList = ret.data.data
            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },
    // 开启
    sellKai() {
      console.log(this.result)
      //
      var that = this
      this.$axios
        .post('/api/quant/robot/mulEnable', {
          robot_id: this.result.join(','),
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            that.$toast.success(ret.data.msg)

            setTimeout(function () {
              that.$router.go(0)
            }, 100)
            // console.log(ret.data);

            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },
    // 暂停
    sellZan() {
      console.log(this.result)
      //
      var that = this
      this.$axios
        .post('/api/quant/robot/mulDisable', {
          robot_id: this.result.join(','),
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            that.$toast.success(ret.data.msg)

            setTimeout(function () {
              that.$router.go(0)
            }, 100)
            // console.log(ret.data);
            // that.robotList = ret.data.data
            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },
    checkAll() {
      if (this.checked) {
        this.$refs.checkboxGroup.toggleAll(true)
      } else {
        this.$refs.checkboxGroup.toggleAll(false)
      }
    },

    // 获取机器人列表
    getRobotList() {
        return new Promise((resolve,reject)=>{
            var param = {
                platform: this.$route.query.name,
            }
            console.log(this.active)

            if (this.active == 0 || this.active == 1) {
                param.recycle_status = this.active
            } else if (this.active == 2) {
                param.status = 0
            }

            var that = this
            this.$axios.post('/api/quant/robot/newRobotList', param).then(function (ret) {
                if (ret.data.code == 1) {
                // console.log(ret.data);
                that.robotList = ret.data.data
                that.market_id = ret.data.data.id
                // that.creatQrCode();
                resolve(ret.data)
                } else {
                that.$toast.fail(ret.data.msg)
                }
            })
        })
      
    },
    gal() {
      this.getRobotList()
      console.log(this.active)
    },
    // 线上余额
    getLists() {
      var that = this
      this.$axios
        .post('api/third/account/accountBalance', {
          platform: this.$route.query.name,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            // console.log(ret.data)
            // ;(that.yue = ret.data.data.USDT), console.log(ret.data.data)
            var num = ret.data.data.USDT.total

            that.yu = that.toNonExponential(num)
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },
    toNonExponential(num) {
      var m = num.toExponential().match(/\d(?:\.(\d*))?e([+-]\d+)/)
      return num.toFixed(Math.max(0, (m[1] || '').length - m[2]))
    },
    // 获取平台是否绑定
    spotMarket() {
      console.log(this.result)
      //
      var that = this
      this.$axios
        .post('/api/quant/robot/spotMarket', {
          platform: this.$route.query.name,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data.is_ok)
            that.spotok = ret.data.data.is_ok

            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },

    //搜索
    searchSub(e) {
        this.$route.query.name = e.target.value
        if(e.target.value == ''){
            this.$route.query.name = 'huobi'
        }
        this.getRobotList().then((res)=>{
            if(res.data.length > 0){
                this.curName = this.$route.query.name
                this.getLists()
                this.spotMarket()
            }
        })
    },
    //选择币种
    selectCoin(){
        this.$router.push(`/market/tbChange`)
        
    },
    //批量设置
    setting(){

    }
  },
}
</script>

<style scoped lang="less">
.sou {
  background-color: @themeColor;
  position: fixed;
  top:0;
  width: 100%;
}
.sou  .van-icon-search{
    position: relative;
    top:0;
    right:0;
    font-size: 16px;
}
.sou /deep/.van-search__label {
  line-height: 39px;
}
.sou .van-icon-arrow-down{
    font-size: 10px;
    position: relative;
    top:0;
    right:0;
}
.tabs{
    position: fixed;
    top:59px;
    width: 100%;
    z-index:1;
}
.yue {
  position: fixed;
  width: 100%;
  padding: 0 2%;
  line-height: 36px;
  bottom: 50px;
  color: @themeColor;
  background: #e3f1ff;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.pi_sp{
    position: absolute;
}

.tu_nav1 {
  width: 100%;
  background: #fff;
  padding: 0 3%;
  margin: 10px auto;
  overflow: hidden;
  margin-top: 50px;
}
.tu_nav1 .dl {
  width: 25%;
  float: left;
  text-align: center;
  line-height: 24px;
  color: #333;
}
.tu_nav1 .dt img {
  width: 58%;
}
.van-icon {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
}
/deep/.van-tab {
  font-size: 16px;
}
.tan {
  width: 100%;
  position: fixed;
  top: 0;
  height: 100%;
  overflow: hidden;
  background: rgba(0, 0, 0, 0.5);
  z-index: 9999;
}
.tan .bg_bai {
  width: 80%;
  position: absolute;
  left: 10%;
  top: 30%;
  background: #fff;
  padding: 10px 7%;
  border-radius: 10px;
}
/deep/.van-radio-group--horizontal {
  margin-top: 20px;
  margin-bottom: 20px;
}
.bg_bai .ti {
  width: 100px;
  line-height: 40px;
  border-radius: 10px;
  color: #fff;
  background: @themeColor;
}
.ul {
  width: 100%;
  overflow: hidden;
  padding-bottom: 42px;
  padding-top: 104px;
}
.ul .li {
  width: 94%;
  padding: 10px 0;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
  align-items: center;
  margin: 0 auto;
  overflow: hidden;
  border-bottom: 1px solid #f8f8f8;
}
.ul .li .center {
  width: 70%;
  margin-left: 10px;
}
.ul .li .ying {
  background:#03ad90;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}
.ul .li .fu {
  background: #d14b64;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}
.li .ce {
  font-size: 12px;
  color: @themeColor;
  background: #e3f1ff;
  border-radius: 4px;
  padding: 4px 5px;
}
.title {
  color: #333333;
  font-size: 16px;
  font-weight: 500;
  line-height: 40px;
}
.shu {
  font-size: 12px;
  color: #888888;
}
.shu span {
  padding-right: 10px;
}
.pi {
  width: 100%;
  padding: 0 3%;
  position: fixed;
  bottom: 50px;
  height: 50px;
  background-color: #fff;
  box-shadow: 0px -3px 6px rgba(0, 0, 0, 0.05);
}
.pi .piQ {
  float: right;
  line-height: 50px;
  color: #0077ff;
}
.pi .van-checkbox {
  width: 50%;
  padding-top: 16px;
  float: left;
}
/deep/.van-tabs__nav {
  background-color: #f0f2f5;
}
.box {
  width: 100%;
  height: 100vh;
  overflow-y: scroll;
  background-color: #fff;
}
.page-header {
  background-color: @themeColor;
  height: 66px;
  padding: 0 15px;
  color: #fff;

  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}
.ti {
  width: 94%;
  margin: 10px auto;
  overflow: hidden;
  text-align: center;
  font-size: 12px;
  color: #333333;
}
.yuTitle {
  width: 94%;
  margin: 10px auto;
  font-size: 16px;
  color: #666666;
}
.yushu {
  width: 94%;
  margin: 0 auto;
  font-size: 24px;
  color: #0077fd;
  margin-bottom: 20px;
}
.my {
  width: 94%;
  margin: 10px auto;
  background: #ffffff;
  overflow: hidden;
  box-shadow: 0px 0px 10px rgba(201, 204, 223, 0.3);
  border-radius: 12px;
  overflow: hidden;
}
/deep/.anniu .van-icon {
  position: absolute;
  top: 20px;
  left: 100px;
  font-size: 24px;
}
.my .tou {
  width: 30%;
  float: left;
  font-size: 14px;
  line-height: 24px;
}
.my .tou img {
  width: 40%;
  vertical-align: -15px;
}
.my .anniu {
  width: 10%;
  float: left;
  color: @themeColor;
  padding-top: 10px;
}
.weiBang {
  width: 50px;
  padding: 2px 0;
  margin-top: 13px;
  text-align: center;
  float: right;
  line-height: 16px;
  font-size: 10px;
  color: #999999;
  background-color: #fdfdfd;
  border-radius: 9px;
  border: 1px solid #d8d8d8;
}
.yiBang {
  width: 50px;
  padding: 2px 0;
  margin-top: 13px;
  text-align: center;
  float: right;
  line-height: 16px;
  font-size: 10px;
  color: #333;
  background-color: #ffcc00;
  border-radius: 9px;
}
.top {
  width: 94%;
  margin: 0 auto;
  overflow: hidden;
  padding: 10px 0;
  border-bottom: 1px solid #d8d8d8;
  position: relative;
}
.tu_nav {
  width: 100%;
  background: #fff;
  padding: 10px 3%;
  margin: 10px auto;
  overflow: hidden;
}
.tu_nav .dl {
  width: 25%;
  float: left;
  text-align: center;
  line-height: 24px;
  color: #999999;
}
.tu_nav .dt {
  width: 24px;
  height: 24px;
  margin: 0 auto;
}
.tu_nav .dt img {
  width: 100%;
}
</style>
