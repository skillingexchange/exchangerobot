<template>
  <div   class="api_back" >
    <div  class="api_content van-cell van-cell--center" @click="$router.push('/authorize')">
      <i  class="api_icon van-cell__left-icon"
        ><img
          
          src="@/assets/images/index_api_auth_left.png"
          class="van-icon__image"
        /></i >
      <div  class="van-cell__title api_title">
        <span >{{$t('homeMenu.item1.title')}}</span>
        <div  class="van-cell__label api_label">{{$t('homeMenu.item1.sub')}}</div>
      </div>
      <div  class="van-image right_icon" >
        <img src="@/assets/images/index_api_auth_right.png" class="van-image__img" />
        <van-icon name="arrow" size="14"></van-icon>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { Icon } from 'vant';
export default {
  components: {
  },
  computed: {
    ...mapState({
      logged: ({ user }) => user.logged,
    }),
  },
  created() {},
  beforeDestroy() {},
  methods: {
    jump(url) {
      if (url !== '/market') {
        if (!this.logged) {
          this.$router.push({ path: '/sign/login' })
          return
        }
      }
      this.$router.push({ path: url })
    },
  },
}
</script>

<style scoped lang="less">
.api_back {
  background-color: #f7f7fb;
  padding: 10px 0;
}
.api_content {
  padding-right: 0 !important;
  max-height: 66px;
}
.api_icon {
  display: flex;
  width: 54px;
  height: 54px;
  margin-right: 10px;
}
.api_icon img {
  width: inherit;
  height: auto;
}
.api_title {
  font-size: 15px;
  color: #15181e;
  font-weight: 500;
}
.api_label {
  font-size: 13px;
  color: #666666;
  margin-top:0;
}
.nav-pic {
  background-color: #fff;
  margin: 10px 0;
  padding: 15px;
}
.nav-item {
  background: no-repeat 50% / cover;
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-radius: 6px;
  box-shadow: 0 5px 20px -8px rgba(0, 0, 0, 0.5);
  height: 80px;
  color: #fff;
  padding: 0 10px 10px;
}
.nav-item .title {
  font-size: 14px;
  font-weight: 600;
}
.nav-item .sub {
  font-size: 12px;
  opacity: 0.8;
  margin-top: 8px;
}
.van-cell__right-icon {
  font-size: 14px;
}
.van-field {
  line-height: 32px;
  padding: 8px 15px;
}
.right_icon{
  display: flex;
  align-items: center;
  margin-right:10px;
  img{
    width: 60px;
  }
}
</style>
