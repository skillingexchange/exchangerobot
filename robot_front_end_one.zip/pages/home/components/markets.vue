<template>
  <div class="markets_box" style="background-color: #fff">
    <!-- <div class="title">{{ $t('机器人') }}</div> -->
    <van-tabs
      v-model="active"
      swipeable
      animated
      sticky
      line-width="20px"
      :border="true"
    >
      <van-tab
        v-for="item in platform"
        :key="item.name"
      >
        <template #title>{{ $t(item.label) }}</template>
        <van-pull-refresh
          v-model="isLoading"
          @refresh="loadData"
        >
          <template v-if="robot_list[item.label] && robot_list[item.label].length > 0">
            <div
              v-for="robot in robot_list[item.label]"
              :key="robot.id"
            >
              <van-cell
                class="asset-item"
                @click="goDetail(robot)"
              >
                <div class="center">
                  <div class="name">
                    {{ robot.market_name }}
                    <van-tag
                      v-if="robot && robot.recycle_status == 1"
                      round
                      type="primary"
                    >{{ $t('ce') }}</van-tag>
                    <van-tag
                      v-if="robot && robot.recycle_status == 0"
                      round
                      type="primary"
                    >{{ $t('dan') }}</van-tag>
                  </div>
                  <div
                    v-if="robot"
                    class="info"
                  >
                    <p>{{ $t('yu') }}：{{ Number(robot.revenue) | numberFormat(5) }} {{ robot.money }}</p>
                    <p
                      v-if="robot.show_msg"
                      class="van-ellipsis"
                    >{{ $t('zui') }}：{{ robot.show_msg }}</p>
                  </div>
                  <div class="po">
                    <div :class="robot.lilv >= 0 ? 'zheng' : 'fushu'">{{
                    robot.lilv
                  }}%</div>
                  </div>
                </div>
              </van-cell>
            </div>
          </template>
          <van-empty
            v-else
            :description="$t('empty.run_robot')"
          />
        </van-pull-refresh>
      </van-tab>
    </van-tabs>

  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        ce: '循环策略',
        dan: '单次策略',
        yu: '预计收益',
        zui:'最新消息'
      },
      en: {
        ce: 'Circular Strategy',
        dan: 'Single Strategy',
        yu: 'Estimated Income',
        zui:'Latest News'
      },
    }
  },
  data () {
    return {
      active: 0,
      isLoading: false,
      robot_list: {},
    }
  },
  computed: {
    ...mapState({
      platform: ({ robot }) => robot.platform,
      robots: ({ robot }) => robot.robotList
    })
  },
  watch: {
    robots (values) {
      const list = values.filter(item => item.status === 1)
      this.platform.forEach((item) => {
        this.robot_list[item.label] = []
        for (const i in list) {
          if (list[i].platform === item.label) {
            this.robot_list[item.label].push(list[i])
          }
        }
      })
      this.$forceUpdate()
    }
  },
  mounted () {
    this.loadData()
  },
  methods: {
    ...mapActions({
      robotList: 'robot/robotList'
    }),
    loadData () {
      this.robotList().then(() => {
        this.isLoading = false
      })
    },
    goDetail (item) {
      this.$nextTick(() => {
        this.$router.push({
          name: 'robot',
          query: { market_id: item.market_id }
        })
      })
    },

  },

}
</script>

<style scoped lang="less">
/deep/ .van-tab{
  color: #333;
  font-weight: 700;
}
/deep/.van-tag--primary{
  background-color: @themeColor;
}
.title {
  background-color: #fff;
  padding: 10px 15px;
  font-size: 18px;
  font-weight: 600;
}
.fushu {

  background: #d14b64;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}
.zheng {

  background: #03ad90;
  color: #fff;
  width: 70px;
  text-align: center;
  border-radius: 8px;
  line-height: 36px;
}

.asset-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .left {
    flex-shrink: 0;
  }
  .center {
    flex-grow: 1;
    min-width: 0;
    position: relative;
  }
  .name {
    color: #333333;
    font-size: 16px;
    font-weight: 500;
  }
  .info {
    font-size: 12px;
    color: #888888;
  }
}
.po{
  position:absolute;
  right: 10px;
  top: 1px;
}
/deep/.van-tag--primary {
  color: @themeColor;
  background: #e3f1ff;
  border-radius: 4px;
  padding: 4px 5px;
}
</style>
