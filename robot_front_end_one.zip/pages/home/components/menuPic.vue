<template>
  <van-row class="nav-pic" type="flex" gutter="15">
    <!-- <van-col :span="12">
      <nuxt-link to="/authorize" class="nav-item" :style="{ 'background-image': `url(${image1})` }">
        <p class="title">{{ $t('homeMenu.item1.title') }}</p>
        <p class="sub">{{ $t('homeMenu.item1.sub') }}</p>
      </nuxt-link>
    </van-col> -->
    <van-col :span="12">
      <nuxt-link to="/home/revenue" class="nav-item" :style="{ 'background-image': `url(${image2})` }">
        <p class="title">{{ $t('homeMenu.item2.title') }}</p>
        <p class="sub">{{ $t('homeMenu.item2.sub') }}</p>
      </nuxt-link>
    </van-col>
    <van-col :span="12">
      <nuxt-link to="batch" class="nav-item" :style="{ 'background-image': `url(${image3})` }">
        <p class="title">{{ $t('homeMenu.item3.title') }}</p>
        <p class="sub">{{ $t('homeMenu.item3.sub') }}</p>
      </nuxt-link>
    </van-col>
    <!-- <van-col :span="12" @click="$toast('正在开发中 ')">
      <nuxt-link to="/home" class="nav-item" :style="{ 'background-image': `url(${image4})` }">
        <p class="title">{{ $t('homeMenu.item4.title') }}</p>
        <p class="sub">{{ $t('homeMenu.item4.sub') }}</p>
      </nuxt-link>
    </van-col> -->
  </van-row>
</template>

<script>
export default {
  data () {
    return {
      image1: require('@/assets/images/image1.png'),
      image2: require('@/assets/images/image2.png'),
      image3: require('@/assets/images/image5.png'),
      image4: require('@/assets/images/image6.png'),
    }
  }
}
</script>

<style scoped lang="less">
.nav-pic {
  background-color: #fff;
  // margin: 10px 0;
  padding: 15px 15px 0;
}
.nav-item {
  background: no-repeat center center/cover;
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-radius: 6px;
  box-shadow: 0 5px 20px -8px rgba(0, 0, 0, .5);
  height: 80px;
  color: #ffffff;
  padding: 0 10px 10px;
  .title {
    font-size: 14px;
    font-weight: 600;
  }
  .sub {
    font-size: 12px;
    opacity: 0.8;
    margin-top: 8px;
  }
}
/deep/.van-col{
  margin-bottom:10px;
}
</style>
