<template>
  <div>
    <div class="my">
        <div class="dian">{{ $t('title') }}  </div>
        <div class="zhang" @click="$router.push({ path: '/home/revenue' })">{{ $t('dian') }}</div>
    </div>
    <div class="detail-info">
      <van-row>
        <van-col span="20">
          <div class="detail-title">{{ $t('total1') }}</div>
          <div class="detail-amount">{{ detailInfo.cuc }}</div>
          <!-- <div class="detail-price">≈{{ currency.symbol }} {{ detailInfo.price }}</div> -->
        </van-col>
      </van-row>
      <!-- <div class="btn-group">
        <van-button
          plain
          type="primary"
          size="small"
          style="padding: 0 10px"
          @click="handleLink('/wallet/into')"
        >
          {{ $t('into') }}
        </van-button>
        <van-button
          plain
          type="info"
          size="small"
          style="padding: 0 10px"
          @click="handleLink('/wallet/transfer')"
        >
          {{ $t('transfer') }}
        </van-button>
      </div> -->
    </div>
    <div class="detail-info">
      <van-row>
        <van-col span="20">
          <div class="detail-title">{{ $t('total') }}（USDT）</div>
          <div class="detail-amount">{{detailInfo.cloud_balance}}</div>
          <!-- <div class="detail-price">≈{{ currency.symbol }} {{ detailInfo.price }}</div> -->
        </van-col>
        <van-col span="4">
          <van-icon :name="detailInfo.img_url" size="54" />
        </van-col>
      </van-row>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '我的资产',
        dian:'电子账单',
        total: '总资产折合',
        total1: 'CUC余额',
        receipt: '充币',
        withdraw: '提币',
        into:'转入',
        transfer:'转出',
        cuc:'CUC',
        usdt:'USDT',
        log_time:'时间'
      }
    }
  },
  data() {
    return {
      detailInfo: {},
      currency:'',
      coin_symbol:'',
    }
  },
  computed: {
    
  },
  created() {
    this.loadDetail()
  },
  methods: {
    ...mapActions({
      fundDetail: 'wallet/fundDetail',
      
    }),
    loadDetail() {
      this.fundDetail({
        currency: 'USD',
        coin_symbol: 'USDT',
      }).then(({ data }) => {
        this.detailInfo = data
      })
    },
  },
}
</script>
<style scoped lang="less">
.my{
    width:100%;
    padding: 0 3%;
    margin: 0 auto;
    line-height: 50px;
    font-size: 24px;
    color: #333;
    background: #fff;
    border-bottom: 1px solid #f8f8f8;
    overflow: hidden;
}
.my .dian{
    width: 80%;
    float: left;
}
.my .zhang{
    width: 20%;
    font-size: 14px;
    text-align: center;
    line-height:36px;
    margin: 7px 0;
    float: right;
    border-radius: 8px;
    background-color:#ed6a0c;
    color: #fff;
}
/deep/.van-icon{
    float: right;
    margin-top: 14px;
}
.margin {
  margin-bottom: 20px;
}
.van-ellipsis {
  display: inline-block;
  width: 80%;
}
.detail {
  &-info {
    background-color: #fff;
    padding: 10px;
  }
  &-title {
    font-size: 16px;
    color: #727272;
  }
  &-amount {
    margin-top: 6px;
    font-size: 28px;
  }
  &-price {
    font-size: 18px;
    color: #727272;
  }
}
.copy {
  &-wrap {
    margin-top: 10px;
    display: flex;
  }
}
.bill {
  &-title {
    font-size: 16px;
    padding: 10px 10px;
    border-left: 2px solid @themeColor;
    background-color: #eee;
  }
}
.btn {
  &-group {
    margin-top: 20px;
  }
}
.van-list {
  min-height: 300px;
}
</style>
