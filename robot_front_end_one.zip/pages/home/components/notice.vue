<template>
<div>
  <van-notice-bar :left-icon="require('@/assets/images/index_notice.png')" :scrollable="false" class="notice">
    <van-swipe vertical class="notice-swipe" :autoplay="3000" :show-indicators="false">
      <van-swipe-item v-for="item in notice" :key="item.id">
        <div class="van-ellipsis"  @click="$router.push({ path: '/information/information_detail?id=' + item.id })">
          {{ item.post_title }}
        </div>
      </van-swipe-item>
    </van-swipe>
    <!-- <van-icon class="quan" name="wap-nav" color="#ed6a0c" size="18" @click="$router.push('/home/components/notices')" /> -->
    <!-- <div class="quan" @click="$router.push('/home/components/notices')"><img src="@/assets/images/gao_list.png" alt=""></div> -->
    <div slot="right-icon" class="quan" @click="$router.push('/home/components/notices')">更多</div>
  </van-notice-bar>
</div>

  
</template>

<script>
import { Swipe, SwipeItem, NoticeBar } from 'vant'
import { mapActions } from 'vuex'
export default {
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    [NoticeBar.name]: NoticeBar
  },
  data () {
    return {
      notice: []
    }
  },
  mounted () {
    this.getNotice({ type: 1 }).then((res) => {
      this.notice = res.data.list
    })
  },
  methods: {
    ...mapActions({
      getNotice: 'getNotice'
    }),
    viewDetail (item) {
      this.$router.push({
        name: 'common-article',
        params: {
          url: item.visit_url,
          title: item.post_title
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
.notice-swipe {
  height: 40px;
  line-height: 40px;
}
/deep/ .van-notice-bar{
  background: #fff;
  color:#333;
  font-size: 13px;
  font-weight: 500;
}
/deep/ .van-notice-bar__content {
  width: 96%;
}
.quan{
  color:@themeColor;
}
</style>
