<template>
  <van-swipe class="rank_swipe"  indicator-color="white" :loop="false" @change="change">
    <van-swipe-item v-for="(item,index) in swiper_list" :key="index">
      <van-grid :column-num="3" :border="false">
        <van-grid-item
          v-for="item in item"
          :key="item.id"
          @click="$router.push('/ticker')"
          :border="false"
        >
          <div class="name">{{ item.coin }}/{{ item.currency }}</div>
          <div class="price" :class="item.change > 0 ?'price_sp':''">{{ item.price }}</div>
          <div
            class="change"
            :class="{red: item.change < 0, green: item.change > 0}"
          >
            {{ item.change > 0 ? `+${item.change}` : item.change }}%
          </div>
        </van-grid-item>
      </van-grid>
    </van-swipe-item>
    <template #indicator>
    <div class="custom_indicator" :style="{width:swiper_list.length*16 + 'px'}">
      <div class="custom_indicator_s" :style="{left:current*16 + 'px'}"></div>
    </div>
  </template>
  </van-swipe>
  
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { Grid, GridItem, Swipe, SwipeItem } from 'vant'
let timer = null
let isDestroy = false
export default {
  data(){
    return {
      current:0
    }
  },
  components: {
    [Grid.name]: Grid,
    [GridItem.name]: GridItem,
     [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
  },
  computed: {
    ...mapState({
      currency: ({ currency }) => currency,
      swiper_list: ({ ticker }) => {
        let data = [...ticker.list]
        let list = []
        for(let index=0; index < data.length; index ++){
          if(index >= 9 ) break;
          if((index+1)%3 == 0){
            let i = 2,list1 = []
            while(i>=0){
              list1.push(data[index-i])
              i--
            }
            list.push(list1)
          }
        }
        return list
      }
    })
  },
  created () {
    isDestroy = false
    this.loadData()
  },
  beforeDestroy () {
    isDestroy = true
    clearTimeout(timer)
  },
  methods: {
    ...mapActions({
      getTickerList: 'ticker/getTickerList'
    }),
    loadData () {
      this.getTickerList({
        currency: this.currency.name,
        order: 'price',
        order_type: 'desc'
      }).finally(() => {
        if (isDestroy) { return }
        clearTimeout(timer)
        timer = setTimeout(() => {
          this.loadData()
        }, 1000)
      })
    },
    change(e){
      this.current = e
    }
  }
}
</script>

<style scoped lang="less">
.name {
  font-size: 12px;
  font-weight: bold;
}
.price {
  margin: 5px 0;
  font-size: 16px;
  color: #D54567;
  font-weight: bold;
}
.price_sp{
  color:#10AD92;
  font-weight: bold;
}
.change {
  font-size: 16px;
  &.red {
    color: #D54567;
    font-weight: bold;
  }
  &.green {
    color: #10AD92;
    font-weight: bold;
  }
}
.rank_swipe{
  height: 90px;
  padding-bottom: 10px;
  box-sizing: initial;
}
.custom_indicator{
  position: absolute;
  bottom:10px;
  left:50%;
  transform: translateX(-50%);
  min-width: 16px;
  background: #f1f1f1;
  height: 3px;
  border-radius: 10px;
  position: relative;
  display: inline-block;
  .custom_indicator_s{
    width:16px;
    height: 3px;
    background: @themeColor;
    border-radius: 10px;
    position: absolute;
    left: 0;
    transition: all 0.5s;
  }
}
</style>
