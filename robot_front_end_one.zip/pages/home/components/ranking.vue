<template>
  <div>
    <div class="pai">{{ $t('title') }}</div>
    <van-tabs v-model="active" @click="orderClick">
      <van-tab :title="$t('ri')" name='1'></van-tab>
      <van-tab :title="$t('zong')" name=''></van-tab>
    </van-tabs>
    <div class="list">
      <div class="pai_list" v-for="(val, key) in robotList" :key="key"  >
        <div class="key">{{key+1}}</div>
        <div class="img"><img :src="val.avatar" alt="" /></div>
        <div class="list_cen">
          <div class="name">{{val.user_nickname}}</div>
          <div class="one">{{ $t('di') }}{{key+1}}{{ $t('ming') }}</div>
        </div>
        <div class="list_right"><span class="yi">{{ $t('ying') }}:</span><span class="li">{{ Number( val.total) | numberFormat(6)}}</span></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  i18n: {
    messages: {
      zh: {
        title: '排行榜',
        ri: '日榜',
        zong: '总榜',
        ying:'盈利',
        di:'第',
        ming:'名'
      },

    },
  },
  data() {
    return {
      finished:false,
      loading:false,
      limit:10,
      robotList:"",
      active:'',
      type:1,
    }
  },
  methods: {
    orderClick(e) {
      // console.log(this.active)
      this.type = this.active
      // this.type = active;
      this.getList();
    },
     // 排行榜
    getList() {
      var that = this;
      this.$axios
        .post("/api/quant/robot/top", {
          type:this.type,
          limit:this.limit,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data)
            that.robotList = ret.data.data.list;
          } else {
            that.$toast.fail(ret.data.msg);
          }
        });
    },
  },
  mounted() {
     this.getList();
  }
}
</script>

<style scoped lang="less">
/deep/.van-tabs__nav--line {
  width: 94%;
  margin: 0 auto;
  background: url(~@/assets/images/bg_c.png) no-repeat center;
  color: #fff;
}
/deep/.van-tab--active {
  color: #fff;
}
/deep/.van-tab {
  color: #fff;
}
.pai {
  width: 94%;
  margin: 0 auto;
  overflow: hidden;
  font-size: 20px;
  color: #333;
  line-height: 28px;
  font-weight: bold;
  margin-bottom: 10px;
}
.list {
  width: 94%;
  overflow: hidden;
  margin: 20px auto;
  background: #ffffff;
  box-shadow: 0px 0px 10px rgba(191, 191, 191, 0.16);
  border-radius: 4px;
}
.list .pai_list:nth-child(1) .key{
  background: url(~@/assets/images/one.png) no-repeat left;
  background-size: 100%;
  font-size: 0;
}
.list .pai_list:nth-child(2) .key{
  background: url(~@/assets/images/two.png) no-repeat left;
  background-size: 100%;
  font-size: 0;
}
.list .pai_list:nth-child(3) .key{
  background: url(~@/assets/images/three.png) no-repeat left;
  background-size: 100%;
  font-size: 0;
}
.pai_list {
  width: 94%;
  margin: 20px auto;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding-bottom:20px;
  border-bottom: 1px solid #F4F4F4;

}
.list .pai_list:last-child{
  border-bottom:none
}
.key {
  width: 24px;
  height: 24px;
  font-size: 20px;
  color: @themeColor;
  font-weight: bold;
  text-align: center;
}
.img {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  margin: 0 10px;
  overflow: hidden;
}
.img img{
  width: 100%;
}
.list_cen {
  width:30%;
  color: #999999;
  font-size: 12px;
}
.name {
  font-size: 14px;
  color: #333333;
  line-height: 20px;
}
.list_right {
  width:40%;
  color: #333;
  font-size: 14px;
  overflow: hidden;
}
.list_right span.yi {
  display: block;
  float: left;
  width: 27%;
  color: #999999;
  font-size: 12px;
}
.list_right span.li {
  width:70% ;
  float: left;

//  overflow: hidden;
// white-space: nowrap;
// text-overflow: ellipsis;
}
</style>
