<template>
  <div data-v-48470b50="" class="home_head">
    <div data-v-48470b50="" class="left">
      <div data-v-48470b50="" class="van-image" style="width: 30px; height: 30px" @click="jump('/user/settings')">
        <img src="@/assets/images/touxiang.png" class="van-image__img" />
      </div>
    </div>
    <div data-v-48470b50="" class="home_search" @click="jump('/market')">
      <div data-v-48470b50="" class="van-image" style="width: 20px; height: 20px">
        <img src="@/assets/images/search.png" class="van-image__img" />
      </div>
      <span data-v-48470b50="">{{$t('homeSearch.placeholder')}}</span>
    </div>
    <div data-v-48470b50="" class="home_news" @click="jump('/information')">
      <div data-v-48470b50="" class="van-image" style="width: 30px; height: 30px">
        <img src="@/assets/images/detail.png" class="van-image__img" />
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  components: {},
  computed: {
    ...mapState({
        logged: ({user}) => user.logged
    })
  },
  created() {},
  beforeDestroy() {},
  methods: {
      jump(url){
          if(url !== '/market'){
              if(!this.logged){
                  this.$router.push({ path: '/sign/login' })
                  return
              }
          }
          this.$router.push({ path: url })
      }
  },
}
</script>

<style scoped lang="less">
.home_back {
  min-height: 100vh;
  background-color: #fff;
  padding-top: 55px;
}
.home_head {
  display: flex;
  justify-content: space-between;
  padding: 10px 20px;
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  z-index: 99;
  background-color: #fff;
}
.home_head .home_search {
  display: flex;
  background-color: #eff1f3;
  align-items: center;
  padding: 0 10px;
  border-radius: 20px;
  width: 100%;
}
.home_head .home_search span {
  margin-left: 5px;
  color: #8f9eab;
}
.home_head .left {
  margin-right: 12px;
}
.home_head .home_news {
  margin-left: 15px;
}
.home_swiper {
  padding: 2px 16px 10px;
  background-color: #fff;
}
.home_swiper .swiper_content {
  border-radius: 10px;
  overflow: hidden;
  position: relative;
  will-change: transform;
  transform: translateY(0);
}
.my-swipe {
  height: 40vw;
  width: 100%;
  overflow: hidden;
  border-radius: 10px;
}
.van-swipe-item {
  font-size: 0;
}
.quo_font {
  font-family: fonthoubi;
}
.page-header {
  background-color: #fff;
  height: 46px;
  padding: 0 15px;
}
.page-header-right .van-icon {
  display: inline-block;
  vertical-align: middle;
}
.page-header-title {
  font-size: 22px;
  line-height: 1;
  color: #333;
}
.page-header-title,
 .ticker-item .left {
  display: flex;
  align-items: center;
}
 .ticker-item .left p {
  font-size: 15px;
}
 .ticker-item .left p span {
  color: #cdcfd2;
  font-size: 12px;
  margin-left: 5px;
}
 .ticker-item .van-image__img {
  width: 32px;
  margin-right: 10px;
  border-radius: 50%;
}
 .ticker-item .right {
  text-align: right;
  line-height: 1.2;
  font-size: 15px;
}
 .ticker-item .right .price_cny {
  font-size: 13px;
  color: #8f9eab;
}
.hq-red {
  background-color: #d24c67;
}
.hq-green {
  background-color: #04ad94;
}
.head {
  padding: 10px 16px;
  background-color: #fff;
}
.head_right {
  text-align: right;
}
.head_span {
  position: relative;
  margin-right: 15px;
}
.head_span.active1:before {
  border-bottom-color: #0080ff;
}
.head_span.active2:after {
  border-top-color: #0080ff;
}
.head_span:before {
  border-bottom: 5px solid #cdcfcf;
  top: 2px;
}
.head_span:after,
.head_span:before {
  content: '';
  width: 0;
  height: 0;
  border-left: 4px solid transparent;
  border-right: 4px solid transparent;
  position: absolute;
  right: -13px;
}
.head_span:after {
  border-top: 5px solid #cdcfcf;
  bottom: 2px;
}
.ticket_btn {
  padding: 0 10px !important;
  color: #fff;
  border-radius: 5px;
  font-size: 15px;
  width: 70px;
}
.van-cell__right-icon {
  font-size: 14px;
}
.van-field{
  line-height: 32px;
  padding: 8px 15px;
}
</style>
