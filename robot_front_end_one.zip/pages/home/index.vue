<template>
  <div class="home" style="padding-top:53px;">
    <!-- <van-search
        v-model="keyword"
        shape="round"
        background="#fff"
        placeholder="请输入搜索关键词"
       @click="$router.push({ path: '/market' })"
      /> -->
    <m-search ></m-search>
    <div class="swiper_index">
        <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
          <van-swipe-item v-for="item in banner.list" :key="item.id">
            <van-image height="165px"  fit="cover" :src="item.image" />
          </van-swipe-item>
        </van-swipe>
    </div>

    <notice></notice>


    <rank v-if="is_hangqing"></rank>
    <apiAuth></apiAuth>
    <menu-pic></menu-pic>
    <!-- <ranking></ranking> -->
    <!-- api -->

    <markets></markets>
    <!-- <myAssets></myAssets> -->
  </div>
</template>
<script>
import { Swipe, SwipeItem } from 'vant'
import { mapState, mapActions } from 'vuex'
import Vue from 'vue'
import { Search } from 'vant'

Vue.use(Search)
import notice from './components/notice'
import rank from './components/rank'
import menuPic from './components/menuPic'
// import myAssets from './components/myAssets'
import markets from './components/markets'
import ranking from './components/ranking'

import mSearch from './components/search'
import apiAuth from './components/apiAuth'

export default {
  layout: 'navigation',
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    notice,
    rank,
    menuPic,
    // myAssets,
    markets,
    ranking,

    mSearch,
    apiAuth
  },
  data () {
    return {
      keyword:'',
      is_hangqing:false,
    }
  },
  computed: {
    ...mapState({
      banner: index => index.banner,
      initInfo:(index)=>index.initInfo,
      platform: ({ robot }) => robot.platform,
    })
  },
  mounted () {
    this.getBanner()
    this.$store.commit('setSelectPlatform',this.platform[0].label)
    if(this.initInfo.switch_hangqing==1){
      this.is_hangqing=true
    }else{
      this.is_hangqing=false
    }
  },

  methods: {
    ...mapActions({
      getBanner: 'getBanner'
    }),
    viewDetail (item) {
      this.$router.push({
        name: 'common-article',
        params: {
          url: item.url,
          title: item.title
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
.home{
  padding-bottom: 60px!important;
}
/deep/.van-search{
  padding-top: 15px;
}
/deep/.van-search__content{
  background-color: #e9e9e9;
}
.my-swipe {
  height: 165px;
  border-radius: 10px;
}
.van-swipe-item {
  font-size: 0;
}
.tu_nav{
  width:100%;
  background: #fff;
  padding: 0 3%;
  margin:10px auto;
  overflow: hidden;
}
.tu_nav .dl{
  width: 25%;
  float: left;
  text-align: center;
  line-height: 24px;
  color: #333;
}
.tu_nav .dt img{
  width: 58%;
}

.swiper_index{
  padding:2px 16px 10px;
  background: #fff;
}
.swiper_box{
  border-radius: 10px;
}
</style>
