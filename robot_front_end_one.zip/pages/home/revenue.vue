<template>
  <div class="page page_revenue">
    <div class="color_bg"></div>
    <div class="pofe" ref="ele">
      <div class="topbox">
        <div class="top_bg">
          <van-nav-bar fixed placeholder left-arrow :title="$t('bill')" @click-left="$router.back()" />
          <div class="boxv">
            <div class="boxe left">
              <div class="value">{{Number(all.today_revenues).toFixed(5)}}</div>
              <div class="label">{{ $t('jin') }}(USDT)</div>
            </div>
            <div class="boxe">
              <div class="value">{{Number(all.month_revenues).toFixed(5)}}</div>
              <div class="label">{{ $t('yue') }}(USDT)</div>
            </div>
            <div class="boxe right">
              <div class="value">{{Number(all.total_revenues).toFixed(5)}}</div>
              <div class="label">{{ $t('lei') }}(USDT)</div>
            </div>
          </div>
        </div>
      </div>
      <div class="" style="position: relative;z-index: 200;background-color: #FFFFFF;border-radius: 21px 21px 0 0;">
        <div class="newadd">
          <div class="nep">
            <div @click="tabChange('hy', 1)" :class="types == 1 ? 's1_s' : 's1'">现货</div>
            <div @click="tabChange('hy', 2)" :class="types == 2 ? 's1_s' : 's1'">合约</div>
          </div>
        </div>
        <div class="total-card" type="flex" gutter="20">
          <div class="total-item s1" @click="tabChange(1)" :class="type == 1 ? 's1_s' : ''">
            <div class="value">{{ Number(today_revenue).toFixed(5) }}</div>
            <div class="label">{{ $t('jin') }}(USDT)</div>
          </div>
          <div class="total-item s2" @click="tabChange(2)" :class="type == 2 ? 's1_s' : ''">
            <div class="value">{{ Number(total_revenue).toFixed(5) }}</div>
            <div class="label">{{ $t('lei') }}(USDT)</div>
          </div>
        </div>
      </div>
    </div>
    <div id="" class="newbox" :style="{top: top}">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list v-model="loading" :finished="finished" :finished-text="$t('finished_text')" @load="onLoad">
          <van-cell v-for="item in orderList" :key="item.id">
            <div class="robot-item flex">
              <!-- <div class="row">
              <div class="name">{{ item.market }}</div>
              <div>{{ $t('shou') }}：{{ Number(item.revenue) | numberFormat(8) }}</div>
            </div>
            <div class="row">
              <div>{{ $t('ping') }}：{{ item.platform }}</div>
              <div class="time">{{ item.ctime }}</div>
            </div> -->
              <div class="row_sp">
                <div class="name">{{ item.market }}</div>
                <!-- <div class="name" v-if="type == 1">{{ item.market }}</div> -->
                <div class="time">{{ item.ctime }}</div>
              </div>
              <div class="row row_sp1">
                <div>+{{ Number(item.revenue) | numberFormat(8) }}</div>
              </div>
            </div>
          </van-cell>
        </van-list>
        <van-empty v-if="orderList.length == 0" :description="$t('empty.bill')" />
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
  import {
    mapActions
  } from 'vuex'
  export default {
    i18n: {
      messages: {
        zh: {
          jin: '今日盈利',
          yue: '本月盈利',
          lei: '累计盈利',
          shou: '收益',
          ping: '平台',
          bill: '盈亏分析',
        },
        en: {
          jin: "Today's earnings",
          yue: 'Month earnings',
          lei: 'Total earnings',
          shou: 'Income',
          ping: 'Platform',
          bill: 'P/L Analyse',
        },
      },
    },
    data() {
      return {
        loading: false,
        finished: false,
        refreshing: false,
        orderList: [],
        offset: 0,
        limit: 20,
        today_revenue: 0,
        total_revenue: 0,
        type: 1,
        types: 1,
        all: '',
        top: '40%'
      }
    },
    methods: {
      ...mapActions({
        robotRevenue: 'robot/robotRevenue',
      }),
      loadList() {
        if (this.refreshing) {
          this.orderList = []
          this.offset = 0
          this.finished = false
          if (this.loading) {
            this.loading = false
            return
          }
        }
        if (this.loading) {
          this.refreshing = false
        }
        const payload = {
          limit_begin: this.offset,
          limit_end: this.limit,
          type: this.type,
          types: this.types,
        }
        this.robotRevenue(payload)
          .then(({
            data
          }) => {
            if (!data) {
              this.loading = false
              this.finished = true
              return
            }
            this.total_revenue = data.total_revenue
            this.today_revenue = data.today_revenue
            this.all = data
            const list = data.data
            if (list.length < this.limit) {
              this.finished = true
            } else {
              this.offset += this.limit
            }
            this.orderList = this.orderList.concat(list)
          })
          .finally(() => {
            this.loading = false
            this.refreshing = false
          })
      },
      onLoad() {
        this.top = window.getComputedStyle(this.$refs.ele).height
        this.loadList()
      },
      onRefresh() {
        this.loadList()
      },
      tabChange(e, index) {
        if (!index) {
          if (e == this.type) return
        }
        if (index) {
          if (index == this.types) return
        }
        this.orderList = []
        this.offset = 0
        this.finished = false
        this.loading = true
        if (!index) {
          this.type = e
        }
        if (index) {
          this.types = index
        }
        // this.types = index
        this.loadList()
      },
    },
  }
</script>
<style scoped lang="less">
  .page_revenue {
    height: 100vh;
    display: flex;
    flex-direction: column;
    // overflow: hidden;
    background-color: #FFFFFF;
  }

  .pofe {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 200;
  }

  .flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .robot-item {
    font-size: 12px;
    color: #666;

    .row {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .name {
      font-weight: 500;
      font-size: 1.125rem;
      font-weight: 600;
    }

    .time {
      font-size: 0.75rem;
    }
  }

  .total-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    padding: 0 21px;
    // transform: translateY(40px);
  }

  .total-item {
    position: relative;
    width: 50%;
    margin: 0;
    flex: 1;
    // box-shadow: 0 0 20px -8px rgba(0, 0, 0, 0.2);
    // box-shadow: 0 6px 20px rgba(0,0,0,0.15);
    padding: 0.6875rem 1.0625rem;
    font-weight: 500;
    color: #333;
    border-radius: 5px;
    overflow: hidden;
    background-size: 100% 100%;
    font-size: 0.75rem;

    // &::before {
    //   content: '';
    //   position: absolute;
    //   top: 50%;
    //   left: 60%;
    //   width: 40vw;
    //   height: 40vw;
    //   border-radius: 50%;
    //   background-color: rgba(255, 255, 255, 0.2);
    // }
    // &::after {
    //   content: '';
    //   position: absolute;
    //   bottom: 50%;
    //   left: -30%;
    //   width: 20vw;
    //   height: 20vw;
    //   border-radius: 50%;
    //   background-color: rgba(255, 255, 255, 0.2);
    // }
    &.s1 {
      background: #F5F6FB;
      border-radius: 10px;
      height: 4.5625rem;
      margin-right: 1.75rem;
    }

    &.s2 {
      background: #F5F6FB;
      border-radius: 10px;
      height: 4.5625rem;
      // text-align: right;
    }

    &.s1_s {
      background: #E3EAFF;
      /* 主题色 */
      border: 2px solid #3366FF;
    }

    .label {
      position: relative;
      color: #64748B;
      font-size: 0.75rem;
    }

    .value {
      position: relative;
      font-size: 1.25rem;
      margin-bottom: 0.1875rem;
    }
  }

  .topbox {
    // background: #fff;
    // position: sticky;
    // top: 0;
    padding-bottom: 1.0625rem;
    z-index: 1;
  }

  .top_bg {
    width: 100%;
    // height: 150px;
    // background: url(~@/assets/images/bg_profit_top.png) no-repeat center;
    background-size: 100% 100%;
    position: relative;

    /deep/ .van-nav-bar {
      background: transparent;

      .van-icon,
      .van-nav-bar__title {
        color: #fff;
      }
    }

    /deep/ .van-nav-bar:after {
      border: 0;
    }
  }

  /deep/.van-pull-refresh {
    z-index: 100;
    background-color: #fff;
    // flex: 1;
  }

  .color_bg {
    background: url(~@/assets/images/beij.png) no-repeat center;
    background-size: 100% 100%;
    position: fixed;
    width: 100%;
    height: 14.0625rem;
    top: 0;
    left: 0;
    z-index: 150;
    // border-radius: 0 0 50% 50%;https://www.figma.com/verify?fuid=1115809687823008577
  }

  .row_sp1 {
    font-size: 1.25rem;
    font-weight: 700;
    color: #58BD7D;
  }

  .row_sp {
    text-align: left;
  }

  .newbox {
    background-color: #FFFFFF;
    z-index: 100;
    position: absolute;
    top: 40%;
    left: 0;
    width: 100%;
    // border-radius: 21px 21px 0 0;
  }

  .boxv {
    margin: 0.8rem auto 0;
    width: 95%;
    height: 6.875rem;
    background: #FFFFFF;
    padding: 0 1.0625rem;
    box-shadow: 0px 3px 10px rgba(204, 204, 204, 0.3);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .boxe {
      width: 34%;
      border-left: 1px solid #ECEDF0;
      border-right: 1px solid #ECEDF0;
      text-align: center;
      height: 3.4375rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .left {
      text-align: left;
      border: none;
      width: 32%;
    }

    .right {
      text-align: right;
      border: none;
      width: 32%;
    }

    .value {
      font-weight: 700;
      font-size: 1.25rem;
      margin-bottom: 0.1875rem;
      width: 100%;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .label {
      color: #55555D;
      font-size: 0.875rem;
    }
  }

  .newadd {
    // position: absolute;
    // top: 3.5rem;
    // left: 0;
    padding: 1.0625rem;
    width: 100%;
    // justify-content: space-around;
    font-size: 0.875rem;
    color: #000;

    .nep {
      display: flex;
      align-items: center;
      background: #F5F5F5;
      width: 12.4375rem;
      height: 2.4375rem;
      border-radius: 0.5rem;
      padding: 0;

      div {
        width: 50%;
        text-align: center;
        border-radius: 0.5rem;
        height: 2.4375rem;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }

    div {
      padding: 0.375rem 1rem;
      border-radius: 5px;
    }

    .s1 {
      background-color: transparent;
    }

    .s1_s {
      background-color: #3366FF;
      color: #FFFFFF;
    }
  }
</style>
