<template>
  <div class="page page_revenue">
    <van-nav-bar fixed placeholder left-arrow :title="$t('bill')" @click-left="$router.back()" />
    <!-- <div class="total-card" type="flex" gutter="20">
      <div class="total-item s1">
        <div class="label">{{ $t('jin') }}(USDT)</div>
        <div class="value">{{ Number(today_revenue).toFixed(6) }}</div>
      </div>
      <div class="total-item s2">
        <div class="label">{{ $t('lei') }}(USDT)</div>
        <div class="value">{{ Number(total_revenue).toFixed(6) }}</div>
      </div>
    </div> -->
     <div class="top_card">
      <div class="top_card_box flex">
          <van-tabs type="card" class="tabs_sp" @change="tabChange">
            <van-tab :title="$t('jin')" name="1"></van-tab>
            <van-tab :title="$t('lei')" name="2"></van-tab>
          </van-tabs>
          <div class="value">
            <p >{{ type==1?Number(today_revenue).toFixed(6):Number(total_revenue).toFixed(6) }}</p>
            <p class="label">{{$t('lei')}}（{{money}}）</p>
          </div>
      </div>
      
    </div>
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="$t('finished_text')"
        @load="onLoad"
      >
        <van-cell v-for="item in orderList" :key="item.id">
          <div class="robot-item flex">
            <!-- <div class="row">
              <div class="name">{{ item.market }}</div>
              <div>{{ $t('shou') }}：{{ Number(item.revenue) | numberFormat(8) }}</div>
            </div>
            <div class="row">
              <div>{{ $t('ping') }}：{{ item.platform }}</div>
              <div class="time">{{ item.ctime }}</div>
            </div> -->
             <div class="row_sp">
              <div class="name" v-if="type==1">{{ item.market }}</div>
              <div class="time">{{ item.ctime }}</div>
            </div>
            <div class="row row_sp1">
              <div>+{{ Number(item.revenue) | numberFormat(8) }}</div>
            </div>
           
          </div>
        </van-cell>
      </van-list>
      <van-empty v-if="orderList.length == 0" :description="$t('empty.bill')" />
    </van-pull-refresh>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
   i18n: {
    messages: {
      zh: {
        jin: '今日盈利',
        lei:'累计盈利',
        shou:'收益',
        ping:'平台'
      },
      en: {
        jin: "Today's earnings",
        lei:'Total earnings',
        shou:'Income',
        ping:'Platform'
      },
    },
  },
  data() {
    return {
      loading: false,
      finished: false,
      refreshing: false,
      orderList: [],
      offset: 0,
      limit: 20,
      today_revenue: 0,
      total_revenue: 0,
      money:'USDT',
      type:'1'
    }
  },
  methods: {
    ...mapActions({
      robotRevenue: 'robot/robotRevenue',
    }),
    loadList() {
      if (this.refreshing) {
        this.orderList = []
        this.offset = 0
        this.finished = false
        if (this.loading) {
          this.loading = false
          return
        }
      }
      if (this.loading) {
        this.refreshing = false
      }
      const payload = {
        limit_begin: this.offset,
        limit_end: this.limit,
        type:this.type
      }
      this.robotRevenue(payload)
        .then(({ data }) => {
          if (!data) {
            this.loading = false
            this.finished = true
            return;
          }
          this.total_revenue = data.total_revenue
          this.today_revenue = data.today_revenue
          const list = data.data
          if (list.length < this.limit) {
            this.finished = true
          } else {
            this.offset += this.limit
          }
          this.orderList = this.orderList.concat(list)
        })
        .finally(() => {
          this.loading = false
          this.refreshing = false
        })
    },
    onLoad() {
      this.loadList()
    },
    onRefresh() {
      this.loadList()
    },
    tabChange(e){
      if(e == this.type) return;
      this.orderList = []
      this.offset = 0
      this.finished = false
       this.loading = true
      this.type = e
      this.loadList()
    }
  },
}
</script>

<style scoped lang="less">
.robot-item {
  font-size: 12px;
  color: #666;
  .row {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .name {
    font-weight: 500;
    font-size: 14px;
  }
}
.total-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  margin-bottom: 10px;
  padding: 12px 5px;
}
.total-item {
  position: relative;
  width: 50%;
  margin: 0 8px;
  flex: 1;
  box-shadow: 0 0 20px -8px rgba(0, 0, 0, 0.2);
  padding: 15px;
  font-weight: 500;
  color: #fff;
  border-radius: 5px;
  overflow: hidden;
  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 60%;
    width: 40vw;
    height: 40vw;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.2);
  }
  &::after {
    content: '';
    position: absolute;
    bottom: 50%;
    left: -30%;
    width: 20vw;
    height: 20vw;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.2);
  }
  &.s1 {
    // background: linear-gradient(45deg, rgb(146, 211, 217), rgb(81, 185, 195))
    background: url(~@/assets/images/image3.png) no-repeat center;
  }
  &.s2 {
    // background: linear-gradient(45deg, rgb(150, 201, 252), rgb(87, 165, 251))
    background: url(~@/assets/images/image4.png) no-repeat center;
  }
  .label {
    position: relative;
  }
  .value {
    position: relative;
    margin-top: 5px;
    font-size: 1.4em;
  }
}

.flex{
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.top_card{
  padding:10px 15px;
  .top_card_box{
    border-radius: 20px;
    background:linear-gradient(to right, @themeColor, @themeColor) ;
    padding:15px 10px 20px;
    justify-content: center;
    flex-direction: column;
  }
  .tabs_sp{
    width: 60%;
  }
  .value{
    text-align: center;
    margin-top:20px;
    color:#fff;
     font-size:20px;
     font-weight: 700;
  }
  .label{
    font-size: 12px;
    font-weight: 400;
  }
  @color:#0000FF;
  /deep/ .van-tabs__nav{
    border-color: @color;
    border-radius: 6px;
    overflow: hidden;
    padding: 2px;
    background:  @color;
   
   
  }
    /deep/.van-tab{
      font-size: 11px;
      color:#fff;
       background:  @color;
      border-color: @color;
    }
   /deep/.van-tab--active{
      color:#333;
      background: #fff;
      border-color: @color;
      border-radius: 6px;
    }
  
 
  /deep/.van-tabs--card > .van-tabs__wrap{
     height: 35px;
  }
  /deep/.van-tabs__nav--card{
    height: 35px;
  }
}
.row_sp{
  text-align: right;
}
.row_sp1{
  font-size: 15px;
  font-weight: 700;
}
</style>
