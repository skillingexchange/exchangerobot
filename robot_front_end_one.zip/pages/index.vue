<template>
  <nuxt />
</template>

<script>
import { mapActions } from 'vuex'
import { Dialog } from 'vant'
export default {
  data () {
    return {
      authToken: this.$route.query.token
    }
  },
  created () {
    this.needAuth()
    this.add()
  },
  methods: {
    ...mapActions({
      openAuthLogin: 'user/openAuthLogin',
      getUserInfo: 'user/getUserInfo',
    }),
    needAuth () {
      if (this.authToken) {
        this.$toast.loading('身份验证中...')
        this.openAuthLogin({ token: this.authToken })
          .then(() => {
            this.getUserInfo()
            this.$toast('授权登录成功')
            this.$router.push('/home')
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
      } else {
        this.$router.push('/home')
      }
    },
    add() {
      this.$axios
        .post('/api/wallet/account/amount', { currency: 'USD', coin_symbol: 'USDT' })
        .then(function (ret) {
          console.log(ret.data.data);
          if (ret.data.data.amount) {
            Dialog.alert({
              title: '提示',
              message: '你的余额不足，请及时充值',
            }).then(() => {
              // on close
            })
          }
        })
    },
  }
}
</script>
