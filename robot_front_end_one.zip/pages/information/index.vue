<template>
  <div class="page_information ">
    <div safe-area-inset-top>
      <van-row
        type="flex"
        justify="space-between"
        align="center"
        class="page-header"
      >
        <van-col class="page-header-left">
          <h2 class="page-title">{{ $t('nav.information') }}</h2>
        </van-col>
      </van-row>
    </div>
    <van-cell-group :border="false">
      <!-- <van-cell
        :title="$t('info')"
        is-link
        to="/user/settings/personal"
      /> -->
      <div class="zi_dl" v-for="(val,key) in integralList.list " :key='key' @click="$router.push({ path: '/information/information_detail?id=' + val.id })" >
        <div class="dd">
            <div class="zi_title">{{val.post_title}}</div>
            <div class="zi_time">{{val.create_time}}</div>
        </div>
        <div class="dt"><img :src="val.thumbnail" alt=""></div>
      </div>
      
    </van-cell-group>
     <van-empty
        v-if="integralList.list&&integralList.list.length === 0"
        :description="$t('empty.default')"
      />
  </div>
</template>

<script>
import { Dialog } from 'vant'
import { mapState, mapActions } from 'vuex'
export default {
  layout: 'navigation',
  i18n: {
    messages: {
      zh: {
        information:'学院'
      },
      
    }
  },
  data() {
    return {
      integralList:{},
      page: 1,
      limit:10,
    };
  },
  computed: {
    // ...mapState({
    //   userInfo: ({ user }) => user.userInfo,
    //   thirdLoginEnabled: ({ thirdLoginEnabled }) => thirdLoginEnabled
    // })
  },
  
  methods: {
    // 资讯列表  
    getLists() {
      var that = this;
      this.$axios 
        .post("api/user/articles/lists", {
          
          page: this.page,
          limit:this.limit,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data);
            that.integralList = ret.data.data;
          } else {
            that.$toast.fail(ret.data.msg);
          }
        });
    }
  },
   mounted() {
    this.getLists();
  },
}
</script>

<style scoped lang="less">
.page_information{
  padding-bottom: 60px!important;
}
.page-header {
  background-color: @themeColor;
  height: 66px;
  padding: 0 15px;
  color: #fff;
  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}
.zi_dl{
  width: 94%;
  margin: 0 auto;
  overflow: hidden;
  border-bottom:1px solid #ebedf0;
}
.zi_dl:last-child{
  border-bottom: none;
}
.zi_dl .dd{
  width:70%;
  float: left;
  margin: 10px 0;
}
.zi_dl .zi_title{
  font-size: 16px;
  color: #323233;
  line-height: 24px;
}
.zi_dl .zi_time{
  margin-top: 30px;
  font-size: 14px;
  color: #999;
  line-height: 24px;
}
.zi_dl .dt{
  width:30%;
  height: 80px;
  overflow: hidden;
  float: right;
  margin: 10px 0;
  border-radius: 8px;
  background: #ebedf0;
}
.zi_dl .dt img{
  width:100%;
}
</style>
