<template>
  <div class="page page_infomation_detail">
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <van-cell-group :border="false">
      <div class="center" v-html="Listdetail.post_content" v-if="Listdetail.post_content"></div>
      <div class="center" v-html="Listdetail.post_content" v-else></div>
    </van-cell-group>
  </div>
</template>

<script>
import { Dialog } from 'vant'
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '详情',
      },
      en: {
        title: 'Detail',
      },
    },
  },
  data() {
    return {
      Listdetail: '',
      id: '',
    }
  },
  computed: {},
  methods: {
    // 资讯详情
    getLists() {
      var that = this
      console.log(this.$route.query)
       if (this.$route.query.nid) {
        this.$axios.post('api/user/articles/gettutorial', {}).then(function (ret) {
          if (that.$route.query.id == '0') {
            for (let i = 0; i < ret.data.data.list.length; i++) {
              if (ret.data.data.list[i].id == 13) {
                ret.data.data.list[i].post_content = that.showHtml(
                  ret.data.data.list[i].post_content
                )
                that.Listdetail = ret.data.data.list[i]
              }
            }
          }
          if (that.$route.query.id == '1') {
            for (let i = 0; i < ret.data.data.list.length; i++) {
              if (ret.data.data.list[i].id == 11) {
                ret.data.data.list[i].post_content = that.showHtml(
                  ret.data.data.list[i].post_content
                )
                that.Listdetail = ret.data.data.list[i]
              }
            }
          }
          console.log(that.Listdetail)
        })
        return
      }
      this.$axios
        .post('api/user/articles/details', {
          id: that.$route.query.id,
        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data)
            that.Listdetail = ret.data.data.list
          } else {
            that.$toast.fail(ret.data.msg)
          }
        })
    },
    showHtml(str) {
      return str
        .replace(str ? /&(?!#?\w+;)/g : /&/g, '&amp;')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
    },
  },

  mounted() {
    this.getLists()
    //   console.log(this.$route.query.id);
  },
}
</script>

<style scoped lang="less">
.center {
  font-size: 14px;
  color: #333;
  line-height: 24px;
  width: 94%;
  margin: 0 auto;
  padding: 15px 0;
  /deep/img {
    width: 100% !important;
    height: auto !important;
  }
  /deep/image {
    width: 100% !important;
    height: auto !important;
  }
}
</style>
