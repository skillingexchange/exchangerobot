<template>
  <div class="page_information ">
    <div safe-area-inset-top>
      <van-row
        type="flex"
        justify="space-between"
        align="center"
        class="page-header"
      >
        <van-col class="page-header-left">
          <h2 class="page-title">{{ $t('informations') }}</h2>
        </van-col>
      </van-row>
    </div>
    <van-pull-refresh
      v-model="refreshing"
      @refresh="onRefresh"
    >
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="finished_text"
        @load="onLoad"
      >
        <van-cell
          v-for="item in integralList"
          :key="item.id"
        >
          <div class="zi_dl" @click="$router.push({ path: '/informations/information_detail?id=' + item.id })">
            <div class="dd">
              <div class="zi_title">{{ item.title }}</div>
              <div class="zi_time">{{ item.createtime }}</div>
            </div>
            <div class="dt" v-if="item.thumbnail!=''"><img :src="item.thumbnail" alt=""></div>
          </div>
        </van-cell>
      </van-list>
      <van-empty
        v-if="integralList.list&&integralList.list.length === 0"
        :description="$t('empty.default')"
      />
    </van-pull-refresh>
  </div>
</template>

<script>
import { Dialog } from 'vant'
import { mapState, mapActions } from 'vuex'
export default {
  layout: 'navigation',
  i18n: {
    messages: {
      zh: {
        informations:'财经新闻'
      },

    }
  },
  data() {
    return {
      integralList:[],
      loading: false,
      finished: false,
      refreshing: false,
      page: 0,
      limit:10,
      finished_text:''
    };
  },
  computed: {
    // ...mapState({
    //   userInfo: ({ user }) => user.userInfo,
    //   thirdLoginEnabled: ({ thirdLoginEnabled }) => thirdLoginEnabled
    // })
  },

  methods: {
    ...mapActions({
      caiJing: 'robot/caijing'
    }),
    // 资讯列表
    getLists() {
      var that = this;
      if (this.refreshing) {
        this.integralList = []
        this.page = 0
        this.finished = false
        if (this.loading) {
          this.loading = false
          return
        }
        this.loading = true
      }
      if (this.loading) {
        this.refreshing = false
      }
      const payload = {
        page: this.page,
        limit:this.limit,
      }
      this.caiJing(payload)
      .then(({ data }) => {
        const list = data.list
        console.log(list)
        if (!list.length || list.length < this.limit) {
          this.finished = true
        } else {
          this.finished = false
          this.page += 1
        }
        this.integralList = this.integralList.concat(list)
      })
      .finally(() => {
        if(this.integralList.length == 0){
          this.finished = true
          this.finished_text = ''
        }else{
          this.loading = false
        }
        this.refreshing = false
      })
    },
    onLoad () {
      this.finished_text = '财经新闻'
      this.getLists()
    },
    onRefresh () {
      this.getLists()
    }
  },
}
</script>

<style scoped lang="less">
.page_information{
  padding-bottom: 60px!important;
}
.page-header {
  background-color: @themeColor;
  height: 66px;
  padding: 0 15px;
  color: #fff;
  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}
.zi_dl{
  width: 94%;
  margin: 0 auto;
  overflow: hidden;
  border-bottom:1px solid #ebedf0;
}
.zi_dl:last-child{
  border-bottom: none;
}
.zi_dl .dd{
  width:70%;
  float: left;
  margin: 10px 0;
}
.zi_dl .zi_title{
  font-size: 16px;
  color: #323233;
  line-height: 24px;
}
.zi_dl .zi_time{
  margin-top: 30px;
  font-size: 14px;
  color: #999;
  line-height: 24px;
}
.zi_dl .dt{
  width:30%;
  height: 80px;
  overflow: hidden;
  float: right;
  margin: 10px 0;
  border-radius: 8px;
  background: #ebedf0;
}
.zi_dl .dt img{
  width:100%;
}
</style>
