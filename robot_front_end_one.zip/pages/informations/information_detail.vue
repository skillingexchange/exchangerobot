<template>
  <div class="page page_infomation_detail">
    <van-nav-bar
      :title="$t('title')"
      left-arrow
      @click-left="$router.back()"
    />
    <van-cell-group :border="false">
       <div class="center" v-html="Listdetail.content">

       </div>
    </van-cell-group>

  </div>
</template>

<script>
import { Dialog } from 'vant'
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '详情',

      },
      en: {
        title: 'Detail',
      },
    }
  },
  data() {
    return {
      Listdetail:"",
       id:'',
    };
  },
  methods: {
    ...mapActions({
      robotLog: 'robot/caijing'
    }),
    // 资讯详情
    getLists() {
      var that = this;
      console.log(this.$route.query.id)
      this.$axios
        .post("api/user/articles/detail", {

          id:that.$route.query.id

        })
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data);
            that.Listdetail = ret.data.data.list;
          } else {
            that.$toast.fail(ret.data.msg);
          }
        });
    }
  },

  mounted(){
       this.getLists();
    //   console.log(this.$route.query.id);
  }
}
</script>

<style scoped lang="less">
.center {
  font-size: 14px;
  color: #333;
  line-height: 24px;
  width: 94%;
  margin: 0 auto;
  padding: 15px 0;
}
</style>
