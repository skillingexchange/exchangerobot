<template>
  <div class=" page_journal">
    <div safe-area-inset-top>
      <van-row
        type="flex"
        justify="space-between"
        align="center"
        class="page-header"
      >
        <van-col class="page-header-left">
          <h2 class="page-title">{{ $t('nav.journal') }}</h2>
        </van-col>
      </van-row>
    </div>
    <van-pull-refresh
      v-model="refreshing"
      @refresh="onRefresh"
    >
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="finished_text"
        @load="onLoad"
      >
        <van-cell
          v-for="item in logList"
          :key="item.id"
        >
          <div class="robot-item">
            <div class="info">
              <div class="time">{{ item.ctime }}</div>
              <div class="cont">{{ item.content }}</div>
            </div>
          </div>
        </van-cell>
      </van-list>
      <van-empty
        v-if="logList.length === 0"
        :description="$t('empty.log')"
      />
    </van-pull-refresh>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
    layout: 'navigation',
  data () {
    return {
      loading: false,
      finished: false,
      refreshing: false,
      logList: [],
      offset: 0,
      limit: 20,
      finished_text:''
    }
  },
  methods: {
    ...mapActions({
      robotLog: 'robot/robotLog'
    }),
    loadTransactionLog () {
      if (this.refreshing) {
        this.logList = []
        this.offset = 0
        this.finished = false
        if (this.loading) {
          this.loading = false
          return
        }
        this.loading = true
      }
      if (this.loading) {
        this.refreshing = false
      }
     
      const payload = {
        robot_id: this.robot_id,
        limit_begin: this.offset,
        limit_end: this.limit
      }
      this.robotLog(payload)
        .then(({ data }) => {
          const list = data.data
          if (!list.length || list.length < this.limit) {
            this.finished = true
          } else {
            this.finished = false
            this.offset += this.limit
          }
          this.logList = this.logList.concat(list)
        })
        .finally(() => {
          if(this.logList.length == 0){
            this.finished = true
            this.finished_text = ''
          }else{
            this.loading = false
          }
          this.refreshing = false
        })
    },
    onLoad () {
      this.finished_text = this.$t('finished_text')
      this.loadTransactionLog()
    },
    onRefresh () {
      this.loadTransactionLog()
    }
  }
}
</script>
<style lang="less" scoped>
.page_journal{
  padding-bottom: 60px!important;
}
.page-header {
  background-color: @themeColor;
  height: 66px;
  padding: 0 15px;
  color: #fff;
  
  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}
.robot-item {
  overflow: hidden;
  .info {
    padding: 10px;
    background-color: rgba(0, 0, 0, 0.03);
    font-size: 12px;
    line-height: 1.5;
  }
  .time {
    color: #333333;
    border-bottom: 1px solid #eee;
    padding-bottom: 5px;
    margin-bottom: 5px;
  }
}
</style>
