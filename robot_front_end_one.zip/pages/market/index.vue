<template>
  <div class="page_market">
    <!-- <div safe-area-inset-top>
      <van-row type="flex" justify="space-between" align="center" class="page-header">
        <van-col class="page-header-left">
          <h2 class="page-title">{{ $t('nav.exchange') }}</h2>
        </van-col>
      </van-row>
    </div> -->
    <div class="sou">
      <van-search
        v-model="keyword"
        shape="round"
        :background="themeColor"
        :placeholder="$t('qing')"
        @input="searchSub"
      />
    </div>
    <van-tabs v-model="active" swipeable animated sticky line-width="20px">
      <van-tab v-for="item in platform" :key="item.name">
        <template #title>{{ $t(item.label) }}</template>
        <assets-list ref="child" :platform="item.label" :keyword="keyword" :platforms="platform" :actives="active"></assets-list>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import assetsList from './components/assetsList'
import Vue from 'vue'
import { Search } from 'vant'

Vue.use(Search)
export default {

  layout: 'navigation',
 i18n: {
    messages: {
      zh: {
        qing: '请输入搜索关键词',
      },
     en: {
        qing: 'Please enter search keywords',
      },
    },
  },

  components: {
    assetsList,
  },
  data() {
    return {
      active: 0,
    
      keyword: '',
    }
  },
  watch:{
    active(val){
      this.$store.dispatch('robot/marketIndex',val)
    }
  },
  computed: {
    ...mapState({
      platform: ({ robot }) => robot.platform,
      marketIndex: ({ robot }) => robot.marketIndex,
      themeColor:( index ) => index.themeColor,
    }),
  },
  
  methods: {
    searchSub(val) {
      // this.$refs.assets.onLoad(val);
      // console.log(this.$refs.child[0].onLoad(val))
      this.$nextTick(()=>{
        this.$refs.child[this.active].onLoad(val)
      })
      // this.keyword = val ;
    },
  },
  mounted() {
    if(this.$route.query.active){
      this.active = this.$route.query.active;
    }else{
      this.active = this.marketIndex
    }
    // this.getLists()
  },
}
</script>

<style lang="less" >
.page{
  padding-bottom:0!important;
}
.van-cell{
  background-color: transparent;
}
.van-tab{
  color: #333;
  font-weight: 700;
}
.yue {
  position: fixed;
  width: 100%;
  padding: 0 2%;
  line-height: 36px;
  bottom: 50px;
  color: @themeColor;
  background: #e3f1ff;
}
.sou{
  padding-top:15px;
  background-color: @themeColor;
}
/deep/.page{
 padding-top: 0!important;
}
.page-header {
  background-color: @themeColor;
  height: 66px;
  color: #fff;
  padding-top: 15px;
  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}

</style>
