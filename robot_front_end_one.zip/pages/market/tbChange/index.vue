<template>
  <div class="box page page_tbchange">
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <div class="box_1">
      <div class="my">
        <div class="title">当前执行平台</div>
        <div class="top">
          <div class="tou" v-if="platform == 'huobi'" >
            <img src="@/assets/images/huobi.png" alt="" />
            <div>
                <p>{{ $t('huobi') }}</p>
                <p class="tip1">执行策略币种：USDT</p>
            </div>
          </div>
          <div class="tou" v-if="platform== 'okex'" >
            <img src="@/assets/images/okex.png" alt="" />
            <div>
                <p>{{ $t('okex') }}</p>
                <p class="tip1">执行策略币种：USDT</p>
            </div>
          </div>
          <div class="tou" v-if="platform== 'binance'" >
            <img src="@/assets/images/binance.png" alt="" />
            <div>
                <p>{{ $t('binance') }}</p>
                <p class="tip1">执行策略币种：USDT</p>
            </div>
          </div>
          <div class="tou" v-if="platform== 'gateio'" >
            <img src="@/assets/images/gateio.png" alt="" />
            <div>
                <p>{{ $t('gateio') }}</p>
                <p class="tip1">执行策略币种：USDT</p>
            </div>
          </div>
        </div>
      </div>
    <div class="tips">注：请先关闭机器人，再切换平台</div>
      <div class="my">
        <div class="title">切换平台</div>
        <div class="tu_nav">
          <!-- <div class="dl" @click="sellKai">
                <div class="dt"><img src="@/assets/images/kaiqi.png" alt="" /></div>
                <div class="dd">{{ $t('kai') }}</div>
                </div> -->
          <div class="dl" @click="selectP('huobi')">
            <div class="dt"><img src="@/assets/images/huobi.png" alt="" /></div>
            <div class="dd">{{ $t('huobi') }}</div>
          </div>
          <div class="dl"  @click="selectP('okex')">
            <div class="dt"><img src="~@/assets/images/okex.png" alt="" /></div>
            <div class="dd">{{ $t('okex') }}</div>
          </div>
          <div class="dl"  @click="selectP('binance')">
            <div class="dt"><img src="~@/assets/images/binance.png" alt="" /></div>
            <div class="dd">{{ $t('binance') }}</div>
          </div>
          <div class="dl"  @click="selectP('gateio')">
            <div class="dt"><img src="~@/assets/images/gateio.png" alt="" /></div>
            <div class="dd">{{ $t('gateio') }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {mapState} from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '切换平台',
      },
      en: {
        title: 'Switching Platform',
      },
    },
  },
  data() {
    return {
      

    }
  },
  computed: {
    ...mapState({
      platform:(index)=>index.selectPlatform
    })
  },
  mounted() {
    this.$route.query.name = 'bianace'
  },
  methods: {
    //切换平台
    selectP(p){
      this.$store.commit('setSelectPlatform',p)
      this.$router.go(-1)
    },
  }
}
</script>
<style  lang="less">
.page{
  background: #f5f6f7!important;
}
.box{
    background: #f5f6f7;
}
.box_1 {
  padding: 0 ;
}
.my {
  margin: 10px 14px;
  padding:14px;
  background: #fff;
  overflow: hidden;
  box-shadow: 0px 0px 10px rgba(201, 204, 223, 0.3);
  border-radius: 6px;
  overflow: hidden;
}
/deep/.anniu .van-icon {
  position: absolute;
  top: 20px;
  left: 100px;
  font-size: 24px;
}
.title{
    font-size: 15px;
    color: #000;
    position: relative;
    padding-left: 9px;
}
.title:after{
    content: " ";
    position: absolute;
    width: 2px;
    height: 14px;
    background-color: #008bff;
    left: 0;
    top: 0;
    bottom: 0;
    margin: auto;
}
.tips{
    padding: 0 19px;
    color: #969696;
    font-size: 13px;
}
.my .tou {
  width: 100%;
  float: left;
  font-size: 14px;
  line-height: 18px;
  display: flex;
  align-items: center;
}
.my .tou .tip1{
    color:#999;
    font-size: 12px;
}
.my .tou img {
  width: 50px;
  height: 50px;
  vertical-align: -15px;
}
.my .anniu {
  width: 10%;
  float: left;
  color: @themeColor;
  padding-top: 10px;
}
.weiBang {
  width: 50px;
  padding: 2px 0;
  margin-top: 13px;
  text-align: center;
  float: right;
  line-height: 16px;
  font-size: 10px;
  color: #999999;
  background-color: #fdfdfd;
  border-radius: 9px;
  border: 1px solid #d8d8d8;
}
.yiBang {
  width: 50px;
  padding: 2px 0;
  margin-top: 13px;
  text-align: center;
  float: right;
  line-height: 16px;
  font-size: 10px;
  color: #333;
  background-color: #ffcc00;
  border-radius: 9px;
}
.top {
  width: 94%;
  margin: 0 auto;
  overflow: hidden;
  padding: 10px 0;
  position: relative;
}
.tu_nav {
  width: 100%;
  background: #fff;
  padding: 0 0 10px;
  margin: 10px auto 0;
  overflow: hidden;
}
.tu_nav .dl {
  width: 25%;
  float: left;
  text-align: center;
  line-height: 24px;
  color: #999999;
}
.tu_nav .dt {
  width: 36px;
  height: 36px;
  margin: 0 auto;
}
.tu_nav .dt img {
  width: 100%;
}
</style>