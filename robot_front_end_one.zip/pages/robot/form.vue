<template>
  <div class="page page_robot_form">
    <van-nav-bar
      :border="false"
      :title="$t('pageRobot.robot_setup')"
      left-arrow
      @click-left="$router.back()"
    />
    <div class="default_data" v-if="true">
      <div class="defalut_data_title">{{ $t('default_strategy') }}</div>
      <div class="default_data_box">
        <div
          class="default_data_i"
          :class="index == curDefault ? 'default_data_i_s' : ''"
          v-for="(item, index) in defalutStrategy"
          :key="index"
          @click="selectDefault(index)"
        >
          {{ item.title }}
        </div>
      </div>
    </div>
    <van-form label-width="40%" @submit="onSubmit">
      <!--平台-->
      <van-field :value="$t(platform)" readonly :label="$t('platform')" />
      <!--交易区-->
      <van-field
        v-if="$route.query.robot_id != 0"
        :value="market"
        readonly
        clickable
        :label="$t('pageRobot.trade_area')"
        :placeholder="$t('pageRobot.trade_area')"
        :rules="[{ required: true }]"
        @click="onMarket"
        right-icon="arrow"
      />
      <!--首单额度-->
      <van-field
        v-model="first_order_value"
        :label="$t('first_order_amount')"
        :placeholder="$t('first_order_amount')"
        :rules="[{ required: true }]"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('first_order_amount')">
          <div class="label">{{ $t('first_order_amount') }}</div>
          <van-icon
            name="question-o"
            size="16"
            v-if="$t('tip.first_order_amount') != ' '"
          ></van-icon>
        </div>
      </van-field>
      <!--首单额度加倍-->
      <van-cell center @click="onInput">
        <div class="my_label flex" slot="title" @click="clickLeftIcon('shou_jia')">
          <div class="label">{{ $t('shou_jia') }}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.shou_jia') != ' '"></van-icon>
        </div>
        <template #right-icon>
          <van-switch v-model="checked" size="20" />
        </template>
      </van-cell>
      <!--补仓次数-->
      <van-field
        v-model="max_order_count"
        :label="$t('number_of_orders')"
        :placeholder="$t('number_of_orders')"
        :rules="[{ required: true }]"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('number_of_orders')">
          <div class="label">{{ $t('number_of_orders') }}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.number_of_orders') != ' '"></van-icon>
        </div>
        <template #right-icon>
          <div class="jiayi jiayi_sp">
            <div class="right" @click="showPopup">
              <p>已设置</p>
              <van-icon name="play" size="15"></van-icon>
            </div>
          </div>
        </template>
      </van-field>
      <!-- 补仓回调 -->
      <van-field
        v-model="cover_callback_rate"
        :label="$t('cover_pullback')"
        :placeholder="$t('cover_pullback')"
        :rules="[{ required: true }]"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('cover_pullback')">
          <div class="label">{{ $t('cover_pullback') }}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.cover_pullback') != ' '"></van-icon>
        </div>
      </van-field>
      <van-field
        v-model="stop_profit_rate"
        :label="$t('all_take_profit_ratio')"
        :placeholder="$t('all_take_profit_ratio')"
        :rules="[{ required: true }]"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('all_take_profit_ratio')">
          <div class="label">{{ $t('all_take_profit_ratio') }}</div>
          <van-icon
            name="question-o"
            size="16"
            v-if="$t('tip.all_take_profit_ratio') != ' '"
          ></van-icon>
        </div>
      </van-field>
      <van-field
        v-model="stop_profit_callback_rate"
        :label="$t('all_take_profit_retracement')"
        :placeholder="$t('all_take_profit_retracement')"
        :rules="[{ required: true }]"
      >
        <div
          class="my_label flex"
          slot="label"
          @click="clickLeftIcon('all_take_profit_retracement')"
        >
          <div class="label">{{ $t('all_take_profit_retracement') }}</div>
          <van-icon
            name="question-o"
            size="16"
            v-if="$t('tip.all_take_profit_retracement') != ' '"
          ></van-icon>
        </div>
      </van-field>
      <!-- 补仓设置  -->
      <!-- <div class="jiayi" >
        <div class="fei">
          <div class="my_label flex" slot="label" @click="clickLeftIcon('cover_down')">
            <van-icon name="question-o" size="16" v-if="$t('tip.cover_down') != ' '"></van-icon>
            <div class="label">{{$t('cover_down_pl')}}</div>
          </div>
        </div>
        <div class="right" @click="showPopup">
          <p>已设置</p>
          <van-icon name="play" size="15"></van-icon>
        </div>
      </div> -->

      <!-- <van-field
        v-model="part_cover_callback_rate"
        :label="$t('cover_pullback') + '(%)'"
        :placeholder="$t('part_cover_callback_rate')"
        :rules="[{ required: true }]"
      >
       <div class="my_label flex" slot="label" @click="clickLeftIcon('part_cover_callback_rate')">
          <van-icon name="question-o" size="16" v-if="$t('tip.part_cover_callback_rate') != ' '"></van-icon>
          <div class="label">{{$t('part_cover_callback_rate')}}</div>
        </div>
      </van-field> -->

      <!--分仓止盈比例-->
      <div class="jiayi" v-if="showPartField">
        <div class="fei">
          <div
            class="my_label flex"
            slot="label"
            @click="clickLeftIcon('part_cover_callback_rate')"
          >
            <div class="label">{{ $t('part_cover_callback_rate') }}</div>
            <van-icon
              name="question-o"
              size="16"
              v-if="$t('tip.part_cover_callback_rate') != ' '"
            ></van-icon>
          </div>
        </div>
        <div class="right" @click="showPart = true">
          <p>已设置</p>
          <van-icon name="play" size="15"></van-icon>
        </div>
      </div>

      <!--分仓止盈回调-->
      <van-field
        v-if="showPartField"
        v-model="cover_grid_back"
        :label="$t('part_take_profit_retracement') + '(%)'"
        :placeholder="$t('part_take_profit_retracement')"
        :rules="[{ required: true }]"
      >
        <div
          class="my_label flex"
          slot="label"
          @click="clickLeftIcon('part_take_profit_retracement')"
        >
          <div class="label">{{ $t('part_take_profit_retracement') }}</div>
          <van-icon
            name="question-o"
            size="16"
            v-if="$t('tip.part_take_profit_retracement') != ' '"
          ></van-icon>
        </div>
      </van-field>
      <!--尾单加仓开关-->
      <!-- <van-cell center :title="$t('last_cover')" >
        <div class="my_label flex" slot="title" @click="clickLeftIcon('last_cover')" >
          <div class="label">{{$t('last_cover')}}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.last_cover') != ' '"></van-icon>
        </div>
        <template #right-icon>
          <van-switch v-model="lastCover" size="20" />
        </template>
      </van-cell> -->
      <!--风险控制-->
      <van-cell center :title="$t('risk_control')">
        <div class="my_label flex" slot="title" @click="clickLeftIcon('risk_control')">
          <div class="label">{{ $t('risk_control') }}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.risk_control') != ' '"></van-icon>
        </div>
        <template #right-icon>
          <van-switch v-model="riskControl" size="20" />
        </template>
      </van-cell>
      <!--风险控制设置-->
      <div class="control" v-if="riskControl">
        <van-field
          v-model="control_min_prcie"
          :label="`${$t('control_min_prcie')}`"
          :placeholder="$t('control_min_prcie')"
          label-width="120px"
          type="number"
        />
        <van-field
          v-model="control_max_prcie"
          :label="`${$t('control_max_prcie')}`"
          :placeholder="$t('control_max_prcie')"
          label-width="120px"
          type="number"
        />
      </div>

      <van-field
        name="radio"
        :label="$t('pageRobot.strategy_type')"
        v-if="$route.query.robot_id != 0"
        class="s_radio"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('pageRobot.strategy_type')">
          <div class="label">{{ $t('pageRobot.strategy_type') }}</div>
          <van-icon
            name="question-o"
            size="16"
            v-if="$t('tip.pageRobot.strategy_type') != ' '"
          ></van-icon>
        </div>
        <template #input style="margin-top: 4px">
          <van-radio-group
            v-model="recycle_status"
            direction="horizontal"
            @change="circleChange"
            style="margin-left: -15px"
          >
            <van-radio style="margin-right: 4px" :name="1">{{ $t('cycle_strategy') }}</van-radio>
            <van-radio style="margin-right: 0px" :name="0">{{ $t('single_strategy') }}</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <!--循环次数-->
      <van-field
        v-model="circle_number"
        :label="$t('circle_number')"
        :placeholder="$t('circle_number')"
        :rules="[{ required: true }]"
        v-if="showCircle"
      >
        <div class="my_label flex" slot="label" @click="clickLeftIcon('circle_number')">
          <div class="label">{{ $t('circle_number') }}</div>
          <van-icon name="question-o" size="16" v-if="$t('tip.circle_number') != ' '"></van-icon>
        </div>
      </van-field>
      <!-- 激活码 -->
      <!-- <van-field
        v-if="!thirdLoginEnabled && formType==='create'"
        v-model="cd_key"
        :label="$t('cdkey')"
        :placeholder="$t('cdkey')"
        :rules="[{ required: true }]"
      /> -->
      <div style="padding: 16px">
        <van-button round block type="info" native-type="submit">
          {{ $t('actions.submit') }}
        </van-button>
      </div>
    </van-form>
    <van-popup v-model="marketPicker" teleport="body" position="bottom">
      <van-picker
        show-toolbar
        :columns="marketLists"
        value-key="market_name"
        @confirm="onConfirm"
        @cancel="marketPicker = false"
      />
    </van-popup>
    <!--补仓设置-->
    <van-popup v-model="show" closeable teleport="body" position="bottom" :style="{ height: '50%' }">
      <div class="cent">
        <div class="title">{{ $t('cover_down_pl') }}</div>
        <!-- <van-field
          v-for="(val, key) in bcweekList"
          :key="key"
          v-model="bcweekCon[key]"
          :label="$t(val) + '(%)'"
          :placeholder="$t('cover_down')"
          :rules="[{ required: true }]"
        /> -->
        <div class="field flex">
          <div class="name">{{ $t('number_of_orders') }}</div>
          <div class="flex flex_1">
            <div class="numer numer_sp flex_1">
              {{ $t('cover_down') }}
            </div>
            <div class="numer numer_sp flex f_e flex_1">
              {{ $t('cover_down_multiple') }}
            </div>
          </div>
        </div>
        <div class="field flex" v-for="(item, index) in coverdownList" :key="index">
          <div class="name">{{ coverdownList[index].title }}</div>
          <div class="flex flex_1">
            <div class="numer flex">
              <input
                type="number"
                v-model="coverdownList[index].value"
                :placeholder="$t('cover_down')"
              />
              <p>%</p>
            </div>
            <div class="numer flex">
              <input
                type="number"
                v-model="coverdownList[index].tirst_order_multiple"
                :placeholder="$t('cover_down_multiple')"
              />
              <p>倍</p>
            </div>
          </div>
        </div>
        <div class="tijiao" @click="subCon">{{ $t('ti') }}</div>
      </div>
    </van-popup>
    <!--分仓止盈比例弹窗-->
    <van-popup v-model="showPart" closeable position="bottom" teleport="body" :style="{ height: '50%' }">
      <div class="cent">
        <div class="title">{{ $t('part_cover_callback_rate') }}</div>

        <div class="field flex f_sb">
          <div class="name">{{ $t('number_of_orders') }}</div>
          <div class="flex flex_1 f_e">
            <div class="numer number_sp flex">分仓止盈比例</div>
          </div>
        </div>
        <div class="field flex f_sb" v-for="(item, index) in partcoverdownList" :key="index">
          <div class="name">{{ partcoverdownList[index].title }}</div>
          <div class="flex flex_1 f_e">
            <div class="numer number_sp flex">
              <input
                type="number "
                v-model="partcoverdownList[index].value"
                :placeholder="分仓止盈比例"
              />
              <p>%</p>
            </div>
            <!-- <div class="numer flex">
                <input type="number" v-model="coverdownList[index][1]" :placeholder="$t('cover_down_multiple')"> <p>倍</p>
              </div> -->
          </div>
        </div>
        <div class="tijiao" @click="showPart = false">{{ $t('ti') }}</div>
      </div>
    </van-popup>
    <!--参数说明弹窗-->
    <van-popup v-model="infoShow" teleport="body" position="bottom"> </van-popup>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import tokenStorage from '@/utils/storage'
import Vue from 'vue'
import { Switch, Dialog } from 'vant'
import { currencyStorage, langStorage } from '@/utils/storage'

Vue.use(Switch)
export default {
  i18n: {
    messages: {
      zh: {
        shou_jia: '首单金额加倍',
        one: '首次补仓',
        two: '第2次补仓',
        three: '第3次补仓',
        four: '第4次补仓',
        five: '第5次补仓',
        six: '第6次补仓',
        sever: '第7次补仓',
        eight: '第8次补仓',
        nine: '第9次补仓',
        ten: '第10次补仓',
        eleven: '第11次补仓',
        twelve: '第12次补仓',
        thirteen: '第13次补仓',
        fourteen: '第14次补仓',
        ti: '提交',
        default_strategy: '预设策略',
        risk_control: '风险控制',
        last_cover: '尾单加仓',
        control_min_prcie: '限制买入最低价',
        control_max_prcie: '限制买入最高价',
        tip: {
          number_of_orders: '加仓次数说明', //加仓次数说明
          all_take_profit_ratio: '全仓止盈比例说明', //全仓止盈比例说明
          all_take_profit_retracement: '全仓止盈回调说明', //全仓止盈回调说明
          cover_down: '补仓设置说明', //补仓跌幅说明
          cover_pullback: '补仓回调说明', //补仓回调说明
          circle_number: '循环次数说明', //循环次数说明
          part_cover_callback_rate: '分仓止盈比例说明', //分仓止盈比例说明
          part_take_profit_retracement: '应大于等于全仓止盈，且小于等于分仓止盈最大的值', //分仓止盈回调说明
          risk_control: '风险控制说明', //风险控制说明
          last_cover: '尾单加仓说明', //风险控制说明
          first_order_amount: '首单额度说明', //首单额度说明
          shou_jia: '首单额度加倍说明', //首单额度加倍说明
        },
      },
      en: {
        shou_jia: 'Double the amount of the first order',
        one: '首次补仓',
        two: '第2次补仓',
        three: '第3次补仓',
        four: '第4次补仓',
        five: '第5次补仓',
        six: '第6次补仓',
        sever: '第7次补仓',
        eight: '第8次补仓',
        nine: '第9次补仓',
        ten: '第10次补仓',
        eleven: '第11次补仓',
        twelve: '第12次补仓',
        thirteen: '第13次补仓',
        fourteen: '第14次补仓',
        ti: 'Submit',
        default_strategy: 'Default Strategy',

        risk_control: 'Risk Control',
        last_cover: 'Last Cover',
        control_min_prcie: 'Minimum purchase price',
        control_max_prcie: 'Maximum purchase price',
        tip: {
          number_of_orders: '加仓次数说明', //加仓次数说明
          all_take_profit_ratio: '全仓止盈比例说明', //全仓止盈比例说明
          all_take_profit_retracement: '全仓止盈回调说明', //全仓止盈回调说明
          cover_down: '补仓设置说明', //补仓跌幅说明
          cover_pullback: '补仓回调说明', //补仓回调说明
          circle_number: '循环次数说明', //循环次数说明
          part_cover_callback_rate: '分仓止盈比例说明', //分仓止盈比例说明
          part_take_profit_retracement:
            'Should be greater than such as full warehouse stop profit, and less than or equal to the maximum value of the warehouse stop profit', //分仓止盈回调说明
          risk_control: '风险控制说明', //风险控制说明
          last_cover: '尾单加仓说明', //风险控制说明
          first_order_amount: '首单额度说明', //首单额度说明
          shou_jia: '首单额度加倍说明', //首单额度加倍说明
        },
      },
    },
  },
  data() {
    return {
      infoShow: false,
      showPart: false,
      bcweekList1: [
        'one',
        'two',
        'three',
        'four',
        'five',
        'six',
        'sever',
        'eight',
        'nine',
        'ten',
        'eleven',
        'twelve',
        'thirteen',
        'fourteen',
      ],
      bcweekList: Array(
        'one',
        'two',
        'three',
        'four',
        'five',
        'six',
        'sever'
        // 'eight',
        // 'nine',
        // 'ten',
        // 'eleven',
        // 'twelve',
        // 'thirteen',
        // 'fourteen'
      ),
      bcweekCon: [3, 4, 5, 6, 7, 8, 9],
      formType: 'create',
      marketPicker: false,
      market: '', //哪个
      money: '',
      platform: '',
      robot_id: '',
      market_id: '',
      first_order_value: '10',
      max_order_count: 7,
      stop_profit_rate: '1.3',
      stop_profit_callback_rate: '0.3',
      circle_number: '1',
      cover_rate: '4',
      cover_one: '4',
      cover_two: '4',
      cover_three: '4',
      cover_four: '4',
      cover_five: '4',
      cover_six: '4',
      cover_sever: '4',
      // cover_eight: '4',
      // cover_nine: '4',
      // cover_ten: '4',
      // cover_eleven: '4',
      // cover_twelve: '4',
      // cover_thirteen: '4',
      // cover_fourteen: '4',
      cover_callback_rate: '0.5',
      recycle_status: 1,
      // cd_key: ''
      show: false,
      checked: false,
      is_double: 0,

      showPartField: false,
      curDefault: -1,
      defalutData: [],

      coverdownList: [],
      partcoverdownList: [],
      riskControl: false,
      control_min_prcie: '',
      control_max_prcie: '',
      cover_grid_back: '1.3',

      c_coverdownList: [],
      c_partcoverdownList: [],
      showCircle: false,
      lastCover: true,
    }
  },
  watch: {
    max_order_count(val) {
      if (!val) return
      val = val > 0 ? val : 0
      let len = val >= 30 ? val : val,
        bcweekList1 = [...this.bcweekList1]
      this.bcweekList = bcweekList1.splice(0, len)
      let coverdownList = [...this.c_coverdownList],
        partcoverdownList = [...this.c_partcoverdownList],
        c_len = this.c_coverdownList.length,
        p_len = this.c_partcoverdownList.length
      if (c_len > len) {
        coverdownList.splice(len)
      } else if (c_len < len) {
        for (let i = 0; i < len - c_len; i++) {
          coverdownList.push({
            title: c_len + i + 1 == 1 ? '首次补仓' : `第${c_len + i + 1}次补仓`,
            value: '',
            tirst_order_multiple: '',
          })
        }
      }

      let len1 = len - 4
      if (len1 > 0) {
        this.showPartField = true
        if (p_len > len1) {
          partcoverdownList.splice(len1)
        } else if (p_len < len1) {
          for (let i = 0; i < len1 - p_len; i++) {
            partcoverdownList.push({
              title: len + i + 1 == 1 ? '首次补仓' : `第${5 + Number(i) + p_len}次补仓`,
              value: '',
            })
          }
        }
      } else {
        this.showPartField = false
      }
      this.$nextTick(() => {
        this.partcoverdownList = partcoverdownList
        this.coverdownList = coverdownList
      })
    },
  },
  computed: {
    ...mapState({
      robotList: ({ robot }) => robot.robotList,
      thirdLoginEnabled: ({ thirdLoginEnabled }) => thirdLoginEnabled,
      defalutStrategy: ({ robot }) => robot.defalutStrategy,
    }),
    ...mapGetters({
      markets: 'robot/markets',
    }),
    marketLists() {
      this.curDefault = this.defalutStrategy.length - 1
      return this.markets(this.platform) || []
    },
  },

  async created() {
    this.circleChange(1)
    var that = this
    this.getIntro()
    await this.robotStrategy({ platform: this.$route.query.platform || '' })
    this.formType = this.$route.query.type
    if (this.$route.query.robot_id == 0) return this.selectDefault(0)

    if (this.formType === 'edit') {
      const robot = (this.robot = this.robotList.find(
        (item) => this.$route.query.robot_id === item.id
      ))
      this.$nextTick(() => {
        this.setInfo1(robot)

        this.platform = robot.platform
        this.market = robot.market_name
        this.market_id = robot.market_id
        this.robot_id = robot.id
        this.first_order_value = robot.first_order_value
        this.max_order_count = robot.max_order_count
        this.stop_profit_rate = robot.stop_profit_rate
        this.stop_profit_callback_rate = robot.stop_profit_callback_rate
        this.cover_rate = robot.cover_rate
        this.cover_callback_rate = robot.cover_callback_rate
        this.recycle_status = robot.recycle_status
        this.showCircle = robot.recycle_status == 1 ? true : false
        this.money = robot.money || 'USDT'
        this.bcweekCon = robot.cover_rates.length > 0 ? robot.cover_rates : this.bcweekCon
        this.is_double = robot.is_double
        this.checked = robot.is_double == 1 ? true : false
        this.marketList({
          platform: this.platform,
          type: 'spot',
        })
      })
    } else {
      const markets = JSON.parse(this.$route.query.data)
      this.platform = this.$route.query.platform
      this.market = markets.market_name
      this.market_id = markets.id
      this.money = markets.money

      this.selectDefault(0)
      this.marketList({
        platform: this.platform,
        type: 'spot',
      })
    }
  },
  methods: {
    //改变策略设置信息
    setInfo(robot) {
      this.coverdownList = robot.cover_rates
      this.c_coverdownList = robot.cover_rates
      this.partcoverdownList = robot.sub_warehouse
      this.c_partcoverdownList = robot.sub_warehouse
      this.riskControl = robot.risk == 2 ? true : false
      this.control_min_prcie = robot.min_price || ''
      this.control_max_prcie = robot.max_price || ''
      this.circle_number = robot.cycles
      this.cover_grid_back = robot.cover_grid_back || ''
      this.showCircle = robot.recycle_status == 1 ? true : false
    },
    //设置机器人默认信息
    setInfo1(robot) {
      this.riskControl = robot.open_risk == 2 ? true : false
      this.control_min_prcie = robot.low_buy || ''
      this.control_max_prcie = robot.top_buy || ''
      this.circle_number = robot.round_num
      this.cover_grid_back = robot.cover_grid_back || ''

      let coverdownList = robot.cover_rates.map((item, index) => {
        return {
          title: index == 0 ? '第1次补仓' : `第${index + 1}次补仓`,
          value: item.decline,
          tirst_order_multiple: item.multiple,
        }
      })
      this.coverdownList = coverdownList || []
      this.c_coverdownList = [...coverdownList]

      let partcoverdownList = robot.cover_grid.map((item, index) => {
        return {
          title: `第${5 + index}次补仓`,
          value: item,
        }
      })
      this.partcoverdownList = partcoverdownList || []
      this.c_partcoverdownList = [...partcoverdownList]
    },
    onInput(checked) {
      console.log('asfdf')
      // console.log(is_double)
      if (this.checked) {
        this.is_double = 1
      } else {
        this.is_double = 0
      }
      console.log(this.is_double)
    },
    subCon() {
      // console.log(this.bcweekCon)
      this.show = false
    },
    // 弹窗
    showPopup() {
      this.show = true
    },
    ...mapActions({
      marketList: 'robot/marketList',
      robotCreate: 'robot/robotCreate',
      robotEdit: 'robot/robotEdit',
      mulEdit: 'robot/mulEdit',
      robotStrategy: 'robot/robotStrategy',
      getrobotList: 'robot/robotList',
    }),
    onMarket() {
      this.marketPicker = true
      if (this.formType === 'create') {
      }
    },
    onSubmit() {
      this.$toast.loading()

      const payload = {
        platform: this.platform,
        market_id: this.market_id,
        first_order_value: this.first_order_value,
        max_order_count: this.max_order_count,
        stop_profit_rate: this.stop_profit_rate,
        stop_profit_callback_rate: this.stop_profit_callback_rate,
        cover_rate: this.cover_rate,
        cover_callback_rate: this.cover_callback_rate,
        recycle_status: this.recycle_status,
        cover_rates: this.bcweekCon.join(','),
        is_double: this.is_double,
        // cd_key: this.cd_key
      }

      let cover_rates = [],
        sub_warehouse = {}
      this.coverdownList.map((item) => {
        cover_rates.push({
          decline: item.value,
          multiple: item.tirst_order_multiple,
        })
      })
      this.partcoverdownList.map((item, index) => {
        sub_warehouse[index] = item.value
      })
      payload.cycles = this.circle_number
      payload.is_risk = this.riskControl ? 2 : 1
      payload.min_price = this.control_min_prcie
      payload.max_price = this.control_max_prcie
      payload.cover_grid_back = this.cover_grid_back || ''
      payload.cover_rates = JSON.stringify(cover_rates)
      payload.sub_warehouse = JSON.stringify(sub_warehouse)

      if (this.formType === 'edit') {
        payload.robot_id = this.robot_id
      }
      if (this.$route.query.robot_id == 0) {
        payload.robot_id = tokenStorage.get('robot_ids')
        delete payload.recycle_status
        var that = this

        this.mulEdit(payload).then(function (ret) {
          console.log(ret)
          if (ret.code == 1) {
            // console.log(ret.data);
            that.$toast.clear()
            // that.$toast.success('修改成功')
            that.$toast(ret.msg)
            //
            that.$router.push({
              path: '/market',
              query: {
                active: that.$route.query.active,
              },
            }) //返回上一页
            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.msg)
          }
        })
      } else {
        const promise =
          this.formType === 'create' ? this.robotCreate(payload) : this.robotEdit(payload)
        promise
          .then((res) => {
            this.$toast(res.msg)
            if (res.code == 1) {
              this.$router.back()
            }
            if (this.formType === 'create') {
              this.getrobotList()
            }
          })
          .catch(({ msg }) => this.$toast(msg))
      }
    },
    onConfirm(value) {
      this.market = value.market_name
      this.market_id = value.id
      this.marketPicker = false
      if (value.robot_status == 1) {
        this.formType = 'edit'
      } else {
        this.formType = 'create'
      }
    },

    selectDefault(index) {
      if (this.curDefault == index) return
      this.curDefault = index
      this.setInfo(this.defalutStrategy[index].data)
      for (let i in this.defalutStrategy[index].data) {
        if (i == 'market') continue
        this[i] = this.defalutStrategy[index].data[i]
      }
      let bcweekList1 = [...this.bcweekList1],
        len =
          this.defalutStrategy[index].data.bcweekCon.length <= 7
            ? 7
            : this.defalutStrategy[index].data.bcweekCon.length
      this.bcweekList = bcweekList1.splice(0, len)
    },

    //点击显示提示
    clickLeftIcon(type) {
      if (this.$t(`tip.${type}`) == ' ') return
      Dialog.confirm({
        title: this.$t(`${type}`),
        message: this.$t(`tip.${type}`),
        showCancelButton: false,
        confirmButtonText: this.$t('actions.confirm'),
        confirmButtonColor: '#333',
        closeOnClickOverlay: true,
      })
    },

    //循环策略设置
    circleChange(e) {
      this.showCircle = e == 1 ? true : false
    },

    //获取说明
    getIntro() {
      let that = this
      this.$axios.post('/api/admin/public/strategy', {}).then(function (ret) {
        if (ret.data.code == 1) {
          let lang = langStorage.get() || 'zh',
            data = ret.data.data
          that.$i18n.setLocaleMessage(
            lang,
            Object.assign(that.$i18n.getLocaleMessage(lang), {
              tip: {
                number_of_orders: data.replenishment_times || ' ', //加仓次数说明
                all_take_profit_ratio: data.stop_profit_in_the_whole_warehouse || ' ', //全仓止盈比例说明
                all_take_profit_retracement: data.full_position_profit_stop_callback || ' ', //全仓止盈回调说明
                cover_pullback: data.make_up_call_back || ' ', //补仓回调说明
                circle_number: data.number_of_cycles || ' ', //循环次数说明
                part_cover_callback_rate: data.proportion_of_profit_stopping_by_warehouse || ' ', //分仓止盈比例说明
                part_take_profit_retracement: data.division_and_profit_control || ' ', //分仓止盈回调说明
                risk_control: data.risk_management || ' ', //风险控制说明
                last_cover: data.closing_order || ' ', //尾仓加单说明
                first_order_amount: ' ', //首单额度说明
                shou_jia: ' ', //首单额度加倍说明
                pageRobot: {
                  strategy_type: ' ', //策略类型说明
                },
              },
            })
          )
        }
      })
    },
  },
}
</script>
<style lang="less" scoped>
.flex {
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.flex_1 {
  flex: 1;
}
.f_sb {
  justify-content: space-between;
}
.f_e {
  justify-content: flex-end;
}
/deep/.van-switch--on {
  background-color: @themeColor;
}
.cent {
  width: 100%;
  font-size: 14px;
  line-height: 26px;
}
/deep/.cent .van-field__label {
  width: 15.2em;
}
/deep/.cent .van-field__control {
  text-align: center;
  padding-right: 10px;
}
.cent .title {
  font-size: 16px;
  margin-top: 15px;
  padding-left: 15px;
  border-bottom: 1px solid #f8f8f8;
}
.jiayi {
  width: 100%;
  line-height: 32px;
  padding: 3px 15px;
  background: #fff;
  border-bottom: 1px solid #f8f8f8;
  overflow: hidden;
  color: #646566;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .right {
    flex: 1;
    margin-left: 15px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    color: @themeColor;
    .van-icon {
      color: @themeColor;
      transform: rotate(90deg);
      margin-left: 10px;
    }
  }
}
.jiayi .fei {
  // width:31%;
  float: left;
}
.jiayi .lv {
  float: right;
  width: 14px;
  height: 14px;
}
.jiayi .lv img {
  width: 100%;
}
.jiayi_sp {
  padding: 0;
}
.cent .tijiao {
  width: 90%;
  overflow: hidden;
  margin: 10px auto;
  text-align: center;
  background: @themeColor;
  border-radius: 999px;
  color: #fff;
  line-height: 36px;
}

.default_data {
  padding: 10px 15px;
  background: #fff;
  .defalut_data_title {
    margin-bottom: 10px;
    color: #646566;
  }
  .default_data_box {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-wrap: wrap;
  }
  .default_data_i {
    width: 70px;
    padding: 5px 0;
    box-sizing: border-box;
    border: 1px solid @themeColor;
    color: @themeColor;
    text-align: center;
    font-size: 13px;
    margin-bottom: 10px;
    margin-right: 15px;
  }
  .default_data_i_s {
    background: @themeColor;
    color: #fff;
  }
}

.my_label {
  color: #323233;
  /deep/ .van-icon {
    // margin-right:4px;
    margin-left: 4px;
    // display: none;
  }
}

.field {
  padding: 10px 15px;
  box-sizing: border-box;
  .name {
    width: 120px;
  }
  .numer {
    input {
      width: 90px;
      text-align: center;
      border: 0;
    }
    p {
      color: #999;
    }
  }
  .numer_sp {
    text-align: center;
  }
  .numer:last-child {
    margin-left: 30px;
  }
}
.s_radio {
  .van-cell__value {
    display: flex;
    align-items: center;
  }
}
</style>
