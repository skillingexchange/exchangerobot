<template>
  <div class="page page_robot_form">
    <van-nav-bar
      :border="false"
      :title="$t('pageRobot.robot_setup')"
      left-arrow
      @click-left="$router.back()"
    />
    <div class="default_data" v-if="true">
      <div class="defalut_data_title">{{$t('default_strategy')}}</div>
      <div class="default_data_box">
        <div class="default_data_i" :class="index==curDefault?'default_data_i_s':''" v-for="(item,index) in defalutStrategy" :key="index" @click="selectDefault(index)">
          {{item.title}}
        </div>
      </div>
    </div>
    <van-form label-width="32%" @submit="onSubmit">
      <van-field
        v-if="$route.query.robot_id != 0"
        :value="market"
        readonly
        clickable
        :label="$t('pageRobot.trade_area')"
        :placeholder="$t('pageRobot.trade_area')"
        :rules="[{ required: true }]"
        @click="onMarket"
        right-icon="arrow"
      />
      <van-field
        v-model="first_order_value"
        :label="$t('first_order_amount') + '(' + money + ')'"
        :placeholder="$t('first_order_amount')"
        :rules="[{ required: true }]"
      />
      <van-cell center :title="$t('shou_jia')" @click="onInput">
        <template #right-icon>
          <van-switch v-model="checked" size="20" />
        </template>
      </van-cell>
      <van-field
        v-model="max_order_count"
        :label="$t('number_of_orders')"
        :placeholder="$t('number_of_orders')"
        :rules="[{ required: true }]"
      />
      <van-field
        v-model="stop_profit_rate"
        :label="$t('take_profit_ratio') + '(%)'"
        :placeholder="$t('take_profit_ratio')"
        :rules="[{ required: true }]"
      />
      <van-field
        v-model="stop_profit_callback_rate"
        :label="$t('take_profit_retracement') + '(%)'"
        :placeholder="$t('take_profit_retracement')"
        :rules="[{ required: true }]"
      />
      <!-- 补仓回调 弹窗 -->
      <div class="jiayi" @click="showPopup">
        <div class="fei">{{ $t('cover_down') }}%</div>
        <div class="lv"><img src="@/assets/images/lower.png" alt="" /></div>
      </div>
      <!-- 补仓回调 -->
      <!-- <van-field
        v-model="cover_rate"
        :label="$t('cover_down') + '(%)'"
        :placeholder="$t('cover_down')"
        :rules="[{ required: true }]"
      /> -->
      <van-field
        v-model="cover_callback_rate"
        :label="$t('cover_pullback') + '(%)'"
        :placeholder="$t('cover_pullback')"
        :rules="[{ required: true }]"
      />
      <van-field
        name="radio"
        :label="$t('pageRobot.strategy_type')"
        v-if="$route.query.robot_id != 0"
      >
        <template #input style="margin-top: 4px;">
          <van-radio-group v-model="recycle_status" direction="horizontal" >
            <van-radio :name="1">{{ $t('cycle_strategy') }}</van-radio>
            <van-radio :name="0">{{ $t('single_strategy') }}</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <!-- 激活码 -->
      <!-- <van-field
        v-if="!thirdLoginEnabled && formType==='create'"
        v-model="cd_key"
        :label="$t('cdkey')"
        :placeholder="$t('cdkey')"
        :rules="[{ required: true }]"
      /> -->
      <div style="padding: 16px">
        <van-button round block type="info" native-type="submit">
          {{ $t('actions.submit') }}
        </van-button>
      </div>
    </van-form>
    <van-popup v-model="marketPicker" position="bottom">
      <van-picker
        show-toolbar
        :columns="marketLists"
        value-key="market_name"
        @confirm="onConfirm"
        @cancel="marketPicker = false"
      />
    </van-popup>
    <van-popup v-model="show" closeable position="bottom" :style="{ height: '50%' }">
      <div class="cent">
        <div class="title">{{ $t('cover_down') }}</div>
        <van-field
          v-for="(val, key) in bcweekList"
          :key="key"
          v-model="bcweekCon[key]"
          :label="$t(val) + '(%)'"
          :placeholder="$t('cover_down')"
          :rules="[{ required: true }]"
        />
        <!-- <div class="tijiao">一键补仓</div> -->
        <div class="tijiao" @click="subCon">{{ $t('ti') }}</div>
      </div>
    </van-popup>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import tokenStorage from '@/utils/storage'
import Vue from 'vue'
import { Switch } from 'vant'

Vue.use(Switch)
export default {
  i18n: {
    messages: {
      zh: {
        shou_jia: '首单金额加倍',
        one: '首次补仓',
        two: '第2次补仓',
        three: '第3次补仓',
        four: '第4次补仓',
        five: '第5次补仓',
        six: '第6次补仓',
        sever: '第7次补仓',
        eight: '第8次补仓',
        nine: '第9次补仓',
        ten: '第10次补仓',
        eleven: '第11次补仓',
        twelve: '第12次补仓',
        thirteen: '第13次补仓',
        fourteen: '第14次补仓',
        ti: '提交',
        default_strategy:'预设策略'
      },
      en: {
        shou_jia: 'Double the amount of the first order',
        one: '首次补仓',
        two: '第2次补仓',
        three: '第3次补仓',
        four: '第4次补仓',
        five: '第5次补仓',
        six: '第6次补仓',
        sever: '第7次补仓',
        eight: '第8次补仓',
        nine: '第9次补仓',
        ten: '第10次补仓',
        eleven: '第11次补仓',
        twelve: '第12次补仓',
        thirteen: '第13次补仓',
        fourteen: '第14次补仓',
        ti: 'Submit',
        default_strategy:'Default Strategy'
      },
    },
  },
  data() {
    return {
      bcweekList1:[
        'one',
        'two',
        'three',
        'four',
        'five',
        'six',
        'sever',
        'eight',
        'nine',
        'ten',
        'eleven',
        'twelve',
        'thirteen',
        'fourteen'
      ],
      bcweekList: Array(
        'one',
        'two',
        'three',
        'four',
        'five',
        'six',
        'sever'
        // 'eight',
        // 'nine',
        // 'ten',
        // 'eleven',
        // 'twelve',
        // 'thirteen',
        // 'fourteen'
      ),
      bcweekCon: [3, 4, 5, 6, 7, 8, 9],
      formType: 'create',
      marketPicker: false,
      market: '', //哪个
      money: '',
      platform: '',
      robot_id: '',
      market_id: '',
      first_order_value: '10',
      max_order_count: '7',
      stop_profit_rate: '1.3',
      stop_profit_callback_rate: '0.3',
      cover_rate: '4',
      cover_one: '4',
      cover_two: '4',
      cover_three: '4',
      cover_four: '4',
      cover_five: '4',
      cover_six: '4',
      cover_sever: '4',
      // cover_eight: '4',
      // cover_nine: '4',
      // cover_ten: '4',
      // cover_eleven: '4',
      // cover_twelve: '4',
      // cover_thirteen: '4',
      // cover_fourteen: '4',
      cover_callback_rate: '0.5',
      recycle_status:1,
      // cd_key: ''
      show: false,
      checked: false,
      is_double: 0,

      curDefault:-1,
      defalutData:[]
    }
  },
  watch:{
    max_order_count(val){
      if(val>0){
        let len = val >= 14 ? 14 : val <= 7 ? 7: val, bcweekList1 = [...this.bcweekList1]
        this.bcweekList = bcweekList1.splice(0,len)
      }
    }
  },
  computed: {
    ...mapState({
      robotList: ({ robot }) => robot.robotList,
      thirdLoginEnabled: ({ thirdLoginEnabled }) => thirdLoginEnabled,
      defalutStrategy: ({ robot }) => robot.defalutStrategy,
    }),
    ...mapGetters({
      markets: 'robot/markets',
    }),
    marketLists() {
      return this.markets(this.platform) || []
    },
  },

  async created() {
    var that = this
    await this.robotStrategy()
    this.formType = this.$route.query.type
    if (this.$route.query.robot_id == 0) return this.selectDefault(0);

    if (this.formType === 'edit') {
      const robot = (this.robot = this.robotList.find(
        (item) => this.$route.query.robot_id === item.id
      ))
      this.$nextTick(() => {
        this.platform = robot.platform
        this.market = robot.market_name
        this.market_id = robot.market_id
        this.robot_id = robot.id
        this.first_order_value = robot.first_order_value
        this.max_order_count = robot.max_order_count
        this.stop_profit_rate = robot.stop_profit_rate
        this.stop_profit_callback_rate = robot.stop_profit_callback_rate
        this.cover_rate = robot.cover_rate
        this.cover_callback_rate = robot.cover_callback_rate
        this.recycle_status = robot.recycle_status
        this.money = robot.money || 'USDT'
        this.bcweekCon = robot.cover_rates.length > 0 ? robot.cover_rates : this.bcweekCon
        this.is_double = robot.is_double
        this.checked = robot.is_double==1?true:false
        this.marketList({
          platform: this.platform,
          type: 'spot',
        })
      })
      
    } else {
      const markets = JSON.parse(this.$route.query.data)
      this.platform = this.$route.query.platform
      this.market = markets.market_name
      this.market_id = markets.id
      this.money = markets.money

      this.selectDefault(0)
      this.marketList({
        platform: this.platform,
        type: 'spot',
      })
    }
   
  },
  methods: {
    onInput(checked) {
      console.log('asfdf')
      // console.log(is_double)
      if (this.checked) {

        this.is_double = 1
      } else {

        this.is_double = 0
      }
      console.log(this.is_double)
    },
    subCon() {
      // console.log(this.bcweekCon)
      this.show = false
    },
    // 弹窗
    showPopup() {
      this.show = true
    },
    ...mapActions({
      marketList: 'robot/marketList',
      robotCreate: 'robot/robotCreate',
      robotEdit: 'robot/robotEdit',
      mulEdit: 'robot/mulEdit',
       robotStrategy: 'robot/robotStrategy',
       getrobotList: 'robot/robotList',
    }),
    onMarket() {
      this.marketPicker = true
      if (this.formType === 'create') {
      }
    },
    onSubmit() {
      this.$toast.loading()
     
      const payload = {
        platform: this.platform,
        market_id: this.market_id,
        first_order_value: this.first_order_value,
        max_order_count: this.max_order_count,
        stop_profit_rate: this.stop_profit_rate,
        stop_profit_callback_rate: this.stop_profit_callback_rate,
        cover_rate: this.cover_rate,
        cover_callback_rate: this.cover_callback_rate,
        recycle_status: this.recycle_status,
        cover_rates: this.bcweekCon.join(','),
        is_double: this.is_double,
        // cd_key: this.cd_key
      }
      if (this.formType === 'edit') {
        payload.robot_id = this.robot_id
      }
      if (this.$route.query.robot_id == 0) {
        payload.robot_id = tokenStorage.get('robot_ids')
        delete payload.recycle_status
        var that = this

        this.mulEdit(payload).then(function (ret) {
          console.log(ret)
          if (ret.code == 1) {
            // console.log(ret.data);
            that.$toast.clear()
            // that.$toast.success('修改成功')
            that.$toast(ret.msg)
            //
            that.$router.push({
              path:'/market',
              query:{
                active:that.$route.query.active
              }
            }) //返回上一页
            // that.creatQrCode();
          } else {
            that.$toast.fail(ret.msg)
          }
        })
      } else {
        const promise =
          this.formType === 'create' ? this.robotCreate(payload) : this.robotEdit(payload)
        promise
          .then((res) => {
            this.$toast(res.msg)
           
           if(res.code == 1){
            this.$router.back()
           }
            
            if(this.formType === 'create'){
              this.getrobotList()
            }
          })
          .catch(({ msg }) => this.$toast(msg))
      }
    },
    onConfirm(value) {
      this.market = value.market_name
      this.market_id = value.id
      this.marketPicker = false
      if(value.robot_status == 1){
          this.formType = 'edit'
      }else{
          this.formType = 'create'
      }
    },

    selectDefault(index){
      if(this.curDefault == index) return;
      this.curDefault = index
      for(let i in this.defalutStrategy[index].data){
        if(i == 'market') continue;
        this[i] = this.defalutStrategy[index].data[i]
      }
      let bcweekList1 = [...this.bcweekList1],len = this.defalutStrategy[index].data.bcweekCon.length<=7?7:this.defalutStrategy[index].data.bcweekCon.length
      this.bcweekList = bcweekList1.splice(0,len)
    }
  },
}
</script>
<style lang="less" scoped>
/deep/.van-switch--on {
  background-color: @themeColor;
}
.cent {
  width: 100%;
  font-size: 14px;
  line-height: 26px;
}
/deep/.cent .van-field__label {
  width: 15.2em;
}
/deep/.cent .van-field__control {
  text-align: center;
  padding-right: 10px;
}
.cent .title {
  font-size: 16px;
  margin-top: 15px;
  padding-left: 15px;
  border-bottom: 1px solid #f8f8f8;
}
.jiayi {
  width: 100%;
  line-height: 32px;
  padding: 3px 15px;
  background: #fff;
  border-bottom: 1px solid #f8f8f8;
  overflow: hidden;
  color: #646566;
}
.jiayi .fei {
  width: 26%;
  float: left;
}
.jiayi .lv {
  float: right;
  width: 14px;
  height: 14px;
}
.jiayi .lv img {
  width: 100%;
}
.cent .tijiao {
  width: 90%;
  overflow: hidden;
  margin: 10px auto;
  text-align: center;
  background: @themeColor;
  border-radius: 999px;
  color: #fff;
  line-height: 36px;
}

.default_data{
  padding:10px 15px;
  background: #fff;
  .defalut_data_title{
    margin-bottom:10px;
    color:#646566;
  }
  .default_data_box{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-wrap: wrap;
  }
  .default_data_i{
    width:70px;
    padding:5px 0;
    box-sizing: border-box;
    border:1px solid @themeColor;
    color:@themeColor;
    text-align: center;
    font-size: 13px;
    margin-bottom:10px;
    margin-right: 15px;

  }
  .default_data_i_s{
    background: @themeColor;
    color:#fff;
  }
}
</style>
