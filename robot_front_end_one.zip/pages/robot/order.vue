<template>
  <div class="page page_robot_order">
    <van-nav-bar
      :border="false"
      :title="$t('pageRobot.order')"
      left-arrow
      @click-left="$router.back()"
    />
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="$t('finished_text')"
        @load="onLoad"
      >
        <van-cell v-for="item in orderList" :key="item.id">
          <div class="b_log">
            <img :src="item.img" alt="" />
          </div>
          <div class="robot-item">
            <div class="hd">
              <div v-if="item.side == 1" class="status" style="color: red; opacity: 0.8">
                {{ $t('sell_out') }}
              </div>
              <div v-else class="status" style="color: green">{{ $t('buy_in') }}</div>
              <div class="name">{{ item.stock }} / {{ item.money }}</div>
              <div class="huo">{{item.platform}}</div>
            </div>
            <div class="time">
              <span class="ti">{{ $t('closing_time') }}</span
              ><span>{{ item.ctime }}</span>
            </div>
            <div class="info">
              <div>
                <span class="ti">{{ $t('order_hao') }}</span
                ><span>{{item.order_id}}</span>
              </div>
              <div>
                <span class="ti">{{ $t('order_xia') }}</span
                ><span>市价</span>
              </div>
              <div>
                <span class="ti">{{ $t('order_xiasl') }}</span
                ><span>{{item.total}}</span>
              </div>
              <div>
                <span class="ti">{{ $t('order_cheng') }}</span
                ><span>{{ Number(item.price) | numberFormat(8) }} {{ item.money }}</span>
              </div>
              <div>
                <span class="ti">{{ $t('turnover') }}</span
                ><span>{{ Number(item.deal_money) | numberFormat(8) }} {{ item.money }}</span>
              </div>
              <div>
                <span class="ti">{{ $t('number_deals') }}</span
                ><span>{{ Number(item.deal_amount) | numberFormat(8) }} {{ item.stock }}</span>
              </div>
              <!-- <div>
                <span class="ti">{{ $t('price') }}</span
                ><span>{{ Number(item.price) | numberFormat(8) }} {{ item.money }}</span>
              </div> -->
              <div>
                <span class="ti">{{ $t('order_shou') }}</span
                ><span>{{ Number(item.fee) | numberFormat(8) }}</span>
              </div>
              <div>
                <span class="ti">{{ $t('order_bu') }}</span
                ><span>{{ Number(item.amount) | numberFormat(8) }}</span>
              </div>
              <div>
                <span class="ti">{{ $t('order_ying') }}</span
                ><span>{{ Number(item.revenue) | numberFormat(8) }}</span>
              </div>
            </div>
          </div>
        </van-cell>
      </van-list>
      <van-empty v-if="orderList.length === 0" :description="$t('empty.order')" />
    </van-pull-refresh>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  data() {
    return {
      robot_id: this.$route.query.id,
      loading: false,
      finished: false,
      refreshing: false,
      orderList: [],
      offset: 0,
      limit: 20,
    }
  },
  methods: {
    ...mapActions({
      robotOrder: 'robot/robotOrder',
    }),
    loadList() {
      if (this.refreshing) {
        this.orderList = []
        this.offset = 0
        this.finished = false
        if (this.loading) {
          this.loading = false
          return
        }
      }
      if (this.loading) {
        this.refreshing = false
      }
      const payload = {
        robot_id: this.robot_id,
        limit_begin: this.offset,
        limit_end: this.limit,
      }
      this.robotOrder(payload)
        .then(({ data }) => {
          const list = data.data
          if (list.length < this.limit) {
            this.finished = true
          } else {
            this.offset += this.limit
          }
          this.orderList = this.orderList.concat(list)
        })
        .finally(() => {
          this.loading = false
          this.refreshing = false
        })
    },
    onLoad() {
      this.loadList()
    },
    onRefresh() {
      this.loadList()
    },
  },
}
</script>
<style lang="less" scoped>
/deep/ .van-cell {
  width: 94%;
  margin: 10px auto;
}

.robot-item div.huo {
  float: right;
  width: 100px;
  text-align: right;
  font-size: 12px;
  color: @themeColor;
}
.robot-item div.time {
  padding-bottom: 10px;
  border-bottom: 1px solid #efefef;
}
.b_log {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: #e9e9e9;
  float: left;
  margin-right: 10px;
  margin-top: 10px;
  overflow: hidden;
}
.b_log img{
  width: 100%;
}
.robot-item {
  overflow: hidden;
}
.robot-item .hd {
  font-size: 16px;
  display: flex;
  padding: 10px 0 5px;
  // justify-content: space-between;
  align-items: center;
}
.robot-item .name {
  float: left;
  width: 200px;
  font-weight: bold;
}
.robot-item .status {
  width: 50px;
  float: left;
  font-size: 16px;
  font-weight: bold;
}
.robot-item .info {
  padding: 10px 0;
  // background-color: rgba(0, 0, 0, 0.03);
  line-height: 1.8;
  font-size: 12px;
  color: #999999;
}
.robot-item .info .ti {
  display: block;
  float: left;
  width: 64px;
  color: #999999;
}
.robot-item .info span {
  color: #333;
  background-color: transparent;
  font-weight: 400;
}
.robot-item div {
  background-color: transparent;
  font: inherit;
  color: inherit;
}
</style>
