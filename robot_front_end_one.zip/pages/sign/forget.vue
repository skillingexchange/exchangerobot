<template>
  <div class="forget page">
    <van-nav-bar :title="$t('forget_pwd')" left-arrow @click-left="$router.back()" />
    <van-form @submit="onSubmit">
      <van-field
        v-model="username"
        :label="$t('pageSign.account')"
        :placeholder="$t('pageSign.account')"
        :rules="[{ required: true }]"
        label-class="select_name"
      >
      <template #label>
          <van-dropdown-menu >
            <van-dropdown-item v-model="typeValue" :options="option"  title-class="select_type" @change="typeChange" />
          </van-dropdown-menu>
      </template>
      
      </van-field>
      <van-field
        v-model="verification_code"
        clearable
        :label="$t('pageSign.valid_code')"
        :placeholder="$t('pageSign.valid_code')"
        :rules="[{ required: true }]"
      >
        <template #button>
          <van-button
            size="small"
            type="primary"
            block
            :disabled="times !== 60"
             style="background:#0166ec;color:#fff;"
            @click.prevent="handleGetCode"
          >
            <template v-if="times === 60">{{ $t('pageSign.send_code') }}</template>
            <template v-else>{{ times }}s</template>
          </van-button>
        </template>
      </van-field>
      <van-field
        v-model="password"
        type="password"
        :label="$t('pageSign.pwd')"
        :placeholder="$t('pageSign.pwd')"
        :rules="[{ required: true }]"
      />
      <van-field
        v-model="confirm_password"
        type="password"
        :label="$t('pageSign.confirm_pwd')"
        :placeholder="$t('pageSign.pwd')"
        :rules="[{ required: true }]"
      />
      <div style="margin: 15px">
        <van-button block type="info" native-type="submit" class="submit">{{ $t('actions.submit') }}</van-button>
      </div>
    </van-form>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import { isPhone, isEmailOrPhone, isEmail } from '@/utils/validator'
export default {
   i18n: {
    messages: {
      zh: {
        forget_pwd: '找回密码',

      },

    },
  },
  data () {

    return {
      username: '',
      password: '',
      confirm_password: '',
      verification_code: '',
      times:60,
      option:[
          { text: '手机号', value: 1 },
          { text: '邮箱', value: 0 },
      ],
      typeValue:1
    }

  },
  computed:{
    ...mapState({
      initInfo:(index)=>index.initInfo
    })
  },
  mounted(){
    if(this.initInfo.switch_sgin==1){
      this.option.splice(1,1)
      this.typeValue = 1
    }else if(this.initInfo.switch_sgin==0){
      this.option.splice(0,1)
      this.typeValue = 0
    }
  },
  methods: {
    ...mapActions({
      getCode: 'user/getCode',
      login: 'user/login',
      forgetPwd: 'user/forgetPwd',
      getEmailCode: 'user/getEmailCode',
    }),
    handleGetCode () {
      if (isEmailOrPhone(this.username)) {
        const username = isPhone(this.username) ? `86-${this.username}` : this.username
        if(this.times!=60){
          this.$toast('请稍后再试')
          return false;
        }
         if(isEmail(this.username)){
          this.getEmailCode(username)
          .then((data) => {
            this.$toast(data.msg)
            if(data.code==1){
              this.getTime()
            }
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
        }else{
        // console.log(username);
        this.getCode(username)
          .then((data) => {
            // console.log(data);
            // console.log('in time');
            this.$toast(data.msg)
            if(data.code==1){
              this.getTime()
            }
          })
          .catch(({ msg }) => {
            // console.log('show msg');
            this.$toast(msg)
          })
        }
      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
    getTime () {
      this.timer = setInterval(() => {
        this.times--
        // console.log(that.times);
        if (this.times === 0) {
          this.times = 60
          clearInterval(this.timer)
        }
      }, 1000)
    },
    onSubmit () {
      if (this.password !== this.confirm_password) {
        this.$toast(this.$t('pageSign.pwd_err'))
        return false
      }
      const username = isPhone(this.username)
        ? `86-${this.username}`
        : this.username
      const payload = {
        username,
        password: this.password,
        verification_code: this.verification_code
      }
      this.forgetPwd(payload).then((res) => {
        this.$toast(res.msg)
        this.$router.replace('/sign/login')
      })
    },
    typeChange(e){
      console.log(e)
    }
  }
}
</script>

<style scoped lang="less">
/deep/.select_name{
  display: flex;
  justify-content: flex-start;
  align-items: center;

}
/deep/ .van-dropdown-menu{
    
}
/deep/ .van-dropdown-menu__bar{
  height: auto!important;
  background: transparent!important;
  box-shadow: 0 0 0;
 
}
/deep/ .van-dropdown-menu__item{
  justify-content: flex-start;
   .van-dropdown-menu__title--active{
       color:@themeColor!important;
    } 
  .select_type{
    padding: 0 8px 0 0;
   
  }
  .select_type:after{
    border-color:transparent transparent #333 #333;
  }
}
/deep/ .van-dropdown-item{
  .van-dropdown-item__option--active,.van-dropdown-item__icon{
    color:@themeColor!important;
  }
}
</style>
