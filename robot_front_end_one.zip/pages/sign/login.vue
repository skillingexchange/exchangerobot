<template>
  <div class="container login">
    <div class="card" >
      <div class="form-title" >
        <van-image width="80px" :src="logo" />
        <h3><b>{{ appName[$i18n.locale] }}</b></h3>
<!--        <h2>{{ $t('login') }}</h2>-->
      </div>
      <div class="card-shadow" >
        <div class="tab" >
          <div class="tab_i" :class="{ tab_i_active: active === 1 }"  @click="active = 1" >
             <div class="span" :class="{ active: active === 1 }">{{
                $t('login')
              }}</div>
          </div>
          <div class="tab_i" :class="{ tab_i_active: active === 2 }" @click="active = 2">
              <div class="span" :class="{ active: active === 2 }" >{{
                $t('sign_up')
              }}</div>
          </div>

        </div>
        <!--登录表单 S-->
        <van-form v-if="active === 1" label-width="4.5em" @submit="onSubmit">
          <van-field
            v-model="username"
            :rules="[{ required: true }]"
            type="text"
            :placeholder="$t('login_input') + $t('login_label')"
            :border='false'
            v-if="!loginType"
             @input="inputData($event,'username')"
          >

          </van-field>
          <van-field
            v-model="username"
            :rules="[{ required: true }]"
            type="text"
            :placeholder="$t('login_input') + $t('pageSign.email')"
            :border='false'
            v-if="loginType === 'email'"
            @input="inputData($event,'username')"
          >
          </van-field>
          <van-field
            v-model="username"
            :rules="[{ required: true }]"
            type="text"
            :placeholder="$t('login_input') + $t('pageSign.phone')"
            :border='false'
            v-if="loginType === 'phone'"
            @input="inputData($event,'username')"
          >
          </van-field>
          <!-- 图片验证码 -->
          <!-- <van-field
            v-model="verification_code"
            clearable
            :label="$t('pageSign.valid_code')"
            :placeholder="$t('pageSign.valid_code')"
            :rules="[{ required: true }]"
          >
             <div class="tu"></div>
          </van-field> -->
          <van-field
            v-model="password"
            type="password"
            :placeholder="$t('login_input') + $t('pageSign.pwd')"
            :rules="[{ required: true }]"
            :border='false'
            @input="inputData($event,'password')"
          />
          <van-button block type="info" native-type="submit" class="submit"  :disabled="!canLogin">{{
            $t('button_login')
          }}</van-button>
        </van-form>
        <!--登录表单 E-->
        <!--注册表单 S-->
        <van-form v-else label-width="4em" >
           <van-field
            v-model="username1"
            :rules="[{ required: true }]"
            :placeholder="$t('login_input') + $t('login_label_placeholder')"
            v-if="!loginType"
            :error-message="err_username1"
            :border="false"
          >
          </van-field>
          <van-field
            v-model="username1"
            :placeholder="$t('login_input') + $t('pageSign.phone')"
            :rules="[{ validator: isPhone }]"
            v-if="loginType === 'phone'"
            :error-message="err_username1"
            :border="false"
          >
          </van-field>
          <van-field
            v-if="loginType === 'email'"
            v-model="username1"
            :placeholder="$t('login_input') + $t('pageSign.email')"
            :rules="[{ validator: isEmail }]"
            :error-message="err_username1"
            :border="false"
          />

          <div class="verification_code flex">
            <van-field
              v-model="verification_code1"
              clearable
              :placeholder="$t('pageSign.valid_code')"
              :rules="[{ required: true }]"
              :border="false"
              :error-message="err_verification_code1"
            >

            </van-field>
            <div class="code_btn">
               <van-button
                size="small"
                type="primary"
                block
                :disabled="times !== 60"
                @click.prevent="handleGetCode"
              >
                <template v-if="times === 60">{{$t('pageSign.send_code')}}</template>
                <template v-else>{{$t('has_send')}}{{ times }}s</template>
              </van-button>
            </div>

          </div>

          <van-field
            v-model="password1"
            type="password"
            :placeholder="$t('login_input') + $t('pageSign.pwd')"
            :rules="[{ required: true }]"
            :border="false"
            :error-message="err_password1"
          />
          <van-field
            v-model="confirm_password"
            type="password"
            :placeholder="$t('login_input_again') + $t('pageSign.pwd')"
            :rules="[{ required: true }]"
            :border="false"
            :error-message="err_confirm_password"
          />
          <van-field
            v-model="invitation_code"
            :placeholder="$t('login_input') + $t('pageSign.invitation_code')"
            :border="false"
          />
          <van-checkbox v-model="checked" icon-size="16" class="checkbox-link">
            {{ $t('pageSign.agreed')
            }}<a @click.stop="goAgreement">{{ $t('pageSign.agreement') }}</a>
          </van-checkbox>

          <van-button block type="info" @click="registerSubmit" class="submit" :disabled="!checked">
            {{ $t('button_register') }}
          </van-button>

        </van-form>
        <!--注册表单 E-->

        <!--忘记密码-->
        <div class="links" v-if="active == 1">
          <nuxt-link to="/sign/forget">{{ $t('pageSign.forget_pwd') }}</nuxt-link>
        </div>
      </div>
    </div>
    <!-- <div class="fx">{{ $t('pageSign.fx') }}</div> -->
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { isPhone, isEmailOrPhone, isEmail } from '@/utils/validator'
import storage from '@/utils/storage'
export default {
   i18n: {
    messages: {
      zh: {
        button_login:'登 录',
        button_register:'注 册',
        login_input:'请输入',
        login_input_again:'再次输入',
        login_label: '账号',
        login_label_phone: '手机号',
        login_label_email: '邮箱',
        login_label_placeholder:'手机号/邮箱',
        has_send:'已发送',

        err_username:'*格式错误',
        err_password:'*请输入密码',
        err_verification_code1:'*请输入验证码',
        err_confirm_password:'*密码不一致',
      },
      en: {
        button_login:'Login',
        login_input:'Please enter the ',
        login_input_again:'Please repeat the ',
        login_label: 'Account',
        login_label_phone: 'Phone',
        login_label_email: 'Email',
        login_label_placeholder:'Phone/Email',
        has_send:'Has send ',

        err_username:'*Format Error',
        err_password:'*Please enter the password',
        err_verification_code1:'*Please enter the verification code',
        err_confirm_password:'*Password Inconsistency',
      },
    },
  },
  data() {
    return {
      // logo: require('@/assets/images/login_logo.png'),
      active: 1,
      username: '',
      password: '',
      verification_code: '',
      times: 60,
      loginType: '',
      times:60,
      canLogin:false,

      username1:'',
      password1:'',
      verification_code1:'',
      confirm_password:'',
      invitation_code:'',

      checked: false,
      err_username:'',
      err_password:'',
      err_username1:'',
      err_confirm_password:'',
      err_password1:'',
      err_verification_code1:''

    }
  },
  computed:{
    ...mapState({
      appName:(index)=>{return index.appName},
      logo:(index)=>{return index.logo},
      initInfo: (index) => index.initInfo,
    })
  },
   watch:{
    initInfo:{
      handler(val,v){
        if(val.switch_sgin==1 ){
          this.loginType = 'phone'
        }else if(val.switch_sgin==0){
          this.loginType = 'email'
        }else{
          this.loginType = ''
        }
      },
      immediate:true,
    }
  },
  methods: {
    ...mapActions({
      getCode: 'user/getCode',
      login: 'user/login',
      getUserInfo: 'user/getUserInfo',
      register: 'user/register',
      getEmailCode: 'user/getEmailCode',
    }),
    //表单输入
    inputData(e,type){
      if(this.username && this.password){
        this.canLogin = true
      }else{
        this.canLogin = false
      }
    },

    handleGetCode1() {
      if (isEmailOrPhone(this.username)) {
        const username = isPhone(this.username) ? `86-${this.username}` : this.username
        this.$toast.loading()
        this.getCode(username)
          .then(({ msg }) => {
            this.$toast(msg)
            this.getTime()
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
    onSubmit() {
      this.$toast.loading()
      const username = isPhone(this.username) ? `86-${this.username}` : this.username
      const payload = { username, device_type: 'web' }
      if (this.active === 1) {
        payload.password = this.password
      } else {
        payload.verification_code = this.verification_code
      }
      this.$toast.loading()
      this.login([this.active, payload])
        .then((res) => {
          this.$toast(res.msg)
          if (res.code == 1) {
            this.getUserInfo()
            this.$nextTick(() => {
              this.$router.replace('/home')
            })
          } else {
          }
        })
        .catch((res) => {
          this.$toast(res.msg)
        })
    },
    getTime() {
      this.timer = setInterval(() => {
        this.times--
        if (this.times === 0) {
          clearInterval(this.timer)
          this.times = 60
        }
      }, 1000)
    },

    //注册
    registerSubmit(){
      //参数校验
      if(!isEmailOrPhone(this.username1)){
        this.err_username1 = this.$t('err_username')
        return
      }else{
        this.err_username1 = ''
      }

      if(!this.verification_code1){
        this.err_verification_code1 = this.$t('err_verification_code1')
        return
      }else{
        this.err_verification_code1 = ''
      }

      if(!this.password1){
        this.err_password1 = this.$t('err_password')
        return
      }else{
        this.err_password1 = ''
      }

      if(this.password1 !== this.confirm_password){
        this.err_confirm_password = this.$t('err_confirm_password')
        return
      }else{
        this.err_confirm_password = ''
      }


      if (this.password1 !== this.confirm_password) {
        this.$toast(this.$t('pageSign.pwd_err'))
        return false
      }
      const username = isPhone(this.username1) ? `86-${this.username1}` : this.username1
      const payload = {
        username,
        password: this.password1,
        verification_code: this.verification_code1,
      }
      if (this.invitation_code) {
        payload.invitation_code = this.invitation_code
      }
      this.$toast.loading()
      this.register(payload)
        .then((res) => {
          this.$toast(res.msg)
          console.log(res);
          if (res.code == 1) {
            this.active = 1
            this.$router.replace('/sign/login')
          } else {

          }
        })
        .catch(({ msg }) => this.$toast(msg))
    },

    //发送验证码
    handleGetCode() {
      if (isEmailOrPhone(this.username1)) {
        const username = isPhone(this.username1) ? `86-${this.username1}` : this.username1
        this.$toast.loading()

        if(isEmail(this.username1)){
          this.getEmailCode(username)
          .then((data) => {
            this.$toast(data.msg)
            if(data.code==1){
              this.getTime()
            }
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
        }else{
           this.getCode(username)
          .then((data) => {
            this.$toast(data.msg)
            if(data.code==1){
              this.getTime()
            }
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
        }


      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
    goAgreement() {
      const regInfo = {
        active: this.active,
        username: this.username1,
        password: this.password1,
        confirm_password: this.confirm_password,
        verification_code: this.verification_code1,
        invitation_code: this.invitation_code,
      }
      storage.set('regInfo', JSON.stringify(regInfo))
      this.$router.push({
        name: 'common-article',
        params: {
          url: this.initInfo.system_user_agreement,
          title: '用户协议',
        },
      })
    },
  },
}
</script>

<style scoped lang="less">
.flex{
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.container {
  position: absolute;
  min-height: 100vh;
  // background: linear-gradient(135deg, @themeColor 0 50%, #fff 50% 100%);
  background: url(~@/assets/images/login_bg.jpg) no-repeat top center;
  // background-color: @themeColor;
  background-size: 100% 100%;
  overflow: hidden;
  padding: 60px 19px 30px;
}
.card {
  // height: 100%;
  // display: flex;
  // flex-direction: column;
  // align-items: center;
}
.fx {
  width: 92%;
  position: absolute;
  text-align: center;
  bottom: 5%;
  left: 4%;
  color: #fff;
}
.card-shadow {
  width: 90vw;
  padding: 0 0 35px;
  border-radius: 23px;
  background-color: rgba(255, 255, 255, 1);
  box-shadow: 0px 7px 50px 0px rgba(169, 169, 169, 0.3);

}
.form-title {
  color: #ffffff;
  margin-bottom: 30px;
  font-weight: 500;
  text-align: center;
}
/deep/ .van-form{
  padding:0 22px 0;
}
/deep/.van-form .van-field {
  margin-bottom: 20px;
  line-height: 45px;
  margin-top: 20px;
  padding:0;
  .van-field__body{
    background: #f5f5f5;
    padding: 3px 15px;
    border-radius: 40px;
  }
  .van-field__body{
    font-size: 15px;
  }
  .slot-inp{
    width: 100%;
    font-size: 15px;
  }
  .van-field__error-message{
    padding: 0 15px;
    line-height: 30px;
  }

}
.submit {
  border-radius: 40px;
  height: 45px;
  box-shadow: 0px 5px 23px 2px rgba(2, 85, 196, 0.3);
  background: linear-gradient(90deg, #0B73FF 0%, #4E6EF2 100%);
  margin-top: 30px;
  font-size: 18px;
}
.submit_disable{
  opacity: 0.4;
}
.divider {
  display: inline-block;
  vertical-align: middle;
  width: 1px;
  height: 16px;
  margin: 0 10px;
  background-color: #eee;
  transform: scaleX(0.5);
}
.links {
  text-align: center;
  margin-top:20px;
  a {
    color: @themeColor;
  }
}
.tab {
  margin-bottom: 10px;
  color: #333;
  display: flex;
  text-align: center;
  justify-content: space-around;
  align-items: center;
  font-size: 15px;
  font-weight: 500;
  border-radius: 23px 23px 0 0 ;
  overflow: hidden;
  .tab_i{
    padding: 15px 0;
    flex: 1;
    background: #f5f5f5;
  }
  .tab_i_active{
    background: #fff;
  }
  .span {
    cursor: pointer;
    transition: 0.3s;
    position: relative;
    &::after {
      content: '';
      position: absolute;
      top: 145%;
      left: 50%;
      width: 12px;
      height: 3px;
      margin-left: -6px;
      transition: 0.3s;
      border-radius: 10px;
    }
  }
  .active {

    color:  @themeColor;

    &::after {
      background-color: @themeColor;
    }
  }
}
.slot-inp {
  display: flex;
  align-items: center;
}
.tel-area {
  flex-shrink: 0;
  color: #666;
  margin-right: 5px;
}
.slot-label {
  height: 100%;
  display: flex;
  align-items: center;
}
.select {
  border: none;
  -moz-appearance: none;
  -webkit-appearance: none;
  border-radius: 0;
  outline: medium;
  background-color: transparent;
  color: #646566;
}
.checkbox-link {
  font-size: 12px;
  margin-bottom: 15px;
  a {
    color: @themeColor;
  }
}
.verification_code{
  /deep/ .van-field{
    margin:0;
  }
  .code_btn{
    width: 55%;
    margin-left:5px;
    /deep/ .van-button--primary{
      color: @themeColor;
      background: transparent;
      border: 0;
      font-size: 13px;
    }
    /deep/ .van-button::before{
      border: 0;
    }
  }
}
</style>
