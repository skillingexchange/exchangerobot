<template>
  <div class="container login">
    <div class="card">
      <div class="form-title">
        <van-image width="100px" :src="logo" />
        <h2><b>{{ appName[$i18n.locale] }}</b></h2>
<!--        <h2>{{ $t('login') }}</h2>-->
      </div>
      <div class="card-shadow">
        <div class="tab">
          <span :class="{ active: active === 1 }" @click="active = 1">{{
            $t('pageSign.login_pwd')
          }}</span>
<!--          <span :class="{ active: active === 2 }" @click="active = 2">{{-->
<!--            $t('pageSign.login_code')-->
<!--          }}</span>-->
        </div>
        <van-form v-if="active === 1" label-width="4.5em" @submit="onSubmit">
          <van-field
            v-model="username"
            :rules="[{ required: true }]"
            type="text"
            :label="$t('login_label')"
            :placeholder="$t('login_label')"
            :border='false'
          >
            <!-- <div slot="label" class="slot-label">
              <select v-model="loginType" class="select">
                <option value="phone">{{ $t('pageSign.phone') }}</option>
                <option value="email">{{ $t('pageSign.email') }}</option>
              </select>
              <van-icon name="arrow-down" size="12" />
            </div> -->
            <div v-if="!loginType" slot="input" class="slot-inp">
              <input
                v-model="username"
                type="text"
                class="van-field__control"
                :placeholder="$t('login_label_placeholder')"
              />
            </div>
            <div v-if="loginType === 'email'" slot="input" class="slot-inp">
              <input
                v-model="username"
                type="text"
                class="van-field__control"
                :placeholder="$t('pageSign.email')"
              />
            </div>
            <div v-if="loginType === 'phone'" slot="input" class="slot-inp">
              <!-- <span class="tel-area">86 -</span> -->
              <input
                v-model="username"
                type="text"
                class="van-field__control"
                :placeholder="$t('pageSign.phone')"
              />
            </div>
          </van-field>
          <!-- 图片验证码 -->
          <!-- <van-field
            v-model="verification_code"
            clearable
            :label="$t('pageSign.valid_code')"
            :placeholder="$t('pageSign.valid_code')"
            :rules="[{ required: true }]"
          >
             <div class="tu"></div>
          </van-field> -->
          <van-field
            v-model="password"
            type="password"
            :label="$t('pageSign.pwd')"
            :placeholder="$t('pageSign.pwd')"
            :rules="[{ required: true }]"
            :border='false'
          />
          <van-button block type="info" native-type="submit" class="submit">{{
            $t('login')
          }}</van-button>
        </van-form>
        <van-form v-else label-width="4em" @submit="onSubmit">
          <van-field
            v-model="username"
            :label="$t('pageSign.account')"
            :rules="[{ required: true }]"
          >
            <div slot="input" class="slot-inp">
              <!-- <span class="tel-area">86 -</span> -->
              <input
                v-model="username"
                type="text"
                class="van-field__control"
                :placeholder="$t('pageSign.phone')"
              />
            </div>
          </van-field>
          <van-field
            v-model="verification_code"
            clearable
            :label="$t('pageSign.valid_code')"
            :placeholder="$t('pageSign.valid_code')"
            :rules="[{ required: true }]"
          >
<!--            <template v-if="active === 2" #button>-->
<!--              <van-button-->
<!--                size="small"-->
<!--                type="primary"-->
<!--                block-->
<!--                :disabled="times !== 60"-->
<!--                @click.prevent="handleGetCode"-->
<!--              >-->
<!--                <template v-if="times === 60">{{ $t('pageSign.send_code') }}</template>-->
<!--                <template v-else>{{ times }}s</template>-->
<!--              </van-button>-->
<!--            </template>-->
          </van-field>
          <van-button block type="info" native-type="submit" class="submit">
            {{ $t('login') }}
          </van-button>
        </van-form>
        <div class="links">
          <nuxt-link to="/sign/register">{{ $t('pageSign.free_reg') }}</nuxt-link>
          <div class="divider"></div>
          <nuxt-link to="/sign/forget">{{ $t('pageSign.forget_pwd') }}</nuxt-link>
        </div>
      </div>
    </div>
    <div class="fx">{{ $t('pageSign.fx') }}</div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { isPhone, isEmailOrPhone } from '@/utils/validator'
export default {
   i18n: {
    messages: {
      zh: {
        login_label: '账号',
        login_label_phone: '手机号',
        login_label_email: '邮箱',
        login_label_placeholder:'手机号/邮箱'
      },
      en: {
        login_label: 'Account',
        login_label_phone: 'Phone',
        login_label_email: 'Email',
        login_label_placeholder:'Phone/Email'
      },
    },
  },
  data() {
    return {
      // logo: require('@/assets/images/login_logo.png'),
      active: 1,
      username: '',
      password: '',
      verification_code: '',
      times: 60,
      loginType: '',
    }
  },
  computed:{
    ...mapState({
      appName:(index)=>{return index.appName},
      logo:(index)=>{return index.logo},
      initInfo: (index) => index.initInfo,
    })
  },
   watch:{
    initInfo:{
      handler(val,v){
        if(val.switch_sgin==1 ){
          this.loginType = 'phone'
        }else if(val.switch_sgin==0){
          this.loginType = 'email'
        }else{
          this.loginType = ''
        }
      },
      immediate:true,
    }
  },
  methods: {
    ...mapActions({
      getCode: 'user/getCode',
      login: 'user/login',
      getUserInfo: 'user/getUserInfo',
    }),
    handleGetCode() {
      if (isEmailOrPhone(this.username)) {
        const username = isPhone(this.username) ? `86-${this.username}` : this.username
        this.$toast.loading()
        this.getCode(username)
          .then(({ msg }) => {
            this.$toast(msg)
            this.getTime()
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
    onSubmit() {
      this.$toast.loading()
      const username = isPhone(this.username) ? `86-${this.username}` : this.username
      const payload = { username, device_type: 'web' }
      if (this.active === 1) {
        payload.password = this.password
      } else {
        payload.verification_code = this.verification_code
      }
      this.$toast.loading()
      this.login([this.active, payload])
        .then((res) => {
          this.$toast(res.msg)
          if (res.code == 1) {
            this.getUserInfo()
            this.$nextTick(() => {
              this.$router.replace('/home')
            })
          } else {
          }
        })
        .catch((res) => {
          this.$toast(res.msg)
        })
    },
    getTime() {
      this.timer = setInterval(() => {
        this.times--
        if (this.times === 0) {
          clearInterval(this.timer)
          this.times = 60
        }
      }, 1000)
    },
  },
}
</script>

<style scoped lang="less">
.container {
  height: 100vh;
  // background: linear-gradient(135deg, @themeColor 0 50%, #fff 50% 100%);
  // background: url(~@/assets/images/login.png) no-repeat top center;
  background-color: @themeColor;
  background-size: 100%;
  overflow: hidden;
}
.card {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  transform: translateY(-8%);
}
.fx {
  width: 92%;
  position: absolute;
  text-align: center;
  bottom: 5%;
  left: 4%;
  color: #fff;
}
.card-shadow {
  width: 90vw;
  padding: 10vw 5vw;
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.8);
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
  box-shadow: 10px 10px 50px -20px rgba(0, 0, 0, 0.4);
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.5);
  border-right: 1px solid rgba(255, 255, 255, 0.2);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}
.form-title {
  color: #ffffff;
  margin-bottom: 30px;
  font-weight: 500;
  text-align: center;
  margin-top: 60px;
}
/deep/ .van-field {
  border-radius: 10px;
  margin-bottom: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}
.submit {
  border-radius: 10px;
  margin-bottom: 25px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}
.divider {
  display: inline-block;
  vertical-align: middle;
  width: 1px;
  height: 16px;
  margin: 0 10px;
  background-color: #eee;
  transform: scaleX(0.5);
}
.links {
  text-align: center;
  a {
    color: @themeColor;
  }
}
.tab {
  margin-bottom: 30px;
  color: #333;
  display: flex;
  text-align: center;
  justify-content: space-around;
  align-items: center;
  font-size: 16px;
  font-weight: 500;
  span {
    cursor: pointer;
    transition: 0.3s;
    &::after {
      content: '';
      position: absolute;
      top: 120%;
      left: 50%;
      width: 20px;
      height: 2px;
      margin-left: -10px;
      transition: 0.3s;
    }
  }
  .active {
    position: relative;
    transform: scale(1.2);
    &::after {
      background-color: @themeColor;
    }
  }
}
.slot-inp {
  display: flex;
  align-items: center;
}
.tel-area {
  flex-shrink: 0;
  color: #666;
  margin-right: 5px;
}
.slot-label {
  height: 100%;
  display: flex;
  align-items: center;
}
.select {
  border: none;
  -moz-appearance: none;
  -webkit-appearance: none;
  border-radius: 0;
  outline: medium;
  background-color: transparent;
  color: #646566;
}
</style>
