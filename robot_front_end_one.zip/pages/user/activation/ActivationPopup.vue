<template>
  <van-dialog
    v-model="showCodePop"
    :title="$t('title')"
    :confirm-button-text="$t('get')"
    :cancel-button-text="$t('actions.cancel')"
    confirmButtonColor="#0166ec"
    show-cancel-button
    @confirm="onActive"
  >
    <van-cell-group :border="false">
      <van-field
        v-model="activationCode"
        :label="$t('key')"
        label-width="4em"
        :placeholder="$t('please')"
      />
    </van-cell-group>
  </van-dialog>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '输入激活码',
        get: '激活',
        key: '激活码',
        please: '请输入激活码'
      },
      en: {
        title: 'Use CDkey',
        get: 'activate',
        key: 'CDkey',
        please: 'Please enter the CDkey'
      },
    }
  },
  data () {
    return {
      showCodePop: false,
      activationCode: ''
    }
  },
  methods: {
    ...mapActions({
      cdkeyActive: 'user/cdkeyActive'
    }),
    onActive () {
      this.$dialog
        .confirm({
          title: '提示',
          message: `使用该激活码? \n ${this.activationCode}`,
          className:'dialog_class'
        })
        .then(() => {
          this.$toast.loading()
          this.cdkeyActive({ keys: this.activationCode }).then(({ msg }) => {
            this.$toast(msg)
            var that = this;
            setTimeout(function(){
              that.$router.go(0)
            },100)
            // this.$toast(res.msg)
          })
            .catch(({ msg }) => {
              this.$toast(msg)
            })
        })
    }
  }
}
</script>

<style>

</style>
