<template>
  <div class="page page_user_activation">
    <van-nav-bar
      :title="$t('public.cdkey')"
      left-arrow
      :right-text="$t('buy')"
      @click-left="$router.back()"
      @click-right="playshow = true"
    />
    <!--  -->
    <div class="tishi">{{ $t('tishi') }}</div>
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="$t('finished_text')"
        @load="onLoad"
      >
        <div v-for="item in list" :key="item.id" class="key-item">
          <van-row type="flex" justify="space-between" align="center">
            <van-col class="title">{{ $t('public.cdkey') }}：{{ item.keys }}</van-col>
            <van-col v-if="!item.used">
              <copy
                v-clipboard:copy="item.keys"
                v-clipboard:success="onCopy"
                theme="outline"
                size="16"
                fill="#323233"
                :stroke-width="2"
              />
            </van-col>
          </van-row>
          <van-row type="flex" justify="space-between" align="center">
            <van-col class="time">{{ $t('time') }}：{{ item.ctime | timeFormat }}</van-col>
            <van-col>
              <span v-if="item.used" class="status"
                >{{ $t('state') }}({{ $t('robot') }} ID:{{ item.qrobot_id }})</span
              >
            </van-col>
          </van-row>
        </div>
      </van-list>
    </van-pull-refresh>
    <!-- 月卡选择 -->

    <div class="tan" v-if="playshow">
      <div class="bg_bai">
        <van-icon name="close" @click="playshow = false" />
        <van-radio-group
          v-model="play_checked"
          direction="horizontal"
          v-for="item in cdkeyLevel"
          :key="item.flag"
        >
          <van-radio :name="item.flag">{{ item.title }}{{ item.price }}U</van-radio>
        </van-radio-group>

        <div class="ti" @click="palySub">{{ $t('pay') }}</div>
        <div class="she">
          {{ $t('setPwd') }}
          <span @click="$router.push({ path: 'settings/payPwd' })">
            {{ $t('pageUser.setting') }}</span
          >
        </div>
      </div>
    </div>
    <password-confirm :show="showPwd" @close="showPwd = false" @confrim="buyCdkey" />
  </div>
</template>

<script>
import { Copy } from '@icon-park/vue'
import { mapActions } from 'vuex'
import PasswordConfirm from '@/components/common/PasswordConfirm'
export default {
  components: { Copy, PasswordConfirm },
  i18n: {
    messages: {
      zh: {
        que: '支付',
        title: '激活码',
        tishi: '提示：购买激活码后复制，去粘贴来激活会员 ，多次购买可赠予他人',
        buy: '购买激活码',
        key: '激活码',
        time: '获得时间',
        state: '已使用',
      },
      en: {
        que: 'Pay',
        title: 'CDkey',
        tishi: '提示：购买激活码后复制，去粘贴来激活会员 ，多次购买可赠予他人',
        buy: 'Buy',
        key: 'CDkey',
        time: '获得时间',
        state: '已使用',
      },
    },
  },
  data() {
    return {
      showPwd: false,
      loading: false,
      finished: false,
      refreshing: false,
      playshow: false,
      list: [],
      play_checked: '',
      cdkeyLevel: [],
      flag: 'year',
    }
  },
  created() {
    // this.loadDetail()
    this.getkey()
    console.log(this.play_checked)
  },
  methods: {
    ...mapActions({
      cdkeyList: 'user/cdkeyList',
      cdkeyActive: 'user/cdkeyActive',
      cdkeyBuy: 'user/cdkeyBuy',
    }),
    //支付
    palySub() {
      var that = this
      this.cdkeyBuy()
        .then((res) => {
          console.log(res)
          if (res.code == 0) {
            this.$router.push(`/user/settings/payPwd`)
            this.$toast(res.msg)
          }
          if (res.code == 1) {
            this.playshow = false
            var that = this
            that.showPwd = true
            console.log(this.play_checked)
            this.flag = this.play_checked
          }
        })
        .catch((res) => {
          // console.log(res);
          this.$toast(res.msg)
        })
    },
    //
    getkey() {
      // console.log(this.play_checked)
      var that = this
      this.$axios.post('/api/user/cdkey/cdkeyLevel', {}).then(function (ret) {
        if (ret.data.code == 1) {
          that.cdkeyLevel = ret.data.data

          // that.robotList = ret.data.data

          // that.creatQrCode();
        } else {
          that.$toast.fail(ret.data.msg)
        }
      })
    },
    onLoad() {
      this.cdkeyList()
        .then((res) => {
          this.list = res.data
        })
        .finally(() => {
          this.loading = false
          this.finished = true
        })
    },
    onRefresh() {
      this.finished = false
      this.loading = true
      this.onLoad()
    },
    onCopy() {
      this.$toast('复制成功')
    },
    buyCdkey(password) {
      this.showPwd = false
      this.$toast.loading()
      this.cdkeyBuy({ password, flag: this.flag })
        .then((res) => {
          this.$toast(res.msg)
          this.onRefresh()
        })
        .catch(({ msg }) => {
          this.$toast(msg)
        })
    },
  },
}
</script>

<style scoped lang="less">
.she {
  width: 100%;
  text-align: center;
  line-height: 50px;

  color: @themeColor;
}
.she span {
  padding: 5px;
  border: 1px solid @themeColor;
  color: @themeColor;
}
/deep/.van-radio-group--horizontal {
  margin-top: 20px;
  margin-bottom: 20px;
}
.tishi {
  width: 94%;
  margin: 0 auto;
  margin-top: 10px;
  overflow: hidden;
  color: @themeColor;
  font-size: 14px;
  line-height: 20px;
}
.key-item {
  margin: 10px 15px;
  padding: 10px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 5px 5px 15px -5px rgba(0, 0, 0, 0.05);
  line-height: 30px;
}
.title {
  font-weight: 500;
}
.time {
  color: #999999;
  font-size: 12px;
}
.status {
  font-size: 12px;
  color: red;
  opacity: 0.6;
}
.btn {
  display: block;
  height: auto;
  padding: 5px 10px;
}
.tan {
  width: 100%;
  position: fixed;
  top: 0;
  height: 100%;
  overflow: hidden;
  background: rgba(0, 0, 0, 0.5);
  z-index: 9999;
}
.tan .bg_bai {
  width: 80%;
  position: absolute;
  left: 10%;
  top: 30%;
  background: #fff;
  padding: 10px 7%;
  border-radius: 10px;
}
/deep/.van-radio-group--horizontal {
  margin-top: 20px;
  margin-bottom: 20px;
}
/deep/.van-radio--horizontal {
  width: 100%;
  margin-top: 20px;
}
.bg_bai .ti {
  width: 100px;
  line-height: 40px;
  border-radius: 10px;
  color: #fff;
  background: @themeColor;
  text-align: center;
  margin: 0 auto;
}
.van-icon {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
}
/deep/.van-tab {
  font-size: 16px;
}
</style>
