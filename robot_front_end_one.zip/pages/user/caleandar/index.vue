<template>
  <div class="page page_user_caleandar">
    <van-nav-bar :border="false" :title="$t('pageUser.history')" left-arrow @click-left="$router.back()" />
    <!-- <van-tabs v-model="active">
      <van-tab :title="$t('log')"><log></log></van-tab>
      <van-tab :title="$t('order')"></van-tab>
    </van-tabs> -->
    <order></order>
  </div>
</template>

<script>
import Log from './components/Log'
import Order from './components/Order'
export default {
  components: { Log, Order },
  i18n: {
    messages: {
      zh: {
        log: '交易日志',
        order: '交易订单'
      },
      
    }
  },
  data () {
    return {
      active: 1
    }
  }
}
</script>
<style lang="less" scoped>
</style>
