<template>
  <div class="page_user" style="background: #f8f8f8">
    <div class="top-cover">
      <div safe-area-inset-top>
        <van-row type="flex" justify="space-between" align="center" class="page-header">
          <van-col class="page-header-left">
            <h2 class="page-title">{{ $t('nav.user') }}</h2>
          </van-col>
          <!-- <van-col v-if="logged" class="page-header-right">
            <nuxt-link to="/user/settings">
              <van-icon name="setting-o" color="#fff" size="20" />
            </nuxt-link>
          </van-col> -->
        </van-row>
      </div>
      <van-row
        v-if="logged"
        type="flex"
        justify="space-between"
        align="center"
        gutter="20"
        class="user-info"
      >
        <van-col style="flex: 1; min-width: 0">
          <van-row type="flex" align="center">
            <van-col>
              <van-image class="avatar" width="60" :src="userInfo.avatar"></van-image>
            </van-col>
            <van-col style="flex: 1; min-width: 0">
              <div class="user-nickname">{{ userInfo.user_nickname }}</div>
              <div class="infos flex">
                <div class="user-account user-account-sp">{{ $t('uid') }}:{{ userUid }}</div>
                <!-- <div class="user-account">{{ userInfo.signature }}</div> -->
                <div class="user-account user-account-sp">
                  {{ $t('deng') }}:{{ userInfo.level_title }}
                </div>
              </div>
              <div class="user-account">{{ $t('dao') }}:{{ userInfo.end_time }}</div>
            </van-col>
          </van-row>
        </van-col>
        <van-col>
          <div v-if="!thirdLoginEnabled" class="user-links" @click="$refs.cdkey.showCodePop = true">
            <van-icon name="coupon-o" />
            {{ $t('cdkey') }}
          </div>
        </van-col>
      </van-row>
      <van-row
        v-else
        class="user-info"
        type="flex"
        align="center"
        @click="$router.push('/sign/login')"
      >
        <van-col>
          <van-icon class="avatar" name="user-circle-o" size="60" />
        </van-col>
        <van-col>
          <div class="user-nickname">{{ $t('pageUser.login') }}</div>
          <div class="user-account">{{ $t('pageUser.welcome') }}</div>
        </van-col>
      </van-row>
    </div>

    <van-cell-group class="list-group" style="border-bottom: 0" :border="false">
      <van-cell
        :icon="require('@/assets/images/my_wallet.png')"
        :title="$t('pageUser.asset')"
        is-link
        @click="handleLink('/wallet?symbol=USDT')"
      />

      <van-cell
        :icon="require('@/assets/images/my_record.png')"
        :title="$t('pageUser.history')"
        is-link
        to="/user/caleandar"
      />
      <!-- 2021-04-10 zl 新增购买激活码 -->
      <van-cell
        v-if="!thirdLoginEnabled"
        :icon="require('@/assets/images/my_code.png')"
        :title="$t('pageUser.buyKey')"
        @click="buycdkeydone"
      />

      <van-cell
        v-if="!thirdLoginEnabled"
        :icon="require('@/assets/images/my_code.png')"
        :title="$t('pageUser.cdkey')"
        is-link
        to="/user/activation"
      />
    </van-cell-group>
    <!--
    <van-cell-group
      v-if="!thirdLoginEnabled"
      class="list-group"
    >
      <van-cell
        icon="manager"
        :title="$t('pageUser.safety_lv')"
        is-link
        to="/user/verified"
      />
      <van-cell
        icon="youzan-shield"
        :title="$t('pageUser.google_valid')"
        is-link
        to="/user/googleValid"
      />
    </van-cell-group> -->

    <van-cell-group v-if="!thirdLoginEnabled" class="list-group1" :border="false">
      <van-cell
        v-if="is_hangqing"
        :icon="require('@/assets/images/my_info.png')"
        :title="$t('nav.ticker')"
        is-link
        to="/ticker"
      />
      <van-cell
        :icon="require('@/assets/images/my_community.png')"
        :title="$t('pageUser.invite')"
        is-link
        to="/user/invite"
      />
      <!-- share-o -->
      <van-cell
        :icon="require('@/assets/images/my_invite.png')"
        :title="$t('pageUser.fen')"
        is-link
        to="/user/invite/poster"
      />
      <!-- icon="chart-trending-o" -->
      <!-- <van-cell class="hang" :title="$t('nav.ticker')" is-link to="/ticker" /> -->
      <!-- <van-cell icon="column" :title="$t('nav.ticker')" is-link to="/ticker" /> -->
      <!-- <van-cell class="pai" :title="$t('pai')" is-link to="/user/pai" /> -->
<!-- https://www.tttctc.com/join/79425478?src=from:referral_poster_blindbox_scan_qrcode_cn:android -->
      <van-cell
        :icon="require('@/assets/images/my_rank.png')"
        :title="$t('pai')"
        is-link
        to="/user/pai"
        v-if="showRankList"
      />
<!-- 
      <van-cell
        title="okex官方下载链接"
        is-link
        @click="onCopy"
      /> -->

      <van-cell
        :icon="require('@/assets/images/my_community.png')"
        :title="$t('pageUser.about')"
        is-link
        to="/user/about"
      />
    </van-cell-group>
    <van-cell-group class="list-group1" :border="false">
      <van-cell
        v-if="logged"
        :icon="require('@/assets/images/my_setting.png')"
        :title="$t('pageUser.setting')"
        is-link
        to="/user/settings"
      />
      <!-- <van-cell :icon="require('@/assets/images/my_skin.png')" :title="$t('pageUser.skin')" is-link url="https://robot.mydbc.cn/app2" /> -->
      <van-cell
        :icon="require('@/assets/images/my_change.png')"
        :title="$t('pageUser.language')"
        is-link
        to="/user/settings/changeLanguage"
      />
    </van-cell-group>
    <activation-popup ref="cdkey" />

    <!-- 购买激活码 -->

    <div class="tan" v-if="playshow">
      <div class="bg_bai">
        <van-icon class="close-icon" name="close" @click="playshow = false" size="24" />
        <van-radio-group
          v-model="play_checked"
          direction="horizontal"
          v-for="item in cdkeyLevel"
          :key="item.flag"
        >
          <van-radio :name="item.flag">{{ item.title }}{{ item.price }}U</van-radio>
        </van-radio-group>

        <div class="ti" @click="palySub">{{ $t('pay') }}</div>
        <div class="she">
          {{ $t('setPwd') }}
          <span @click="$router.push({ path: 'user/settings/payPwd' })">
            {{ $t('pageUser.setting') }}</span
          >
        </div>
      </div>
    </div>
    <password-confirm :show="showPwd" @close="showPwd = false" @confrim="buyCdkey" />
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { mapActions } from 'vuex'
import { Notify } from 'vant'
import Vue from 'vue'
import ActivationPopup from './activation/ActivationPopup'
import PasswordConfirm from '@/components/common/PasswordConfirm'

Vue.use(Notify)
export default {
  layout: 'navigation',
  components: {
    ActivationPopup,
    PasswordConfirm,
  },
  i18n: {
    messages: {
      zh: {
        deng: '等级',
        pai: '排行榜',
        dao: '到期时间',
        uid: 'UID',
      },
      en: {
        deng: 'level',
        pai: 'Ranking List',
        dao: 'Expiration Time',
        uid: 'UID',
      },
    },
  },
  data() {
    return {
      showPwd: false,
      activationCode: '',
      playshow: false,
      cdkeyLevel: [],
      play_checked: '',
      baseUrl: '',
      is_hangqing: false,
      url:'https://www.tttctc.com/join/79425478?src=from:referral_poster_blindbox_scan_qrcode_cn:android'
    }
  },
  mounted() {
    this.baseUrl = 'https://robot.mydbc.cn/app2'
  },
  computed: {
    ...mapState({
      logged: ({ user }) => user.logged,
      userInfo: ({ user }) => user.userInfo,
      initInfo: (index) => index.initInfo,
      thirdLoginEnabled: ({ thirdLoginEnabled }) => thirdLoginEnabled,
      showRankList: (index) => index.showRankList,
    }),
    userUid() {
      if (this.initInfo.switch_hangqing == '1') {
        this.is_hangqing = true
      } else {
        this.is_hangqing = false
      }
      if (String(this.userInfo.id).length >= 6) {
        return this.userInfo.id
      } else {
        let uid = ''
        for (var i = 0; i < 6 - String(this.userInfo.id).length; i++) {
          uid += '0'
        }
        return uid + this.userInfo.id
      }
    },
  },
  methods: {
    ...mapActions({
      cdkeyList: 'user/cdkeyList',
      cdkeyBuy: 'user/cdkeyBuy',
      pay_pwd: 'robot/pay_pwd',
    }),
    handleLink(path) {
      if (this.logged) {
        this.$router.push(path)
      } else {
        this.$router.push('/sign/login')
      }
    },
    onCopy(){
      var input = document.createElement("input"); // 创建input对象
      input.value = this.url; // 设置复制内容
      document.body.appendChild(input); // 添加临时实例
      input.select(); // 选择实例内容
      document.execCommand("Copy"); // 执行复制
      document.body.removeChild(input); // 删除临时实例
      this.$toast.success("成功复制");
    },
    //支付
    palySub() {
      var that = this
      this.cdkeyBuy()
        .then((res) => {
          console.log(res)
          if (res.code == 0) {
            this.$router.push(`/user/settings/payPwd`)
            this.$toast(res.msg)
          }
          if (res.code == 1) {
            this.playshow = false
            var that = this
            that.showPwd = true
            console.log(this.play_checked)
            this.flag = this.play_checked
          }
        })
        .catch((res) => {
          // console.log(res);
          this.$toast(res.msg)
        })
    },
    getkey() {
      // console.log(this.play_checked)
      var that = this
      this.$axios.post('/api/user/cdkey/cdkeyLevel', {}).then(function (ret) {
        if (ret.data.code == 1) {
          that.cdkeyLevel = ret.data.data

          // that.robotList = ret.data.data

          // that.creatQrCode();
        } else {
          that.$toast.fail(ret.data.msg)
        }
      })
    },
    buycdkeydone() {
      this.playshow = true
      this.getkey()
    },
    buyCdkey(password) {
      this.showPwd = false
      this.$toast.loading()
      this.cdkeyBuy({ password, flag: this.flag })
        .then((res) => {
          // console.log(res);
          this.$toast(res.msg)
          this.onRefresh()
        })
        .catch((res) => {
          // console.log(res);
          // this.$toast(res.msg)
        })
    },
  },
}
</script>

<style lang="less">
.newcdk {
  z-index: 10000 !important;
}
</style>
<style scoped lang="less">
.page_user {
  padding-bottom: 60px !important;
}
.pai span {
  padding-left: 30px;
}
/* .pai {
  background: url(~@/assets/images/pai.png) no-repeat 14px;
  background-size: 5%;
} */
/* .hang span {
  padding-left: 30px;
}
.hang {
  background: url(~@/assets/images/me_icon_hangqing@2x.png) no-repeat 14px;
  background-size: 5%;
} */
.van-col {
  color: #fff;
}
.page-title {
  color: #fff;
}
.top-cover {
  // background-color: #fff;
  // background: url(~@/assets/images/me_bg@2x.png) no-repeat center;
  background-color: @themeColor;
  padding-bottom: 20px;
}
.page-header {
  height: 66px;
  padding: 0 15px;
  margin-bottom: 0px;
  &-right .van-icon {
    display: inline-block;
    vertical-align: middle;
  }
  &-title {
    display: flex;
    align-items: center;
    font-size: 22px;
    line-height: 1;
    color: #333333;
  }
}
.van-cell-group {
  margin-top: 0px;
}
.user-info {
  padding: 15px 15px 25px;
  font-size: 14px;
  line-height: 1;
  .avatar {
    display: block;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    margin-right: 15px;
    overflow: hidden;
  }
}
.user-nickname {
  font-size: 18px;
  font-weight: 500;
}
.user-account {
  margin-top: 6px;
  color: #fff;
  opacity: 0.5;
}
.user-links {
  text-align: center;
  font-size: 12px;
  .van-icon {
    font-size: 18px;
    display: block;
    margin-bottom: 5px;
  }
}
/deep/ .van-dialog__content {
  padding: 30px 15px;
  .van-cell-group {
    margin-top: 0;
  }
}
/deep/ .van-cell {
  font-size: 16px;
}
/deep/ .van-cell__left-icon {
  font-size: 20px;
  display: flex;
  align-items: center;
}
/deep/ .van-cell__left-icon {
  margin-right: 10px;
}
.van-cell__left-icon {
  color: #666;
}
.tan {
  width: 100%;
  position: fixed;
  top: 0;
  height: 100%;
  overflow: hidden;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2015;
}
.tan .bg_bai {
  width: 80%;
  position: absolute;
  left: 10%;
  top: 30%;
  background: #fff;
  padding: 10px 7%;
  border-radius: 10px;
}
/deep/.van-radio-group--horizontal {
  margin-top: 20px;
  margin-bottom: 20px;
}
/deep/.van-radio--horizontal {
  width: 100%;
  margin-top: 20px;
}
.bg_bai .ti {
  width: 100px;
  line-height: 40px;
  border-radius: 10px;
  color: #fff;
  background: @themeColor;
  text-align: center;
  margin: 0 auto;
}
.she {
  width: 100%;
  text-align: center;
  line-height: 50px;

  color: @themeColor;
}
.she span {
  padding: 5px;
  border: 1px solid @themeColor;
  color: @themeColor;
}

.flex {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.infos {
  justify-content: flex-start;
}
.user-account-sp {
  white-space: nowrap;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50px;
  padding: 3px 10px;
  margin-right: 10px;
  opacity: 1;
  font-size: 12px;
}
.list-group {
  border-bottom: 0px;
  margin-top: -20px;
  border-radius: 15px 15px 0 0;
  z-index: 1000;
  overflow: hidden;
}
.list-group1 {
  margin-top: 8px;
}

.close-icon {
  position: absolute;
  right: 15px;
  top: 15px;
}
</style>
