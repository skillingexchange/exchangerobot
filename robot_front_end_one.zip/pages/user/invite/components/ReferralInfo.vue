<template>
  <div>
    <div class="referral-info">
      <div class="total">
        <div class="val">{{ info.total_all_sum }} {{ info.coin_symbol }}</div>
      </div>
      <div class="reg">{{ $t('invite') }}</div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.active_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.noactive_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_2') }}</div>
        </div>
      </div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.all_money2 }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('yao_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.all_money2_today }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('yao_2') }}</div>
        </div>
      </div>
    </div>
<!--    <div class="referral-info">
      <div class="reg">{{ $t('active') }}</div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.subsidi_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.nosubsidi_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_2') }}</div>
        </div>
      </div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.all_money3 }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('li_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.all_money3_today }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('li_2') }}</div>
        </div>
      </div>
    </div>-->
    <div class="referral-info">
      <div class="reg">{{ $t('number') }}</div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.team_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.noteam_count }}</div>
          <div class="lab"><img src="@/assets/images/me_icon.png" alt="">{{ $t('number_2') }}</div>
        </div>
      </div>
      <div class="items">
        <div class="item">
          <div class="val">{{ info.all_money }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('she_1') }}</div>
        </div>
        <div class="item">
          <div class="val">{{ info.all_money_today }}</div>
          <div class="lab"><img src="@/assets/images/me_icon2.png" alt="">{{ $t('she_2') }}</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        total: '累计邀请注册奖励',
        invite: '直推用户',
        active: '隶属用户',
        number: '社区用户',
        number_1: '已激活用户',
        number_2: '未激活用户',
        yao_1: '总盈利',
        yao_2: '今日盈利',
        li_1: '隶属总盈利',
        li_2: '隶属今日盈利',
        she_1: '社区总盈利',
        she_2: '社区今日盈利',
      },
       en: {
        total: 'Cumulative Invitation Registration Bonus',
        invite: 'Direct Users',
        active: 'Affiliated Users',
        number: 'Community Users',
        number_1: 'Activated user',
        number_2: 'Inactive user',
        yao_1: 'Total profit',
        yao_2: 'Profit today',
        li_1: 'Affiliated total profit',
        li_2: 'Affiliated to profit today',
        she_1: 'Community total profit',
        she_2: 'Community to profit today',
      },
    },
  },
  data() {
    return {
      info: '',
    }
  },
  beforeMount() {
    this.invitationInfo().then((data) => {
      this.info = data.data
      this.info.all_money = this.info.all_money.toFixed(6)
      this.info.all_money_today = this.info.all_money_today.toFixed(6)
      this.info.all_money2 = this.info.all_money2.toFixed(6)
      this.info.all_money2_today = this.info.all_money2_today.toFixed(6)
       this.info.all_money3 = this.info.all_money3.toFixed(6)
      this.info.all_money3_today = this.info.all_money3_today.toFixed(6)
    })
  },
  methods: {
    ...mapActions({
      invitationInfo: 'user/invitationInfo',
    }),
  },
}
</script>
<style scoped>
.referral-info {
       margin: 15px;
    padding: 40px 10px;
    border-radius: 10px;
    background: @themeColor;
    text-align: center;
    padding-bottom: 10px;
    /* overflow: hidden; */
    position: relative;
    margin-top: 50px;
}
.referral-info .total {
  padding-top: 0px;
}
.referral-info .total .lab,
.referral-info .total .val {
  color: rgb(208, 209, 128);
  font-size: 16px;
}
.referral-info .total .val {
  font-weight: bold;

}
.referral-info .items {
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px 0;
  background: #fff;
  color: #333;
  border-radius: 6px;
  margin-bottom: 15px;
}
.referral-info .item {
  flex: 1 0 0;
}
.referral-info .item:nth-child(1){
  border-right: 1px solid #efefef;
}
.referral-info .item .val {
  font-size: 15px;
  font-weight: bold;
  color: @themeColor;
}
.referral-info .item .lab {
  font-size: 14px;
  color: #333;
  margin-top: 5px;
}
.referral-info .item .lab img{
      width: 10%;
    vertical-align: -3px;
}
.reg {
    line-height: 36px;
    margin: 0 auto;
    border-radius: 22px;
    color: #845016;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 12px;
    background: linear-gradient(180deg, #fcca30 0%, #fedf55 100%);
    margin: 0 auto 10px;
    margin-top: -20px;
    position: absolute;
    top: 3px;
    left: 50%;
        padding: 0 20px;
    transform: translateX(-50%);
    display: inline-table;
}

</style>
