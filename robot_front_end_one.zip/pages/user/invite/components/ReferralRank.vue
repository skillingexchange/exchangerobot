<template>
  <div>
    <div class="team-list">
      <div class="caption-box"><div class="caption">{{ $t('title') }}</div></div>
      
      <ul class="list">
        <li class="item">
          <span class="val">{{ $t('zhang') }}</span>
          <span class="val">{{ $t('ji') }}</span>
          <span class="val ren">{{ $t('zhi') }}</span>
          <span class="val ren">{{ $t('tuan') }}</span>
          <span class="val time">{{ $t('zhu') }}</span>
        </li>
        <li v-for="item in list" :key="item.id" class="item color">
          <!-- <span v-if="index < 3" class="num rank" :class="'s' + (index + 1)"
            >No.{{ index + 1 }}</span
          >
          <span v-else class="num">No.{{ index + 1 }}</span> -->
          <span class="val">{{ item.mobile }}</span>
          <span class="val">{{ item.is_activate }}</span>
          <span class="val ren">{{ item.invitation_count }}</span>
          <span class="val ren">{{ item.team_all_count }}</span>
          <span class="val time">{{ item.ctime }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '直推用户明细',
        zhang:'账号',
        ji:'是否激活',
        zhi:'直推用户',
        tuan:'团队用户',
        zhu:'注册时间',

      },
      en: {
        title: 'Directly push user details',
        zhang:'account',
        ji:'Activate',
        zhi:'Direct Users',
        tuan:'Affiliated Users',
        zhu:'Registration time',

      },
    },
  },
  data() {
    return {
      list: '',
    }
  },
  beforeMount() {
    this.invitationList().then((data) => {
      this.list = data.data.list
    })
  },
  methods: {
    ...mapActions({
      invitationList: 'user/invitationList',
    }),
  },
}
</script>
<style scoped>
.color{
  color: #666;
}
.team-list {
  padding: 10px 15px 15px;
}
.team-list .caption {
  line-height: 36px;
  margin: 0 auto;
  padding:0 20px;
border-radius: 22px;
  color: #845016;
  text-align: center;
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 12px;
background: linear-gradient(180deg, #FCCA30 0%, #FEDF55 100%);
}
.team-list .list {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  overflow: hidden;
  padding: 10px 0;
  background: #fff;
}
.team-list .item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 40px;
  border-top: 1px solid #eee;
  background:#EDEAFD;
}
.team-list .item:nth-child(1){
  background: #DAD9FB ;
}
/* .team-list .item:first-child {
  border-top: none;
} */
.team-list .item .val:first-child {
  width:30%;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}

.team-list .val {
  display:block;
  width: 19%;
  overflow: hidden;
  text-align: center;
  line-height: 20px;
}
.team-list .item .ren{
  width: 19%;
}
.team-list .item .time{
  width: 25%;
}
.team-list .num {
  position: relative;
  width: 40px;
  text-align: center;
  line-height: 20px;
}
.team-list .num.rank {
  color: #fff;
}
.team-list .num.rank:before {
  content: '';
  position: absolute;
  z-index: -1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 3px;
  transform: skewX(-10deg);
}
.team-list .num.rank.s1:before {
  background-color: rgb(255, 182, 98);
}
.team-list .num.rank.s2:before {
  background-color: rgb(158, 95, 37);
}
.team-list .num.rank.s3:before {
  background-color: rgb(85, 84, 6);
}
.team-list .id {
  flex-grow: 1;
  padding: 0 15px;
}

.caption-box{
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
