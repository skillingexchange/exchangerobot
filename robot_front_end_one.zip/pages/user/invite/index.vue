<template>
  <div class="bg  page_user_invite">
    <div class="center" >
      <van-nav-bar :title="$t('pageUser.invite')" left-arrow @click-left="$router.back()" class="cen_color">
        <template #right>
          <van-icon name="share-o" color="#fff" size="18" @click="$router.push('/user/invite/poster')" />
        </template>
      </van-nav-bar>
      <referralInfo/>
      <referralRank/>
    </div>
  </div>
</template>

<script>
import referralInfo from './components/ReferralInfo'
import referralRank from './components/ReferralRank'
export default {
  components: { referralInfo, referralRank }
}
</script>
<style lang="less" scoped>
.bg {
  position: relative;
  background: no-repeat center top;
  // background: linear-gradient(135deg, rgb(21, 91, 212), rgb(101, 46, 155));
  background: url(~@/assets/images/yao.jpg) no-repeat top center;
  // padding-top: 160%;
  height: 100vh;
  background-size: 100% 100%;

}
.center{
  width:100vw;
  height:100vh;
  margin:0 auto;
  overflow-y: scroll;
}
.van-nav-bar{
  background: none;
  border:none;
  color: #fff!important;
  padding-top:15px;
}
.van-nav-bar__title {
    max-width: 60%;
    margin: 0 auto;
    color: #fff;
    font-weight: 500;
    font-size: 16px;
}

.van-hairline--bottom::after {
    border-bottom-width: 0px;
}
/deep/.van-nav-bar .van-icon{
  color: #fff;
 
}
/deep/.van-nav-bar__title{
  color: #fff;
}
</style>