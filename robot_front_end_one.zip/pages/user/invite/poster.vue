<template>
  <div class="bg" :style="{'background-image':initInfo.back_img?`url(${initInfo.back_img})`:`url(${bg})`}">
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <div class="share-box">
      <div class="ft-bar">
        <!-- <div>{{ userInfo.invitation_desc }}</div> -->
        <div v-clipboard:copy="userInfo.invitation_url" v-clipboard:success="onCopy" class="btn">
          {{ $t('invitation_code') }}：{{ userInfo.invitation_code }}
          <span class="fu">{{ $t('userfen') }}</span>
        </div>
      </div>
      <div id="qrcode" ref="qrCodeUrl" class="qr"></div>
      <!-- <div class="fener" @click="clickGeneratePicture">
        <img src="@/assets/images/me.png" alt="" />{{ $t('xia') }}
      </div> -->
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import QRCode from 'qrcodejs2'
import html2canvas from 'html2canvasforios13'
export default {
  i18n: {
    messages: {
      zh: {
        title: '邀请注册',
        invitation_code: '邀请码',
        userfen: '复制',
        xia: '保存二维码',
      },
      en: {
        title: 'Invitation to register',
        invitation_code: 'Invitation code',
        userfen: 'Copy',
        xia: 'Save the QR code',
      },
    },
  },
  data(){
    return{
      bg:require('@/assets/images/yao.jpg')
    }
  },
  computed: {
    ...mapState({
      userInfo: ({ user }) => user.userInfo,
      initInfo: ( index ) => index.initInfo,
    }),
  },
  mounted() {
    new QRCode(this.$refs.qrCodeUrl, {
      text: this.userInfo.invitation_url,
      width: 140,
      height: 140,
    })
  },

  methods: {
    onCopy() {
      this.$toast('复制成功')
    },
    /**
     * 将页面指定节点内容转为图片
     * 1.拿到想要转换为图片的内容节点DOM；
     * 2.转换，拿到转换后的canvas
     * 3.转换为图片
     */

    clickGeneratePicture() {
      //生成图片
      html2canvas(this.$refs.qrCodeUrl).then((canvas) => {
        // 转成图片，生成图片地址
        this.imgUrl = canvas.toDataURL('image/png') //可将 canvas 转为 base64 格式
        this.downloadImg(this.imgUrl, 'pic')
        // console.log(this.imgUrl)
      })
    },
    downloadImg(imgsrc, name) {
      var image = new Image()
      // 解决跨域 Canvas 污染问题
      image.setAttribute('crossOrigin', 'anonymous')
      image.onload = function () {
        var canvas = document.createElement('canvas')
        canvas.width = image.width
        canvas.height = image.height
        var context = canvas.getContext('2d')
        context.drawImage(image, 0, 0, image.width, image.height)
        var url = canvas.toDataURL() //得到图片的base64编码数据
        console.log(url)

        var a = document.createElement('a') // 生成一个a元素
        var event = new MouseEvent('click') // 创建一个单击事件
        a.download = name || 'photo' // 设置图片名称
        a.href = url // 将生成的URL设置为a.href属性
        a.dispatchEvent(event) // 触发a的单击事件
      }
      image.src = imgsrc
    },
  },
}
</script>

<style lang="less" scoped>
.fu {
  border: 1px solid #fff;
  border-radius: 11px;
  color: #fff;
  padding: 2px 5px;
}
.bg {
  position: relative;
  background: no-repeat center top;
  // background: linear-gradient(135deg, rgb(21, 91, 212), rgb(101, 46, 155));
  background: url(~@/assets/images/fen_er.png) no-repeat center;
  // padding-top: 160%;
  height:100vh;
  background-size: 100% 100%;
}
.btn-back {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
  background-color: transparent;
  box-shadow: none;
  color: #ffc52e;
}
.main {
  padding-top: 0;
  background-color: rgb(254, 195, 136);
}
.qr {
  position: absolute;
  top: 39%;
  left: 50%;
  margin-left: -80px;
  padding: 10px;
  border-radius: 5px;
  background-color: #fff;
  box-shadow: 0 0 20px -5px rgba(0, 0, 0, 0.3);
}
.share-btn {
  position: absolute;
  top: 0;
  right: 0;
  width: 40px;
  height: 40px;
  z-index: 99;
  display: flex;
  justify-content: center;
  align-items: center;
}
.share-btn .img {
  width: 18px;
}
.ft-bar {
  position: absolute;
  top: 32%;
  width: 100%;
  text-align: center;
  color: #fff;
}
.fen {
  font-size: 30px;
  color: #fff;
  padding-top: 50px;
  text-align: center;
}
.fener {
  width: 150px;
  background: #fff;
  border-radius:100px;
  color: @themeColor;
  text-align: center;
  line-height: 50px;
  position: absolute;
  bottom: 100px;
  left: 50%;
  margin-left: -75px;
}
.fener img {
  width: 20%;
  vertical-align: -8px;
}
/deep/.van-nav-bar .van-icon {
  color: #fff;
}
/deep/.van-nav-bar__title {
  color: #fff;
}
.van-nav-bar {
  background: none;
  border: none;
  color: #fff !important;
  padding-top: 15px;
}
.van-hairline--bottom::after {
    border-bottom-width: 0px; 
}
</style>
