<template>
  <div>
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <van-form @submit="onSubmit">
      <van-field
        v-model="username"
        :label="$t('phone')"
        :placeholder="$t('phone_please')"
        :rules="[{ required: true, message: $t('phone_please') }]"
      />
      <van-field
        v-model="verification_code"
        clearable
        :label="$t('code')"
        :placeholder="$t('code_please')"
        :rules="[{ required: true, message: $t('code_please') }]"
      >
        <template #button>
          <van-button size="small" type="primary" block @click.prevent="handleGetCode">{{ $t('send') }}</van-button>
        </template>
      </van-field>
      <div style="margin: 15px">
        <van-button block type="info" native-type="submit" class="submit">
          {{ $t('actions.submit') }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import { isPhone } from '@/utils/validator'
export default {
  i18n: {
    messages: {
      zh: {
        title: '绑定手机',
        phone: '手机',
        phone_please: '请填写手机',
        code: '验证码',
        code_please: '请填写验证码',
        send: '发送验证码'
      },

    }
  },
  data () {
    return {
      username: '',
      verification_code: '',
      times: 60
    }
  },
  methods: {
    ...mapActions({
      bindPhone: 'user/bindPhone',
      getUserInfo: 'user/getUserInfo',
      getCode: 'user/getCode'
    }),
    handleGetCode () {
      if (isPhone(this.username)) {
        const username = `86-${this.username}`
        this.getCode(username)
          .then(({ msg }) => {
            this.$toast(msg)
            this.getTime()
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
      } else {
        this.$toast('手机号格式不正确')
      }
    },
    getTime () {
      this.timer = setInterval(() => {
        this.times--
        if (this.times === 0) {
          clearInterval(this.timer)
          this.times = 60
        }
      }, 1000)
    },
    onSubmit () {
      this.bindPhone({mobile:this.username,verification_code:this.verification_code}).then(() => {
        this.getUserInfo()
        this.$router.back()
      })
    }
  }
}
</script>
