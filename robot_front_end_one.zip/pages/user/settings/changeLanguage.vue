<template>
  <div class="page page_setting_changeLanguage">
    <van-nav-bar
      :title="$t('pageUser.language')"
      left-arrow
      @click-left="$router.back()"
    />
    <van-cell-group :border="false">
        <van-cell title="简体中文" @click="select('zh')">
            <template #right-icon v-if="locale == 'zh'">
                <van-icon name="success" class="success"  />
            </template>
        </van-cell>
        <van-cell title="English" @click="select('en')">
            <template #right-icon v-if="locale == 'en'">
                <van-icon name="success" class="success" />
            </template>
    </van-cell>
    </van-cell-group>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      
    }
  },
  data() {
    return {
      about:"",
     
    };
  },
    computed: {
        ...mapState({
            locale: (index ) => index.locale,
        })
    },
    methods: {
        select(lang){
            this.$root.$i18n.locale = lang
            this.$store.dispatch('setLang',lang)
        }
    },  
   mounted() {
       
    
  },
}
</script>

<style scoped lang="less">
.center {
  font-size: 14px;
  color: #333;
  line-height: 24px;
  width: 94%;
  margin: 0 auto;
  padding: 15px 0;
}
</style>
