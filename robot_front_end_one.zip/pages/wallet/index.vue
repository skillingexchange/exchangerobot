<template>
  <div class="page page_wallet">
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <!-- <div class="detail-info margin">
      <van-row>
        <van-col span="20">
          <div class="detail-title">{{ $t('total1') }}</div>
          <div class="detail-amount">{{ detailInfo.cuc }}</div>
          <div class="detail-price">≈{{ currency.symbol }} {{ detailInfo.price }}</div>
        </van-col>
      </van-row>
      <div class="btn-group">
        <van-button
          plain
          type="primary"
          size="small"
          style="padding: 0 10px"
          @click="handleLink('/wallet/into')"
        >
          {{ $t('into') }}
        </van-button>
        <van-button
          plain
          type="info"
          size="small"
          style="padding: 0 10px"
          @click="handleLink('/wallet/transfer')"
        >
          {{ $t('transfer') }}
        </van-button>
      </div>
    </div> -->
    <div class="detail-info">
      <van-row>
        <van-col span="20">
          <div class="detail-title">{{ $t('total') }}（{{ symbol }}）</div>
          <div class="detail-amount">{{ detailInfo.cloud_balance | numberFormat(8) }}</div>
          <!-- <div class="detail-price">≈{{ currency.symbol }} {{ detailInfo.price }}</div> -->
        </van-col>
        <van-col span="4">
          <van-icon :name="detailInfo.img_url" size="54" />
        </van-col>
      </van-row>
      <!-- <div class="copy-wrap">
        <span class="van-ellipsis">{{ detailInfo.address ? detailInfo.address : '^-^' }}</span>
        <van-button
          v-if="detailInfo.address"
          v-clipboard:copy="detailInfo.address"
          v-clipboard:success="onCopy"
          plain
          type="info"
          size="mini"
        >复 制</van-button>
      </div> -->
      <div class="btn-group">
        <van-button
          plain
          type="primary"
          size="small"
          style="padding: 0 15px;margin-right:15px;color:#0166ec;border-color:#0166ec;"
          @click="handleLink('/wallet/receive')"
        >
          {{ $t('receipt') }}
        </van-button>
        <van-button
          plain
          type="info"
          size="small"
          style="padding: 0 15px"
          @click="handleLink('/wallet/withdraw')"
        >
          {{ $t('withdraw') }}
        </van-button>
      </div>
    </div>
    <!-- 账单 -->
    <div class="bill-list">
      <div class="bill-title">{{ $t('bill') }}</div>
      <!-- <van-tabs v-model="active" @click="tabClick">
        <van-tab :title="$t('cuc')"></van-tab>
        <van-tab :title="$t('usdt')"></van-tab>
      </van-tabs> -->
      <!-- USDt账单 -->
      <van-pull-refresh v-model="refreshing" class="pull-refresh" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          :finished-text="$t('finished_text')"
          @load="onLoad"
        >
          <van-cell
            v-for="item in list"
            :key="item.id"
            center
            :title="`${item.amount} ${item.to_address=='cdkey'?'':item.to_address}`"

            :value="item.type_msg=='抵扣信誉值'?'盈利手续费':item.type_msg"
            :label="`${item.amount_after}  ${item.log_time}`"
          />
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from 'vuex'
export default {
  i18n: {
    messages: {
      zh: {
        title: '资产',
        total: '总资产折合',
        total1: 'CUC余额',
        receipt: '充币',
        withdraw: '提币',
        into:'转入',
        transfer:'转出',
        cuc:'CUC',
        usdt:'USDT',
        log_time:'时间'
      },
      en: {
        title: 'Assets',
        total: 'Total Assets',
        total1: 'CUC余额',
        receipt: 'receipt',
        withdraw: 'withdraw',
        into:'转入',
        transfer:'转出',
        cuc:'CUC',
        usdt:'USDT',
        log_time:'时间'
      },
    },
  },
  data() {
    return {
      symbol: this.$route.query.symbol,
      detailInfo: {},
      list: [
       
      ],
      loading: false,
      finished: false,
      refreshing: false,
      offset: 0,
      limit: 20,
      active:1,

    }
  },
  computed: {
    ...mapState({
      currency: ({ currency }) => currency,
    }),
  },
  created() {
    this.loadFundList()
    this.loadDetail()
  },
  methods: {
    ...mapActions({
      fundDetail: 'wallet/fundDetail',
      billList: 'wallet/transacTions',
      fundList: 'wallet/fundList',

    }),
    tabClick(val){
      console.log(val)
      this.offset = 0;
      this.list = [];
      this.loadBillList();

    },
    handleLink(path) {
      this.$router.push(`${path}?symbol=${this.symbol}`)
    },
    loadFundList() {
      this.fundList({ currency: this.currency.name })
    },
    loadDetail() {
      this.fundDetail({
        currency: this.currency.name,
        coin_symbol: this.symbol,
      }).then(({ data }) => {
        this.detailInfo = data
      })
    },
    loadBillList() {
      if (this.refreshing) {
        this.list = []
        this.offset = 0
        this.finished = false
        if (this.loading) {
          this.loading = false
          return
        }
      }
      if (this.loading) {
        this.refreshing = false
      }

      this.billList({
        coin_symbol: this.active?'USDT':'CUC',
        limit_begin: this.offset,
        limit_end: this.limit,
      })
        .then(({ data }) => {
          if (data.list.length < this.limit) {
            this.finished = true
          } else {
            this.finished = false
            this.offset += this.limit
          }
          this.list = this.list.concat(data.list)
        })
        .finally(() => {
          this.loading = false
          this.refreshing = false
        })
    },
    onCopy() {
      this.$toast('复制成功')
    },
    onLoad() {

      this.loadBillList();
    },
    onRefresh() {
      this.loadBillList()
    },
  },
}
</script>
<style scoped lang="less">
/deep/.van-button--plain.van-button--info{
 color: #fff;
}
.margin {
  margin-bottom: 20px;
}
.van-ellipsis {
  display: inline-block;
  width: 80%;
}
.detail {
  &-info {
    background-color: #fff;
    padding: 10px;
  }
  &-title {
    font-size: 16px;
    color: #727272;
  }
  &-amount {
    margin-top: 6px;
    font-size: 28px;
  }
  &-price {
    font-size: 18px;
    color: #727272;
  }
}
.copy {
  &-wrap {
    margin-top: 10px;
    display: flex;
  }
}
.bill {
  &-title {
    font-size: 16px;
    padding: 10px 10px;
    border-left: 2px solid @themeColor;
    background-color: #eee;
  }
}
.btn {
  &-group {
    margin-top: 20px;
  }
}
.van-list {
  min-height: 300px;
}
</style>
