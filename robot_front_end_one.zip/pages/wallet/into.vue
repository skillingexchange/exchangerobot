<template>
  <div>
    <van-nav-bar :title="$t('title')" left-arrow @click-left="$router.back()" />
    <van-form @submit="onSubmit">
      <van-field
        v-model="form.amount"
        type="number"
        name="number"
        :label="$t('number')"
        :placeholder="symbol"
        :rules="[{ required: true, message: $t('number_please'),validator:numberVd}]"
        

      />
      <div class="zhuan">1USDT = {{bili}}CUC</div>
      <!-- <van-row
        style="background:#fff"
        type="flex"
        justify="end"
        class="balance-wrap"
      >
        <van-col span="18">{{ $t('balance') }}: {{ detailInfo.cloud_balance }} {{ symbol }}</van-col>
        <van-col
          span="6"
          class="balance-link"
          @click="pickAll"
        >
          {{ $t('extract_all') }}
        </van-col>
      </van-row> -->
      <van-field
        v-model="form.fee"
        type="number"
        name="fee"
        :label="$t('fee')"
        :placeholder="$t('fee_please') + `(${detailInfo.min_fee} ~ ${detailInfo.max_fee})`"
        :rules="[{ required: true, message: $t('fee_please') }]"
        readonly
      />

      <van-field
        v-if="userInfo.has_paypwd === 1"
        v-model="form.passWord_pay"
        type="password"
        name="paypass"
        :label="$t('pay_pwd')"
        :placeholder="$t('pwd_please')"
        :rules="[{ required: true, message: $t('pwd_please') }]"
      />
      <van-field
        v-else
        center
        clearable
        :label="$t('pay_pwd')"
        :placeholder="$t('no_pay_pwd')"
        disabled
      >
        <template #button>
          <nuxt-link to="/user/settings/payPwd">
            <van-button plain size="mini" type="primary">
              {{ $t('setting') }}
            </van-button>
          </nuxt-link>
        </template>
      </van-field>
      <!-- <van-field
        v-model="form.memo"
        rows="1"
        autosize
        :label="$t('memo')"
        type="textarea"
        :placeholder="$t('memo_please')"
      /> -->
      <div style="padding: 16px">
        <van-button round block type="info" native-type="submit">
          {{ $t('submit') }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import { mapState, mapActions } from 'vuex'
import { isPhone, isEmail, isEmailOrPhone } from '@/utils/validator'
import { Slider } from 'vant'
export default {
  components: {
    [Slider.name]: Slider,
  },
  i18n: {
    messages: {
      zh: {
        title: 'CUC转入',
        address: '收款地址',
        address_please: '请输入收款地址',
        yan: '验证码',
        yan_please: '请输入验证码',
        memo_please: '请输入memo',
        number: '转入数量',
        number_please: '请输入转入数量',
        balance: '当前余额',
        extract_all: '提取全部',
        fee: '到账数量',
        // fee_please: '请填写交易费',
        pay_pwd: '支付密码',
        pwd_please: '请填写支付密码',
        no_pay_pwd: '还未设置支付密码',
        setting: '去设置',
        memo: '备注',
        submit: '发送',
      },
      en: {
        title: 'CUC转入',
        address: 'address',
        address_please: 'Please enter the Receipt address',
        yan: '验证码',
        yan_please: '请输入验证码',
        memo_please: '请输入memo',
        number: 'Number',
        number_please: 'Please enter the coins number',
        balance: 'Current Balance',
        extract_all: 'Extract all',
        fee: '到账数量',
        // fee_please: '请填写交易费',
        pay_pwd: 'Payment Password',
        pwd_please: 'Please fill in the payment password',
        no_pay_pwd: 'The payment password has not been set',
        setting: 'Setting',
        memo: '备注',
        submit: 'Submit',
      },
     
    },
  },

  data() {
    const symbol = this.$route.query.symbol
    return {
      times: 60,
      symbol,
      form: {
        coin_symbol: symbol,
        amount: '',
        to_address: '',
        yan: '',
        memo: '',
        fee: 0,
        address_memo: '',
        passWord_pay: '',
      },
      detailInfo: {
        min_fee: '-',
        max_fee: '-',
      },
      activeSymbol: symbol,
      bili:"",
    }
  },
  computed: {
    ...mapState({
      currency: ({ currency }) => currency,
      userInfo: ({ user }) => user.userInfo,
    }),
  },
  created() {
    // this.loadDetail()
  },
  methods: {
    ...mapActions({
      fundDetail: 'wallet/fundDetail',
      cucIn: 'wallet/cucIn',
    }),
    numberVd(val){
      console.log(val)
      console.log(this.bili)

      this.form.fee = val * this.bili;
    },
    pickAll() {
      if (this.detailInfo.cloud_balance > 0) {
        this.form.amount = this.detailInfo.cloud_balance - this.form.fee
      }
    },
    loadDetail() {
      this.$toast.loading()
      this.fundDetail({
        currency: this.currency.name,
        coin_symbol: this.activeSymbol,
      })
        .then(({ data }) => {
          this.detailInfo = data
          this.form.fee = data.max_fee
        })
        .finally(() => {
          this.$toast.clear()
        })
    },
    onSubmit(values) {
      if (this.userInfo.has_paypwd === 0) {
        this.$router.push('/user/settings/payPwd')
        return
      }

      this.$toast.loading()
      var that = this;  
      this.cucIn({
          amount: parseInt(values.number),
          passWord_pay: values.paypass,
        })
        .then(({ msg }) => {
          this.$toast(msg)
       
        })
        .catch(({ msg }) => {
          this.$toast(msg)
        })
    },
    switchTab(name) {
      this.form = {
        coin_symbol: name,
        amount: '',
        to_address: '',
        yan: '',
        memo: '',
        fee: '',
        address_memo: '',
        passWord_pay: '',
      }
      this.loadDetail()
    },
    handleGetCode() {
      if (isEmailOrPhone(this.username)) {
        const username = isPhone(this.username) ? `86-${this.username}` : this.username
        this.$toast.loading()
        this.getCode(username)
          .then(({ msg }) => {
            this.$toast(msg)
            this.getTime()
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
     // 兑换率
    getBili() {
      var that = this;
      this.$axios 
        .post("api/wallet/account/getBili")
        .then(function (ret) {
          if (ret.data.code == 1) {
            console.log(ret.data.data);
            that.bili= ret.data.data.bili;
          } else {
            that.$toast.fail(ret.data.msg);
          }
        });
    }
  },
    mounted() {
    this.getBili();
  },
}
</script>
<style scoped lang="less">
.custom-button {
  width: 26px;
  color: #fff;
  font-size: 10px;
  line-height: 18px;
  text-align: center;
  background-color: #ee0a24;
  border-radius: 100px;
}
.balance-wrap {
  text-align: right;
  padding: 5px 10px;
}
.balance-link {
  display: inline-block;
  text-align: center;
  color: #1296db;
}
.tab-wrap {
  padding: 10px;
}
.zhuan {
  width: 100%;
  background: #fff;
  overflow: hidden;
  // text-align: center;
  line-height: 36px;
  padding-left: 7.7em;
}
</style>
