<template>
  <div class="page page_withdraw">
    <van-nav-bar :title="`${symbol}${$t('title')}`" left-arrow @click-left="$router.back()" />
    <van-tabs v-model="activeSymbol" type="card" class="tab-wrap" @click="switchTab">
      <van-tab title="TRC20" name="USDT" />
      <!-- <van-tab title="ERC20" name="USDT-TRC" /> -->
    </van-tabs>
    <van-form @submit="onSubmit">
      <van-field
        v-model="form.to_address"
        :label="$t('address')"
        :placeholder="$t('address_please')"
        :rules="[{ required: true, message: $t('address_please') }]"
      />
      <!-- <van-field
        v-model="form.address_memo"
        label="Memo"
        :placeholder="$t('memo_please')"
        :rules="[{ required: true, message: $t('memo_please') }]"
      /> -->
      <van-field
        v-model="form.amount"
        type="number"
        :label="$t('number')"
        :placeholder="$t('number_please')"
        @input="numberInput"
        :rules="[{ required: true, message: $t('number_please') }]"
      />
      <div class="tibi">{{ $t('tibi') }}{{min_withdraw}}</div>
      <van-row style="background: #fff" type="flex" justify="end" class="balance-wrap">
        <van-col span="18">
          {{ $t('balance') }}: {{ detailInfo.can_cash }} {{ symbol }}
        </van-col>
        <van-col span="6" class="balance-link" @click="pickAll">
          {{ $t('extract_all') }}
        </van-col>
      </van-row>
      <!-- <van-field
        v-model="form.fee"
        type="number"
        name="fee"
        :label="$t('fee')"
        :placeholder="$t('fee_please') + `(${detailInfo.min_fee} ~ ${detailInfo.max_fee})`"
        :rules="[{ required: true, message: $t('fee_please') }]"
        readonly
      /> -->
      <div class="jiayi">
        <div class="fei">{{ $t('fee') }}</div>
        <div class="lv">{{ fee }}</div>
      </div>
      <van-field
        v-model="form.verification_code"
        name="verification_code"
        clearable
        :label="$t('pageSign.valid_code')"
        :placeholder="$t('pageSign.valid_code')"
        :rules="[{ required: true }]"
      >
        <template #button>
          <van-button
            size="small"
            type="primary"
            block
            :disabled="times !== 60"
            @click.prevent="handleGetCode"
            style="color:#fff;background:#0166ec;"
          >
            <template v-if="times === 60">{{ $t('pageSign.send_code') }}</template>
            <template v-else>{{ times }}s</template>
          </van-button>
        </template>
      </van-field>
      <van-field
        v-if="userInfo.has_paypwd === 1"
        v-model="form.passWord_pay"
        type="password"
        name="paypass"
        :label="$t('pay_pwd')"
        :placeholder="$t('pwd_please')"
        :rules="[{ required: true, message: $t('pwd_please') }]"
      />
      <van-field
        v-else
        center
        clearable
        :label="$t('pay_pwd')"
        :placeholder="$t('no_pay_pwd')"
        disabled
      >
        <template #button>
          <nuxt-link to="/user/settings/payPwd">
            <van-button plain size="mini" type="primary">
              {{ $t('setting') }}
            </van-button>
          </nuxt-link>
        </template>
      </van-field>
      <!-- <van-field
        v-model="form.memo"
        rows="1"
        autosize
        :label="$t('memo')"
        type="textarea"
        :placeholder="$t('memo_please')"
      /> -->
      <div style="padding: 16px">
        <van-button round block type="info" native-type="submit">
          {{ $t('submit') }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import { mapState, mapActions } from 'vuex'
import { isPhone, isEmail, isEmailOrPhone } from '@/utils/validator'
import { Slider } from 'vant'
export default {
  components: {
    [Slider.name]: Slider,
  },
  i18n: {
    messages: {
      zh: {
        title: '提币',
        tibi: '注:提币数不少于',
        address: '收款地址',
        address_please: '请输入收款地址',
        yan: '验证码',
        yan_please: '请输入验证码',
        memo_please: '请输入memo',
        number: '提币数量',
        number_please: '请输入提币数量',
        balance: '当前余额',
        extract_all: '提取全部',
        fee: '交易费',
        fee_please: '请填写交易费',
        pay_pwd: '支付密码',
        pwd_please: '请填写支付密码',
        no_pay_pwd: '还未设置支付密码',
        setting: '去设置',
        memo: '备注',
        submit: '发送',
      },
      en: {
        title: 'withdraw coins',
        tibi: 'Tip:Minimum withdrawal amount：',
        address: 'Address',
        address_please: 'Please enter the Receipt address',
        yan: '验证码',
        yan_please: '请输入验证码',
        memo_please: '请输入memo',
        number: 'Number',
        number_please: 'Please enter the coins number',
        balance: 'Current Balance',
        extract_all: 'Extract all',
        fee: 'Fee',
        fee_please: '请填写交易费',
        pay_pwd: 'Payment Password',
        pwd_please: 'Please fill in the payment password',
        no_pay_pwd: 'The payment password has not been set',
        setting: 'Setting',
        memo: '备注',
        submit: 'Submit',
      },

    }
  },

  data() {
    const symbol = this.$route.query.symbol
    return {
      times: 60,
      symbol,
      verification_code: '',
      fee: 0,
      form: {
        coin_symbol: symbol,
        amount: '',
        to_address: '',
        yan: '',
        memo: '',
        fee: 0,
        address_memo: '',
        passWord_pay: '',
        is_debug:1,
      },
      detailInfo: {
        min_fee: '-',
        max_fee: '-',
      },
      activeSymbol: symbol,
      bili: '',
      withdraw_bili: '',
      min_withdraw:'',
    }
  },
  computed: {
    ...mapState({
      currency: ({ currency }) => currency,
      userInfo: ({ user }) => user.userInfo,
    }),
  },
  created() {
    this.loadDetail()
    this.getBili()
  },
  methods: {
    ...mapActions({
      getCode: 'user/getCode',
      fundDetail: 'wallet/fundDetail',
      withdraw: 'wallet/withdraw',
      getEmailCode: 'user/getEmailCode',
    }),
    numberInput(val) {
      // console.log(Number(val) * Number(this.withdraw_bili))
      // this.fee = (Number(val) * Number(this.withdraw_bili)) / 100
      console.log(this.withdraw_bili);
      this.fee = Number(this.withdraw_bili)
    },
    pickAll() {
      if (this.detailInfo.cloud_balance > 0) {
        this.form.amount = this.detailInfo.cloud_balance - this.form.fee
      }
    },
    // 交易费
    getBili() {
      var that = this
      this.$axios.post('api/wallet/account/getBili').then(function (ret) {
        if (ret.data.code == 1) {
          console.log(ret.data.data)
          that.bili = ret.data.data.bili
          that.withdraw_bili = ret.data.data.withdraw_bili
          that.min_withdraw = ret.data.data.min_withdraw
        } else {
          that.$toast.fail(ret.data.msg)
        }
      })
    },
    loadDetail() {
      this.$toast.loading()
      this.fundDetail({
        currency: this.currency.name,
        coin_symbol: this.activeSymbol,
      })
        .then(({ data }) => {
          this.detailInfo = data
          this.form.fee = data.max_fee
        })
        .finally(() => {
          this.$toast.clear()
        })
    },
    onSubmit(values) {
      if (this.userInfo.has_paypwd === 0) {
        this.$router.push('/user/settings/payPwd')
        return
      }
      this.$toast.loading()

      this.withdraw(this.form)
        .then((ret) => {
          this.$toast(ret.msg)

          this.$router.push('/wallet?symbol=USDT')
        })
        .catch(({ msg }) => {
          this.$toast(msg)
        })
    },
    switchTab(name) {
      this.form = {
        coin_symbol: name,
        amount: '',
        to_address: '',
        yan: '',
        memo: '',
        fee: '',
        address_memo: '',
        passWord_pay: '',
        is_debug:1,
      }
      this.loadDetail()
    },
    handleGetCode() {
      this.username = this.userInfo.mobile?this.userInfo.mobile.split('-')[1]:this.userInfo.user_email
      if (isEmailOrPhone(this.username)) {
        let ismobile = isPhone(this.username)
        const username = ismobile ? `86-${this.username}` : this.username
        if(ismobile){
            this.getCode(username)
            .then(({ msg }) => {
              console.log(msg)
              this.$toast(msg)

              this.getTime()
            })
            .catch(({ msg }) => {
              this.$toast(msg)
            })
        }else{
          this.getEmailCode(username)
          .then((data) => {
            this.$toast(data.msg)
            if(data.code==1){
              this.getTime()
            }
          })
          .catch(({ msg }) => {
            this.$toast(msg)
          })
        }
       
      } else {
        this.$toast(this.$t('pageSign.account_err'))
      }
    },
    getTime() {
      this.timer = setInterval(() => {
        this.times--
        if (this.times === 0) {
          clearInterval(this.timer)
          this.times = 60
        }
      }, 1000)
    },
  },
}
</script>
<style scoped lang="less">
.tibi{
  width: 100%;
  background: #fff;
  margin: 0 auto;
  line-height: 25px;
  padding-left: 30px;
  overflow: hidden;

}
.jiayi {
  width: 100%;
  line-height: 32px;
  padding: 3px 15px;
  background: #fff;
  border-bottom: 1px solid #f8f8f8;
  overflow: hidden;
}
.jiayi .fei {
  width: 26%;
  float: left;
}
.jiayi .lv {
  float: left;
}
.custom-button {
  width: 26px;
  color: #fff;
  font-size: 10px;
  line-height: 18px;
  text-align: center;
  background-color: #ee0a24;
  border-radius: 100px;
}
.balance-wrap {
  text-align: right;
  padding: 5px 10px;
}
.balance-link {
  display: inline-block;
  text-align: center;
  color: #1296db;
}
.tab-wrap {
  padding: 10px;
}
</style>
