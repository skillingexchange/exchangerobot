import Vue from 'vue'
import clickOutside from './click-outside'

Vue.directive('click-outside', clickOutside)
