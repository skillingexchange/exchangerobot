import API from '@/constants/api'
import { PLATFORM } from '@/constants/global'
import qs from 'qs'
export const state = () => ({
  platform: PLATFORM,
  marketData: { okex: [], huobi: [], binance: [], gateio: [], sinance: [] },
  marketDatas: { okex: [], huobi: [], binance: [], gateio: [], sinance: [] },
  robotList: [],
  robotLists: [],

  defalutStrategy:[],
  defalutStrategynew:[],
  timer:null,
  timer1:null,

  marketIndex:0,//策略导航当前选中索引
})

export const getters = {
  markets: state => (platform) => {
    return state.marketData[platform]
  },
  marketss: state => (platform) => {
    return state.marketDatas[platform]
  },
  robot: state => (id) => {
    return state.robotList.filter(item => item.market_id === id)[0]
  },
  robot_contract: state => (id) => {
    return state.robotLists.filter(item => item.market_id === id)[0]
  }
}

export const mutations = {
  SET_ROBOT_LIST (state, data) {
    state.robotList = data
  },
  SET_ROBOTS_LIST (state, data) {
    state.robotLists = data
  },
  SET_MARKET_LIST (state, data) {
    state.marketData[data[0]] = data[1]
  },
  SET_MARKETS_LIST (state, data) {
    state.marketDatas[data[0]] = data[1]
  },
  SET_ROBOT_STRATEGY (state, data) {
    state.defalutStrategy = data
  },
  SET_ROBOT_STRATEGYNEW (state, data) {
    state.defalutStrategynew = data
  },
  SET_TIMER (state, data) {
    state.timer = data
  },
  SET_TIMER1 (state, data) {
    state.timer1 = data
  },

  marketIndex (state, data) {
    state.marketIndex = data
  },
}

export const actions = {
  async marketList ({ commit }, params) {
    const result = await this.$axios.$post(API.MARKET_LIST, params)
    const { data } = result
    commit('SET_MARKET_LIST', [params.platform, data])
    return result
  },
  async marketLists ({ commit }, params) {
    const result = await this.$axios.$post(API.MARKETS_LIST, params)
    const { data } = result
    commit('SET_MARKETS_LIST', [params.platform, data])
    return result
  },
  async robotList ({ commit }, params) {
    const result = await this.$axios.$post(API.ROBOT_LIST, params)
    const { data } = result
    data.forEach((item) => {
      item.values = {}
      if (item.values_str) { item.values = JSON.parse(item.values_str) }
    })
    commit('SET_ROBOT_LIST', data)
    return result
  },
  async robotLists ({ commit }, params) {
    const result = await this.$axios.$post(API.ROBOTS_LIST, params)
    const { data } = result
    data.forEach((item) => {
      item.values = {}
      if (item.values_str) { item.values = JSON.parse(item.values_str) }
    })
    commit('SET_ROBOTS_LIST', data)
    return result
  },
  async robotCreate ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CREATE, params)
  },
  async robotEdit ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_EDIT, params)
  },
  async robotContractCreate ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_CREATE, params)
  },
  async robotContractEdit ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_EDIT, params)
  },
  async mulEdit ({ commit }, params) {
    return await this.$axios.$post('api/quant/robot/mulEdit', params)
  },
  async mulEdits ({ commit }, params) {
    return await this.$axios.$post('api/quant/robot/mulEdit', params)
  },
  async robotDisable ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_DISABLE, params)
  },
  async robotDisables ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_DISABLE, params)
  },
  async dialog ({ commit }, params) {
    return await this.$axios.$post('api/user/articles/getWarning', params)
  },
  async robotEnable ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_ENABLE, params)
  },
  async robotEnables ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_ENABLE, params)
  },
  async robotEnablesPostions ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_ENABLE_POSITION, params)
  },
  async robotClean ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CLEAN, params)
  },
  async robotCleans ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_CLEAN, params)
  },
  async robotCleanT ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_CLEAN_TYPE, params)
  },
  async robotLog ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_LOG, params)
  },
  async robotLogs ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_LOG, params)
  },
  async caijing ({ commit }, params) {
    return await this.$axios.$post(API.CAIJING, params)
  },
  async robotOrder ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_ORDER, params)
  },
  async robotOrders ({ commit }, params) {
    return await this.$axios.$post(API.ROBOT_CONTRACT_ORDER, params)
  },
  async robotRevenue ({ commit }, params) {
    let url = API.ROBOT_REVENUE +'?' +qs.stringify(params)
    return await this.$axios.$post(url)
    // return await this.$axios.$post(API.ROBOT_REVENUE, params)
  },
  async robotRevenues ({ commit }, params) {
    let url = API.ROBOT_REVENUE +'?' +qs.stringify(params)
    return await this.$axios.$post(url)
    // return await this.$axios.$post(API.ROBOT_REVENUE, params)
  },
  async robotStrategy ({ commit }, params) {
    const result = await this.$axios.$post(API.ROBOT_STRATEGY, params)
    const { data } = result
    data.forEach((item,index)=>{
      let bcweekCon = []
      for(let i in item.data.cover_rates){
        bcweekCon.push(item.data.cover_rates[i].value)
      }
      item.data.bcweekCon = bcweekCon
      item.data.checked = item.data.is_double == 1?true:false
      item.data.recycle_status = item.data.recycle_status == 1?1:0
    })
    let cover_rates = [],sub_warehouse = [],i = 0, len = 7, len1 = len - 4
    while(i < len){
      cover_rates.push({
        title:i == 0?'第1次补仓':`第${i+1}次补仓`,
        value:'',
        tirst_order_multiple:''
      })
      i ++
    }
    if(len1 > 0 ){
      i = 0
      while(i < len1){
        sub_warehouse.push({
          title:`第${5 + i}次补仓`,
          value:''
        })
        i ++
      }
    }


    data.push({
      id:0,
      title:'自定义',
      data:{
        first_order_value:'',
        checked:false,
        max_order_count:len,
        stop_profit_rate:'',
        stop_profit_callback_rate:'',
        cover_callback_rate:'',
        recycle_status:1,
        bcweekCon:[3,4,5,6,7,8,9],
        cover_rates:cover_rates,
        sub_warehouse:sub_warehouse,
        riskControl:false,
        control_min_prcie: '',
        control_max_prcie :'',
        circle_number : '',
        cover_grid_back:''
      }
    })
    commit('SET_ROBOT_STRATEGY', data)
    return result
  },
  async robotStrategynew ({ commit }, params) {
    const result = await this.$axios.$post(API.ROBOT_STRATEGYNEW, params)
    const { data } = result
    console.log(data)
    data.forEach((item,index)=>{
      let bcweekCon = []
      for(let i in item.data.cover_rates){
        bcweekCon.push(item.data.cover_rates[i].value)
      }
      item.data.bcweekCon = bcweekCon
      item.data.checked = item.data.is_double == 1?true:false
      item.data.recycle_status = item.data.recycle_status == 1?1:0
    })
    let cover_rates = [],sub_warehouse = [],i = 0, len = 7, len1 = len - 4
    while(i < len){
      cover_rates.push({
        title:i == 0?'第1次补仓':`第${i+1}次补仓`,
        value:'',
        tirst_order_multiple:''
      })
      i ++
    }
    if(len1 > 0 ){
      i = 0
      while(i < len1){
        sub_warehouse.push({
          title:`第${5 + i}次补仓`,
          value:''
        })
        i ++
      }
    }


    data.push({
      id:0,
      title:'自定义',
      data:{
        first_order_value:'',
        checked:false,
        max_order_count:len,
        stop_profit_rate:'',
        stop_profit_callback_rate:'',
        cover_callback_rate:'',
        recycle_status:1,
        bcweekCon:[3,4,5,6,7,8,9],
        cover_rates:cover_rates,
        sub_warehouse:sub_warehouse,
        riskControl:false,
        control_min_prcie: '',
        control_max_prcie :'',
        circle_number : '',
        cover_grid_back:''
      }
    })
    commit('SET_ROBOT_STRATEGYNEW', data)
    return result
  },
  setTimer ({ commit }, data) {
    commit('SET_TIMER', data)
  },
  setTimer1 ({ commit }, data) {
    commit('SET_TIMER1', data)
  },
  async getRealPrice({commit},params){
    let url = API.REAL_TIME_PRICE +'?' +qs.stringify(params)
    return await this.$axios.$get(url)
  },
  async getRealPrices({commit},params){
    let url = API.REAL_CONTRACT_TIME_PRICE +'?' +qs.stringify(params)
    return await this.$axios.$get(url)
  },
  marketIndex({ commit }, data) {
    commit('marketIndex', data)
  },
}
